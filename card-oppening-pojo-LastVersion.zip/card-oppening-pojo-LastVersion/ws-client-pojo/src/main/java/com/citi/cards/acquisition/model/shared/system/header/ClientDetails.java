
package com.citi.cards.acquisition.model.shared.system.header;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ClientDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ClientDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Org" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OrgUnit" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ChannelID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TerminalID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ClientIPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SrcCountryCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DestCountryCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UserDomicileBranchCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserDomicileResponsibilityCentre" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProcessingBranchCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProcessingResponsibilityCentre" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SessionLanguageCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientDetails", propOrder = {
    "org",
    "orgUnit",
    "channelID",
    "terminalID",
    "clientIPAddress",
    "userID",
    "srcCountryCode",
    "destCountryCode",
    "userDomicileBranchCode",
    "userDomicileResponsibilityCentre",
    "processingBranchCode",
    "processingResponsibilityCentre",
    "userGroup",
    "sessionLanguageCode"
})
public class ClientDetails {

    @XmlElement(name = "Org", required = true)
    protected String org;
    @XmlElement(name = "OrgUnit", required = true)
    protected String orgUnit;
    @XmlElement(name = "ChannelID", required = true)
    protected String channelID;
    @XmlElement(name = "TerminalID", required = true)
    protected String terminalID;
    @XmlElement(name = "ClientIPAddress")
    protected String clientIPAddress;
    @XmlElement(name = "UserID", required = true)
    protected String userID;
    @XmlElement(name = "SrcCountryCode", required = true)
    protected String srcCountryCode;
    @XmlElement(name = "DestCountryCode", required = true)
    protected String destCountryCode;
    @XmlElement(name = "UserDomicileBranchCode")
    protected String userDomicileBranchCode;
    @XmlElement(name = "UserDomicileResponsibilityCentre")
    protected String userDomicileResponsibilityCentre;
    @XmlElement(name = "ProcessingBranchCode")
    protected String processingBranchCode;
    @XmlElement(name = "ProcessingResponsibilityCentre")
    protected String processingResponsibilityCentre;
    @XmlElement(name = "UserGroup")
    protected String userGroup;
    @XmlElement(name = "SessionLanguageCode")
    protected String sessionLanguageCode;

    /**
     * Obtiene el valor de la propiedad org.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrg() {
        return org;
    }

    /**
     * Define el valor de la propiedad org.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrg(String value) {
        this.org = value;
    }

    /**
     * Obtiene el valor de la propiedad orgUnit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgUnit() {
        return orgUnit;
    }

    /**
     * Define el valor de la propiedad orgUnit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgUnit(String value) {
        this.orgUnit = value;
    }

    /**
     * Obtiene el valor de la propiedad channelID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelID() {
        return channelID;
    }

    /**
     * Define el valor de la propiedad channelID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelID(String value) {
        this.channelID = value;
    }

    /**
     * Obtiene el valor de la propiedad terminalID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTerminalID() {
        return terminalID;
    }

    /**
     * Define el valor de la propiedad terminalID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTerminalID(String value) {
        this.terminalID = value;
    }

    /**
     * Obtiene el valor de la propiedad clientIPAddress.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientIPAddress() {
        return clientIPAddress;
    }

    /**
     * Define el valor de la propiedad clientIPAddress.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientIPAddress(String value) {
        this.clientIPAddress = value;
    }

    /**
     * Obtiene el valor de la propiedad userID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Define el valor de la propiedad userID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

    /**
     * Obtiene el valor de la propiedad srcCountryCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcCountryCode() {
        return srcCountryCode;
    }

    /**
     * Define el valor de la propiedad srcCountryCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcCountryCode(String value) {
        this.srcCountryCode = value;
    }

    /**
     * Obtiene el valor de la propiedad destCountryCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestCountryCode() {
        return destCountryCode;
    }

    /**
     * Define el valor de la propiedad destCountryCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestCountryCode(String value) {
        this.destCountryCode = value;
    }

    /**
     * Obtiene el valor de la propiedad userDomicileBranchCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserDomicileBranchCode() {
        return userDomicileBranchCode;
    }

    /**
     * Define el valor de la propiedad userDomicileBranchCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserDomicileBranchCode(String value) {
        this.userDomicileBranchCode = value;
    }

    /**
     * Obtiene el valor de la propiedad userDomicileResponsibilityCentre.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserDomicileResponsibilityCentre() {
        return userDomicileResponsibilityCentre;
    }

    /**
     * Define el valor de la propiedad userDomicileResponsibilityCentre.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserDomicileResponsibilityCentre(String value) {
        this.userDomicileResponsibilityCentre = value;
    }

    /**
     * Obtiene el valor de la propiedad processingBranchCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessingBranchCode() {
        return processingBranchCode;
    }

    /**
     * Define el valor de la propiedad processingBranchCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessingBranchCode(String value) {
        this.processingBranchCode = value;
    }

    /**
     * Obtiene el valor de la propiedad processingResponsibilityCentre.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessingResponsibilityCentre() {
        return processingResponsibilityCentre;
    }

    /**
     * Define el valor de la propiedad processingResponsibilityCentre.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessingResponsibilityCentre(String value) {
        this.processingResponsibilityCentre = value;
    }

    /**
     * Obtiene el valor de la propiedad userGroup.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserGroup() {
        return userGroup;
    }

    /**
     * Define el valor de la propiedad userGroup.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserGroup(String value) {
        this.userGroup = value;
    }

    /**
     * Obtiene el valor de la propiedad sessionLanguageCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionLanguageCode() {
        return sessionLanguageCode;
    }

    /**
     * Define el valor de la propiedad sessionLanguageCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionLanguageCode(String value) {
        this.sessionLanguageCode = value;
    }

}
