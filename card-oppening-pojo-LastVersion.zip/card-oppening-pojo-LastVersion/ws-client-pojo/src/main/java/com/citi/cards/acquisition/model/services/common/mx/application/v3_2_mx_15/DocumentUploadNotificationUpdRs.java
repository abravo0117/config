
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.GenericResponse;

/**
 * <p>
 * Clase Java para DocumentUploadNotificationUpdRs complex type.
 * 
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DocumentUploadNotificationUpdRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="System" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ServiceOperationName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "DocumentUploadNotificationUpdRs",
    namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_7")
@XmlType(name = "", propOrder = {"system", "serviceOperationName", "status"})
public class DocumentUploadNotificationUpdRs extends GenericResponse {

    @XmlElement(name = "System", required = true,
        namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_7")
    protected String system;

    @XmlElement(name = "ServiceOperationName", required = true,
        namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_7")
    protected String serviceOperationName;

    @XmlElement(name = "Status",
        namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_7")
    protected String status;

    /**
     * Obtiene el valor de la propiedad system.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getSystem() {

        return system;
    }

    /**
     * Define el valor de la propiedad system.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setSystem(String value) {

        this.system = value;
    }

    /**
     * Obtiene el valor de la propiedad serviceOperationName.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getServiceOperationName() {

        return serviceOperationName;
    }

    /**
     * Define el valor de la propiedad serviceOperationName.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setServiceOperationName(String value) {

        this.serviceOperationName = value;
    }

    /**
     * Obtiene el valor de la propiedad status.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getStatus() {

        return status;
    }

    /**
     * Define el valor de la propiedad status.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setStatus(String value) {

        this.status = value;
    }

}
