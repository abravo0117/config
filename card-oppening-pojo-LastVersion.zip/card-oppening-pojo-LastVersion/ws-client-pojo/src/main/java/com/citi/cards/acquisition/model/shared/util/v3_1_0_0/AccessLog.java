
package com.citi.cards.acquisition.model.shared.util.v3_1_0_0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para AccessLog complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="AccessLog">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ProcessingAccountOfficerCode" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}AccountOfficerCode" minOccurs="0"/>
 *         &lt;element name="AccessLogFunctionID" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}AccessLogFunctionID"/>
 *         &lt;choice>
 *           &lt;element name="RelationshipKey" type="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}RelationshipKey"/>
 *           &lt;element name="AccountKey" type="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}AccountKey"/>
 *           &lt;element name="CitiCardKey" type="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}CitiCardKey"/>
 *           &lt;element name="CustomerKey" type="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}CustomerKey"/>
 *         &lt;/choice>
 *         &lt;element name="ProductCode" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}ProductCode" minOccurs="0"/>
 *         &lt;element name="CustomerKeyInContext" type="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}CustomerKey" minOccurs="0"/>
 *         &lt;element name="CustomerDomicileBranchCode" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}BranchCode" minOccurs="0"/>
 *         &lt;element name="CustomerType" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}CustomerType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccessLog", propOrder = {
    "processingAccountOfficerCode",
    "accessLogFunctionID",
    "relationshipKey",
    "accountKey",
    "citiCardKey",
    "customerKey",
    "productCode",
    "customerKeyInContext",
    "customerDomicileBranchCode",
    "customerType"
})
public class AccessLog {

    @XmlElement(name = "ProcessingAccountOfficerCode")
    protected String processingAccountOfficerCode;
    @XmlElement(name = "AccessLogFunctionID", required = true)
    protected String accessLogFunctionID;
    @XmlElement(name = "RelationshipKey")
    protected RelationshipKey relationshipKey;
    @XmlElement(name = "AccountKey")
    protected AccountKey accountKey;
    @XmlElement(name = "CitiCardKey")
    protected CitiCardKey citiCardKey;
    @XmlElement(name = "CustomerKey")
    protected CustomerKey customerKey;
    @XmlElement(name = "ProductCode")
    protected String productCode;
    @XmlElement(name = "CustomerKeyInContext")
    protected CustomerKey customerKeyInContext;
    @XmlElement(name = "CustomerDomicileBranchCode")
    protected String customerDomicileBranchCode;
    @XmlElement(name = "CustomerType")
    protected String customerType;

    /**
     * Obtiene el valor de la propiedad processingAccountOfficerCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessingAccountOfficerCode() {
        return processingAccountOfficerCode;
    }

    /**
     * Define el valor de la propiedad processingAccountOfficerCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessingAccountOfficerCode(String value) {
        this.processingAccountOfficerCode = value;
    }

    /**
     * Obtiene el valor de la propiedad accessLogFunctionID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccessLogFunctionID() {
        return accessLogFunctionID;
    }

    /**
     * Define el valor de la propiedad accessLogFunctionID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccessLogFunctionID(String value) {
        this.accessLogFunctionID = value;
    }

    /**
     * Obtiene el valor de la propiedad relationshipKey.
     * 
     * @return
     *     possible object is
     *     {@link RelationshipKey }
     *     
     */
    public RelationshipKey getRelationshipKey() {
        return relationshipKey;
    }

    /**
     * Define el valor de la propiedad relationshipKey.
     * 
     * @param value
     *     allowed object is
     *     {@link RelationshipKey }
     *     
     */
    public void setRelationshipKey(RelationshipKey value) {
        this.relationshipKey = value;
    }

    /**
     * Obtiene el valor de la propiedad accountKey.
     * 
     * @return
     *     possible object is
     *     {@link AccountKey }
     *     
     */
    public AccountKey getAccountKey() {
        return accountKey;
    }

    /**
     * Define el valor de la propiedad accountKey.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountKey }
     *     
     */
    public void setAccountKey(AccountKey value) {
        this.accountKey = value;
    }

    /**
     * Obtiene el valor de la propiedad citiCardKey.
     * 
     * @return
     *     possible object is
     *     {@link CitiCardKey }
     *     
     */
    public CitiCardKey getCitiCardKey() {
        return citiCardKey;
    }

    /**
     * Define el valor de la propiedad citiCardKey.
     * 
     * @param value
     *     allowed object is
     *     {@link CitiCardKey }
     *     
     */
    public void setCitiCardKey(CitiCardKey value) {
        this.citiCardKey = value;
    }

    /**
     * Obtiene el valor de la propiedad customerKey.
     * 
     * @return
     *     possible object is
     *     {@link CustomerKey }
     *     
     */
    public CustomerKey getCustomerKey() {
        return customerKey;
    }

    /**
     * Define el valor de la propiedad customerKey.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerKey }
     *     
     */
    public void setCustomerKey(CustomerKey value) {
        this.customerKey = value;
    }

    /**
     * Obtiene el valor de la propiedad productCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCode() {
        return productCode;
    }

    /**
     * Define el valor de la propiedad productCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCode(String value) {
        this.productCode = value;
    }

    /**
     * Obtiene el valor de la propiedad customerKeyInContext.
     * 
     * @return
     *     possible object is
     *     {@link CustomerKey }
     *     
     */
    public CustomerKey getCustomerKeyInContext() {
        return customerKeyInContext;
    }

    /**
     * Define el valor de la propiedad customerKeyInContext.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerKey }
     *     
     */
    public void setCustomerKeyInContext(CustomerKey value) {
        this.customerKeyInContext = value;
    }

    /**
     * Obtiene el valor de la propiedad customerDomicileBranchCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerDomicileBranchCode() {
        return customerDomicileBranchCode;
    }

    /**
     * Define el valor de la propiedad customerDomicileBranchCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerDomicileBranchCode(String value) {
        this.customerDomicileBranchCode = value;
    }

    /**
     * Obtiene el valor de la propiedad customerType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerType() {
        return customerType;
    }

    /**
     * Define el valor de la propiedad customerType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerType(String value) {
        this.customerType = value;
    }

}
