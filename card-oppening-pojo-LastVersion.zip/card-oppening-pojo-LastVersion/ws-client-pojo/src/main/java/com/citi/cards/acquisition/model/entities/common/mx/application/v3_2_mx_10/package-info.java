@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;
