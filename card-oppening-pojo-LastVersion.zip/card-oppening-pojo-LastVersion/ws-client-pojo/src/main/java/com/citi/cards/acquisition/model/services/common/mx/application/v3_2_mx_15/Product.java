
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Product complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Product">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ProductClass" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="KnowledgeFlag" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ExperienceFlag" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Product", propOrder = {
    "productClass",
    "knowledgeFlag",
    "experienceFlag"
})
public class Product {

    @XmlElement(name = "ProductClass", required = true)
    protected String productClass;
    @XmlElement(name = "KnowledgeFlag")
    protected boolean knowledgeFlag;
    @XmlElement(name = "ExperienceFlag")
    protected boolean experienceFlag;

    /**
     * Obtiene el valor de la propiedad productClass.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductClass() {
        return productClass;
    }

    /**
     * Define el valor de la propiedad productClass.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductClass(String value) {
        this.productClass = value;
    }

    /**
     * Obtiene el valor de la propiedad knowledgeFlag.
     * 
     */
    public boolean isKnowledgeFlag() {
        return knowledgeFlag;
    }

    /**
     * Define el valor de la propiedad knowledgeFlag.
     * 
     */
    public void setKnowledgeFlag(boolean value) {
        this.knowledgeFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad experienceFlag.
     * 
     */
    public boolean isExperienceFlag() {
        return experienceFlag;
    }

    /**
     * Define el valor de la propiedad experienceFlag.
     * 
     */
    public void setExperienceFlag(boolean value) {
        this.experienceFlag = value;
    }

}
