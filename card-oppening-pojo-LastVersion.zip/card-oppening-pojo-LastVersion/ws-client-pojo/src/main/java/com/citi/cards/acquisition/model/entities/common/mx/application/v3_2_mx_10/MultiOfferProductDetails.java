
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para MultiOfferProductDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="MultiOfferProductDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SequenceNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MinimumCreditLine" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MaximumCreditLine" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LoanTerm" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MonthlyPaymentAmount" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Rate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PromoInterestRate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PromoRatePeriod" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OpeningFee" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MultiOfferProductDetails", propOrder = {
    "sequenceNo",
    "minimumCreditLine",
    "maximumCreditLine",
    "loanTerm",
    "monthlyPaymentAmount",
    "rate",
    "promoInterestRate",
    "promoRatePeriod",
    "openingFee"
})
public class MultiOfferProductDetails {

    @XmlElement(name = "SequenceNo", required = true)
    protected String sequenceNo;
    @XmlElement(name = "MinimumCreditLine", required = true)
    protected String minimumCreditLine;
    @XmlElement(name = "MaximumCreditLine", required = true)
    protected String maximumCreditLine;
    @XmlElement(name = "LoanTerm", required = true)
    protected String loanTerm;
    @XmlElement(name = "MonthlyPaymentAmount", required = true)
    protected String monthlyPaymentAmount;
    @XmlElement(name = "Rate", required = true)
    protected String rate;
    @XmlElement(name = "PromoInterestRate", required = true)
    protected String promoInterestRate;
    @XmlElement(name = "PromoRatePeriod", required = true)
    protected String promoRatePeriod;
    @XmlElement(name = "OpeningFee", required = true)
    protected String openingFee;

    /**
     * Obtiene el valor de la propiedad sequenceNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSequenceNo() {
        return sequenceNo;
    }

    /**
     * Define el valor de la propiedad sequenceNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSequenceNo(String value) {
        this.sequenceNo = value;
    }

    /**
     * Obtiene el valor de la propiedad minimumCreditLine.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMinimumCreditLine() {
        return minimumCreditLine;
    }

    /**
     * Define el valor de la propiedad minimumCreditLine.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMinimumCreditLine(String value) {
        this.minimumCreditLine = value;
    }

    /**
     * Obtiene el valor de la propiedad maximumCreditLine.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaximumCreditLine() {
        return maximumCreditLine;
    }

    /**
     * Define el valor de la propiedad maximumCreditLine.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaximumCreditLine(String value) {
        this.maximumCreditLine = value;
    }

    /**
     * Obtiene el valor de la propiedad loanTerm.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanTerm() {
        return loanTerm;
    }

    /**
     * Define el valor de la propiedad loanTerm.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanTerm(String value) {
        this.loanTerm = value;
    }

    /**
     * Obtiene el valor de la propiedad monthlyPaymentAmount.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMonthlyPaymentAmount() {
        return monthlyPaymentAmount;
    }

    /**
     * Define el valor de la propiedad monthlyPaymentAmount.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMonthlyPaymentAmount(String value) {
        this.monthlyPaymentAmount = value;
    }

    /**
     * Obtiene el valor de la propiedad rate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRate() {
        return rate;
    }

    /**
     * Define el valor de la propiedad rate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRate(String value) {
        this.rate = value;
    }

    /**
     * Obtiene el valor de la propiedad promoInterestRate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPromoInterestRate() {
        return promoInterestRate;
    }

    /**
     * Define el valor de la propiedad promoInterestRate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPromoInterestRate(String value) {
        this.promoInterestRate = value;
    }

    /**
     * Obtiene el valor de la propiedad promoRatePeriod.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPromoRatePeriod() {
        return promoRatePeriod;
    }

    /**
     * Define el valor de la propiedad promoRatePeriod.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPromoRatePeriod(String value) {
        this.promoRatePeriod = value;
    }

    /**
     * Obtiene el valor de la propiedad openingFee.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeningFee() {
        return openingFee;
    }

    /**
     * Define el valor de la propiedad openingFee.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeningFee(String value) {
        this.openingFee = value;
    }

}
