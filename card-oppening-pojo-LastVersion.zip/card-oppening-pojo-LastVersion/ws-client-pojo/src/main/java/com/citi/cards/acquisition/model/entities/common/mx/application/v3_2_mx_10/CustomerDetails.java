
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CustomerKey" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerKey" minOccurs="0"/>
 *         &lt;element name="CustomerBasicData" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerBasicData" minOccurs="0"/>
 *         &lt;element name="CustomerIDDetailsList" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerIDDetailsList" minOccurs="0"/>
 *         &lt;element name="CustomerAddressDetailsList" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerAddressDetailsList" minOccurs="0"/>
 *         &lt;element name="CustomerBankInfo" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerBankInfo" minOccurs="0"/>
 *         &lt;element name="CustomerCostCenterDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerCostCenterDetails" minOccurs="0"/>
 *         &lt;element name="CustomerEmailAddrList" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerEmailAddrList" minOccurs="0"/>
 *         &lt;element name="CustomerEmploymentDetailsList" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerEmploymentDetailsList" minOccurs="0"/>
 *         &lt;element name="CustomerKYCDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerKYCDetails" minOccurs="0"/>
 *         &lt;element name="CustomerPhoneDetailsList" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerPhoneDetailsList" minOccurs="0"/>
 *         &lt;element name="CustomerAdditionalDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerAdditionalDetails" minOccurs="0"/>
 *         &lt;element name="CustomerSignatureDetailsList" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerSignatureDetailsList" minOccurs="0"/>
 *         &lt;element name="CustomerDocumentDetailsList" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerDocumentDetailsList" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerDetails", propOrder = {
    "customerKey",
    "customerBasicData",
    "customerIDDetailsList",
    "customerAddressDetailsList",
    "customerBankInfo",
    "customerCostCenterDetails",
    "customerEmailAddrList",
    "customerEmploymentDetailsList",
    "customerKYCDetails",
    "customerPhoneDetailsList",
    "customerAdditionalDetails",
    "customerSignatureDetailsList",
    "customerDocumentDetailsList"
})
public class CustomerDetails {

    @XmlElement(name = "CustomerKey")
    protected CustomerKey customerKey;
    @XmlElement(name = "CustomerBasicData")
    protected CustomerBasicData customerBasicData;
    @XmlElement(name = "CustomerIDDetailsList")
    protected CustomerIDDetailsList customerIDDetailsList;
    @XmlElement(name = "CustomerAddressDetailsList")
    protected CustomerAddressDetailsList customerAddressDetailsList;
    @XmlElement(name = "CustomerBankInfo")
    protected CustomerBankInfo customerBankInfo;
    @XmlElement(name = "CustomerCostCenterDetails")
    protected CustomerCostCenterDetails customerCostCenterDetails;
    @XmlElement(name = "CustomerEmailAddrList")
    protected CustomerEmailAddrList customerEmailAddrList;
    @XmlElement(name = "CustomerEmploymentDetailsList")
    protected CustomerEmploymentDetailsList customerEmploymentDetailsList;
    @XmlElement(name = "CustomerKYCDetails")
    protected CustomerKYCDetails customerKYCDetails;
    @XmlElement(name = "CustomerPhoneDetailsList")
    protected CustomerPhoneDetailsList customerPhoneDetailsList;
    @XmlElement(name = "CustomerAdditionalDetails")
    protected CustomerAdditionalDetails customerAdditionalDetails;
    @XmlElement(name = "CustomerSignatureDetailsList")
    protected CustomerSignatureDetailsList customerSignatureDetailsList;
    @XmlElement(name = "CustomerDocumentDetailsList")
    protected CustomerDocumentDetailsList customerDocumentDetailsList;

    /**
     * Obtiene el valor de la propiedad customerKey.
     * 
     * @return
     *     possible object is
     *     {@link CustomerKey }
     *     
     */
    public CustomerKey getCustomerKey() {
        return customerKey;
    }

    /**
     * Define el valor de la propiedad customerKey.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerKey }
     *     
     */
    public void setCustomerKey(CustomerKey value) {
        this.customerKey = value;
    }

    /**
     * Obtiene el valor de la propiedad customerBasicData.
     * 
     * @return
     *     possible object is
     *     {@link CustomerBasicData }
     *     
     */
    public CustomerBasicData getCustomerBasicData() {
        return customerBasicData;
    }

    /**
     * Define el valor de la propiedad customerBasicData.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerBasicData }
     *     
     */
    public void setCustomerBasicData(CustomerBasicData value) {
        this.customerBasicData = value;
    }

    /**
     * Obtiene el valor de la propiedad customerIDDetailsList.
     * 
     * @return
     *     possible object is
     *     {@link CustomerIDDetailsList }
     *     
     */
    public CustomerIDDetailsList getCustomerIDDetailsList() {
        return customerIDDetailsList;
    }

    /**
     * Define el valor de la propiedad customerIDDetailsList.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerIDDetailsList }
     *     
     */
    public void setCustomerIDDetailsList(CustomerIDDetailsList value) {
        this.customerIDDetailsList = value;
    }

    /**
     * Obtiene el valor de la propiedad customerAddressDetailsList.
     * 
     * @return
     *     possible object is
     *     {@link CustomerAddressDetailsList }
     *     
     */
    public CustomerAddressDetailsList getCustomerAddressDetailsList() {
        return customerAddressDetailsList;
    }

    /**
     * Define el valor de la propiedad customerAddressDetailsList.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerAddressDetailsList }
     *     
     */
    public void setCustomerAddressDetailsList(CustomerAddressDetailsList value) {
        this.customerAddressDetailsList = value;
    }

    /**
     * Obtiene el valor de la propiedad customerBankInfo.
     * 
     * @return
     *     possible object is
     *     {@link CustomerBankInfo }
     *     
     */
    public CustomerBankInfo getCustomerBankInfo() {
        return customerBankInfo;
    }

    /**
     * Define el valor de la propiedad customerBankInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerBankInfo }
     *     
     */
    public void setCustomerBankInfo(CustomerBankInfo value) {
        this.customerBankInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad customerCostCenterDetails.
     * 
     * @return
     *     possible object is
     *     {@link CustomerCostCenterDetails }
     *     
     */
    public CustomerCostCenterDetails getCustomerCostCenterDetails() {
        return customerCostCenterDetails;
    }

    /**
     * Define el valor de la propiedad customerCostCenterDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerCostCenterDetails }
     *     
     */
    public void setCustomerCostCenterDetails(CustomerCostCenterDetails value) {
        this.customerCostCenterDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad customerEmailAddrList.
     * 
     * @return
     *     possible object is
     *     {@link CustomerEmailAddrList }
     *     
     */
    public CustomerEmailAddrList getCustomerEmailAddrList() {
        return customerEmailAddrList;
    }

    /**
     * Define el valor de la propiedad customerEmailAddrList.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerEmailAddrList }
     *     
     */
    public void setCustomerEmailAddrList(CustomerEmailAddrList value) {
        this.customerEmailAddrList = value;
    }

    /**
     * Obtiene el valor de la propiedad customerEmploymentDetailsList.
     * 
     * @return
     *     possible object is
     *     {@link CustomerEmploymentDetailsList }
     *     
     */
    public CustomerEmploymentDetailsList getCustomerEmploymentDetailsList() {
        return customerEmploymentDetailsList;
    }

    /**
     * Define el valor de la propiedad customerEmploymentDetailsList.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerEmploymentDetailsList }
     *     
     */
    public void setCustomerEmploymentDetailsList(CustomerEmploymentDetailsList value) {
        this.customerEmploymentDetailsList = value;
    }

    /**
     * Obtiene el valor de la propiedad customerKYCDetails.
     * 
     * @return
     *     possible object is
     *     {@link CustomerKYCDetails }
     *     
     */
    public CustomerKYCDetails getCustomerKYCDetails() {
        return customerKYCDetails;
    }

    /**
     * Define el valor de la propiedad customerKYCDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerKYCDetails }
     *     
     */
    public void setCustomerKYCDetails(CustomerKYCDetails value) {
        this.customerKYCDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad customerPhoneDetailsList.
     * 
     * @return
     *     possible object is
     *     {@link CustomerPhoneDetailsList }
     *     
     */
    public CustomerPhoneDetailsList getCustomerPhoneDetailsList() {
        return customerPhoneDetailsList;
    }

    /**
     * Define el valor de la propiedad customerPhoneDetailsList.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerPhoneDetailsList }
     *     
     */
    public void setCustomerPhoneDetailsList(CustomerPhoneDetailsList value) {
        this.customerPhoneDetailsList = value;
    }

    /**
     * Obtiene el valor de la propiedad customerAdditionalDetails.
     * 
     * @return
     *     possible object is
     *     {@link CustomerAdditionalDetails }
     *     
     */
    public CustomerAdditionalDetails getCustomerAdditionalDetails() {
        return customerAdditionalDetails;
    }

    /**
     * Define el valor de la propiedad customerAdditionalDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerAdditionalDetails }
     *     
     */
    public void setCustomerAdditionalDetails(CustomerAdditionalDetails value) {
        this.customerAdditionalDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad customerSignatureDetailsList.
     * 
     * @return
     *     possible object is
     *     {@link CustomerSignatureDetailsList }
     *     
     */
    public CustomerSignatureDetailsList getCustomerSignatureDetailsList() {
        return customerSignatureDetailsList;
    }

    /**
     * Define el valor de la propiedad customerSignatureDetailsList.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerSignatureDetailsList }
     *     
     */
    public void setCustomerSignatureDetailsList(CustomerSignatureDetailsList value) {
        this.customerSignatureDetailsList = value;
    }

    /**
     * Obtiene el valor de la propiedad customerDocumentDetailsList.
     * 
     * @return
     *     possible object is
     *     {@link CustomerDocumentDetailsList }
     *     
     */
    public CustomerDocumentDetailsList getCustomerDocumentDetailsList() {
        return customerDocumentDetailsList;
    }

    /**
     * Define el valor de la propiedad customerDocumentDetailsList.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerDocumentDetailsList }
     *     
     */
    public void setCustomerDocumentDetailsList(CustomerDocumentDetailsList value) {
        this.customerDocumentDetailsList = value;
    }

}
