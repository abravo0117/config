
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CASADetail complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CASADetail">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OfferKey" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}OfferKey" minOccurs="0"/>
 *         &lt;element name="AcctNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustomerServices" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerServices" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CheckBook" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CheckBook" minOccurs="0"/>
 *         &lt;element name="SweepTDPrdCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SweepPrdDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CASADetail", propOrder = {
    "offerKey",
    "acctNo",
    "customerServices",
    "checkBook",
    "sweepTDPrdCD",
    "sweepPrdDesc"
})
public class CASADetail {

    @XmlElement(name = "OfferKey")
    protected OfferKey offerKey;
    @XmlElement(name = "AcctNo")
    protected String acctNo;
    @XmlElement(name = "CustomerServices")
    protected List<CustomerServices> customerServices;
    @XmlElement(name = "CheckBook")
    protected CheckBook checkBook;
    @XmlElement(name = "SweepTDPrdCD")
    protected String sweepTDPrdCD;
    @XmlElement(name = "SweepPrdDesc")
    protected String sweepPrdDesc;

    /**
     * Obtiene el valor de la propiedad offerKey.
     * 
     * @return
     *     possible object is
     *     {@link OfferKey }
     *     
     */
    public OfferKey getOfferKey() {
        return offerKey;
    }

    /**
     * Define el valor de la propiedad offerKey.
     * 
     * @param value
     *     allowed object is
     *     {@link OfferKey }
     *     
     */
    public void setOfferKey(OfferKey value) {
        this.offerKey = value;
    }

    /**
     * Obtiene el valor de la propiedad acctNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctNo() {
        return acctNo;
    }

    /**
     * Define el valor de la propiedad acctNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctNo(String value) {
        this.acctNo = value;
    }

    /**
     * Gets the value of the customerServices property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customerServices property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomerServices().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CustomerServices }
     * 
     * 
     */
    public List<CustomerServices> getCustomerServices() {
        if (customerServices == null) {
            customerServices = new ArrayList<CustomerServices>();
        }
        return this.customerServices;
    }

    /**
     * Obtiene el valor de la propiedad checkBook.
     * 
     * @return
     *     possible object is
     *     {@link CheckBook }
     *     
     */
    public CheckBook getCheckBook() {
        return checkBook;
    }

    /**
     * Define el valor de la propiedad checkBook.
     * 
     * @param value
     *     allowed object is
     *     {@link CheckBook }
     *     
     */
    public void setCheckBook(CheckBook value) {
        this.checkBook = value;
    }

    /**
     * Obtiene el valor de la propiedad sweepTDPrdCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSweepTDPrdCD() {
        return sweepTDPrdCD;
    }

    /**
     * Define el valor de la propiedad sweepTDPrdCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSweepTDPrdCD(String value) {
        this.sweepTDPrdCD = value;
    }

    /**
     * Obtiene el valor de la propiedad sweepPrdDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSweepPrdDesc() {
        return sweepPrdDesc;
    }

    /**
     * Define el valor de la propiedad sweepPrdDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSweepPrdDesc(String value) {
        this.sweepPrdDesc = value;
    }

}
