
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CitiClearDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CitiClearDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ParentTitle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ParentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PArentNric" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PArentPhCtryCd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ParentPhArea" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ParentPhNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CitiClearDetails", propOrder = {
    "parentTitle",
    "parentName",
    "pArentNric",
    "pArentPhCtryCd",
    "parentPhArea",
    "parentPhNo"
})
public class CitiClearDetails {

    @XmlElement(name = "ParentTitle")
    protected String parentTitle;
    @XmlElement(name = "ParentName")
    protected String parentName;
    @XmlElement(name = "PArentNric")
    protected String pArentNric;
    @XmlElement(name = "PArentPhCtryCd")
    protected String pArentPhCtryCd;
    @XmlElement(name = "ParentPhArea")
    protected String parentPhArea;
    @XmlElement(name = "ParentPhNo")
    protected String parentPhNo;

    /**
     * Obtiene el valor de la propiedad parentTitle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentTitle() {
        return parentTitle;
    }

    /**
     * Define el valor de la propiedad parentTitle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentTitle(String value) {
        this.parentTitle = value;
    }

    /**
     * Obtiene el valor de la propiedad parentName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentName() {
        return parentName;
    }

    /**
     * Define el valor de la propiedad parentName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentName(String value) {
        this.parentName = value;
    }

    /**
     * Obtiene el valor de la propiedad pArentNric.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPArentNric() {
        return pArentNric;
    }

    /**
     * Define el valor de la propiedad pArentNric.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPArentNric(String value) {
        this.pArentNric = value;
    }

    /**
     * Obtiene el valor de la propiedad pArentPhCtryCd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPArentPhCtryCd() {
        return pArentPhCtryCd;
    }

    /**
     * Define el valor de la propiedad pArentPhCtryCd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPArentPhCtryCd(String value) {
        this.pArentPhCtryCd = value;
    }

    /**
     * Obtiene el valor de la propiedad parentPhArea.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentPhArea() {
        return parentPhArea;
    }

    /**
     * Define el valor de la propiedad parentPhArea.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentPhArea(String value) {
        this.parentPhArea = value;
    }

    /**
     * Obtiene el valor de la propiedad parentPhNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentPhNo() {
        return parentPhNo;
    }

    /**
     * Define el valor de la propiedad parentPhNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentPhNo(String value) {
        this.parentPhNo = value;
    }

}
