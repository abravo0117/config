
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TPin complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TPin">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TpinReq" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TpinIssueBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PinBlock" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TPin", propOrder = {
    "tpinReq",
    "tpinIssueBy",
    "pinBlock"
})
public class TPin {

    @XmlElement(name = "TpinReq")
    protected String tpinReq;
    @XmlElement(name = "TpinIssueBy")
    protected String tpinIssueBy;
    @XmlElement(name = "PinBlock")
    protected String pinBlock;

    /**
     * Obtiene el valor de la propiedad tpinReq.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTpinReq() {
        return tpinReq;
    }

    /**
     * Define el valor de la propiedad tpinReq.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTpinReq(String value) {
        this.tpinReq = value;
    }

    /**
     * Obtiene el valor de la propiedad tpinIssueBy.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTpinIssueBy() {
        return tpinIssueBy;
    }

    /**
     * Define el valor de la propiedad tpinIssueBy.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTpinIssueBy(String value) {
        this.tpinIssueBy = value;
    }

    /**
     * Obtiene el valor de la propiedad pinBlock.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPinBlock() {
        return pinBlock;
    }

    /**
     * Define el valor de la propiedad pinBlock.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPinBlock(String value) {
        this.pinBlock = value;
    }

}
