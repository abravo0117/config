
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CheckBook complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CheckBook">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ChkBookReq" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkBookStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkFromRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkToRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkCollMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkPickupInstruc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkNoBooks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkAddrRefNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkAutoReorder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkReorderAT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkPersonTitle1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkPersonTitle2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkPersonTitle3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ThirdPartyPick" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SecChkReq" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsInstantChkBk" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReferralCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CheckBook", propOrder = {
    "chkBookReq",
    "chkBookStatus",
    "chkFromRange",
    "chkToRange",
    "chkType",
    "chkCollMode",
    "chkPickupInstruc",
    "chkNoBooks",
    "chkAddrRefNo",
    "chkAutoReorder",
    "chkReorderAT",
    "chkPersonTitle1",
    "chkPersonTitle2",
    "chkPersonTitle3",
    "thirdPartyPick",
    "secChkReq",
    "isInstantChkBk",
    "referralCode"
})
public class CheckBook {

    @XmlElement(name = "ChkBookReq")
    protected String chkBookReq;
    @XmlElement(name = "ChkBookStatus")
    protected String chkBookStatus;
    @XmlElement(name = "ChkFromRange")
    protected String chkFromRange;
    @XmlElement(name = "ChkToRange")
    protected String chkToRange;
    @XmlElement(name = "ChkType")
    protected String chkType;
    @XmlElement(name = "ChkCollMode")
    protected String chkCollMode;
    @XmlElement(name = "ChkPickupInstruc")
    protected String chkPickupInstruc;
    @XmlElement(name = "ChkNoBooks")
    protected String chkNoBooks;
    @XmlElement(name = "ChkAddrRefNo")
    protected String chkAddrRefNo;
    @XmlElement(name = "ChkAutoReorder")
    protected String chkAutoReorder;
    @XmlElement(name = "ChkReorderAT")
    protected String chkReorderAT;
    @XmlElement(name = "ChkPersonTitle1")
    protected String chkPersonTitle1;
    @XmlElement(name = "ChkPersonTitle2")
    protected String chkPersonTitle2;
    @XmlElement(name = "ChkPersonTitle3")
    protected String chkPersonTitle3;
    @XmlElement(name = "ThirdPartyPick")
    protected String thirdPartyPick;
    @XmlElement(name = "SecChkReq")
    protected String secChkReq;
    @XmlElement(name = "IsInstantChkBk")
    protected String isInstantChkBk;
    @XmlElement(name = "ReferralCode")
    protected String referralCode;

    /**
     * Obtiene el valor de la propiedad chkBookReq.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkBookReq() {
        return chkBookReq;
    }

    /**
     * Define el valor de la propiedad chkBookReq.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkBookReq(String value) {
        this.chkBookReq = value;
    }

    /**
     * Obtiene el valor de la propiedad chkBookStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkBookStatus() {
        return chkBookStatus;
    }

    /**
     * Define el valor de la propiedad chkBookStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkBookStatus(String value) {
        this.chkBookStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad chkFromRange.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkFromRange() {
        return chkFromRange;
    }

    /**
     * Define el valor de la propiedad chkFromRange.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkFromRange(String value) {
        this.chkFromRange = value;
    }

    /**
     * Obtiene el valor de la propiedad chkToRange.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkToRange() {
        return chkToRange;
    }

    /**
     * Define el valor de la propiedad chkToRange.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkToRange(String value) {
        this.chkToRange = value;
    }

    /**
     * Obtiene el valor de la propiedad chkType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkType() {
        return chkType;
    }

    /**
     * Define el valor de la propiedad chkType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkType(String value) {
        this.chkType = value;
    }

    /**
     * Obtiene el valor de la propiedad chkCollMode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkCollMode() {
        return chkCollMode;
    }

    /**
     * Define el valor de la propiedad chkCollMode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkCollMode(String value) {
        this.chkCollMode = value;
    }

    /**
     * Obtiene el valor de la propiedad chkPickupInstruc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkPickupInstruc() {
        return chkPickupInstruc;
    }

    /**
     * Define el valor de la propiedad chkPickupInstruc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkPickupInstruc(String value) {
        this.chkPickupInstruc = value;
    }

    /**
     * Obtiene el valor de la propiedad chkNoBooks.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkNoBooks() {
        return chkNoBooks;
    }

    /**
     * Define el valor de la propiedad chkNoBooks.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkNoBooks(String value) {
        this.chkNoBooks = value;
    }

    /**
     * Obtiene el valor de la propiedad chkAddrRefNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkAddrRefNo() {
        return chkAddrRefNo;
    }

    /**
     * Define el valor de la propiedad chkAddrRefNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkAddrRefNo(String value) {
        this.chkAddrRefNo = value;
    }

    /**
     * Obtiene el valor de la propiedad chkAutoReorder.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkAutoReorder() {
        return chkAutoReorder;
    }

    /**
     * Define el valor de la propiedad chkAutoReorder.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkAutoReorder(String value) {
        this.chkAutoReorder = value;
    }

    /**
     * Obtiene el valor de la propiedad chkReorderAT.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkReorderAT() {
        return chkReorderAT;
    }

    /**
     * Define el valor de la propiedad chkReorderAT.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkReorderAT(String value) {
        this.chkReorderAT = value;
    }

    /**
     * Obtiene el valor de la propiedad chkPersonTitle1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkPersonTitle1() {
        return chkPersonTitle1;
    }

    /**
     * Define el valor de la propiedad chkPersonTitle1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkPersonTitle1(String value) {
        this.chkPersonTitle1 = value;
    }

    /**
     * Obtiene el valor de la propiedad chkPersonTitle2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkPersonTitle2() {
        return chkPersonTitle2;
    }

    /**
     * Define el valor de la propiedad chkPersonTitle2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkPersonTitle2(String value) {
        this.chkPersonTitle2 = value;
    }

    /**
     * Obtiene el valor de la propiedad chkPersonTitle3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkPersonTitle3() {
        return chkPersonTitle3;
    }

    /**
     * Define el valor de la propiedad chkPersonTitle3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkPersonTitle3(String value) {
        this.chkPersonTitle3 = value;
    }

    /**
     * Obtiene el valor de la propiedad thirdPartyPick.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getThirdPartyPick() {
        return thirdPartyPick;
    }

    /**
     * Define el valor de la propiedad thirdPartyPick.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setThirdPartyPick(String value) {
        this.thirdPartyPick = value;
    }

    /**
     * Obtiene el valor de la propiedad secChkReq.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecChkReq() {
        return secChkReq;
    }

    /**
     * Define el valor de la propiedad secChkReq.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecChkReq(String value) {
        this.secChkReq = value;
    }

    /**
     * Obtiene el valor de la propiedad isInstantChkBk.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsInstantChkBk() {
        return isInstantChkBk;
    }

    /**
     * Define el valor de la propiedad isInstantChkBk.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsInstantChkBk(String value) {
        this.isInstantChkBk = value;
    }

    /**
     * Obtiene el valor de la propiedad referralCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferralCode() {
        return referralCode;
    }

    /**
     * Define el valor de la propiedad referralCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferralCode(String value) {
        this.referralCode = value;
    }

}
