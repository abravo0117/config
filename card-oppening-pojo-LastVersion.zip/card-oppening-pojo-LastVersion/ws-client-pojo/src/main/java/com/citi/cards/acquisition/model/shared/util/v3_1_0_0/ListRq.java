
package com.citi.cards.acquisition.model.shared.util.v3_1_0_0;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ListRq complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ListRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="StartIndex" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}ListIndex" minOccurs="0"/>
 *         &lt;element name="Size" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}ListSize" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListRq", propOrder = {
    "startIndex",
    "size"
})
public class ListRq {

    @XmlElement(name = "StartIndex")
    protected String startIndex;
    @XmlElement(name = "Size")
    protected BigInteger size;

    /**
     * Obtiene el valor de la propiedad startIndex.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartIndex() {
        return startIndex;
    }

    /**
     * Define el valor de la propiedad startIndex.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartIndex(String value) {
        this.startIndex = value;
    }

    /**
     * Obtiene el valor de la propiedad size.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getSize() {
        return size;
    }

    /**
     * Define el valor de la propiedad size.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setSize(BigInteger value) {
        this.size = value;
    }

}
