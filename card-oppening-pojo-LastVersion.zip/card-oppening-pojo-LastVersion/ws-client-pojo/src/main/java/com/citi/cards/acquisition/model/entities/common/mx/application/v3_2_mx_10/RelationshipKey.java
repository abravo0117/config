
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para RelationshipKey complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="RelationshipKey">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RelationshipNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="InternalCountryCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="RelationshipType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RelationshipKey", propOrder = {
    "relationshipNo",
    "internalCountryCode",
    "relationshipType"
})
public class RelationshipKey {

    @XmlElement(name = "RelationshipNo", required = true)
    protected String relationshipNo;
    @XmlElement(name = "InternalCountryCode", required = true)
    protected String internalCountryCode;
    @XmlElement(name = "RelationshipType")
    protected String relationshipType;

    /**
     * Obtiene el valor de la propiedad relationshipNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipNo() {
        return relationshipNo;
    }

    /**
     * Define el valor de la propiedad relationshipNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipNo(String value) {
        this.relationshipNo = value;
    }

    /**
     * Obtiene el valor de la propiedad internalCountryCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInternalCountryCode() {
        return internalCountryCode;
    }

    /**
     * Define el valor de la propiedad internalCountryCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInternalCountryCode(String value) {
        this.internalCountryCode = value;
    }

    /**
     * Obtiene el valor de la propiedad relationshipType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipType() {
        return relationshipType;
    }

    /**
     * Define el valor de la propiedad relationshipType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipType(String value) {
        this.relationshipType = value;
    }

}
