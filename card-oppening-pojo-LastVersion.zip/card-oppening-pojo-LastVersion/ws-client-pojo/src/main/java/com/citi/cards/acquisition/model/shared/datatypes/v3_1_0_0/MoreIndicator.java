
package com.citi.cards.acquisition.model.shared.datatypes.v3_1_0_0;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para MoreIndicator.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * <p>
 * <pre>
 * &lt;simpleType name="MoreIndicator">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="Y"/>
 *     &lt;enumeration value="N"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "MoreIndicator")
@XmlEnum
public enum MoreIndicator {

    Y,
    N;

    public String value() {
        return name();
    }

    public static MoreIndicator fromValue(String v) {
        return valueOf(v);
    }

}
