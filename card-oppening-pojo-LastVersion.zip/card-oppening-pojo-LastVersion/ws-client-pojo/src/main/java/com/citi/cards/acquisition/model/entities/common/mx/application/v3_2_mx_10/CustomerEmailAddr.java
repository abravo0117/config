
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerEmailAddr complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerEmailAddr">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="EmailAddr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailTypCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailRefNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OkToEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailPrefInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailInvalidFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerEmailAddr", propOrder = {
    "seqNo",
    "emailAddr",
    "emailTypCD",
    "emailRefNo",
    "okToEmail",
    "emailPrefInd",
    "emailInvalidFlag"
})
public class CustomerEmailAddr {

    @XmlElement(name = "SeqNo", required = true)
    protected String seqNo;
    @XmlElement(name = "EmailAddr")
    protected String emailAddr;
    @XmlElement(name = "EmailTypCD")
    protected String emailTypCD;
    @XmlElement(name = "EmailRefNo")
    protected String emailRefNo;
    @XmlElement(name = "OkToEmail")
    protected String okToEmail;
    @XmlElement(name = "EmailPrefInd")
    protected String emailPrefInd;
    @XmlElement(name = "EmailInvalidFlag")
    protected String emailInvalidFlag;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad emailAddr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddr() {
        return emailAddr;
    }

    /**
     * Define el valor de la propiedad emailAddr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddr(String value) {
        this.emailAddr = value;
    }

    /**
     * Obtiene el valor de la propiedad emailTypCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailTypCD() {
        return emailTypCD;
    }

    /**
     * Define el valor de la propiedad emailTypCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailTypCD(String value) {
        this.emailTypCD = value;
    }

    /**
     * Obtiene el valor de la propiedad emailRefNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailRefNo() {
        return emailRefNo;
    }

    /**
     * Define el valor de la propiedad emailRefNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailRefNo(String value) {
        this.emailRefNo = value;
    }

    /**
     * Obtiene el valor de la propiedad okToEmail.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOkToEmail() {
        return okToEmail;
    }

    /**
     * Define el valor de la propiedad okToEmail.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOkToEmail(String value) {
        this.okToEmail = value;
    }

    /**
     * Obtiene el valor de la propiedad emailPrefInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailPrefInd() {
        return emailPrefInd;
    }

    /**
     * Define el valor de la propiedad emailPrefInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailPrefInd(String value) {
        this.emailPrefInd = value;
    }

    /**
     * Obtiene el valor de la propiedad emailInvalidFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailInvalidFlag() {
        return emailInvalidFlag;
    }

    /**
     * Define el valor de la propiedad emailInvalidFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailInvalidFlag(String value) {
        this.emailInvalidFlag = value;
    }

}
