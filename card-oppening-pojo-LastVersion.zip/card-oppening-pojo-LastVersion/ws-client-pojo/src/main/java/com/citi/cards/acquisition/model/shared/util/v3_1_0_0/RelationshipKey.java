
package com.citi.cards.acquisition.model.shared.util.v3_1_0_0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para RelationshipKey complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="RelationshipKey">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RelationshipNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}RelationshipNo" minOccurs="0"/>
 *         &lt;element name="InternalCountryCode" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}InternalCountryCode" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RelationshipKey", propOrder = {
    "relationshipNo",
    "internalCountryCode"
})
public class RelationshipKey {

    @XmlElement(name = "RelationshipNo")
    protected String relationshipNo;
    @XmlElement(name = "InternalCountryCode")
    protected String internalCountryCode;

    /**
     * Obtiene el valor de la propiedad relationshipNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipNo() {
        return relationshipNo;
    }

    /**
     * Define el valor de la propiedad relationshipNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipNo(String value) {
        this.relationshipNo = value;
    }

    /**
     * Obtiene el valor de la propiedad internalCountryCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInternalCountryCode() {
        return internalCountryCode;
    }

    /**
     * Define el valor de la propiedad internalCountryCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInternalCountryCode(String value) {
        this.internalCountryCode = value;
    }

}
