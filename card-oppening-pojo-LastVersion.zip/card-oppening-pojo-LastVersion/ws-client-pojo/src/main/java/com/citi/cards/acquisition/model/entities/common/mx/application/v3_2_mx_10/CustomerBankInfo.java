
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerBankInfo complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerBankInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BizGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SancInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BlackListInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PFInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SancIndOvrd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BlckLstIndOvrd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PFIndOvrd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NessInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOFReferral" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AcqChannel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AcqUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AcqOfficer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefChannel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefOfficer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CampaignSrcCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GoldToBE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NessToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReferralRemarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CGTLimit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="REMExrefLimit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerBankInfo", propOrder = {
    "bizGroup",
    "sancInd",
    "blackListInd",
    "pfInd",
    "sancIndOvrd",
    "blckLstIndOvrd",
    "pfIndOvrd",
    "nessInd",
    "sofReferral",
    "acqChannel",
    "acqUnit",
    "acqOfficer",
    "refChannel",
    "refUnit",
    "refOfficer",
    "campaignSrcCD",
    "goldToBE",
    "nessToken",
    "referralRemarks",
    "cgtLimit",
    "remExrefLimit"
})
public class CustomerBankInfo {

    @XmlElement(name = "BizGroup")
    protected String bizGroup;
    @XmlElement(name = "SancInd")
    protected String sancInd;
    @XmlElement(name = "BlackListInd")
    protected String blackListInd;
    @XmlElement(name = "PFInd")
    protected String pfInd;
    @XmlElement(name = "SancIndOvrd")
    protected String sancIndOvrd;
    @XmlElement(name = "BlckLstIndOvrd")
    protected String blckLstIndOvrd;
    @XmlElement(name = "PFIndOvrd")
    protected String pfIndOvrd;
    @XmlElement(name = "NessInd")
    protected String nessInd;
    @XmlElement(name = "SOFReferral")
    protected String sofReferral;
    @XmlElement(name = "AcqChannel")
    protected String acqChannel;
    @XmlElement(name = "AcqUnit")
    protected String acqUnit;
    @XmlElement(name = "AcqOfficer")
    protected String acqOfficer;
    @XmlElement(name = "RefChannel")
    protected String refChannel;
    @XmlElement(name = "RefUnit")
    protected String refUnit;
    @XmlElement(name = "RefOfficer")
    protected String refOfficer;
    @XmlElement(name = "CampaignSrcCD")
    protected String campaignSrcCD;
    @XmlElement(name = "GoldToBE")
    protected String goldToBE;
    @XmlElement(name = "NessToken")
    protected String nessToken;
    @XmlElement(name = "ReferralRemarks")
    protected String referralRemarks;
    @XmlElement(name = "CGTLimit")
    protected String cgtLimit;
    @XmlElement(name = "REMExrefLimit")
    protected String remExrefLimit;

    /**
     * Obtiene el valor de la propiedad bizGroup.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBizGroup() {
        return bizGroup;
    }

    /**
     * Define el valor de la propiedad bizGroup.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBizGroup(String value) {
        this.bizGroup = value;
    }

    /**
     * Obtiene el valor de la propiedad sancInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSancInd() {
        return sancInd;
    }

    /**
     * Define el valor de la propiedad sancInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSancInd(String value) {
        this.sancInd = value;
    }

    /**
     * Obtiene el valor de la propiedad blackListInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBlackListInd() {
        return blackListInd;
    }

    /**
     * Define el valor de la propiedad blackListInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBlackListInd(String value) {
        this.blackListInd = value;
    }

    /**
     * Obtiene el valor de la propiedad pfInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPFInd() {
        return pfInd;
    }

    /**
     * Define el valor de la propiedad pfInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPFInd(String value) {
        this.pfInd = value;
    }

    /**
     * Obtiene el valor de la propiedad sancIndOvrd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSancIndOvrd() {
        return sancIndOvrd;
    }

    /**
     * Define el valor de la propiedad sancIndOvrd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSancIndOvrd(String value) {
        this.sancIndOvrd = value;
    }

    /**
     * Obtiene el valor de la propiedad blckLstIndOvrd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBlckLstIndOvrd() {
        return blckLstIndOvrd;
    }

    /**
     * Define el valor de la propiedad blckLstIndOvrd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBlckLstIndOvrd(String value) {
        this.blckLstIndOvrd = value;
    }

    /**
     * Obtiene el valor de la propiedad pfIndOvrd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPFIndOvrd() {
        return pfIndOvrd;
    }

    /**
     * Define el valor de la propiedad pfIndOvrd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPFIndOvrd(String value) {
        this.pfIndOvrd = value;
    }

    /**
     * Obtiene el valor de la propiedad nessInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNessInd() {
        return nessInd;
    }

    /**
     * Define el valor de la propiedad nessInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNessInd(String value) {
        this.nessInd = value;
    }

    /**
     * Obtiene el valor de la propiedad sofReferral.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOFReferral() {
        return sofReferral;
    }

    /**
     * Define el valor de la propiedad sofReferral.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOFReferral(String value) {
        this.sofReferral = value;
    }

    /**
     * Obtiene el valor de la propiedad acqChannel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcqChannel() {
        return acqChannel;
    }

    /**
     * Define el valor de la propiedad acqChannel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcqChannel(String value) {
        this.acqChannel = value;
    }

    /**
     * Obtiene el valor de la propiedad acqUnit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcqUnit() {
        return acqUnit;
    }

    /**
     * Define el valor de la propiedad acqUnit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcqUnit(String value) {
        this.acqUnit = value;
    }

    /**
     * Obtiene el valor de la propiedad acqOfficer.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcqOfficer() {
        return acqOfficer;
    }

    /**
     * Define el valor de la propiedad acqOfficer.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcqOfficer(String value) {
        this.acqOfficer = value;
    }

    /**
     * Obtiene el valor de la propiedad refChannel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefChannel() {
        return refChannel;
    }

    /**
     * Define el valor de la propiedad refChannel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefChannel(String value) {
        this.refChannel = value;
    }

    /**
     * Obtiene el valor de la propiedad refUnit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefUnit() {
        return refUnit;
    }

    /**
     * Define el valor de la propiedad refUnit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefUnit(String value) {
        this.refUnit = value;
    }

    /**
     * Obtiene el valor de la propiedad refOfficer.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefOfficer() {
        return refOfficer;
    }

    /**
     * Define el valor de la propiedad refOfficer.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefOfficer(String value) {
        this.refOfficer = value;
    }

    /**
     * Obtiene el valor de la propiedad campaignSrcCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCampaignSrcCD() {
        return campaignSrcCD;
    }

    /**
     * Define el valor de la propiedad campaignSrcCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCampaignSrcCD(String value) {
        this.campaignSrcCD = value;
    }

    /**
     * Obtiene el valor de la propiedad goldToBE.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGoldToBE() {
        return goldToBE;
    }

    /**
     * Define el valor de la propiedad goldToBE.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGoldToBE(String value) {
        this.goldToBE = value;
    }

    /**
     * Obtiene el valor de la propiedad nessToken.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNessToken() {
        return nessToken;
    }

    /**
     * Define el valor de la propiedad nessToken.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNessToken(String value) {
        this.nessToken = value;
    }

    /**
     * Obtiene el valor de la propiedad referralRemarks.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferralRemarks() {
        return referralRemarks;
    }

    /**
     * Define el valor de la propiedad referralRemarks.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferralRemarks(String value) {
        this.referralRemarks = value;
    }

    /**
     * Obtiene el valor de la propiedad cgtLimit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCGTLimit() {
        return cgtLimit;
    }

    /**
     * Define el valor de la propiedad cgtLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCGTLimit(String value) {
        this.cgtLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad remExrefLimit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREMExrefLimit() {
        return remExrefLimit;
    }

    /**
     * Define el valor de la propiedad remExrefLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREMExrefLimit(String value) {
        this.remExrefLimit = value;
    }

}
