
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerAddressDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerAddressDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="AddrRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrLine1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrLine2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrLine3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrLine4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrLine5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrLine6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrTypCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrZipCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrMailerInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProvinceCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExistNewInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrCtryCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OkToMail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UpdatedToHost" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrTypDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PropagateInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerAddressDetails", propOrder = {
    "seqNo",
    "addrRef",
    "addrLine1",
    "addrLine2",
    "addrLine3",
    "addrLine4",
    "addrLine5",
    "addrLine6",
    "addrTypCD",
    "addrCity",
    "addrState",
    "addrCountry",
    "addrZipCD",
    "addrMailerInd",
    "provinceCD",
    "existNewInd",
    "addrCtryCD",
    "okToMail",
    "updatedToHost",
    "custNo",
    "addrTypDesc",
    "propagateInd"
})
public class CustomerAddressDetails {

    @XmlElement(name = "SeqNo", required = true)
    protected String seqNo;
    @XmlElement(name = "AddrRef")
    protected String addrRef;
    @XmlElement(name = "AddrLine1")
    protected String addrLine1;
    @XmlElement(name = "AddrLine2")
    protected String addrLine2;
    @XmlElement(name = "AddrLine3")
    protected String addrLine3;
    @XmlElement(name = "AddrLine4")
    protected String addrLine4;
    @XmlElement(name = "AddrLine5")
    protected String addrLine5;
    @XmlElement(name = "AddrLine6")
    protected String addrLine6;
    @XmlElement(name = "AddrTypCD")
    protected String addrTypCD;
    @XmlElement(name = "AddrCity")
    protected String addrCity;
    @XmlElement(name = "AddrState")
    protected String addrState;
    @XmlElement(name = "AddrCountry")
    protected String addrCountry;
    @XmlElement(name = "AddrZipCD")
    protected String addrZipCD;
    @XmlElement(name = "AddrMailerInd")
    protected String addrMailerInd;
    @XmlElement(name = "ProvinceCD")
    protected String provinceCD;
    @XmlElement(name = "ExistNewInd")
    protected String existNewInd;
    @XmlElement(name = "AddrCtryCD")
    protected String addrCtryCD;
    @XmlElement(name = "OkToMail")
    protected String okToMail;
    @XmlElement(name = "UpdatedToHost")
    protected String updatedToHost;
    @XmlElement(name = "CustNo")
    protected String custNo;
    @XmlElement(name = "AddrTypDesc")
    protected String addrTypDesc;
    @XmlElement(name = "PropagateInd")
    protected String propagateInd;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad addrRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrRef() {
        return addrRef;
    }

    /**
     * Define el valor de la propiedad addrRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrRef(String value) {
        this.addrRef = value;
    }

    /**
     * Obtiene el valor de la propiedad addrLine1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrLine1() {
        return addrLine1;
    }

    /**
     * Define el valor de la propiedad addrLine1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrLine1(String value) {
        this.addrLine1 = value;
    }

    /**
     * Obtiene el valor de la propiedad addrLine2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrLine2() {
        return addrLine2;
    }

    /**
     * Define el valor de la propiedad addrLine2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrLine2(String value) {
        this.addrLine2 = value;
    }

    /**
     * Obtiene el valor de la propiedad addrLine3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrLine3() {
        return addrLine3;
    }

    /**
     * Define el valor de la propiedad addrLine3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrLine3(String value) {
        this.addrLine3 = value;
    }

    /**
     * Obtiene el valor de la propiedad addrLine4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrLine4() {
        return addrLine4;
    }

    /**
     * Define el valor de la propiedad addrLine4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrLine4(String value) {
        this.addrLine4 = value;
    }

    /**
     * Obtiene el valor de la propiedad addrLine5.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrLine5() {
        return addrLine5;
    }

    /**
     * Define el valor de la propiedad addrLine5.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrLine5(String value) {
        this.addrLine5 = value;
    }

    /**
     * Obtiene el valor de la propiedad addrLine6.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrLine6() {
        return addrLine6;
    }

    /**
     * Define el valor de la propiedad addrLine6.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrLine6(String value) {
        this.addrLine6 = value;
    }

    /**
     * Obtiene el valor de la propiedad addrTypCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrTypCD() {
        return addrTypCD;
    }

    /**
     * Define el valor de la propiedad addrTypCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrTypCD(String value) {
        this.addrTypCD = value;
    }

    /**
     * Obtiene el valor de la propiedad addrCity.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrCity() {
        return addrCity;
    }

    /**
     * Define el valor de la propiedad addrCity.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrCity(String value) {
        this.addrCity = value;
    }

    /**
     * Obtiene el valor de la propiedad addrState.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrState() {
        return addrState;
    }

    /**
     * Define el valor de la propiedad addrState.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrState(String value) {
        this.addrState = value;
    }

    /**
     * Obtiene el valor de la propiedad addrCountry.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrCountry() {
        return addrCountry;
    }

    /**
     * Define el valor de la propiedad addrCountry.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrCountry(String value) {
        this.addrCountry = value;
    }

    /**
     * Obtiene el valor de la propiedad addrZipCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrZipCD() {
        return addrZipCD;
    }

    /**
     * Define el valor de la propiedad addrZipCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrZipCD(String value) {
        this.addrZipCD = value;
    }

    /**
     * Obtiene el valor de la propiedad addrMailerInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrMailerInd() {
        return addrMailerInd;
    }

    /**
     * Define el valor de la propiedad addrMailerInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrMailerInd(String value) {
        this.addrMailerInd = value;
    }

    /**
     * Obtiene el valor de la propiedad provinceCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvinceCD() {
        return provinceCD;
    }

    /**
     * Define el valor de la propiedad provinceCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvinceCD(String value) {
        this.provinceCD = value;
    }

    /**
     * Obtiene el valor de la propiedad existNewInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExistNewInd() {
        return existNewInd;
    }

    /**
     * Define el valor de la propiedad existNewInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExistNewInd(String value) {
        this.existNewInd = value;
    }

    /**
     * Obtiene el valor de la propiedad addrCtryCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrCtryCD() {
        return addrCtryCD;
    }

    /**
     * Define el valor de la propiedad addrCtryCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrCtryCD(String value) {
        this.addrCtryCD = value;
    }

    /**
     * Obtiene el valor de la propiedad okToMail.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOkToMail() {
        return okToMail;
    }

    /**
     * Define el valor de la propiedad okToMail.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOkToMail(String value) {
        this.okToMail = value;
    }

    /**
     * Obtiene el valor de la propiedad updatedToHost.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedToHost() {
        return updatedToHost;
    }

    /**
     * Define el valor de la propiedad updatedToHost.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedToHost(String value) {
        this.updatedToHost = value;
    }

    /**
     * Obtiene el valor de la propiedad custNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustNo() {
        return custNo;
    }

    /**
     * Define el valor de la propiedad custNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustNo(String value) {
        this.custNo = value;
    }

    /**
     * Obtiene el valor de la propiedad addrTypDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddrTypDesc() {
        return addrTypDesc;
    }

    /**
     * Define el valor de la propiedad addrTypDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddrTypDesc(String value) {
        this.addrTypDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad propagateInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPropagateInd() {
        return propagateInd;
    }

    /**
     * Define el valor de la propiedad propagateInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPropagateInd(String value) {
        this.propagateInd = value;
    }

}
