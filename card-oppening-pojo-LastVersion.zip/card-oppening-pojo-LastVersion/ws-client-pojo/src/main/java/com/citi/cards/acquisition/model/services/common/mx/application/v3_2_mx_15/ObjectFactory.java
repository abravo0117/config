
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PreprocessCardApplicationInqRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "PreprocessCardApplicationInqRs");
    private final static QName _ApplicationStatusAndStageInqRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "ApplicationStatusAndStageInqRs");
    private final static QName _ApplicationStatusAndStageInqRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "ApplicationStatusAndStageInqRq");
    private final static QName _PreCreatedCardAcceptUpdRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "PreCreatedCardAcceptUpdRq");
    private final static QName _LoanApplicationFullDetailsInqRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "LoanApplicationFullDetailsInqRq");
    private final static QName _LoanApplicationFullDetailsInqRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "LoanApplicationFullDetailsInqRs");
    private final static QName _PreprocessCardApplicationInqRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "PreprocessCardApplicationInqRq");
    private final static QName _PreCreatedCardAcceptUpdRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "PreCreatedCardAcceptUpdRs");
    private final static QName _LoanApplicationAddRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "LoanApplicationAddRs");
    private final static QName _LoanApplicationAddRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "LoanApplicationAddRq");
    private final static QName _GetApplicationSummaryRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "GetApplicationSummaryRq");
    private final static QName _PreCreatedCardRejectUpdRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "PreCreatedCardRejectUpdRs");
    private final static QName _PreCreatedCardRejectUpdRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "PreCreatedCardRejectUpdRq");
    private final static QName _GetApplicationSummaryRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "GetApplicationSummaryRs");
    private final static QName _MemoAddRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "MemoAddRq");
    private final static QName _ApplicationFullDetailsInqRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "ApplicationFullDetailsInqRq");
    private final static QName _ListOfCardApplicationInqRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "ListOfCardApplicationInqRs");
    private final static QName _MemoAddRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "MemoAddRs");
    private final static QName _ListOfDuplicateCardApplicationInqRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "ListOfDuplicateCardApplicationInqRq");
    private final static QName _GenerateApplicationRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "GenerateApplicationRs");
    private final static QName _ApplicationFullDetailsInqRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "ApplicationFullDetailsInqRs");
    private final static QName _ListOfCardApplicationInqRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "ListOfCardApplicationInqRq");
    private final static QName _ListOfDuplicateCardApplicationInqRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "ListOfDuplicateCardApplicationInqRs");
    private final static QName _GenerateApplicationRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "GenerateApplicationRq");
    private final static QName _DocumentUploadNotificationUpdRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "DocumentUploadNotificationUpdRq");
    private final static QName _DocumentUploadNotificationUpdRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "DocumentUploadNotificationUpdRs");
    private final static QName _PendingAccountOpeningApplicationInqRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "PendingAccountOpeningApplicationInqRq");
    private final static QName _PendingAccountOpeningApplicationInqRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "PendingAccountOpeningApplicationInqRs");
    private final static QName _CardApplicationAddRq_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "CardApplicationAddRq");
    private final static QName _CardApplicationAddRs_QNAME = new QName("http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", "CardApplicationAddRs");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PreprocessCardApplicationInqRs }
     * 
     */
    public PreprocessCardApplicationInqRs createPreprocessCardApplicationInqRs() {
        return new PreprocessCardApplicationInqRs();
    }

    /**
     * Create an instance of {@link ApplicationStatusAndStageInqRs }
     * 
     */
    public ApplicationStatusAndStageInqRs createApplicationStatusAndStageInqRs() {
        return new ApplicationStatusAndStageInqRs();
    }

    /**
     * Create an instance of {@link ApplicationStatusAndStageInqRq }
     * 
     */
    public ApplicationStatusAndStageInqRq createApplicationStatusAndStageInqRq() {
        return new ApplicationStatusAndStageInqRq();
    }

    /**
     * Create an instance of {@link PreCreatedCardAcceptUpdRq }
     * 
     */
    public PreCreatedCardAcceptUpdRq createPreCreatedCardAcceptUpdRq() {
        return new PreCreatedCardAcceptUpdRq();
    }

    /**
     * Create an instance of {@link LoanApplicationFullDetailsInqRq }
     * 
     */
    public LoanApplicationFullDetailsInqRq createLoanApplicationFullDetailsInqRq() {
        return new LoanApplicationFullDetailsInqRq();
    }

    /**
     * Create an instance of {@link LoanApplicationFullDetailsInqRs }
     * 
     */
    public LoanApplicationFullDetailsInqRs createLoanApplicationFullDetailsInqRs() {
        return new LoanApplicationFullDetailsInqRs();
    }

    /**
     * Create an instance of {@link PreprocessCardApplicationInqRq }
     * 
     */
    public PreprocessCardApplicationInqRq createPreprocessCardApplicationInqRq() {
        return new PreprocessCardApplicationInqRq();
    }

    /**
     * Create an instance of {@link PreCreatedCardAcceptUpdRs }
     * 
     */
    public PreCreatedCardAcceptUpdRs createPreCreatedCardAcceptUpdRs() {
        return new PreCreatedCardAcceptUpdRs();
    }

    /**
     * Create an instance of {@link LoanApplicationAddRs }
     * 
     */
    public LoanApplicationAddRs createLoanApplicationAddRs() {
        return new LoanApplicationAddRs();
    }

    /**
     * Create an instance of {@link LoanApplicationAddRq }
     * 
     */
    public LoanApplicationAddRq createLoanApplicationAddRq() {
        return new LoanApplicationAddRq();
    }

    /**
     * Create an instance of {@link GetApplicationSummaryRq }
     * 
     */
    public GetApplicationSummaryRq createGetApplicationSummaryRq() {
        return new GetApplicationSummaryRq();
    }

    /**
     * Create an instance of {@link PreCreatedCardRejectUpdRs }
     * 
     */
    public PreCreatedCardRejectUpdRs createPreCreatedCardRejectUpdRs() {
        return new PreCreatedCardRejectUpdRs();
    }

    /**
     * Create an instance of {@link GetApplicationSummaryRs }
     * 
     */
    public GetApplicationSummaryRs createGetApplicationSummaryRs() {
        return new GetApplicationSummaryRs();
    }

    /**
     * Create an instance of {@link MemoAddRq }
     * 
     */
    public MemoAddRq createMemoAddRq() {
        return new MemoAddRq();
    }

    /**
     * Create an instance of {@link PreCreatedCardRejectUpdRq }
     * 
     */
    public PreCreatedCardRejectUpdRq createPreCreatedCardRejectUpdRq() {
        return new PreCreatedCardRejectUpdRq();
    }

    /**
     * Create an instance of {@link ListOfCardApplicationInqRs }
     * 
     */
    public ListOfCardApplicationInqRs createListOfCardApplicationInqRs() {
        return new ListOfCardApplicationInqRs();
    }

    /**
     * Create an instance of {@link MemoAddRs }
     * 
     */
    public MemoAddRs createMemoAddRs() {
        return new MemoAddRs();
    }

    /**
     * Create an instance of {@link ListOfDuplicateCardApplicationInqRq }
     * 
     */
    public ListOfDuplicateCardApplicationInqRq createListOfDuplicateCardApplicationInqRq() {
        return new ListOfDuplicateCardApplicationInqRq();
    }

    /**
     * Create an instance of {@link ApplicationFullDetailsInqRq }
     * 
     */
    public ApplicationFullDetailsInqRq createApplicationFullDetailsInqRq() {
        return new ApplicationFullDetailsInqRq();
    }

    /**
     * Create an instance of {@link ListOfCardApplicationInqRq }
     * 
     */
    public ListOfCardApplicationInqRq createListOfCardApplicationInqRq() {
        return new ListOfCardApplicationInqRq();
    }

    /**
     * Create an instance of {@link ListOfDuplicateCardApplicationInqRs }
     * 
     */
    public ListOfDuplicateCardApplicationInqRs createListOfDuplicateCardApplicationInqRs() {
        return new ListOfDuplicateCardApplicationInqRs();
    }

    /**
     * Create an instance of {@link GenerateApplicationRs }
     * 
     */
    public GenerateApplicationRs createGenerateApplicationRs() {
        return new GenerateApplicationRs();
    }

    /**
     * Create an instance of {@link ApplicationFullDetailsInqRs }
     * 
     */
    public ApplicationFullDetailsInqRs createApplicationFullDetailsInqRs() {
        return new ApplicationFullDetailsInqRs();
    }

    /**
     * Create an instance of {@link GenerateApplicationRq }
     * 
     */
    public GenerateApplicationRq createGenerateApplicationRq() {
        return new GenerateApplicationRq();
    }

    /**
     * Create an instance of {@link DocumentUploadNotificationUpdRq }
     * 
     */
    public DocumentUploadNotificationUpdRq createDocumentUploadNotificationUpdRq() {
        return new DocumentUploadNotificationUpdRq();
    }

    /**
     * Create an instance of {@link DocumentUploadNotificationUpdRs }
     * 
     */
    public DocumentUploadNotificationUpdRs createDocumentUploadNotificationUpdRs() {
        return new DocumentUploadNotificationUpdRs();
    }

    /**
     * Create an instance of {@link PendingAccountOpeningApplicationInqRq }
     * 
     */
    public PendingAccountOpeningApplicationInqRq createPendingAccountOpeningApplicationInqRq() {
        return new PendingAccountOpeningApplicationInqRq();
    }

    /**
     * Create an instance of {@link PendingAccountOpeningApplicationInqRs }
     * 
     */
    public PendingAccountOpeningApplicationInqRs createPendingAccountOpeningApplicationInqRs() {
        return new PendingAccountOpeningApplicationInqRs();
    }

    /**
     * Create an instance of {@link CardApplicationAddRq }
     * 
     */
    public CardApplicationAddRq createCardApplicationAddRq() {
        return new CardApplicationAddRq();
    }

    /**
     * Create an instance of {@link CardApplicationAddRs }
     * 
     */
    public CardApplicationAddRs createCardApplicationAddRs() {
        return new CardApplicationAddRs();
    }

    /**
     * Create an instance of {@link ControlDetails }
     * 
     */
    public ControlDetails createControlDetails() {
        return new ControlDetails();
    }

    /**
     * Create an instance of {@link Product }
     * 
     */
    public Product createProduct() {
        return new Product();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreprocessCardApplicationInqRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "PreprocessCardApplicationInqRs")
    public JAXBElement<PreprocessCardApplicationInqRs> createPreprocessCardApplicationInqRs(PreprocessCardApplicationInqRs value) {
        return new JAXBElement<PreprocessCardApplicationInqRs>(_PreprocessCardApplicationInqRs_QNAME, PreprocessCardApplicationInqRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicationStatusAndStageInqRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "ApplicationStatusAndStageInqRs")
    public JAXBElement<ApplicationStatusAndStageInqRs> createApplicationStatusAndStageInqRs(ApplicationStatusAndStageInqRs value) {
        return new JAXBElement<ApplicationStatusAndStageInqRs>(_ApplicationStatusAndStageInqRs_QNAME, ApplicationStatusAndStageInqRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicationStatusAndStageInqRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "ApplicationStatusAndStageInqRq")
    public JAXBElement<ApplicationStatusAndStageInqRq> createApplicationStatusAndStageInqRq(ApplicationStatusAndStageInqRq value) {
        return new JAXBElement<ApplicationStatusAndStageInqRq>(_ApplicationStatusAndStageInqRq_QNAME, ApplicationStatusAndStageInqRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreCreatedCardAcceptUpdRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "PreCreatedCardAcceptUpdRq")
    public JAXBElement<PreCreatedCardAcceptUpdRq> createPreCreatedCardAcceptUpdRq(PreCreatedCardAcceptUpdRq value) {
        return new JAXBElement<PreCreatedCardAcceptUpdRq>(_PreCreatedCardAcceptUpdRq_QNAME, PreCreatedCardAcceptUpdRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LoanApplicationFullDetailsInqRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "LoanApplicationFullDetailsInqRq")
    public JAXBElement<LoanApplicationFullDetailsInqRq> createLoanApplicationFullDetailsInqRq(LoanApplicationFullDetailsInqRq value) {
        return new JAXBElement<LoanApplicationFullDetailsInqRq>(_LoanApplicationFullDetailsInqRq_QNAME, LoanApplicationFullDetailsInqRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LoanApplicationFullDetailsInqRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "LoanApplicationFullDetailsInqRs")
    public JAXBElement<LoanApplicationFullDetailsInqRs> createLoanApplicationFullDetailsInqRs(LoanApplicationFullDetailsInqRs value) {
        return new JAXBElement<LoanApplicationFullDetailsInqRs>(_LoanApplicationFullDetailsInqRs_QNAME, LoanApplicationFullDetailsInqRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreprocessCardApplicationInqRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "PreprocessCardApplicationInqRq")
    public JAXBElement<PreprocessCardApplicationInqRq> createPreprocessCardApplicationInqRq(PreprocessCardApplicationInqRq value) {
        return new JAXBElement<PreprocessCardApplicationInqRq>(_PreprocessCardApplicationInqRq_QNAME, PreprocessCardApplicationInqRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreCreatedCardAcceptUpdRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "PreCreatedCardAcceptUpdRs")
    public JAXBElement<PreCreatedCardAcceptUpdRs> createPreCreatedCardAcceptUpdRs(PreCreatedCardAcceptUpdRs value) {
        return new JAXBElement<PreCreatedCardAcceptUpdRs>(_PreCreatedCardAcceptUpdRs_QNAME, PreCreatedCardAcceptUpdRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LoanApplicationAddRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "LoanApplicationAddRs")
    public JAXBElement<LoanApplicationAddRs> createLoanApplicationAddRs(LoanApplicationAddRs value) {
        return new JAXBElement<LoanApplicationAddRs>(_LoanApplicationAddRs_QNAME, LoanApplicationAddRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LoanApplicationAddRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "LoanApplicationAddRq")
    public JAXBElement<LoanApplicationAddRq> createLoanApplicationAddRq(LoanApplicationAddRq value) {
        return new JAXBElement<LoanApplicationAddRq>(_LoanApplicationAddRq_QNAME, LoanApplicationAddRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetApplicationSummaryRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "GetApplicationSummaryRq")
    public JAXBElement<GetApplicationSummaryRq> createGetApplicationSummaryRq(GetApplicationSummaryRq value) {
        return new JAXBElement<GetApplicationSummaryRq>(_GetApplicationSummaryRq_QNAME, GetApplicationSummaryRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreCreatedCardRejectUpdRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "PreCreatedCardRejectUpdRs")
    public JAXBElement<PreCreatedCardRejectUpdRs> createPreCreatedCardRejectUpdRs(PreCreatedCardRejectUpdRs value) {
        return new JAXBElement<PreCreatedCardRejectUpdRs>(_PreCreatedCardRejectUpdRs_QNAME, PreCreatedCardRejectUpdRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PreCreatedCardRejectUpdRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "PreCreatedCardRejectUpdRq")
    public JAXBElement<PreCreatedCardRejectUpdRq> createPreCreatedCardRejectUpdRq(PreCreatedCardRejectUpdRq value) {
        return new JAXBElement<PreCreatedCardRejectUpdRq>(_PreCreatedCardRejectUpdRq_QNAME, PreCreatedCardRejectUpdRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetApplicationSummaryRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "GetApplicationSummaryRs")
    public JAXBElement<GetApplicationSummaryRs> createGetApplicationSummaryRs(GetApplicationSummaryRs value) {
        return new JAXBElement<GetApplicationSummaryRs>(_GetApplicationSummaryRs_QNAME, GetApplicationSummaryRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MemoAddRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "MemoAddRq")
    public JAXBElement<MemoAddRq> createMemoAddRq(MemoAddRq value) {
        return new JAXBElement<MemoAddRq>(_MemoAddRq_QNAME, MemoAddRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicationFullDetailsInqRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "ApplicationFullDetailsInqRq")
    public JAXBElement<ApplicationFullDetailsInqRq> createApplicationFullDetailsInqRq(ApplicationFullDetailsInqRq value) {
        return new JAXBElement<ApplicationFullDetailsInqRq>(_ApplicationFullDetailsInqRq_QNAME, ApplicationFullDetailsInqRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfCardApplicationInqRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "ListOfCardApplicationInqRs")
    public JAXBElement<ListOfCardApplicationInqRs> createListOfCardApplicationInqRs(ListOfCardApplicationInqRs value) {
        return new JAXBElement<ListOfCardApplicationInqRs>(_ListOfCardApplicationInqRs_QNAME, ListOfCardApplicationInqRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MemoAddRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "MemoAddRs")
    public JAXBElement<MemoAddRs> createMemoAddRs(MemoAddRs value) {
        return new JAXBElement<MemoAddRs>(_MemoAddRs_QNAME, MemoAddRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfDuplicateCardApplicationInqRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "ListOfDuplicateCardApplicationInqRq")
    public JAXBElement<ListOfDuplicateCardApplicationInqRq> createListOfDuplicateCardApplicationInqRq(ListOfDuplicateCardApplicationInqRq value) {
        return new JAXBElement<ListOfDuplicateCardApplicationInqRq>(_ListOfDuplicateCardApplicationInqRq_QNAME, ListOfDuplicateCardApplicationInqRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GenerateApplicationRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "GenerateApplicationRs")
    public JAXBElement<GenerateApplicationRs> createGenerateApplicationRs(GenerateApplicationRs value) {
        return new JAXBElement<GenerateApplicationRs>(_GenerateApplicationRs_QNAME, GenerateApplicationRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ApplicationFullDetailsInqRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "ApplicationFullDetailsInqRs")
    public JAXBElement<ApplicationFullDetailsInqRs> createApplicationFullDetailsInqRs(ApplicationFullDetailsInqRs value) {
        return new JAXBElement<ApplicationFullDetailsInqRs>(_ApplicationFullDetailsInqRs_QNAME, ApplicationFullDetailsInqRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfCardApplicationInqRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "ListOfCardApplicationInqRq")
    public JAXBElement<ListOfCardApplicationInqRq> createListOfCardApplicationInqRq(ListOfCardApplicationInqRq value) {
        return new JAXBElement<ListOfCardApplicationInqRq>(_ListOfCardApplicationInqRq_QNAME, ListOfCardApplicationInqRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfDuplicateCardApplicationInqRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "ListOfDuplicateCardApplicationInqRs")
    public JAXBElement<ListOfDuplicateCardApplicationInqRs> createListOfDuplicateCardApplicationInqRs(ListOfDuplicateCardApplicationInqRs value) {
        return new JAXBElement<ListOfDuplicateCardApplicationInqRs>(_ListOfDuplicateCardApplicationInqRs_QNAME, ListOfDuplicateCardApplicationInqRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GenerateApplicationRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "GenerateApplicationRq")
    public JAXBElement<GenerateApplicationRq> createGenerateApplicationRq(GenerateApplicationRq value) {
        return new JAXBElement<GenerateApplicationRq>(_GenerateApplicationRq_QNAME, GenerateApplicationRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentUploadNotificationUpdRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "DocumentUploadNotificationUpdRq")
    public JAXBElement<DocumentUploadNotificationUpdRq> createDocumentUploadNotificationUpdRq(DocumentUploadNotificationUpdRq value) {
        return new JAXBElement<DocumentUploadNotificationUpdRq>(_DocumentUploadNotificationUpdRq_QNAME, DocumentUploadNotificationUpdRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DocumentUploadNotificationUpdRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "DocumentUploadNotificationUpdRs")
    public JAXBElement<DocumentUploadNotificationUpdRs> createDocumentUploadNotificationUpdRs(DocumentUploadNotificationUpdRs value) {
        return new JAXBElement<DocumentUploadNotificationUpdRs>(_DocumentUploadNotificationUpdRs_QNAME, DocumentUploadNotificationUpdRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PendingAccountOpeningApplicationInqRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "PendingAccountOpeningApplicationInqRq")
    public JAXBElement<PendingAccountOpeningApplicationInqRq> createPendingAccountOpeningApplicationInqRq(PendingAccountOpeningApplicationInqRq value) {
        return new JAXBElement<PendingAccountOpeningApplicationInqRq>(_PendingAccountOpeningApplicationInqRq_QNAME, PendingAccountOpeningApplicationInqRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PendingAccountOpeningApplicationInqRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "PendingAccountOpeningApplicationInqRs")
    public JAXBElement<PendingAccountOpeningApplicationInqRs> createPendingAccountOpeningApplicationInqRs(PendingAccountOpeningApplicationInqRs value) {
        return new JAXBElement<PendingAccountOpeningApplicationInqRs>(_PendingAccountOpeningApplicationInqRs_QNAME, PendingAccountOpeningApplicationInqRs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CardApplicationAddRq }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "CardApplicationAddRq")
    public JAXBElement<CardApplicationAddRq> createCardApplicationAddRq(CardApplicationAddRq value) {
        return new JAXBElement<CardApplicationAddRq>(_CardApplicationAddRq_QNAME, CardApplicationAddRq.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CardApplicationAddRs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", name = "CardApplicationAddRs")
    public JAXBElement<CardApplicationAddRs> createCardApplicationAddRs(CardApplicationAddRs value) {
        return new JAXBElement<CardApplicationAddRs>(_CardApplicationAddRs_QNAME, CardApplicationAddRs.class, null, value);
    }

}
