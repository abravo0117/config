
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para StatementDtls complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="StatementDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="StatementComDtl" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}StatementComDtl" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="StatementAdditional" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}StatementAdditional" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="StatementAddress" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}StatementAdditional" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatementDtls", propOrder = {
    "statementComDtl",
    "statementAdditional",
    "statementAddress"
})
public class StatementDtls {

    @XmlElement(name = "StatementComDtl")
    protected List<StatementComDtl> statementComDtl;
    @XmlElement(name = "StatementAdditional")
    protected List<StatementAdditional> statementAdditional;
    @XmlElement(name = "StatementAddress")
    protected List<StatementAdditional> statementAddress;

    /**
     * Gets the value of the statementComDtl property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the statementComDtl property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatementComDtl().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StatementComDtl }
     * 
     * 
     */
    public List<StatementComDtl> getStatementComDtl() {
        if (statementComDtl == null) {
            statementComDtl = new ArrayList<StatementComDtl>();
        }
        return this.statementComDtl;
    }

    /**
     * Gets the value of the statementAdditional property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the statementAdditional property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatementAdditional().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StatementAdditional }
     * 
     * 
     */
    public List<StatementAdditional> getStatementAdditional() {
        if (statementAdditional == null) {
            statementAdditional = new ArrayList<StatementAdditional>();
        }
        return this.statementAdditional;
    }

    /**
     * Gets the value of the statementAddress property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the statementAddress property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatementAddress().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StatementAdditional }
     * 
     * 
     */
    public List<StatementAdditional> getStatementAddress() {
        if (statementAddress == null) {
            statementAddress = new ArrayList<StatementAdditional>();
        }
        return this.statementAddress;
    }

}
