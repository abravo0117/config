
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para MemoDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="MemoDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ApplicationID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MemoCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Comments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MaintID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MaintDT" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="TargetDepartment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserID" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}UserID" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MemoDetails", propOrder = {
    "applicationID",
    "seqNo",
    "memoCD",
    "comments",
    "maintID",
    "maintDT",
    "targetDepartment",
    "userID"
})
public class MemoDetails {

    @XmlElement(name = "ApplicationID")
    protected String applicationID;
    @XmlElement(name = "SeqNo")
    protected String seqNo;
    @XmlElement(name = "MemoCD")
    protected String memoCD;
    @XmlElement(name = "Comments")
    protected String comments;
    @XmlElement(name = "MaintID")
    protected String maintID;
    @XmlElement(name = "MaintDT")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar maintDT;
    @XmlElement(name = "TargetDepartment")
    protected String targetDepartment;
    @XmlElement(name = "UserID")
    protected String userID;

    /**
     * Obtiene el valor de la propiedad applicationID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationID() {
        return applicationID;
    }

    /**
     * Define el valor de la propiedad applicationID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationID(String value) {
        this.applicationID = value;
    }

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad memoCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemoCD() {
        return memoCD;
    }

    /**
     * Define el valor de la propiedad memoCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemoCD(String value) {
        this.memoCD = value;
    }

    /**
     * Obtiene el valor de la propiedad comments.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComments() {
        return comments;
    }

    /**
     * Define el valor de la propiedad comments.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComments(String value) {
        this.comments = value;
    }

    /**
     * Obtiene el valor de la propiedad maintID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaintID() {
        return maintID;
    }

    /**
     * Define el valor de la propiedad maintID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaintID(String value) {
        this.maintID = value;
    }

    /**
     * Obtiene el valor de la propiedad maintDT.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getMaintDT() {
        return maintDT;
    }

    /**
     * Define el valor de la propiedad maintDT.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMaintDT(XMLGregorianCalendar value) {
        this.maintDT = value;
    }

    /**
     * Obtiene el valor de la propiedad targetDepartment.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetDepartment() {
        return targetDepartment;
    }

    /**
     * Define el valor de la propiedad targetDepartment.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetDepartment(String value) {
        this.targetDepartment = value;
    }

    /**
     * Obtiene el valor de la propiedad userID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Define el valor de la propiedad userID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

}
