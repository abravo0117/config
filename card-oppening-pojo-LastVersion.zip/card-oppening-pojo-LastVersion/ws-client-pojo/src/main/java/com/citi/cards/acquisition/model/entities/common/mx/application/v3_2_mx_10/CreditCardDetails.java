
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CreditCardDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CreditCardDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Org" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Logo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InstantInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditShield" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmbossName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmbossDest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmbossQueue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfficerIncharge" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OwnerShipType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExistingCardNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AppRecFromCust" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AppRecFromSales" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HomeAddrRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfficeAddrRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BillTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PinTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GiftCd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CitiClearDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CitiClearDetails" minOccurs="0"/>
 *         &lt;element name="COBrandDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}COBrandDetails" minOccurs="0"/>
 *         &lt;element name="RelnToPrimary" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PrivilegeCard" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SpendLimit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DeliveryMthd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MGMDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}MGMDetails" minOccurs="0"/>
 *         &lt;element name="ConsentFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ConsentID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="KitasValidity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SignatureInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VIPInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PurposeOfLine" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OneBill" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EzlinkTopup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NFCFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="POS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesPromoCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DDBankBranch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DDAccountNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CampaignCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProgramID1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProgramID2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReadyCreditSpecificDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}ReadyCreditSpecificDetails" minOccurs="0"/>
 *         &lt;element name="ConsentOvrLimt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProviderInfoDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}ProviderInfoDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreditCardDetails", propOrder = {
    "seqNo",
    "custNo",
    "sourceCode",
    "org",
    "logo",
    "agentCode",
    "instantInd",
    "creditShield",
    "embossName",
    "embossDest",
    "embossQueue",
    "officerIncharge",
    "ownerShipType",
    "existingCardNo",
    "appRecFromCust",
    "appRecFromSales",
    "homeAddrRef",
    "officeAddrRef",
    "billTo",
    "cardTo",
    "pinTo",
    "giftCd",
    "citiClearDetails",
    "coBrandDetails",
    "relnToPrimary",
    "privilegeCard",
    "spendLimit",
    "creditAmount",
    "deliveryMthd",
    "mgmDetails",
    "consentFlag",
    "consentID",
    "kitasValidity",
    "signatureInd",
    "vipInd",
    "purposeOfLine",
    "salNo",
    "oneBill",
    "ezlinkTopup",
    "nfcFlag",
    "pos",
    "salesPromoCD",
    "ddBankBranch",
    "ddAccountNum",
    "campaignCode",
    "programID1",
    "programID2",
    "readyCreditSpecificDetails",
    "consentOvrLimt",
    "providerInfoDetails"
})
public class CreditCardDetails {

    @XmlElement(name = "SeqNo")
    protected String seqNo;
    @XmlElement(name = "CustNo")
    protected String custNo;
    @XmlElement(name = "SourceCode")
    protected String sourceCode;
    @XmlElement(name = "Org")
    protected String org;
    @XmlElement(name = "Logo")
    protected String logo;
    @XmlElement(name = "AgentCode")
    protected String agentCode;
    @XmlElement(name = "InstantInd")
    protected String instantInd;
    @XmlElement(name = "CreditShield")
    protected String creditShield;
    @XmlElement(name = "EmbossName")
    protected String embossName;
    @XmlElement(name = "EmbossDest")
    protected String embossDest;
    @XmlElement(name = "EmbossQueue")
    protected String embossQueue;
    @XmlElement(name = "OfficerIncharge")
    protected String officerIncharge;
    @XmlElement(name = "OwnerShipType")
    protected String ownerShipType;
    @XmlElement(name = "ExistingCardNo")
    protected String existingCardNo;
    @XmlElement(name = "AppRecFromCust")
    protected String appRecFromCust;
    @XmlElement(name = "AppRecFromSales")
    protected String appRecFromSales;
    @XmlElement(name = "HomeAddrRef")
    protected String homeAddrRef;
    @XmlElement(name = "OfficeAddrRef")
    protected String officeAddrRef;
    @XmlElement(name = "BillTo")
    protected String billTo;
    @XmlElement(name = "CardTo")
    protected String cardTo;
    @XmlElement(name = "PinTo")
    protected String pinTo;
    @XmlElement(name = "GiftCd")
    protected String giftCd;
    @XmlElement(name = "CitiClearDetails")
    protected CitiClearDetails citiClearDetails;
    @XmlElement(name = "COBrandDetails")
    protected COBrandDetails coBrandDetails;
    @XmlElement(name = "RelnToPrimary")
    protected String relnToPrimary;
    @XmlElement(name = "PrivilegeCard")
    protected String privilegeCard;
    @XmlElement(name = "SpendLimit")
    protected String spendLimit;
    @XmlElement(name = "CreditAmount")
    protected String creditAmount;
    @XmlElement(name = "DeliveryMthd")
    protected String deliveryMthd;
    @XmlElement(name = "MGMDetails")
    protected MGMDetails mgmDetails;
    @XmlElement(name = "ConsentFlag")
    protected String consentFlag;
    @XmlElement(name = "ConsentID")
    protected String consentID;
    @XmlElement(name = "KitasValidity")
    protected String kitasValidity;
    @XmlElement(name = "SignatureInd")
    protected String signatureInd;
    @XmlElement(name = "VIPInd")
    protected String vipInd;
    @XmlElement(name = "PurposeOfLine")
    protected String purposeOfLine;
    @XmlElement(name = "SalNo")
    protected String salNo;
    @XmlElement(name = "OneBill")
    protected String oneBill;
    @XmlElement(name = "EzlinkTopup")
    protected String ezlinkTopup;
    @XmlElement(name = "NFCFlag")
    protected String nfcFlag;
    @XmlElement(name = "POS")
    protected String pos;
    @XmlElement(name = "SalesPromoCD")
    protected String salesPromoCD;
    @XmlElement(name = "DDBankBranch")
    protected String ddBankBranch;
    @XmlElement(name = "DDAccountNum")
    protected String ddAccountNum;
    @XmlElement(name = "CampaignCode")
    protected String campaignCode;
    @XmlElement(name = "ProgramID1")
    protected String programID1;
    @XmlElement(name = "ProgramID2")
    protected String programID2;
    @XmlElement(name = "ReadyCreditSpecificDetails")
    protected ReadyCreditSpecificDetails readyCreditSpecificDetails;
    @XmlElement(name = "ConsentOvrLimt")
    protected String consentOvrLimt;
    @XmlElement(name = "ProviderInfoDetails")
    protected ProviderInfoDetails providerInfoDetails;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad custNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustNo() {
        return custNo;
    }

    /**
     * Define el valor de la propiedad custNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustNo(String value) {
        this.custNo = value;
    }

    /**
     * Obtiene el valor de la propiedad sourceCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceCode() {
        return sourceCode;
    }

    /**
     * Define el valor de la propiedad sourceCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceCode(String value) {
        this.sourceCode = value;
    }

    /**
     * Obtiene el valor de la propiedad org.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrg() {
        return org;
    }

    /**
     * Define el valor de la propiedad org.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrg(String value) {
        this.org = value;
    }

    /**
     * Obtiene el valor de la propiedad logo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogo() {
        return logo;
    }

    /**
     * Define el valor de la propiedad logo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogo(String value) {
        this.logo = value;
    }

    /**
     * Obtiene el valor de la propiedad agentCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentCode() {
        return agentCode;
    }

    /**
     * Define el valor de la propiedad agentCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentCode(String value) {
        this.agentCode = value;
    }

    /**
     * Obtiene el valor de la propiedad instantInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstantInd() {
        return instantInd;
    }

    /**
     * Define el valor de la propiedad instantInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstantInd(String value) {
        this.instantInd = value;
    }

    /**
     * Obtiene el valor de la propiedad creditShield.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditShield() {
        return creditShield;
    }

    /**
     * Define el valor de la propiedad creditShield.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditShield(String value) {
        this.creditShield = value;
    }

    /**
     * Obtiene el valor de la propiedad embossName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmbossName() {
        return embossName;
    }

    /**
     * Define el valor de la propiedad embossName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbossName(String value) {
        this.embossName = value;
    }

    /**
     * Obtiene el valor de la propiedad embossDest.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmbossDest() {
        return embossDest;
    }

    /**
     * Define el valor de la propiedad embossDest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbossDest(String value) {
        this.embossDest = value;
    }

    /**
     * Obtiene el valor de la propiedad embossQueue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmbossQueue() {
        return embossQueue;
    }

    /**
     * Define el valor de la propiedad embossQueue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbossQueue(String value) {
        this.embossQueue = value;
    }

    /**
     * Obtiene el valor de la propiedad officerIncharge.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfficerIncharge() {
        return officerIncharge;
    }

    /**
     * Define el valor de la propiedad officerIncharge.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfficerIncharge(String value) {
        this.officerIncharge = value;
    }

    /**
     * Obtiene el valor de la propiedad ownerShipType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOwnerShipType() {
        return ownerShipType;
    }

    /**
     * Define el valor de la propiedad ownerShipType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOwnerShipType(String value) {
        this.ownerShipType = value;
    }

    /**
     * Obtiene el valor de la propiedad existingCardNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExistingCardNo() {
        return existingCardNo;
    }

    /**
     * Define el valor de la propiedad existingCardNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExistingCardNo(String value) {
        this.existingCardNo = value;
    }

    /**
     * Obtiene el valor de la propiedad appRecFromCust.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppRecFromCust() {
        return appRecFromCust;
    }

    /**
     * Define el valor de la propiedad appRecFromCust.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppRecFromCust(String value) {
        this.appRecFromCust = value;
    }

    /**
     * Obtiene el valor de la propiedad appRecFromSales.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppRecFromSales() {
        return appRecFromSales;
    }

    /**
     * Define el valor de la propiedad appRecFromSales.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppRecFromSales(String value) {
        this.appRecFromSales = value;
    }

    /**
     * Obtiene el valor de la propiedad homeAddrRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomeAddrRef() {
        return homeAddrRef;
    }

    /**
     * Define el valor de la propiedad homeAddrRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomeAddrRef(String value) {
        this.homeAddrRef = value;
    }

    /**
     * Obtiene el valor de la propiedad officeAddrRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfficeAddrRef() {
        return officeAddrRef;
    }

    /**
     * Define el valor de la propiedad officeAddrRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfficeAddrRef(String value) {
        this.officeAddrRef = value;
    }

    /**
     * Obtiene el valor de la propiedad billTo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillTo() {
        return billTo;
    }

    /**
     * Define el valor de la propiedad billTo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillTo(String value) {
        this.billTo = value;
    }

    /**
     * Obtiene el valor de la propiedad cardTo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardTo() {
        return cardTo;
    }

    /**
     * Define el valor de la propiedad cardTo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardTo(String value) {
        this.cardTo = value;
    }

    /**
     * Obtiene el valor de la propiedad pinTo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPinTo() {
        return pinTo;
    }

    /**
     * Define el valor de la propiedad pinTo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPinTo(String value) {
        this.pinTo = value;
    }

    /**
     * Obtiene el valor de la propiedad giftCd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGiftCd() {
        return giftCd;
    }

    /**
     * Define el valor de la propiedad giftCd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGiftCd(String value) {
        this.giftCd = value;
    }

    /**
     * Obtiene el valor de la propiedad citiClearDetails.
     * 
     * @return
     *     possible object is
     *     {@link CitiClearDetails }
     *     
     */
    public CitiClearDetails getCitiClearDetails() {
        return citiClearDetails;
    }

    /**
     * Define el valor de la propiedad citiClearDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link CitiClearDetails }
     *     
     */
    public void setCitiClearDetails(CitiClearDetails value) {
        this.citiClearDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad coBrandDetails.
     * 
     * @return
     *     possible object is
     *     {@link COBrandDetails }
     *     
     */
    public COBrandDetails getCOBrandDetails() {
        return coBrandDetails;
    }

    /**
     * Define el valor de la propiedad coBrandDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link COBrandDetails }
     *     
     */
    public void setCOBrandDetails(COBrandDetails value) {
        this.coBrandDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad relnToPrimary.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnToPrimary() {
        return relnToPrimary;
    }

    /**
     * Define el valor de la propiedad relnToPrimary.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnToPrimary(String value) {
        this.relnToPrimary = value;
    }

    /**
     * Obtiene el valor de la propiedad privilegeCard.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrivilegeCard() {
        return privilegeCard;
    }

    /**
     * Define el valor de la propiedad privilegeCard.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrivilegeCard(String value) {
        this.privilegeCard = value;
    }

    /**
     * Obtiene el valor de la propiedad spendLimit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpendLimit() {
        return spendLimit;
    }

    /**
     * Define el valor de la propiedad spendLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpendLimit(String value) {
        this.spendLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad creditAmount.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditAmount() {
        return creditAmount;
    }

    /**
     * Define el valor de la propiedad creditAmount.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditAmount(String value) {
        this.creditAmount = value;
    }

    /**
     * Obtiene el valor de la propiedad deliveryMthd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveryMthd() {
        return deliveryMthd;
    }

    /**
     * Define el valor de la propiedad deliveryMthd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveryMthd(String value) {
        this.deliveryMthd = value;
    }

    /**
     * Obtiene el valor de la propiedad mgmDetails.
     * 
     * @return
     *     possible object is
     *     {@link MGMDetails }
     *     
     */
    public MGMDetails getMGMDetails() {
        return mgmDetails;
    }

    /**
     * Define el valor de la propiedad mgmDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link MGMDetails }
     *     
     */
    public void setMGMDetails(MGMDetails value) {
        this.mgmDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad consentFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsentFlag() {
        return consentFlag;
    }

    /**
     * Define el valor de la propiedad consentFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsentFlag(String value) {
        this.consentFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad consentID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsentID() {
        return consentID;
    }

    /**
     * Define el valor de la propiedad consentID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsentID(String value) {
        this.consentID = value;
    }

    /**
     * Obtiene el valor de la propiedad kitasValidity.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKitasValidity() {
        return kitasValidity;
    }

    /**
     * Define el valor de la propiedad kitasValidity.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKitasValidity(String value) {
        this.kitasValidity = value;
    }

    /**
     * Obtiene el valor de la propiedad signatureInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignatureInd() {
        return signatureInd;
    }

    /**
     * Define el valor de la propiedad signatureInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignatureInd(String value) {
        this.signatureInd = value;
    }

    /**
     * Obtiene el valor de la propiedad vipInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIPInd() {
        return vipInd;
    }

    /**
     * Define el valor de la propiedad vipInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIPInd(String value) {
        this.vipInd = value;
    }

    /**
     * Obtiene el valor de la propiedad purposeOfLine.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPurposeOfLine() {
        return purposeOfLine;
    }

    /**
     * Define el valor de la propiedad purposeOfLine.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPurposeOfLine(String value) {
        this.purposeOfLine = value;
    }

    /**
     * Obtiene el valor de la propiedad salNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalNo() {
        return salNo;
    }

    /**
     * Define el valor de la propiedad salNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalNo(String value) {
        this.salNo = value;
    }

    /**
     * Obtiene el valor de la propiedad oneBill.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOneBill() {
        return oneBill;
    }

    /**
     * Define el valor de la propiedad oneBill.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOneBill(String value) {
        this.oneBill = value;
    }

    /**
     * Obtiene el valor de la propiedad ezlinkTopup.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEzlinkTopup() {
        return ezlinkTopup;
    }

    /**
     * Define el valor de la propiedad ezlinkTopup.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEzlinkTopup(String value) {
        this.ezlinkTopup = value;
    }

    /**
     * Obtiene el valor de la propiedad nfcFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNFCFlag() {
        return nfcFlag;
    }

    /**
     * Define el valor de la propiedad nfcFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNFCFlag(String value) {
        this.nfcFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad pos.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOS() {
        return pos;
    }

    /**
     * Define el valor de la propiedad pos.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOS(String value) {
        this.pos = value;
    }

    /**
     * Obtiene el valor de la propiedad salesPromoCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesPromoCD() {
        return salesPromoCD;
    }

    /**
     * Define el valor de la propiedad salesPromoCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesPromoCD(String value) {
        this.salesPromoCD = value;
    }

    /**
     * Obtiene el valor de la propiedad ddBankBranch.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDDBankBranch() {
        return ddBankBranch;
    }

    /**
     * Define el valor de la propiedad ddBankBranch.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDDBankBranch(String value) {
        this.ddBankBranch = value;
    }

    /**
     * Obtiene el valor de la propiedad ddAccountNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDDAccountNum() {
        return ddAccountNum;
    }

    /**
     * Define el valor de la propiedad ddAccountNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDDAccountNum(String value) {
        this.ddAccountNum = value;
    }

    /**
     * Obtiene el valor de la propiedad campaignCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCampaignCode() {
        return campaignCode;
    }

    /**
     * Define el valor de la propiedad campaignCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCampaignCode(String value) {
        this.campaignCode = value;
    }

    /**
     * Obtiene el valor de la propiedad programID1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgramID1() {
        return programID1;
    }

    /**
     * Define el valor de la propiedad programID1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgramID1(String value) {
        this.programID1 = value;
    }

    /**
     * Obtiene el valor de la propiedad programID2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgramID2() {
        return programID2;
    }

    /**
     * Define el valor de la propiedad programID2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgramID2(String value) {
        this.programID2 = value;
    }

    /**
     * Obtiene el valor de la propiedad readyCreditSpecificDetails.
     * 
     * @return
     *     possible object is
     *     {@link ReadyCreditSpecificDetails }
     *     
     */
    public ReadyCreditSpecificDetails getReadyCreditSpecificDetails() {
        return readyCreditSpecificDetails;
    }

    /**
     * Define el valor de la propiedad readyCreditSpecificDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link ReadyCreditSpecificDetails }
     *     
     */
    public void setReadyCreditSpecificDetails(ReadyCreditSpecificDetails value) {
        this.readyCreditSpecificDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad consentOvrLimt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsentOvrLimt() {
        return consentOvrLimt;
    }

    /**
     * Define el valor de la propiedad consentOvrLimt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsentOvrLimt(String value) {
        this.consentOvrLimt = value;
    }

    /**
     * Obtiene el valor de la propiedad providerInfoDetails.
     * 
     * @return
     *     possible object is
     *     {@link ProviderInfoDetails }
     *     
     */
    public ProviderInfoDetails getProviderInfoDetails() {
        return providerInfoDetails;
    }

    /**
     * Define el valor de la propiedad providerInfoDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link ProviderInfoDetails }
     *     
     */
    public void setProviderInfoDetails(ProviderInfoDetails value) {
        this.providerInfoDetails = value;
    }

}
