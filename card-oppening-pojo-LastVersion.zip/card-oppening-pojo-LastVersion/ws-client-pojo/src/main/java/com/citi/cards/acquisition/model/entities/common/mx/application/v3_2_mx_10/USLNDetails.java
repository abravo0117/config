
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para USLNDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="USLNDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CreditBasicDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CreditBasicDtls" minOccurs="0"/>
 *         &lt;element name="MGMDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}MGMDetails" minOccurs="0"/>
 *         &lt;element name="LoanSpecificDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}LoanSpecificDtls" minOccurs="0"/>
 *         &lt;element name="DisbBankAcctDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}DisbBankAcctDtls" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "USLNDetails", propOrder = {
    "creditBasicDtls",
    "mgmDetails",
    "loanSpecificDtls",
    "disbBankAcctDtls"
})
public class USLNDetails {

    @XmlElement(name = "CreditBasicDtls")
    protected CreditBasicDtls creditBasicDtls;
    @XmlElement(name = "MGMDetails")
    protected MGMDetails mgmDetails;
    @XmlElement(name = "LoanSpecificDtls")
    protected LoanSpecificDtls loanSpecificDtls;
    @XmlElement(name = "DisbBankAcctDtls")
    protected List<DisbBankAcctDtls> disbBankAcctDtls;

    /**
     * Obtiene el valor de la propiedad creditBasicDtls.
     * 
     * @return
     *     possible object is
     *     {@link CreditBasicDtls }
     *     
     */
    public CreditBasicDtls getCreditBasicDtls() {
        return creditBasicDtls;
    }

    /**
     * Define el valor de la propiedad creditBasicDtls.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditBasicDtls }
     *     
     */
    public void setCreditBasicDtls(CreditBasicDtls value) {
        this.creditBasicDtls = value;
    }

    /**
     * Obtiene el valor de la propiedad mgmDetails.
     * 
     * @return
     *     possible object is
     *     {@link MGMDetails }
     *     
     */
    public MGMDetails getMGMDetails() {
        return mgmDetails;
    }

    /**
     * Define el valor de la propiedad mgmDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link MGMDetails }
     *     
     */
    public void setMGMDetails(MGMDetails value) {
        this.mgmDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad loanSpecificDtls.
     * 
     * @return
     *     possible object is
     *     {@link LoanSpecificDtls }
     *     
     */
    public LoanSpecificDtls getLoanSpecificDtls() {
        return loanSpecificDtls;
    }

    /**
     * Define el valor de la propiedad loanSpecificDtls.
     * 
     * @param value
     *     allowed object is
     *     {@link LoanSpecificDtls }
     *     
     */
    public void setLoanSpecificDtls(LoanSpecificDtls value) {
        this.loanSpecificDtls = value;
    }

    /**
     * Gets the value of the disbBankAcctDtls property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the disbBankAcctDtls property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDisbBankAcctDtls().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DisbBankAcctDtls }
     * 
     * 
     */
    public List<DisbBankAcctDtls> getDisbBankAcctDtls() {
        if (disbBankAcctDtls == null) {
            disbBankAcctDtls = new ArrayList<DisbBankAcctDtls>();
        }
        return this.disbBankAcctDtls;
    }

}
