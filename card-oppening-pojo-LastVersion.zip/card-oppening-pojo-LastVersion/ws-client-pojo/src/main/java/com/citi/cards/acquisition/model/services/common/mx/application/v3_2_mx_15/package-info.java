@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;
