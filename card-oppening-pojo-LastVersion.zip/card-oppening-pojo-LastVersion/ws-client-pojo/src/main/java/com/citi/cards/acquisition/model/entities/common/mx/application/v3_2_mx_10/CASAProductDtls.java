
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CASAProductDtls complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CASAProductDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Offer" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Offer" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CASADetail" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CASADetail" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="AcquisitionAndReferral" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}AcquisitionAndReferral" minOccurs="0"/>
 *         &lt;element name="LinkedAccountDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}LinkedAccountDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CASAProductDtls", propOrder = {
    "offer",
    "casaDetail",
    "acquisitionAndReferral",
    "linkedAccountDetails"
})
public class CASAProductDtls {

    @XmlElement(name = "Offer")
    protected List<Offer> offer;
    @XmlElement(name = "CASADetail")
    protected List<CASADetail> casaDetail;
    @XmlElement(name = "AcquisitionAndReferral")
    protected AcquisitionAndReferral acquisitionAndReferral;
    @XmlElement(name = "LinkedAccountDetails")
    protected List<LinkedAccountDetails> linkedAccountDetails;

    /**
     * Gets the value of the offer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the offer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOffer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Offer }
     * 
     * 
     */
    public List<Offer> getOffer() {
        if (offer == null) {
            offer = new ArrayList<Offer>();
        }
        return this.offer;
    }

    /**
     * Gets the value of the casaDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the casaDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCASADetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CASADetail }
     * 
     * 
     */
    public List<CASADetail> getCASADetail() {
        if (casaDetail == null) {
            casaDetail = new ArrayList<CASADetail>();
        }
        return this.casaDetail;
    }

    /**
     * Obtiene el valor de la propiedad acquisitionAndReferral.
     * 
     * @return
     *     possible object is
     *     {@link AcquisitionAndReferral }
     *     
     */
    public AcquisitionAndReferral getAcquisitionAndReferral() {
        return acquisitionAndReferral;
    }

    /**
     * Define el valor de la propiedad acquisitionAndReferral.
     * 
     * @param value
     *     allowed object is
     *     {@link AcquisitionAndReferral }
     *     
     */
    public void setAcquisitionAndReferral(AcquisitionAndReferral value) {
        this.acquisitionAndReferral = value;
    }

    /**
     * Gets the value of the linkedAccountDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the linkedAccountDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLinkedAccountDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LinkedAccountDetails }
     * 
     * 
     */
    public List<LinkedAccountDetails> getLinkedAccountDetails() {
        if (linkedAccountDetails == null) {
            linkedAccountDetails = new ArrayList<LinkedAccountDetails>();
        }
        return this.linkedAccountDetails;
    }

}
