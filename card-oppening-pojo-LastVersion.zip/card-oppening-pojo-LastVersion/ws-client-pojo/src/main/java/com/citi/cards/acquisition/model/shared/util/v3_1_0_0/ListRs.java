
package com.citi.cards.acquisition.model.shared.util.v3_1_0_0;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;

import com.citi.cards.acquisition.model.shared.datatypes.v3_1_0_0.MoreIndicator;


/**
 * <p>Clase Java para ListRs complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ListRs">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="NextStartIndex" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}ListIndex" minOccurs="0"/>
 *         &lt;element name="MoreIndicator" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}MoreIndicator" minOccurs="0"/>
 *         &lt;element name="Size" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}ListSize" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListRs", propOrder = {
    "nextStartIndex",
    "moreIndicator",
    "size"
})
public class ListRs {

    @XmlElement(name = "NextStartIndex")
    protected String nextStartIndex;
    @XmlElement(name = "MoreIndicator")
    @XmlSchemaType(name = "string")
    protected MoreIndicator moreIndicator;
    @XmlElement(name = "Size")
    protected BigInteger size;

    /**
     * Obtiene el valor de la propiedad nextStartIndex.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNextStartIndex() {
        return nextStartIndex;
    }

    /**
     * Define el valor de la propiedad nextStartIndex.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNextStartIndex(String value) {
        this.nextStartIndex = value;
    }

    /**
     * Obtiene el valor de la propiedad moreIndicator.
     * 
     * @return
     *     possible object is
     *     {@link MoreIndicator }
     *     
     */
    public MoreIndicator getMoreIndicator() {
        return moreIndicator;
    }

    /**
     * Define el valor de la propiedad moreIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link MoreIndicator }
     *     
     */
    public void setMoreIndicator(MoreIndicator value) {
        this.moreIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad size.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getSize() {
        return size;
    }

    /**
     * Define el valor de la propiedad size.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setSize(BigInteger value) {
        this.size = value;
    }

}
