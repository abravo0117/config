
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para StatementAdditional complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="StatementAdditional">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RecType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RecValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PreferedLang" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RegCycleToDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SeqFromAddi" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatementAdditional", propOrder = {
    "recType",
    "recValue",
    "seqNo",
    "preferedLang",
    "regCycleToDate",
    "seqFromAddi"
})
public class StatementAdditional {

    @XmlElement(name = "RecType")
    protected String recType;
    @XmlElement(name = "RecValue")
    protected String recValue;
    @XmlElement(name = "SeqNo")
    protected String seqNo;
    @XmlElement(name = "PreferedLang")
    protected String preferedLang;
    @XmlElement(name = "RegCycleToDate")
    protected String regCycleToDate;
    @XmlElement(name = "SeqFromAddi")
    protected String seqFromAddi;

    /**
     * Obtiene el valor de la propiedad recType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecType() {
        return recType;
    }

    /**
     * Define el valor de la propiedad recType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecType(String value) {
        this.recType = value;
    }

    /**
     * Obtiene el valor de la propiedad recValue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecValue() {
        return recValue;
    }

    /**
     * Define el valor de la propiedad recValue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecValue(String value) {
        this.recValue = value;
    }

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad preferedLang.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreferedLang() {
        return preferedLang;
    }

    /**
     * Define el valor de la propiedad preferedLang.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreferedLang(String value) {
        this.preferedLang = value;
    }

    /**
     * Obtiene el valor de la propiedad regCycleToDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegCycleToDate() {
        return regCycleToDate;
    }

    /**
     * Define el valor de la propiedad regCycleToDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegCycleToDate(String value) {
        this.regCycleToDate = value;
    }

    /**
     * Obtiene el valor de la propiedad seqFromAddi.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqFromAddi() {
        return seqFromAddi;
    }

    /**
     * Define el valor de la propiedad seqFromAddi.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqFromAddi(String value) {
        this.seqFromAddi = value;
    }

}
