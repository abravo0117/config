
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para COBrandDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="COBrandDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CoBrandPrtrName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoBrandCustName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoBrandCustSur" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoBrandMemNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoBrandOldMemNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoMarketingRefNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "COBrandDetails", propOrder = {
    "coBrandPrtrName",
    "coBrandCustName",
    "coBrandCustSur",
    "coBrandMemNo",
    "coBrandOldMemNo",
    "coMarketingRefNo"
})
public class COBrandDetails {

    @XmlElement(name = "CoBrandPrtrName")
    protected String coBrandPrtrName;
    @XmlElement(name = "CoBrandCustName")
    protected String coBrandCustName;
    @XmlElement(name = "CoBrandCustSur")
    protected String coBrandCustSur;
    @XmlElement(name = "CoBrandMemNo")
    protected String coBrandMemNo;
    @XmlElement(name = "CoBrandOldMemNo")
    protected String coBrandOldMemNo;
    @XmlElement(name = "CoMarketingRefNo")
    protected String coMarketingRefNo;

    /**
     * Obtiene el valor de la propiedad coBrandPrtrName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBrandPrtrName() {
        return coBrandPrtrName;
    }

    /**
     * Define el valor de la propiedad coBrandPrtrName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBrandPrtrName(String value) {
        this.coBrandPrtrName = value;
    }

    /**
     * Obtiene el valor de la propiedad coBrandCustName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBrandCustName() {
        return coBrandCustName;
    }

    /**
     * Define el valor de la propiedad coBrandCustName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBrandCustName(String value) {
        this.coBrandCustName = value;
    }

    /**
     * Obtiene el valor de la propiedad coBrandCustSur.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBrandCustSur() {
        return coBrandCustSur;
    }

    /**
     * Define el valor de la propiedad coBrandCustSur.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBrandCustSur(String value) {
        this.coBrandCustSur = value;
    }

    /**
     * Obtiene el valor de la propiedad coBrandMemNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBrandMemNo() {
        return coBrandMemNo;
    }

    /**
     * Define el valor de la propiedad coBrandMemNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBrandMemNo(String value) {
        this.coBrandMemNo = value;
    }

    /**
     * Obtiene el valor de la propiedad coBrandOldMemNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoBrandOldMemNo() {
        return coBrandOldMemNo;
    }

    /**
     * Define el valor de la propiedad coBrandOldMemNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoBrandOldMemNo(String value) {
        this.coBrandOldMemNo = value;
    }

    /**
     * Obtiene el valor de la propiedad coMarketingRefNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCoMarketingRefNo() {
        return coMarketingRefNo;
    }

    /**
     * Define el valor de la propiedad coMarketingRefNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCoMarketingRefNo(String value) {
        this.coMarketingRefNo = value;
    }

}
