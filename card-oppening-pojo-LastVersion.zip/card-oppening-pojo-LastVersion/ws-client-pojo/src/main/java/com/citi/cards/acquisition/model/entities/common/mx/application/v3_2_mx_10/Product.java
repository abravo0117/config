
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Product complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Product">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Logo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Org" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BillTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PinTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BillToDelivery" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardToDelivery" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CollectionLocation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmbosserName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InstantIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ATMCardReqdFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChequeBookReqdFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditShieldIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GiftCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CCLFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SpendLimitAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MerchantId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MerchantIdOrg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SignIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditLineAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CampaignCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountTitle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LoyaltyBonus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProgramID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField7" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField8" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField9" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField10" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField11" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField12" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField13" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField14" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField15" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField16" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField17" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField18" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField19" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField20" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PlasticID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PreCreatedCardNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hasAcceptanceSigned" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="hasEBankingRequestSigned" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="hasCreditBureauCheckAuthorizationSigned" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="hasAutoChargeConsentSigned" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hasTermsAndConditionsAcceptanceSigned" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="hasCreditLineIncreaseRequestSigned" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="hasInsuranceRequestSigned" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="hasServicesPaymentRequestSigned" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hasMarketingConsentSigned" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="hasEBankPINRequestSigned" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="hasSupplementaryCardApplicationSigned" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="hasUpgradeProductRequestSigned" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="RewardType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MaxAuthorizedAmount" type="{http://www.w3.org/2001/XMLSchema}double" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="MaxAmountToCharge" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="CreditCardPaymentFlag" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="CurrentOwnedProduct" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DesiredProduct" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SMSAndEmailFlag" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="isLibraServiceRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isBalanceProtectionInsuranceRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isDeporteismoAssistanceRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isProtectionInsuranceRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isEStatementRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ProductFamily" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LoanRequestAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="isEBankingRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isPriorityPassCardRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="RequestedCreditLineAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="CardNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SuggestedPreCreatedCardCreditLimit" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="DDAAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DDABranchNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DisbursementType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RequestedTenor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FeeCollectionMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CLIAccountNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RejectReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SpecialInterestRate" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Product", propOrder = {
    "logo",
    "org",
    "sourceCode",
    "billTo",
    "cardTo",
    "pinTo",
    "billToDelivery",
    "cardToDelivery",
    "collectionLocation",
    "embosserName",
    "instantIndicator",
    "atmCardReqdFlag",
    "chequeBookReqdFlag",
    "creditShieldIndicator",
    "giftCode",
    "cclFlag",
    "spendLimitAmount",
    "merchantId",
    "merchantIdOrg",
    "signIndicator",
    "creditLineAmount",
    "campaignCode",
    "accountTitle",
    "loyaltyBonus",
    "programID",
    "ctrySpecField1",
    "ctrySpecField2",
    "ctrySpecField3",
    "ctrySpecField4",
    "ctrySpecField5",
    "ctrySpecField6",
    "ctrySpecField7",
    "ctrySpecField8",
    "ctrySpecField9",
    "ctrySpecField10",
    "ctrySpecField11",
    "ctrySpecField12",
    "ctrySpecField13",
    "ctrySpecField14",
    "ctrySpecField15",
    "ctrySpecField16",
    "ctrySpecField17",
    "ctrySpecField18",
    "ctrySpecField19",
    "ctrySpecField20",
    "plasticID",
    "preCreatedCardNo",
    "hasAcceptanceSigned",
    "hasEBankingRequestSigned",
    "hasCreditBureauCheckAuthorizationSigned",
    "hasAutoChargeConsentSigned",
    "hasTermsAndConditionsAcceptanceSigned",
    "hasCreditLineIncreaseRequestSigned",
    "hasInsuranceRequestSigned",
    "hasServicesPaymentRequestSigned",
    "hasMarketingConsentSigned",
    "hasEBankPINRequestSigned",
    "hasSupplementaryCardApplicationSigned",
    "hasUpgradeProductRequestSigned",
    "rewardType",
    "maxAuthorizedAmount",
    "maxAmountToCharge",
    "creditCardPaymentFlag",
    "currentOwnedProduct",
    "desiredProduct",
    "smsAndEmailFlag",
    "isLibraServiceRequested",
    "isBalanceProtectionInsuranceRequested",
    "isDeporteismoAssistanceRequested",
    "isProtectionInsuranceRequested",
    "isEStatementRequested",
    "productFamily",
    "loanRequestAmount",
    "isEBankingRequested",
    "isPriorityPassCardRequested",
    "requestedCreditLineAmount",
    "cardNo",
    "suggestedPreCreatedCardCreditLimit",
    "ddaAccountNumber",
    "ddaBranchNumber",
    "disbursementType",
    "requestedTenor",
    "feeCollectionMode",
    "cliAccountNumber",
    "rejectReasonCode",
    "specialInterestRate"
})
public class Product {

    @XmlElement(name = "Logo")
    protected String logo;
    @XmlElement(name = "Org")
    protected String org;
    @XmlElement(name = "SourceCode")
    protected String sourceCode;
    @XmlElement(name = "BillTo")
    protected String billTo;
    @XmlElement(name = "CardTo")
    protected String cardTo;
    @XmlElement(name = "PinTo")
    protected String pinTo;
    @XmlElement(name = "BillToDelivery")
    protected String billToDelivery;
    @XmlElement(name = "CardToDelivery")
    protected String cardToDelivery;
    @XmlElement(name = "CollectionLocation")
    protected String collectionLocation;
    @XmlElement(name = "EmbosserName")
    protected String embosserName;
    @XmlElement(name = "InstantIndicator")
    protected String instantIndicator;
    @XmlElement(name = "ATMCardReqdFlag")
    protected String atmCardReqdFlag;
    @XmlElement(name = "ChequeBookReqdFlag")
    protected String chequeBookReqdFlag;
    @XmlElement(name = "CreditShieldIndicator")
    protected String creditShieldIndicator;
    @XmlElement(name = "GiftCode")
    protected String giftCode;
    @XmlElement(name = "CCLFlag")
    protected String cclFlag;
    @XmlElement(name = "SpendLimitAmount")
    protected String spendLimitAmount;
    @XmlElement(name = "MerchantId")
    protected String merchantId;
    @XmlElement(name = "MerchantIdOrg")
    protected String merchantIdOrg;
    @XmlElement(name = "SignIndicator")
    protected String signIndicator;
    @XmlElement(name = "CreditLineAmount")
    protected String creditLineAmount;
    @XmlElement(name = "CampaignCode")
    protected String campaignCode;
    @XmlElement(name = "AccountTitle")
    protected String accountTitle;
    @XmlElement(name = "LoyaltyBonus")
    protected String loyaltyBonus;
    @XmlElement(name = "ProgramID")
    protected String programID;
    @XmlElement(name = "CtrySpecField1")
    protected String ctrySpecField1;
    @XmlElement(name = "CtrySpecField2")
    protected String ctrySpecField2;
    @XmlElement(name = "CtrySpecField3")
    protected String ctrySpecField3;
    @XmlElement(name = "CtrySpecField4")
    protected String ctrySpecField4;
    @XmlElement(name = "CtrySpecField5")
    protected String ctrySpecField5;
    @XmlElement(name = "CtrySpecField6")
    protected String ctrySpecField6;
    @XmlElement(name = "CtrySpecField7")
    protected String ctrySpecField7;
    @XmlElement(name = "CtrySpecField8")
    protected String ctrySpecField8;
    @XmlElement(name = "CtrySpecField9")
    protected String ctrySpecField9;
    @XmlElement(name = "CtrySpecField10")
    protected String ctrySpecField10;
    @XmlElement(name = "CtrySpecField11")
    protected String ctrySpecField11;
    @XmlElement(name = "CtrySpecField12")
    protected String ctrySpecField12;
    @XmlElement(name = "CtrySpecField13")
    protected String ctrySpecField13;
    @XmlElement(name = "CtrySpecField14")
    protected String ctrySpecField14;
    @XmlElement(name = "CtrySpecField15")
    protected String ctrySpecField15;
    @XmlElement(name = "CtrySpecField16")
    protected String ctrySpecField16;
    @XmlElement(name = "CtrySpecField17")
    protected String ctrySpecField17;
    @XmlElement(name = "CtrySpecField18")
    protected String ctrySpecField18;
    @XmlElement(name = "CtrySpecField19")
    protected String ctrySpecField19;
    @XmlElement(name = "CtrySpecField20")
    protected String ctrySpecField20;
    @XmlElement(name = "PlasticID")
    protected String plasticID;
    @XmlElement(name = "PreCreatedCardNo")
    protected String preCreatedCardNo;
    protected String hasAcceptanceSigned;
    protected String hasEBankingRequestSigned;
    protected String hasCreditBureauCheckAuthorizationSigned;
    protected String hasAutoChargeConsentSigned;
    protected String hasTermsAndConditionsAcceptanceSigned;
    protected String hasCreditLineIncreaseRequestSigned;
    protected String hasInsuranceRequestSigned;
    protected String hasServicesPaymentRequestSigned;
    protected String hasMarketingConsentSigned;
    protected String hasEBankPINRequestSigned;
    protected String hasSupplementaryCardApplicationSigned;
    protected String hasUpgradeProductRequestSigned;
    @XmlElement(name = "RewardType")
    protected String rewardType;
    @XmlElement(name = "MaxAuthorizedAmount", type = Double.class)
    protected List<Double> maxAuthorizedAmount;
    @XmlElement(name = "MaxAmountToCharge")
    protected Double maxAmountToCharge;
    @XmlElement(name = "CreditCardPaymentFlag")
    protected String creditCardPaymentFlag;
    @XmlElement(name = "CurrentOwnedProduct")
    protected String currentOwnedProduct;
    @XmlElement(name = "DesiredProduct")
    protected String desiredProduct;
    @XmlElement(name = "SMSAndEmailFlag")
    protected String smsAndEmailFlag;
    protected Boolean isLibraServiceRequested;
    protected Boolean isBalanceProtectionInsuranceRequested;
    protected Boolean isDeporteismoAssistanceRequested;
    protected Boolean isProtectionInsuranceRequested;
    protected Boolean isEStatementRequested;
    @XmlElement(name = "ProductFamily")
    protected String productFamily;
    @XmlElement(name = "LoanRequestAmount")
    protected Double loanRequestAmount;
    protected Boolean isEBankingRequested;
    protected Boolean isPriorityPassCardRequested;
    @XmlElement(name = "RequestedCreditLineAmount")
    protected Double requestedCreditLineAmount;
    @XmlElement(name = "CardNo")
    protected String cardNo;
    @XmlElement(name = "SuggestedPreCreatedCardCreditLimit")
    protected Double suggestedPreCreatedCardCreditLimit;
    @XmlElement(name = "DDAAccountNumber")
    protected String ddaAccountNumber;
    @XmlElement(name = "DDABranchNumber")
    protected String ddaBranchNumber;
    @XmlElement(name = "DisbursementType")
    protected String disbursementType;
    @XmlElement(name = "RequestedTenor")
    protected String requestedTenor;
    @XmlElement(name = "FeeCollectionMode")
    protected String feeCollectionMode;
    @XmlElement(name = "CLIAccountNumber")
    protected String cliAccountNumber;
    @XmlElement(name = "RejectReasonCode")
    protected String rejectReasonCode;
    @XmlElement(name = "SpecialInterestRate")
    protected Double specialInterestRate;

    /**
     * Obtiene el valor de la propiedad logo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogo() {
        return logo;
    }

    /**
     * Define el valor de la propiedad logo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogo(String value) {
        this.logo = value;
    }

    /**
     * Obtiene el valor de la propiedad org.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrg() {
        return org;
    }

    /**
     * Define el valor de la propiedad org.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrg(String value) {
        this.org = value;
    }

    /**
     * Obtiene el valor de la propiedad sourceCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceCode() {
        return sourceCode;
    }

    /**
     * Define el valor de la propiedad sourceCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceCode(String value) {
        this.sourceCode = value;
    }

    /**
     * Obtiene el valor de la propiedad billTo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillTo() {
        return billTo;
    }

    /**
     * Define el valor de la propiedad billTo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillTo(String value) {
        this.billTo = value;
    }

    /**
     * Obtiene el valor de la propiedad cardTo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardTo() {
        return cardTo;
    }

    /**
     * Define el valor de la propiedad cardTo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardTo(String value) {
        this.cardTo = value;
    }

    /**
     * Obtiene el valor de la propiedad pinTo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPinTo() {
        return pinTo;
    }

    /**
     * Define el valor de la propiedad pinTo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPinTo(String value) {
        this.pinTo = value;
    }

    /**
     * Obtiene el valor de la propiedad billToDelivery.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillToDelivery() {
        return billToDelivery;
    }

    /**
     * Define el valor de la propiedad billToDelivery.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillToDelivery(String value) {
        this.billToDelivery = value;
    }

    /**
     * Obtiene el valor de la propiedad cardToDelivery.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardToDelivery() {
        return cardToDelivery;
    }

    /**
     * Define el valor de la propiedad cardToDelivery.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardToDelivery(String value) {
        this.cardToDelivery = value;
    }

    /**
     * Obtiene el valor de la propiedad collectionLocation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollectionLocation() {
        return collectionLocation;
    }

    /**
     * Define el valor de la propiedad collectionLocation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollectionLocation(String value) {
        this.collectionLocation = value;
    }

    /**
     * Obtiene el valor de la propiedad embosserName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmbosserName() {
        return embosserName;
    }

    /**
     * Define el valor de la propiedad embosserName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbosserName(String value) {
        this.embosserName = value;
    }

    /**
     * Obtiene el valor de la propiedad instantIndicator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstantIndicator() {
        return instantIndicator;
    }

    /**
     * Define el valor de la propiedad instantIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstantIndicator(String value) {
        this.instantIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad atmCardReqdFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getATMCardReqdFlag() {
        return atmCardReqdFlag;
    }

    /**
     * Define el valor de la propiedad atmCardReqdFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setATMCardReqdFlag(String value) {
        this.atmCardReqdFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad chequeBookReqdFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChequeBookReqdFlag() {
        return chequeBookReqdFlag;
    }

    /**
     * Define el valor de la propiedad chequeBookReqdFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChequeBookReqdFlag(String value) {
        this.chequeBookReqdFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad creditShieldIndicator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditShieldIndicator() {
        return creditShieldIndicator;
    }

    /**
     * Define el valor de la propiedad creditShieldIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditShieldIndicator(String value) {
        this.creditShieldIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad giftCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGiftCode() {
        return giftCode;
    }

    /**
     * Define el valor de la propiedad giftCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGiftCode(String value) {
        this.giftCode = value;
    }

    /**
     * Obtiene el valor de la propiedad cclFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCCLFlag() {
        return cclFlag;
    }

    /**
     * Define el valor de la propiedad cclFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCCLFlag(String value) {
        this.cclFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad spendLimitAmount.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpendLimitAmount() {
        return spendLimitAmount;
    }

    /**
     * Define el valor de la propiedad spendLimitAmount.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpendLimitAmount(String value) {
        this.spendLimitAmount = value;
    }

    /**
     * Obtiene el valor de la propiedad merchantId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMerchantId() {
        return merchantId;
    }

    /**
     * Define el valor de la propiedad merchantId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantId(String value) {
        this.merchantId = value;
    }

    /**
     * Obtiene el valor de la propiedad merchantIdOrg.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMerchantIdOrg() {
        return merchantIdOrg;
    }

    /**
     * Define el valor de la propiedad merchantIdOrg.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantIdOrg(String value) {
        this.merchantIdOrg = value;
    }

    /**
     * Obtiene el valor de la propiedad signIndicator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignIndicator() {
        return signIndicator;
    }

    /**
     * Define el valor de la propiedad signIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignIndicator(String value) {
        this.signIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad creditLineAmount.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditLineAmount() {
        return creditLineAmount;
    }

    /**
     * Define el valor de la propiedad creditLineAmount.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditLineAmount(String value) {
        this.creditLineAmount = value;
    }

    /**
     * Obtiene el valor de la propiedad campaignCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCampaignCode() {
        return campaignCode;
    }

    /**
     * Define el valor de la propiedad campaignCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCampaignCode(String value) {
        this.campaignCode = value;
    }

    /**
     * Obtiene el valor de la propiedad accountTitle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountTitle() {
        return accountTitle;
    }

    /**
     * Define el valor de la propiedad accountTitle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountTitle(String value) {
        this.accountTitle = value;
    }

    /**
     * Obtiene el valor de la propiedad loyaltyBonus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoyaltyBonus() {
        return loyaltyBonus;
    }

    /**
     * Define el valor de la propiedad loyaltyBonus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoyaltyBonus(String value) {
        this.loyaltyBonus = value;
    }

    /**
     * Obtiene el valor de la propiedad programID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgramID() {
        return programID;
    }

    /**
     * Define el valor de la propiedad programID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgramID(String value) {
        this.programID = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField1() {
        return ctrySpecField1;
    }

    /**
     * Define el valor de la propiedad ctrySpecField1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField1(String value) {
        this.ctrySpecField1 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField2() {
        return ctrySpecField2;
    }

    /**
     * Define el valor de la propiedad ctrySpecField2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField2(String value) {
        this.ctrySpecField2 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField3() {
        return ctrySpecField3;
    }

    /**
     * Define el valor de la propiedad ctrySpecField3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField3(String value) {
        this.ctrySpecField3 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField4() {
        return ctrySpecField4;
    }

    /**
     * Define el valor de la propiedad ctrySpecField4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField4(String value) {
        this.ctrySpecField4 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField5.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField5() {
        return ctrySpecField5;
    }

    /**
     * Define el valor de la propiedad ctrySpecField5.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField5(String value) {
        this.ctrySpecField5 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField6.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField6() {
        return ctrySpecField6;
    }

    /**
     * Define el valor de la propiedad ctrySpecField6.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField6(String value) {
        this.ctrySpecField6 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField7.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField7() {
        return ctrySpecField7;
    }

    /**
     * Define el valor de la propiedad ctrySpecField7.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField7(String value) {
        this.ctrySpecField7 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField8.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField8() {
        return ctrySpecField8;
    }

    /**
     * Define el valor de la propiedad ctrySpecField8.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField8(String value) {
        this.ctrySpecField8 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField9.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField9() {
        return ctrySpecField9;
    }

    /**
     * Define el valor de la propiedad ctrySpecField9.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField9(String value) {
        this.ctrySpecField9 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField10.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField10() {
        return ctrySpecField10;
    }

    /**
     * Define el valor de la propiedad ctrySpecField10.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField10(String value) {
        this.ctrySpecField10 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField11.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField11() {
        return ctrySpecField11;
    }

    /**
     * Define el valor de la propiedad ctrySpecField11.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField11(String value) {
        this.ctrySpecField11 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField12.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField12() {
        return ctrySpecField12;
    }

    /**
     * Define el valor de la propiedad ctrySpecField12.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField12(String value) {
        this.ctrySpecField12 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField13.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField13() {
        return ctrySpecField13;
    }

    /**
     * Define el valor de la propiedad ctrySpecField13.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField13(String value) {
        this.ctrySpecField13 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField14.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField14() {
        return ctrySpecField14;
    }

    /**
     * Define el valor de la propiedad ctrySpecField14.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField14(String value) {
        this.ctrySpecField14 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField15.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField15() {
        return ctrySpecField15;
    }

    /**
     * Define el valor de la propiedad ctrySpecField15.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField15(String value) {
        this.ctrySpecField15 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField16.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField16() {
        return ctrySpecField16;
    }

    /**
     * Define el valor de la propiedad ctrySpecField16.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField16(String value) {
        this.ctrySpecField16 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField17.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField17() {
        return ctrySpecField17;
    }

    /**
     * Define el valor de la propiedad ctrySpecField17.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField17(String value) {
        this.ctrySpecField17 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField18.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField18() {
        return ctrySpecField18;
    }

    /**
     * Define el valor de la propiedad ctrySpecField18.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField18(String value) {
        this.ctrySpecField18 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField19.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField19() {
        return ctrySpecField19;
    }

    /**
     * Define el valor de la propiedad ctrySpecField19.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField19(String value) {
        this.ctrySpecField19 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField20.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField20() {
        return ctrySpecField20;
    }

    /**
     * Define el valor de la propiedad ctrySpecField20.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField20(String value) {
        this.ctrySpecField20 = value;
    }

    /**
     * Obtiene el valor de la propiedad plasticID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlasticID() {
        return plasticID;
    }

    /**
     * Define el valor de la propiedad plasticID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlasticID(String value) {
        this.plasticID = value;
    }

    /**
     * Obtiene el valor de la propiedad preCreatedCardNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreCreatedCardNo() {
        return preCreatedCardNo;
    }

    /**
     * Define el valor de la propiedad preCreatedCardNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreCreatedCardNo(String value) {
        this.preCreatedCardNo = value;
    }

    /**
     * Obtiene el valor de la propiedad hasAcceptanceSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasAcceptanceSigned() {
        return hasAcceptanceSigned;
    }

    /**
     * Define el valor de la propiedad hasAcceptanceSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasAcceptanceSigned(String value) {
        this.hasAcceptanceSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad hasEBankingRequestSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasEBankingRequestSigned() {
        return hasEBankingRequestSigned;
    }

    /**
     * Define el valor de la propiedad hasEBankingRequestSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasEBankingRequestSigned(String value) {
        this.hasEBankingRequestSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad hasCreditBureauCheckAuthorizationSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasCreditBureauCheckAuthorizationSigned() {
        return hasCreditBureauCheckAuthorizationSigned;
    }

    /**
     * Define el valor de la propiedad hasCreditBureauCheckAuthorizationSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasCreditBureauCheckAuthorizationSigned(String value) {
        this.hasCreditBureauCheckAuthorizationSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad hasAutoChargeConsentSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasAutoChargeConsentSigned() {
        return hasAutoChargeConsentSigned;
    }

    /**
     * Define el valor de la propiedad hasAutoChargeConsentSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasAutoChargeConsentSigned(String value) {
        this.hasAutoChargeConsentSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad hasTermsAndConditionsAcceptanceSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasTermsAndConditionsAcceptanceSigned() {
        return hasTermsAndConditionsAcceptanceSigned;
    }

    /**
     * Define el valor de la propiedad hasTermsAndConditionsAcceptanceSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasTermsAndConditionsAcceptanceSigned(String value) {
        this.hasTermsAndConditionsAcceptanceSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad hasCreditLineIncreaseRequestSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasCreditLineIncreaseRequestSigned() {
        return hasCreditLineIncreaseRequestSigned;
    }

    /**
     * Define el valor de la propiedad hasCreditLineIncreaseRequestSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasCreditLineIncreaseRequestSigned(String value) {
        this.hasCreditLineIncreaseRequestSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad hasInsuranceRequestSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasInsuranceRequestSigned() {
        return hasInsuranceRequestSigned;
    }

    /**
     * Define el valor de la propiedad hasInsuranceRequestSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasInsuranceRequestSigned(String value) {
        this.hasInsuranceRequestSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad hasServicesPaymentRequestSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasServicesPaymentRequestSigned() {
        return hasServicesPaymentRequestSigned;
    }

    /**
     * Define el valor de la propiedad hasServicesPaymentRequestSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasServicesPaymentRequestSigned(String value) {
        this.hasServicesPaymentRequestSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad hasMarketingConsentSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasMarketingConsentSigned() {
        return hasMarketingConsentSigned;
    }

    /**
     * Define el valor de la propiedad hasMarketingConsentSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasMarketingConsentSigned(String value) {
        this.hasMarketingConsentSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad hasEBankPINRequestSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasEBankPINRequestSigned() {
        return hasEBankPINRequestSigned;
    }

    /**
     * Define el valor de la propiedad hasEBankPINRequestSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasEBankPINRequestSigned(String value) {
        this.hasEBankPINRequestSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad hasSupplementaryCardApplicationSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasSupplementaryCardApplicationSigned() {
        return hasSupplementaryCardApplicationSigned;
    }

    /**
     * Define el valor de la propiedad hasSupplementaryCardApplicationSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasSupplementaryCardApplicationSigned(String value) {
        this.hasSupplementaryCardApplicationSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad hasUpgradeProductRequestSigned.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHasUpgradeProductRequestSigned() {
        return hasUpgradeProductRequestSigned;
    }

    /**
     * Define el valor de la propiedad hasUpgradeProductRequestSigned.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasUpgradeProductRequestSigned(String value) {
        this.hasUpgradeProductRequestSigned = value;
    }

    /**
     * Obtiene el valor de la propiedad rewardType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRewardType() {
        return rewardType;
    }

    /**
     * Define el valor de la propiedad rewardType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRewardType(String value) {
        this.rewardType = value;
    }

    /**
     * Gets the value of the maxAuthorizedAmount property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the maxAuthorizedAmount property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMaxAuthorizedAmount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Double }
     * 
     * 
     */
    public List<Double> getMaxAuthorizedAmount() {
        if (maxAuthorizedAmount == null) {
            maxAuthorizedAmount = new ArrayList<Double>();
        }
        return this.maxAuthorizedAmount;
    }

    /**
     * Obtiene el valor de la propiedad maxAmountToCharge.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getMaxAmountToCharge() {
        return maxAmountToCharge;
    }

    /**
     * Define el valor de la propiedad maxAmountToCharge.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setMaxAmountToCharge(Double value) {
        this.maxAmountToCharge = value;
    }

    /**
     * Obtiene el valor de la propiedad creditCardPaymentFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditCardPaymentFlag() {
        return creditCardPaymentFlag;
    }

    /**
     * Define el valor de la propiedad creditCardPaymentFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditCardPaymentFlag(String value) {
        this.creditCardPaymentFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad currentOwnedProduct.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentOwnedProduct() {
        return currentOwnedProduct;
    }

    /**
     * Define el valor de la propiedad currentOwnedProduct.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentOwnedProduct(String value) {
        this.currentOwnedProduct = value;
    }

    /**
     * Obtiene el valor de la propiedad desiredProduct.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesiredProduct() {
        return desiredProduct;
    }

    /**
     * Define el valor de la propiedad desiredProduct.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesiredProduct(String value) {
        this.desiredProduct = value;
    }

    /**
     * Obtiene el valor de la propiedad smsAndEmailFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSMSAndEmailFlag() {
        return smsAndEmailFlag;
    }

    /**
     * Define el valor de la propiedad smsAndEmailFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSMSAndEmailFlag(String value) {
        this.smsAndEmailFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad isLibraServiceRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsLibraServiceRequested() {
        return isLibraServiceRequested;
    }

    /**
     * Define el valor de la propiedad isLibraServiceRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsLibraServiceRequested(Boolean value) {
        this.isLibraServiceRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad isBalanceProtectionInsuranceRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsBalanceProtectionInsuranceRequested() {
        return isBalanceProtectionInsuranceRequested;
    }

    /**
     * Define el valor de la propiedad isBalanceProtectionInsuranceRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsBalanceProtectionInsuranceRequested(Boolean value) {
        this.isBalanceProtectionInsuranceRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad isDeporteismoAssistanceRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsDeporteismoAssistanceRequested() {
        return isDeporteismoAssistanceRequested;
    }

    /**
     * Define el valor de la propiedad isDeporteismoAssistanceRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsDeporteismoAssistanceRequested(Boolean value) {
        this.isDeporteismoAssistanceRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad isProtectionInsuranceRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsProtectionInsuranceRequested() {
        return isProtectionInsuranceRequested;
    }

    /**
     * Define el valor de la propiedad isProtectionInsuranceRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsProtectionInsuranceRequested(Boolean value) {
        this.isProtectionInsuranceRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad isEStatementRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsEStatementRequested() {
        return isEStatementRequested;
    }

    /**
     * Define el valor de la propiedad isEStatementRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsEStatementRequested(Boolean value) {
        this.isEStatementRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad productFamily.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductFamily() {
        return productFamily;
    }

    /**
     * Define el valor de la propiedad productFamily.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductFamily(String value) {
        this.productFamily = value;
    }

    /**
     * Obtiene el valor de la propiedad loanRequestAmount.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getLoanRequestAmount() {
        return loanRequestAmount;
    }

    /**
     * Define el valor de la propiedad loanRequestAmount.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setLoanRequestAmount(Double value) {
        this.loanRequestAmount = value;
    }

    /**
     * Obtiene el valor de la propiedad isEBankingRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsEBankingRequested() {
        return isEBankingRequested;
    }

    /**
     * Define el valor de la propiedad isEBankingRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsEBankingRequested(Boolean value) {
        this.isEBankingRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad isPriorityPassCardRequested.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsPriorityPassCardRequested() {
        return isPriorityPassCardRequested;
    }

    /**
     * Define el valor de la propiedad isPriorityPassCardRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsPriorityPassCardRequested(Boolean value) {
        this.isPriorityPassCardRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad requestedCreditLineAmount.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getRequestedCreditLineAmount() {
        return requestedCreditLineAmount;
    }

    /**
     * Define el valor de la propiedad requestedCreditLineAmount.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setRequestedCreditLineAmount(Double value) {
        this.requestedCreditLineAmount = value;
    }

    /**
     * Obtiene el valor de la propiedad cardNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardNo() {
        return cardNo;
    }

    /**
     * Define el valor de la propiedad cardNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardNo(String value) {
        this.cardNo = value;
    }

    /**
     * Obtiene el valor de la propiedad suggestedPreCreatedCardCreditLimit.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSuggestedPreCreatedCardCreditLimit() {
        return suggestedPreCreatedCardCreditLimit;
    }

    /**
     * Define el valor de la propiedad suggestedPreCreatedCardCreditLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSuggestedPreCreatedCardCreditLimit(Double value) {
        this.suggestedPreCreatedCardCreditLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad ddaAccountNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDDAAccountNumber() {
        return ddaAccountNumber;
    }

    /**
     * Define el valor de la propiedad ddaAccountNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDDAAccountNumber(String value) {
        this.ddaAccountNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad ddaBranchNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDDABranchNumber() {
        return ddaBranchNumber;
    }

    /**
     * Define el valor de la propiedad ddaBranchNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDDABranchNumber(String value) {
        this.ddaBranchNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad disbursementType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisbursementType() {
        return disbursementType;
    }

    /**
     * Define el valor de la propiedad disbursementType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisbursementType(String value) {
        this.disbursementType = value;
    }

    /**
     * Obtiene el valor de la propiedad requestedTenor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestedTenor() {
        return requestedTenor;
    }

    /**
     * Define el valor de la propiedad requestedTenor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestedTenor(String value) {
        this.requestedTenor = value;
    }

    /**
     * Obtiene el valor de la propiedad feeCollectionMode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFeeCollectionMode() {
        return feeCollectionMode;
    }

    /**
     * Define el valor de la propiedad feeCollectionMode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFeeCollectionMode(String value) {
        this.feeCollectionMode = value;
    }

    /**
     * Obtiene el valor de la propiedad cliAccountNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLIAccountNumber() {
        return cliAccountNumber;
    }

    /**
     * Define el valor de la propiedad cliAccountNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLIAccountNumber(String value) {
        this.cliAccountNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad rejectReasonCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRejectReasonCode() {
        return rejectReasonCode;
    }

    /**
     * Define el valor de la propiedad rejectReasonCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRejectReasonCode(String value) {
        this.rejectReasonCode = value;
    }

    /**
     * Obtiene el valor de la propiedad specialInterestRate.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSpecialInterestRate() {
        return specialInterestRate;
    }

    /**
     * Define el valor de la propiedad specialInterestRate.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSpecialInterestRate(Double value) {
        this.specialInterestRate = value;
    }

}
