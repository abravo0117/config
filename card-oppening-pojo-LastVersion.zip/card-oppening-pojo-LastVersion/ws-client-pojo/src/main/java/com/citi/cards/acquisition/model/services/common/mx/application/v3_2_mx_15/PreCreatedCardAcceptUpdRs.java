
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.GenericResponse;


/**
 * <p>Clase Java para PreCreatedCardAcceptUpdRs complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PreCreatedCardAcceptUpdRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="Time" type="{http://www.w3.org/2001/XMLSchema}time"/>
 *         &lt;element name="System" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ServiceOperationName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicationID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PreCreatedCardLogo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PlasticID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PreCreatedCardNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PreCreatedCardCreditLimit" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="NoOfAttempts" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="PreCreatedCardAcceptUpdRs",namespace="http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15")
@XmlType(name = "", propOrder = {
    "date",
    "time",
    "system",
    "serviceOperationName",
    "applicationID",
    "preCreatedCardLogo",
    "plasticID",
    "preCreatedCardNo",
    "preCreatedCardCreditLimit",
    "noOfAttempts"
})
public class PreCreatedCardAcceptUpdRs
    extends GenericResponse
{

    @XmlElement(name = "Date", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar date;
    @XmlElement(name = "Time", required = true)
    @XmlSchemaType(name = "time")
    protected XMLGregorianCalendar time;
    @XmlElement(name = "System", required = true)
    protected String system;
    @XmlElement(name = "ServiceOperationName", required = true)
    protected String serviceOperationName;
    @XmlElement(name = "ApplicationID")
    protected String applicationID;
    @XmlElement(name = "PreCreatedCardLogo")
    protected String preCreatedCardLogo;
    @XmlElement(name = "PlasticID")
    protected String plasticID;
    @XmlElement(name = "PreCreatedCardNo")
    protected String preCreatedCardNo;
    @XmlElement(name = "PreCreatedCardCreditLimit")
    protected Double preCreatedCardCreditLimit;
    @XmlElement(name = "NoOfAttempts")
    protected BigInteger noOfAttempts;

    /**
     * Obtiene el valor de la propiedad date.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDate() {
        return date;
    }

    /**
     * Define el valor de la propiedad date.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDate(XMLGregorianCalendar value) {
        this.date = value;
    }

    /**
     * Obtiene el valor de la propiedad time.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTime() {
        return time;
    }

    /**
     * Define el valor de la propiedad time.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTime(XMLGregorianCalendar value) {
        this.time = value;
    }

    /**
     * Obtiene el valor de la propiedad system.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystem() {
        return system;
    }

    /**
     * Define el valor de la propiedad system.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystem(String value) {
        this.system = value;
    }

    /**
     * Obtiene el valor de la propiedad serviceOperationName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceOperationName() {
        return serviceOperationName;
    }

    /**
     * Define el valor de la propiedad serviceOperationName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceOperationName(String value) {
        this.serviceOperationName = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationID() {
        return applicationID;
    }

    /**
     * Define el valor de la propiedad applicationID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationID(String value) {
        this.applicationID = value;
    }

    /**
     * Obtiene el valor de la propiedad preCreatedCardLogo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreCreatedCardLogo() {
        return preCreatedCardLogo;
    }

    /**
     * Define el valor de la propiedad preCreatedCardLogo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreCreatedCardLogo(String value) {
        this.preCreatedCardLogo = value;
    }

    /**
     * Obtiene el valor de la propiedad plasticID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlasticID() {
        return plasticID;
    }

    /**
     * Define el valor de la propiedad plasticID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlasticID(String value) {
        this.plasticID = value;
    }

    /**
     * Obtiene el valor de la propiedad preCreatedCardNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreCreatedCardNo() {
        return preCreatedCardNo;
    }

    /**
     * Define el valor de la propiedad preCreatedCardNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreCreatedCardNo(String value) {
        this.preCreatedCardNo = value;
    }

    /**
     * Obtiene el valor de la propiedad preCreatedCardCreditLimit.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPreCreatedCardCreditLimit() {
        return preCreatedCardCreditLimit;
    }

    /**
     * Define el valor de la propiedad preCreatedCardCreditLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPreCreatedCardCreditLimit(Double value) {
        this.preCreatedCardCreditLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad noOfAttempts.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNoOfAttempts() {
        return noOfAttempts;
    }

    /**
     * Define el valor de la propiedad noOfAttempts.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNoOfAttempts(BigInteger value) {
        this.noOfAttempts = value;
    }

}
