
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para LoanProductDtls complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="LoanProductDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Offer" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Offer" minOccurs="0"/>
 *         &lt;element name="USLNDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}USLNDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="AcquisitionAndReferral" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}AcquisitionAndReferral" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanProductDtls", propOrder = {
    "offer",
    "uslnDetails",
    "acquisitionAndReferral"
})
public class LoanProductDtls {

    @XmlElement(name = "Offer")
    protected Offer offer;
    @XmlElement(name = "USLNDetails")
    protected List<USLNDetails> uslnDetails;
    @XmlElement(name = "AcquisitionAndReferral")
    protected AcquisitionAndReferral acquisitionAndReferral;

    /**
     * Obtiene el valor de la propiedad offer.
     * 
     * @return
     *     possible object is
     *     {@link Offer }
     *     
     */
    public Offer getOffer() {
        return offer;
    }

    /**
     * Define el valor de la propiedad offer.
     * 
     * @param value
     *     allowed object is
     *     {@link Offer }
     *     
     */
    public void setOffer(Offer value) {
        this.offer = value;
    }

    /**
     * Gets the value of the uslnDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the uslnDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getUSLNDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link USLNDetails }
     * 
     * 
     */
    public List<USLNDetails> getUSLNDetails() {
        if (uslnDetails == null) {
            uslnDetails = new ArrayList<USLNDetails>();
        }
        return this.uslnDetails;
    }

    /**
     * Obtiene el valor de la propiedad acquisitionAndReferral.
     * 
     * @return
     *     possible object is
     *     {@link AcquisitionAndReferral }
     *     
     */
    public AcquisitionAndReferral getAcquisitionAndReferral() {
        return acquisitionAndReferral;
    }

    /**
     * Define el valor de la propiedad acquisitionAndReferral.
     * 
     * @param value
     *     allowed object is
     *     {@link AcquisitionAndReferral }
     *     
     */
    public void setAcquisitionAndReferral(AcquisitionAndReferral value) {
        this.acquisitionAndReferral = value;
    }

}
