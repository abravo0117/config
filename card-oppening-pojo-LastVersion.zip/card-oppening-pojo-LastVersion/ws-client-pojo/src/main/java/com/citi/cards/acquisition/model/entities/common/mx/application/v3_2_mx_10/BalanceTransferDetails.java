
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para BalanceTransferDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="BalanceTransferDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FINInsCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AcctNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfAccount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BalTrfReq" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BalTrfAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MemberSince" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PayeeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BalanceTransferDetails", propOrder = {
    "seqNo",
    "custNo",
    "finInsCD",
    "acctNo",
    "typeOfAccount",
    "creditAmount",
    "balTrfReq",
    "balTrfAmount",
    "memberSince",
    "payeeName"
})
public class BalanceTransferDetails {

    @XmlElement(name = "SeqNo")
    protected String seqNo;
    @XmlElement(name = "CustNo")
    protected String custNo;
    @XmlElement(name = "FINInsCD")
    protected String finInsCD;
    @XmlElement(name = "AcctNo")
    protected String acctNo;
    @XmlElement(name = "TypeOfAccount")
    protected String typeOfAccount;
    @XmlElement(name = "CreditAmount")
    protected String creditAmount;
    @XmlElement(name = "BalTrfReq")
    protected String balTrfReq;
    @XmlElement(name = "BalTrfAmount")
    protected String balTrfAmount;
    @XmlElement(name = "MemberSince")
    protected String memberSince;
    @XmlElement(name = "PayeeName")
    protected String payeeName;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad custNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustNo() {
        return custNo;
    }

    /**
     * Define el valor de la propiedad custNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustNo(String value) {
        this.custNo = value;
    }

    /**
     * Obtiene el valor de la propiedad finInsCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFINInsCD() {
        return finInsCD;
    }

    /**
     * Define el valor de la propiedad finInsCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFINInsCD(String value) {
        this.finInsCD = value;
    }

    /**
     * Obtiene el valor de la propiedad acctNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctNo() {
        return acctNo;
    }

    /**
     * Define el valor de la propiedad acctNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctNo(String value) {
        this.acctNo = value;
    }

    /**
     * Obtiene el valor de la propiedad typeOfAccount.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfAccount() {
        return typeOfAccount;
    }

    /**
     * Define el valor de la propiedad typeOfAccount.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfAccount(String value) {
        this.typeOfAccount = value;
    }

    /**
     * Obtiene el valor de la propiedad creditAmount.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditAmount() {
        return creditAmount;
    }

    /**
     * Define el valor de la propiedad creditAmount.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditAmount(String value) {
        this.creditAmount = value;
    }

    /**
     * Obtiene el valor de la propiedad balTrfReq.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBalTrfReq() {
        return balTrfReq;
    }

    /**
     * Define el valor de la propiedad balTrfReq.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBalTrfReq(String value) {
        this.balTrfReq = value;
    }

    /**
     * Obtiene el valor de la propiedad balTrfAmount.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBalTrfAmount() {
        return balTrfAmount;
    }

    /**
     * Define el valor de la propiedad balTrfAmount.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBalTrfAmount(String value) {
        this.balTrfAmount = value;
    }

    /**
     * Obtiene el valor de la propiedad memberSince.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberSince() {
        return memberSince;
    }

    /**
     * Define el valor de la propiedad memberSince.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberSince(String value) {
        this.memberSince = value;
    }

    /**
     * Obtiene el valor de la propiedad payeeName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayeeName() {
        return payeeName;
    }

    /**
     * Define el valor de la propiedad payeeName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayeeName(String value) {
        this.payeeName = value;
    }

}
