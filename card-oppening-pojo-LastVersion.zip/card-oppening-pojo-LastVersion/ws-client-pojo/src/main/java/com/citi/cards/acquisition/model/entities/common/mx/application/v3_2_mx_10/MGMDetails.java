
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para MGMDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="MGMDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IntrCardNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IntrName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MGMInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IntrPhoneNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MGMDetails", propOrder = {
    "intrCardNo",
    "intrName",
    "mgmInd",
    "intrPhoneNo"
})
public class MGMDetails {

    @XmlElement(name = "IntrCardNo")
    protected String intrCardNo;
    @XmlElement(name = "IntrName")
    protected String intrName;
    @XmlElement(name = "MGMInd")
    protected String mgmInd;
    @XmlElement(name = "IntrPhoneNo")
    protected String intrPhoneNo;

    /**
     * Obtiene el valor de la propiedad intrCardNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntrCardNo() {
        return intrCardNo;
    }

    /**
     * Define el valor de la propiedad intrCardNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntrCardNo(String value) {
        this.intrCardNo = value;
    }

    /**
     * Obtiene el valor de la propiedad intrName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntrName() {
        return intrName;
    }

    /**
     * Define el valor de la propiedad intrName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntrName(String value) {
        this.intrName = value;
    }

    /**
     * Obtiene el valor de la propiedad mgmInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMGMInd() {
        return mgmInd;
    }

    /**
     * Define el valor de la propiedad mgmInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMGMInd(String value) {
        this.mgmInd = value;
    }

    /**
     * Obtiene el valor de la propiedad intrPhoneNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntrPhoneNo() {
        return intrPhoneNo;
    }

    /**
     * Define el valor de la propiedad intrPhoneNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntrPhoneNo(String value) {
        this.intrPhoneNo = value;
    }

}
