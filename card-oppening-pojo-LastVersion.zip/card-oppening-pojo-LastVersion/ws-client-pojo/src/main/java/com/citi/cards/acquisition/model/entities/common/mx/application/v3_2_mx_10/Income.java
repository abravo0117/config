
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Income complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Income">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DeclaredIncome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VariableIncome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OtherIncome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OtherIncomeType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IncomeProofType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VerifiedMonthlyIncome" type="{http://www.w3.org/2001/XMLSchema}double" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Income", propOrder = {
    "declaredIncome",
    "variableIncome",
    "otherIncome",
    "otherIncomeType",
    "incomeProofType",
    "verifiedMonthlyIncome"
})
public class Income {

    @XmlElement(name = "DeclaredIncome")
    protected String declaredIncome;
    @XmlElement(name = "VariableIncome")
    protected String variableIncome;
    @XmlElement(name = "OtherIncome")
    protected String otherIncome;
    @XmlElement(name = "OtherIncomeType")
    protected String otherIncomeType;
    @XmlElement(name = "IncomeProofType")
    protected String incomeProofType;
    @XmlElement(name = "VerifiedMonthlyIncome", type = Double.class)
    protected List<Double> verifiedMonthlyIncome;

    /**
     * Obtiene el valor de la propiedad declaredIncome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeclaredIncome() {
        return declaredIncome;
    }

    /**
     * Define el valor de la propiedad declaredIncome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeclaredIncome(String value) {
        this.declaredIncome = value;
    }

    /**
     * Obtiene el valor de la propiedad variableIncome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVariableIncome() {
        return variableIncome;
    }

    /**
     * Define el valor de la propiedad variableIncome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVariableIncome(String value) {
        this.variableIncome = value;
    }

    /**
     * Obtiene el valor de la propiedad otherIncome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherIncome() {
        return otherIncome;
    }

    /**
     * Define el valor de la propiedad otherIncome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherIncome(String value) {
        this.otherIncome = value;
    }

    /**
     * Obtiene el valor de la propiedad otherIncomeType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherIncomeType() {
        return otherIncomeType;
    }

    /**
     * Define el valor de la propiedad otherIncomeType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherIncomeType(String value) {
        this.otherIncomeType = value;
    }

    /**
     * Obtiene el valor de la propiedad incomeProofType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncomeProofType() {
        return incomeProofType;
    }

    /**
     * Define el valor de la propiedad incomeProofType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncomeProofType(String value) {
        this.incomeProofType = value;
    }

    /**
     * Gets the value of the verifiedMonthlyIncome property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the verifiedMonthlyIncome property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVerifiedMonthlyIncome().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Double }
     * 
     * 
     */
    public List<Double> getVerifiedMonthlyIncome() {
        if (verifiedMonthlyIncome == null) {
            verifiedMonthlyIncome = new ArrayList<Double>();
        }
        return this.verifiedMonthlyIncome;
    }

}
