
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.LastUpdate;


/**
 * <p>Clase Java para ApplicationDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ApplicationDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ApplicationID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicantName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicantType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicationStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicationStage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicationDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="LastUpdate" type="{http://www.citi.com/query.model/shared/util/v3_1_0_0}LastUpdate" minOccurs="0"/>
 *         &lt;element name="ProductGroupDetails" type="{http://www.citi.com/query.model/entities/common/MX/application/v3_2_MX_10}ProductGroupDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ApplicationDetails", propOrder = {
    "applicationID",
    "applicantName",
    "applicantType",
    "applicationStatus",
    "applicationStage",
    "applicationDate",
    "lastUpdate",
    "productGroupDetails"
})
public class ApplicationDetails {

    @XmlElement(name = "ApplicationID", required = true)
    protected String applicationID;
    @XmlElement(name = "ApplicantName", required = true)
    protected String applicantName;
    @XmlElement(name = "ApplicantType", required = true)
    protected String applicantType;
    @XmlElement(name = "ApplicationStatus", required = true)
    protected String applicationStatus;
    @XmlElement(name = "ApplicationStage", required = true)
    protected String applicationStage;
    @XmlElement(name = "ApplicationDate", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar applicationDate;
    @XmlElement(name = "LastUpdate")
    protected LastUpdate lastUpdate;
    @XmlElement(name = "ProductGroupDetails")
    protected List<ProductGroupDetails> productGroupDetails;

    /**
     * Obtiene el valor de la propiedad applicationID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationID() {
        return applicationID;
    }

    /**
     * Define el valor de la propiedad applicationID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationID(String value) {
        this.applicationID = value;
    }

    /**
     * Obtiene el valor de la propiedad applicantName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicantName() {
        return applicantName;
    }

    /**
     * Define el valor de la propiedad applicantName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicantName(String value) {
        this.applicantName = value;
    }

    /**
     * Obtiene el valor de la propiedad applicantType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicantType() {
        return applicantType;
    }

    /**
     * Define el valor de la propiedad applicantType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicantType(String value) {
        this.applicantType = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationStatus() {
        return applicationStatus;
    }

    /**
     * Define el valor de la propiedad applicationStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationStatus(String value) {
        this.applicationStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationStage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationStage() {
        return applicationStage;
    }

    /**
     * Define el valor de la propiedad applicationStage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationStage(String value) {
        this.applicationStage = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getApplicationDate() {
        return applicationDate;
    }

    /**
     * Define el valor de la propiedad applicationDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setApplicationDate(XMLGregorianCalendar value) {
        this.applicationDate = value;
    }

    /**
     * Obtiene el valor de la propiedad lastUpdate.
     * 
     * @return
     *     possible object is
     *     {@link LastUpdate }
     *     
     */
    public LastUpdate getLastUpdate() {
        return lastUpdate;
    }

    /**
     * Define el valor de la propiedad lastUpdate.
     * 
     * @param value
     *     allowed object is
     *     {@link LastUpdate }
     *     
     */
    public void setLastUpdate(LastUpdate value) {
        this.lastUpdate = value;
    }

    /**
     * Gets the value of the productGroupDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productGroupDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductGroupDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductGroupDetails }
     * 
     * 
     */
    public List<ProductGroupDetails> getProductGroupDetails() {
        if (productGroupDetails == null) {
            productGroupDetails = new ArrayList<ProductGroupDetails>();
        }
        return this.productGroupDetails;
    }

}
