
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.ApplicationFullDetails;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.GenericResponse;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.ListRs;


/**
 * <p>Clase Java para ListOfCardApplicationInqRs complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ListOfCardApplicationInqRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="Time" type="{http://www.w3.org/2001/XMLSchema}time"/>
 *         &lt;element name="System" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ServiceOperationName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Initiator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BranchID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserID" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}UserID" minOccurs="0"/>
 *         &lt;element name="ListRs" type="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}ListRs" minOccurs="0"/>
 *         &lt;element name="ApplicationFullDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}ApplicationFullDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfCardApplicationInqRs", propOrder = {
    "date",
    "time",
    "system",
    "serviceOperationName",
    "initiator",
    "branchID",
    "userID",
    "listRs",
    "applicationFullDetails"
})
public class ListOfCardApplicationInqRs
    extends GenericResponse
{

    @XmlElement(name = "Date", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar date;
    @XmlElement(name = "Time", required = true)
    @XmlSchemaType(name = "time")
    protected XMLGregorianCalendar time;
    @XmlElement(name = "System", required = true)
    protected String system;
    @XmlElement(name = "ServiceOperationName", required = true)
    protected String serviceOperationName;
    @XmlElement(name = "Initiator")
    protected String initiator;
    @XmlElement(name = "BranchID")
    protected String branchID;
    @XmlElement(name = "UserID")
    protected String userID;
    @XmlElement(name = "ListRs")
    protected ListRs listRs;
    @XmlElement(name = "ApplicationFullDetails")
    protected List<ApplicationFullDetails> applicationFullDetails;

    /**
     * Obtiene el valor de la propiedad date.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDate() {
        return date;
    }

    /**
     * Define el valor de la propiedad date.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDate(XMLGregorianCalendar value) {
        this.date = value;
    }

    /**
     * Obtiene el valor de la propiedad time.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTime() {
        return time;
    }

    /**
     * Define el valor de la propiedad time.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTime(XMLGregorianCalendar value) {
        this.time = value;
    }

    /**
     * Obtiene el valor de la propiedad system.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystem() {
        return system;
    }

    /**
     * Define el valor de la propiedad system.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystem(String value) {
        this.system = value;
    }

    /**
     * Obtiene el valor de la propiedad serviceOperationName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceOperationName() {
        return serviceOperationName;
    }

    /**
     * Define el valor de la propiedad serviceOperationName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceOperationName(String value) {
        this.serviceOperationName = value;
    }

    /**
     * Obtiene el valor de la propiedad initiator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitiator() {
        return initiator;
    }

    /**
     * Define el valor de la propiedad initiator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitiator(String value) {
        this.initiator = value;
    }

    /**
     * Obtiene el valor de la propiedad branchID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchID() {
        return branchID;
    }

    /**
     * Define el valor de la propiedad branchID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchID(String value) {
        this.branchID = value;
    }

    /**
     * Obtiene el valor de la propiedad userID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Define el valor de la propiedad userID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

    /**
     * Obtiene el valor de la propiedad listRs.
     * 
     * @return
     *     possible object is
     *     {@link ListRs }
     *     
     */
    public ListRs getListRs() {
        return listRs;
    }

    /**
     * Define el valor de la propiedad listRs.
     * 
     * @param value
     *     allowed object is
     *     {@link ListRs }
     *     
     */
    public void setListRs(ListRs value) {
        this.listRs = value;
    }

    /**
     * Gets the value of the applicationFullDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the applicationFullDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getApplicationFullDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ApplicationFullDetails }
     * 
     * 
     */
    public List<ApplicationFullDetails> getApplicationFullDetails() {
        if (applicationFullDetails == null) {
            applicationFullDetails = new ArrayList<ApplicationFullDetails>();
        }
        return this.applicationFullDetails;
    }

}
