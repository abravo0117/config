
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para ApplicationStatusAndStageInqRq complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ApplicationStatusAndStageInqRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice>
 *           &lt;element name="ApplicationID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *           &lt;element name="TaxID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *           &lt;element name="NationalID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *           &lt;element name="MobileNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;/choice>
 *         &lt;element name="DateOfBirth" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="ProductGroupFilter" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HomePhoneNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ApplicationStatusAndStageInqRq", propOrder = {
    "applicationID",
    "taxID",
    "nationalID",
    "mobileNo",
    "dateOfBirth",
    "productGroupFilter",
    "homePhoneNo"
})
public class ApplicationStatusAndStageInqRq {

    @XmlElement(name = "ApplicationID")
    protected String applicationID;
    @XmlElement(name = "TaxID")
    protected String taxID;
    @XmlElement(name = "NationalID")
    protected String nationalID;
    @XmlElement(name = "MobileNo")
    protected String mobileNo;
    @XmlElement(name = "DateOfBirth")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateOfBirth;
    @XmlElement(name = "ProductGroupFilter")
    protected String productGroupFilter;
    @XmlElement(name = "HomePhoneNo")
    protected String homePhoneNo;

    /**
     * Obtiene el valor de la propiedad applicationID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationID() {
        return applicationID;
    }

    /**
     * Define el valor de la propiedad applicationID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationID(String value) {
        this.applicationID = value;
    }

    /**
     * Obtiene el valor de la propiedad taxID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxID() {
        return taxID;
    }

    /**
     * Define el valor de la propiedad taxID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxID(String value) {
        this.taxID = value;
    }

    /**
     * Obtiene el valor de la propiedad nationalID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNationalID() {
        return nationalID;
    }

    /**
     * Define el valor de la propiedad nationalID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNationalID(String value) {
        this.nationalID = value;
    }

    /**
     * Obtiene el valor de la propiedad mobileNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobileNo() {
        return mobileNo;
    }

    /**
     * Define el valor de la propiedad mobileNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobileNo(String value) {
        this.mobileNo = value;
    }

    /**
     * Obtiene el valor de la propiedad dateOfBirth.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Define el valor de la propiedad dateOfBirth.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfBirth(XMLGregorianCalendar value) {
        this.dateOfBirth = value;
    }

    /**
     * Obtiene el valor de la propiedad productGroupFilter.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductGroupFilter() {
        return productGroupFilter;
    }

    /**
     * Define el valor de la propiedad productGroupFilter.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductGroupFilter(String value) {
        this.productGroupFilter = value;
    }

    /**
     * Obtiene el valor de la propiedad homePhoneNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomePhoneNo() {
        return homePhoneNo;
    }

    /**
     * Define el valor de la propiedad homePhoneNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomePhoneNo(String value) {
        this.homePhoneNo = value;
    }

}
