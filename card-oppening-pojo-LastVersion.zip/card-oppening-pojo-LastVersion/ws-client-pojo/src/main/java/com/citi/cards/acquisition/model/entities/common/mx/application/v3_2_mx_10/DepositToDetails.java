
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para DepositToDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DepositToDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CTPBasicAct" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CTPBasicActCtl1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CTPBasicActCtl2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CTPBasicActCtl3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CTPBasicActCtl4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProdCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProdCcy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditAmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FxRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BmFxRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FxMatchInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FxRefNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LcyEquiv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USDEquiv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NoOfContract" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IntRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ConfIntRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ValueDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EstablishDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Tenor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RoOption" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RoOptionDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RoTier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RoTenor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PrtRoAdvice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PplDispType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PplDispAcct" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PplDispAcctCtl1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PplDispAcctCtl2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PplDispAcctCtl3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PplDispAcctCtl4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PplDispAcctPrd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PplDispAcctTitl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IntDispAcctCcy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IntDispType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IntDispAcct" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IntDispAcctTitl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BeneficiaryIC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BeneficiaryName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InstalTargetAmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditProdSysID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RcIntPRodCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IntAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MaturityDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IntPymtFreqCd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IntAccruedAmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PreProcessToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ToAccount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PplDispBankNm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PplDispRemarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LdInterestRatesDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}LdInterestRatesDetails" minOccurs="0"/>
 *         &lt;element name="PplRefOfferID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IntRefOfferID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PreProResCd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PromotionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VoucherNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TrxNatureCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FwdDtTrxInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MsgName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RoaddIntRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WithHldTaxInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrgPrftRatio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Remarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DepositToDetails", propOrder = {
    "seqNo",
    "ctpBasicAct",
    "ctpBasicActCtl1",
    "ctpBasicActCtl2",
    "ctpBasicActCtl3",
    "ctpBasicActCtl4",
    "prodCode",
    "prodCcy",
    "creditAmt",
    "fxRate",
    "bmFxRate",
    "fxMatchInd",
    "fxRefNo",
    "lcyEquiv",
    "usdEquiv",
    "noOfContract",
    "intRate",
    "confIntRate",
    "valueDate",
    "establishDate",
    "tenor",
    "roOption",
    "roOptionDesc",
    "roTier",
    "roTenor",
    "prtRoAdvice",
    "pplDispType",
    "pplDispAcct",
    "pplDispAcctCtl1",
    "pplDispAcctCtl2",
    "pplDispAcctCtl3",
    "pplDispAcctCtl4",
    "pplDispAcctPrd",
    "pplDispAcctTitl",
    "intDispAcctCcy",
    "intDispType",
    "intDispAcct",
    "intDispAcctTitl",
    "beneficiaryIC",
    "beneficiaryName",
    "instalTargetAmt",
    "creditProdSysID",
    "rcIntPRodCode",
    "intAmount",
    "maturityDate",
    "intPymtFreqCd",
    "intAccruedAmt",
    "preProcessToken",
    "toAccount",
    "pplDispBankNm",
    "pplDispRemarks",
    "ldInterestRatesDetails",
    "pplRefOfferID",
    "intRefOfferID",
    "preProResCd",
    "promotionCode",
    "voucherNo",
    "trxNatureCD",
    "fwdDtTrxInd",
    "msgName",
    "roaddIntRate",
    "withHldTaxInd",
    "orgPrftRatio",
    "remarks"
})
public class DepositToDetails {

    @XmlElement(name = "SeqNo")
    protected String seqNo;
    @XmlElement(name = "CTPBasicAct")
    protected String ctpBasicAct;
    @XmlElement(name = "CTPBasicActCtl1")
    protected String ctpBasicActCtl1;
    @XmlElement(name = "CTPBasicActCtl2")
    protected String ctpBasicActCtl2;
    @XmlElement(name = "CTPBasicActCtl3")
    protected String ctpBasicActCtl3;
    @XmlElement(name = "CTPBasicActCtl4")
    protected String ctpBasicActCtl4;
    @XmlElement(name = "ProdCode")
    protected String prodCode;
    @XmlElement(name = "ProdCcy")
    protected String prodCcy;
    @XmlElement(name = "CreditAmt")
    protected String creditAmt;
    @XmlElement(name = "FxRate")
    protected String fxRate;
    @XmlElement(name = "BmFxRate")
    protected String bmFxRate;
    @XmlElement(name = "FxMatchInd")
    protected String fxMatchInd;
    @XmlElement(name = "FxRefNo")
    protected String fxRefNo;
    @XmlElement(name = "LcyEquiv")
    protected String lcyEquiv;
    @XmlElement(name = "USDEquiv")
    protected String usdEquiv;
    @XmlElement(name = "NoOfContract")
    protected String noOfContract;
    @XmlElement(name = "IntRate")
    protected String intRate;
    @XmlElement(name = "ConfIntRate")
    protected String confIntRate;
    @XmlElement(name = "ValueDate")
    protected String valueDate;
    @XmlElement(name = "EstablishDate")
    protected String establishDate;
    @XmlElement(name = "Tenor")
    protected String tenor;
    @XmlElement(name = "RoOption")
    protected String roOption;
    @XmlElement(name = "RoOptionDesc")
    protected String roOptionDesc;
    @XmlElement(name = "RoTier")
    protected String roTier;
    @XmlElement(name = "RoTenor")
    protected String roTenor;
    @XmlElement(name = "PrtRoAdvice")
    protected String prtRoAdvice;
    @XmlElement(name = "PplDispType")
    protected String pplDispType;
    @XmlElement(name = "PplDispAcct")
    protected String pplDispAcct;
    @XmlElement(name = "PplDispAcctCtl1")
    protected String pplDispAcctCtl1;
    @XmlElement(name = "PplDispAcctCtl2")
    protected String pplDispAcctCtl2;
    @XmlElement(name = "PplDispAcctCtl3")
    protected String pplDispAcctCtl3;
    @XmlElement(name = "PplDispAcctCtl4")
    protected String pplDispAcctCtl4;
    @XmlElement(name = "PplDispAcctPrd")
    protected String pplDispAcctPrd;
    @XmlElement(name = "PplDispAcctTitl")
    protected String pplDispAcctTitl;
    @XmlElement(name = "IntDispAcctCcy")
    protected String intDispAcctCcy;
    @XmlElement(name = "IntDispType")
    protected String intDispType;
    @XmlElement(name = "IntDispAcct")
    protected String intDispAcct;
    @XmlElement(name = "IntDispAcctTitl")
    protected String intDispAcctTitl;
    @XmlElement(name = "BeneficiaryIC")
    protected String beneficiaryIC;
    @XmlElement(name = "BeneficiaryName")
    protected String beneficiaryName;
    @XmlElement(name = "InstalTargetAmt")
    protected String instalTargetAmt;
    @XmlElement(name = "CreditProdSysID")
    protected String creditProdSysID;
    @XmlElement(name = "RcIntPRodCode")
    protected String rcIntPRodCode;
    @XmlElement(name = "IntAmount")
    protected String intAmount;
    @XmlElement(name = "MaturityDate")
    protected String maturityDate;
    @XmlElement(name = "IntPymtFreqCd")
    protected String intPymtFreqCd;
    @XmlElement(name = "IntAccruedAmt")
    protected String intAccruedAmt;
    @XmlElement(name = "PreProcessToken")
    protected String preProcessToken;
    @XmlElement(name = "ToAccount")
    protected String toAccount;
    @XmlElement(name = "PplDispBankNm")
    protected String pplDispBankNm;
    @XmlElement(name = "PplDispRemarks")
    protected String pplDispRemarks;
    @XmlElement(name = "LdInterestRatesDetails")
    protected LdInterestRatesDetails ldInterestRatesDetails;
    @XmlElement(name = "PplRefOfferID")
    protected String pplRefOfferID;
    @XmlElement(name = "IntRefOfferID")
    protected String intRefOfferID;
    @XmlElement(name = "PreProResCd")
    protected String preProResCd;
    @XmlElement(name = "PromotionCode")
    protected String promotionCode;
    @XmlElement(name = "VoucherNo")
    protected String voucherNo;
    @XmlElement(name = "TrxNatureCD")
    protected String trxNatureCD;
    @XmlElement(name = "FwdDtTrxInd")
    protected String fwdDtTrxInd;
    @XmlElement(name = "MsgName")
    protected String msgName;
    @XmlElement(name = "RoaddIntRate")
    protected String roaddIntRate;
    @XmlElement(name = "WithHldTaxInd")
    protected String withHldTaxInd;
    @XmlElement(name = "OrgPrftRatio")
    protected String orgPrftRatio;
    @XmlElement(name = "Remarks")
    protected String remarks;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad ctpBasicAct.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCTPBasicAct() {
        return ctpBasicAct;
    }

    /**
     * Define el valor de la propiedad ctpBasicAct.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCTPBasicAct(String value) {
        this.ctpBasicAct = value;
    }

    /**
     * Obtiene el valor de la propiedad ctpBasicActCtl1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCTPBasicActCtl1() {
        return ctpBasicActCtl1;
    }

    /**
     * Define el valor de la propiedad ctpBasicActCtl1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCTPBasicActCtl1(String value) {
        this.ctpBasicActCtl1 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctpBasicActCtl2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCTPBasicActCtl2() {
        return ctpBasicActCtl2;
    }

    /**
     * Define el valor de la propiedad ctpBasicActCtl2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCTPBasicActCtl2(String value) {
        this.ctpBasicActCtl2 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctpBasicActCtl3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCTPBasicActCtl3() {
        return ctpBasicActCtl3;
    }

    /**
     * Define el valor de la propiedad ctpBasicActCtl3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCTPBasicActCtl3(String value) {
        this.ctpBasicActCtl3 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctpBasicActCtl4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCTPBasicActCtl4() {
        return ctpBasicActCtl4;
    }

    /**
     * Define el valor de la propiedad ctpBasicActCtl4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCTPBasicActCtl4(String value) {
        this.ctpBasicActCtl4 = value;
    }

    /**
     * Obtiene el valor de la propiedad prodCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdCode() {
        return prodCode;
    }

    /**
     * Define el valor de la propiedad prodCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdCode(String value) {
        this.prodCode = value;
    }

    /**
     * Obtiene el valor de la propiedad prodCcy.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdCcy() {
        return prodCcy;
    }

    /**
     * Define el valor de la propiedad prodCcy.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdCcy(String value) {
        this.prodCcy = value;
    }

    /**
     * Obtiene el valor de la propiedad creditAmt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditAmt() {
        return creditAmt;
    }

    /**
     * Define el valor de la propiedad creditAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditAmt(String value) {
        this.creditAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad fxRate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFxRate() {
        return fxRate;
    }

    /**
     * Define el valor de la propiedad fxRate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFxRate(String value) {
        this.fxRate = value;
    }

    /**
     * Obtiene el valor de la propiedad bmFxRate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBmFxRate() {
        return bmFxRate;
    }

    /**
     * Define el valor de la propiedad bmFxRate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBmFxRate(String value) {
        this.bmFxRate = value;
    }

    /**
     * Obtiene el valor de la propiedad fxMatchInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFxMatchInd() {
        return fxMatchInd;
    }

    /**
     * Define el valor de la propiedad fxMatchInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFxMatchInd(String value) {
        this.fxMatchInd = value;
    }

    /**
     * Obtiene el valor de la propiedad fxRefNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFxRefNo() {
        return fxRefNo;
    }

    /**
     * Define el valor de la propiedad fxRefNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFxRefNo(String value) {
        this.fxRefNo = value;
    }

    /**
     * Obtiene el valor de la propiedad lcyEquiv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLcyEquiv() {
        return lcyEquiv;
    }

    /**
     * Define el valor de la propiedad lcyEquiv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLcyEquiv(String value) {
        this.lcyEquiv = value;
    }

    /**
     * Obtiene el valor de la propiedad usdEquiv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSDEquiv() {
        return usdEquiv;
    }

    /**
     * Define el valor de la propiedad usdEquiv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSDEquiv(String value) {
        this.usdEquiv = value;
    }

    /**
     * Obtiene el valor de la propiedad noOfContract.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoOfContract() {
        return noOfContract;
    }

    /**
     * Define el valor de la propiedad noOfContract.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoOfContract(String value) {
        this.noOfContract = value;
    }

    /**
     * Obtiene el valor de la propiedad intRate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntRate() {
        return intRate;
    }

    /**
     * Define el valor de la propiedad intRate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntRate(String value) {
        this.intRate = value;
    }

    /**
     * Obtiene el valor de la propiedad confIntRate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfIntRate() {
        return confIntRate;
    }

    /**
     * Define el valor de la propiedad confIntRate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfIntRate(String value) {
        this.confIntRate = value;
    }

    /**
     * Obtiene el valor de la propiedad valueDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValueDate() {
        return valueDate;
    }

    /**
     * Define el valor de la propiedad valueDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValueDate(String value) {
        this.valueDate = value;
    }

    /**
     * Obtiene el valor de la propiedad establishDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEstablishDate() {
        return establishDate;
    }

    /**
     * Define el valor de la propiedad establishDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEstablishDate(String value) {
        this.establishDate = value;
    }

    /**
     * Obtiene el valor de la propiedad tenor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTenor() {
        return tenor;
    }

    /**
     * Define el valor de la propiedad tenor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTenor(String value) {
        this.tenor = value;
    }

    /**
     * Obtiene el valor de la propiedad roOption.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoOption() {
        return roOption;
    }

    /**
     * Define el valor de la propiedad roOption.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoOption(String value) {
        this.roOption = value;
    }

    /**
     * Obtiene el valor de la propiedad roOptionDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoOptionDesc() {
        return roOptionDesc;
    }

    /**
     * Define el valor de la propiedad roOptionDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoOptionDesc(String value) {
        this.roOptionDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad roTier.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoTier() {
        return roTier;
    }

    /**
     * Define el valor de la propiedad roTier.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoTier(String value) {
        this.roTier = value;
    }

    /**
     * Obtiene el valor de la propiedad roTenor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoTenor() {
        return roTenor;
    }

    /**
     * Define el valor de la propiedad roTenor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoTenor(String value) {
        this.roTenor = value;
    }

    /**
     * Obtiene el valor de la propiedad prtRoAdvice.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrtRoAdvice() {
        return prtRoAdvice;
    }

    /**
     * Define el valor de la propiedad prtRoAdvice.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrtRoAdvice(String value) {
        this.prtRoAdvice = value;
    }

    /**
     * Obtiene el valor de la propiedad pplDispType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPplDispType() {
        return pplDispType;
    }

    /**
     * Define el valor de la propiedad pplDispType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPplDispType(String value) {
        this.pplDispType = value;
    }

    /**
     * Obtiene el valor de la propiedad pplDispAcct.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPplDispAcct() {
        return pplDispAcct;
    }

    /**
     * Define el valor de la propiedad pplDispAcct.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPplDispAcct(String value) {
        this.pplDispAcct = value;
    }

    /**
     * Obtiene el valor de la propiedad pplDispAcctCtl1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPplDispAcctCtl1() {
        return pplDispAcctCtl1;
    }

    /**
     * Define el valor de la propiedad pplDispAcctCtl1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPplDispAcctCtl1(String value) {
        this.pplDispAcctCtl1 = value;
    }

    /**
     * Obtiene el valor de la propiedad pplDispAcctCtl2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPplDispAcctCtl2() {
        return pplDispAcctCtl2;
    }

    /**
     * Define el valor de la propiedad pplDispAcctCtl2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPplDispAcctCtl2(String value) {
        this.pplDispAcctCtl2 = value;
    }

    /**
     * Obtiene el valor de la propiedad pplDispAcctCtl3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPplDispAcctCtl3() {
        return pplDispAcctCtl3;
    }

    /**
     * Define el valor de la propiedad pplDispAcctCtl3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPplDispAcctCtl3(String value) {
        this.pplDispAcctCtl3 = value;
    }

    /**
     * Obtiene el valor de la propiedad pplDispAcctCtl4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPplDispAcctCtl4() {
        return pplDispAcctCtl4;
    }

    /**
     * Define el valor de la propiedad pplDispAcctCtl4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPplDispAcctCtl4(String value) {
        this.pplDispAcctCtl4 = value;
    }

    /**
     * Obtiene el valor de la propiedad pplDispAcctPrd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPplDispAcctPrd() {
        return pplDispAcctPrd;
    }

    /**
     * Define el valor de la propiedad pplDispAcctPrd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPplDispAcctPrd(String value) {
        this.pplDispAcctPrd = value;
    }

    /**
     * Obtiene el valor de la propiedad pplDispAcctTitl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPplDispAcctTitl() {
        return pplDispAcctTitl;
    }

    /**
     * Define el valor de la propiedad pplDispAcctTitl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPplDispAcctTitl(String value) {
        this.pplDispAcctTitl = value;
    }

    /**
     * Obtiene el valor de la propiedad intDispAcctCcy.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntDispAcctCcy() {
        return intDispAcctCcy;
    }

    /**
     * Define el valor de la propiedad intDispAcctCcy.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntDispAcctCcy(String value) {
        this.intDispAcctCcy = value;
    }

    /**
     * Obtiene el valor de la propiedad intDispType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntDispType() {
        return intDispType;
    }

    /**
     * Define el valor de la propiedad intDispType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntDispType(String value) {
        this.intDispType = value;
    }

    /**
     * Obtiene el valor de la propiedad intDispAcct.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntDispAcct() {
        return intDispAcct;
    }

    /**
     * Define el valor de la propiedad intDispAcct.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntDispAcct(String value) {
        this.intDispAcct = value;
    }

    /**
     * Obtiene el valor de la propiedad intDispAcctTitl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntDispAcctTitl() {
        return intDispAcctTitl;
    }

    /**
     * Define el valor de la propiedad intDispAcctTitl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntDispAcctTitl(String value) {
        this.intDispAcctTitl = value;
    }

    /**
     * Obtiene el valor de la propiedad beneficiaryIC.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryIC() {
        return beneficiaryIC;
    }

    /**
     * Define el valor de la propiedad beneficiaryIC.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryIC(String value) {
        this.beneficiaryIC = value;
    }

    /**
     * Obtiene el valor de la propiedad beneficiaryName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBeneficiaryName() {
        return beneficiaryName;
    }

    /**
     * Define el valor de la propiedad beneficiaryName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBeneficiaryName(String value) {
        this.beneficiaryName = value;
    }

    /**
     * Obtiene el valor de la propiedad instalTargetAmt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstalTargetAmt() {
        return instalTargetAmt;
    }

    /**
     * Define el valor de la propiedad instalTargetAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstalTargetAmt(String value) {
        this.instalTargetAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad creditProdSysID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditProdSysID() {
        return creditProdSysID;
    }

    /**
     * Define el valor de la propiedad creditProdSysID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditProdSysID(String value) {
        this.creditProdSysID = value;
    }

    /**
     * Obtiene el valor de la propiedad rcIntPRodCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcIntPRodCode() {
        return rcIntPRodCode;
    }

    /**
     * Define el valor de la propiedad rcIntPRodCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcIntPRodCode(String value) {
        this.rcIntPRodCode = value;
    }

    /**
     * Obtiene el valor de la propiedad intAmount.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntAmount() {
        return intAmount;
    }

    /**
     * Define el valor de la propiedad intAmount.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntAmount(String value) {
        this.intAmount = value;
    }

    /**
     * Obtiene el valor de la propiedad maturityDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaturityDate() {
        return maturityDate;
    }

    /**
     * Define el valor de la propiedad maturityDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaturityDate(String value) {
        this.maturityDate = value;
    }

    /**
     * Obtiene el valor de la propiedad intPymtFreqCd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntPymtFreqCd() {
        return intPymtFreqCd;
    }

    /**
     * Define el valor de la propiedad intPymtFreqCd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntPymtFreqCd(String value) {
        this.intPymtFreqCd = value;
    }

    /**
     * Obtiene el valor de la propiedad intAccruedAmt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntAccruedAmt() {
        return intAccruedAmt;
    }

    /**
     * Define el valor de la propiedad intAccruedAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntAccruedAmt(String value) {
        this.intAccruedAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad preProcessToken.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreProcessToken() {
        return preProcessToken;
    }

    /**
     * Define el valor de la propiedad preProcessToken.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreProcessToken(String value) {
        this.preProcessToken = value;
    }

    /**
     * Obtiene el valor de la propiedad toAccount.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToAccount() {
        return toAccount;
    }

    /**
     * Define el valor de la propiedad toAccount.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToAccount(String value) {
        this.toAccount = value;
    }

    /**
     * Obtiene el valor de la propiedad pplDispBankNm.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPplDispBankNm() {
        return pplDispBankNm;
    }

    /**
     * Define el valor de la propiedad pplDispBankNm.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPplDispBankNm(String value) {
        this.pplDispBankNm = value;
    }

    /**
     * Obtiene el valor de la propiedad pplDispRemarks.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPplDispRemarks() {
        return pplDispRemarks;
    }

    /**
     * Define el valor de la propiedad pplDispRemarks.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPplDispRemarks(String value) {
        this.pplDispRemarks = value;
    }

    /**
     * Obtiene el valor de la propiedad ldInterestRatesDetails.
     * 
     * @return
     *     possible object is
     *     {@link LdInterestRatesDetails }
     *     
     */
    public LdInterestRatesDetails getLdInterestRatesDetails() {
        return ldInterestRatesDetails;
    }

    /**
     * Define el valor de la propiedad ldInterestRatesDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link LdInterestRatesDetails }
     *     
     */
    public void setLdInterestRatesDetails(LdInterestRatesDetails value) {
        this.ldInterestRatesDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad pplRefOfferID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPplRefOfferID() {
        return pplRefOfferID;
    }

    /**
     * Define el valor de la propiedad pplRefOfferID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPplRefOfferID(String value) {
        this.pplRefOfferID = value;
    }

    /**
     * Obtiene el valor de la propiedad intRefOfferID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntRefOfferID() {
        return intRefOfferID;
    }

    /**
     * Define el valor de la propiedad intRefOfferID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntRefOfferID(String value) {
        this.intRefOfferID = value;
    }

    /**
     * Obtiene el valor de la propiedad preProResCd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreProResCd() {
        return preProResCd;
    }

    /**
     * Define el valor de la propiedad preProResCd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreProResCd(String value) {
        this.preProResCd = value;
    }

    /**
     * Obtiene el valor de la propiedad promotionCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPromotionCode() {
        return promotionCode;
    }

    /**
     * Define el valor de la propiedad promotionCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPromotionCode(String value) {
        this.promotionCode = value;
    }

    /**
     * Obtiene el valor de la propiedad voucherNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVoucherNo() {
        return voucherNo;
    }

    /**
     * Define el valor de la propiedad voucherNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVoucherNo(String value) {
        this.voucherNo = value;
    }

    /**
     * Obtiene el valor de la propiedad trxNatureCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrxNatureCD() {
        return trxNatureCD;
    }

    /**
     * Define el valor de la propiedad trxNatureCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrxNatureCD(String value) {
        this.trxNatureCD = value;
    }

    /**
     * Obtiene el valor de la propiedad fwdDtTrxInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFwdDtTrxInd() {
        return fwdDtTrxInd;
    }

    /**
     * Define el valor de la propiedad fwdDtTrxInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFwdDtTrxInd(String value) {
        this.fwdDtTrxInd = value;
    }

    /**
     * Obtiene el valor de la propiedad msgName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgName() {
        return msgName;
    }

    /**
     * Define el valor de la propiedad msgName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgName(String value) {
        this.msgName = value;
    }

    /**
     * Obtiene el valor de la propiedad roaddIntRate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoaddIntRate() {
        return roaddIntRate;
    }

    /**
     * Define el valor de la propiedad roaddIntRate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoaddIntRate(String value) {
        this.roaddIntRate = value;
    }

    /**
     * Obtiene el valor de la propiedad withHldTaxInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWithHldTaxInd() {
        return withHldTaxInd;
    }

    /**
     * Define el valor de la propiedad withHldTaxInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWithHldTaxInd(String value) {
        this.withHldTaxInd = value;
    }

    /**
     * Obtiene el valor de la propiedad orgPrftRatio.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgPrftRatio() {
        return orgPrftRatio;
    }

    /**
     * Define el valor de la propiedad orgPrftRatio.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgPrftRatio(String value) {
        this.orgPrftRatio = value;
    }

    /**
     * Obtiene el valor de la propiedad remarks.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * Define el valor de la propiedad remarks.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemarks(String value) {
        this.remarks = value;
    }

}
