
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TransactionProfiling complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TransactionProfiling">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TrxnCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAmtRngCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitCntRngCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditAmtRngCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditCntRngCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransactionProfiling", propOrder = {
    "seqNo",
    "trxnCD",
    "debitAmtRngCD",
    "debitCntRngCD",
    "creditAmtRngCD",
    "creditCntRngCD"
})
public class TransactionProfiling {

    @XmlElement(name = "SeqNo", required = true)
    protected String seqNo;
    @XmlElement(name = "TrxnCD")
    protected String trxnCD;
    @XmlElement(name = "DebitAmtRngCD")
    protected String debitAmtRngCD;
    @XmlElement(name = "DebitCntRngCD")
    protected String debitCntRngCD;
    @XmlElement(name = "CreditAmtRngCD")
    protected String creditAmtRngCD;
    @XmlElement(name = "CreditCntRngCD")
    protected String creditCntRngCD;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad trxnCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrxnCD() {
        return trxnCD;
    }

    /**
     * Define el valor de la propiedad trxnCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrxnCD(String value) {
        this.trxnCD = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAmtRngCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAmtRngCD() {
        return debitAmtRngCD;
    }

    /**
     * Define el valor de la propiedad debitAmtRngCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAmtRngCD(String value) {
        this.debitAmtRngCD = value;
    }

    /**
     * Obtiene el valor de la propiedad debitCntRngCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitCntRngCD() {
        return debitCntRngCD;
    }

    /**
     * Define el valor de la propiedad debitCntRngCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitCntRngCD(String value) {
        this.debitCntRngCD = value;
    }

    /**
     * Obtiene el valor de la propiedad creditAmtRngCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditAmtRngCD() {
        return creditAmtRngCD;
    }

    /**
     * Define el valor de la propiedad creditAmtRngCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditAmtRngCD(String value) {
        this.creditAmtRngCD = value;
    }

    /**
     * Obtiene el valor de la propiedad creditCntRngCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditCntRngCD() {
        return creditCntRngCD;
    }

    /**
     * Define el valor de la propiedad creditCntRngCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditCntRngCD(String value) {
        this.creditCntRngCD = value;
    }

}
