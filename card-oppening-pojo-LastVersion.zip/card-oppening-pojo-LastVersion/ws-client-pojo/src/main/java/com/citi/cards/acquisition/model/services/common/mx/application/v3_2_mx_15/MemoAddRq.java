
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.MemoDetails;


/**
 * <p>Clase Java para MemoAddRq complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="MemoAddRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Initiator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BranchID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicantID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MemoDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}MemoDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MemoAddRq", propOrder = {
    "initiator",
    "branchID",
    "applicantID",
    "memoDetails"
})
public class MemoAddRq {

    @XmlElement(name = "Initiator", required = true)
    protected String initiator;
    @XmlElement(name = "BranchID")
    protected String branchID;
    @XmlElement(name = "ApplicantID", required = true)
    protected String applicantID;
    @XmlElement(name = "MemoDetails")
    protected MemoDetails memoDetails;

    /**
     * Obtiene el valor de la propiedad initiator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitiator() {
        return initiator;
    }

    /**
     * Define el valor de la propiedad initiator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitiator(String value) {
        this.initiator = value;
    }

    /**
     * Obtiene el valor de la propiedad branchID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchID() {
        return branchID;
    }

    /**
     * Define el valor de la propiedad branchID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchID(String value) {
        this.branchID = value;
    }

    /**
     * Obtiene el valor de la propiedad applicantID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicantID() {
        return applicantID;
    }

    /**
     * Define el valor de la propiedad applicantID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicantID(String value) {
        this.applicantID = value;
    }

    /**
     * Obtiene el valor de la propiedad memoDetails.
     * 
     * @return
     *     possible object is
     *     {@link MemoDetails }
     *     
     */
    public MemoDetails getMemoDetails() {
        return memoDetails;
    }

    /**
     * Define el valor de la propiedad memoDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link MemoDetails }
     *     
     */
    public void setMemoDetails(MemoDetails value) {
        this.memoDetails = value;
    }

}
