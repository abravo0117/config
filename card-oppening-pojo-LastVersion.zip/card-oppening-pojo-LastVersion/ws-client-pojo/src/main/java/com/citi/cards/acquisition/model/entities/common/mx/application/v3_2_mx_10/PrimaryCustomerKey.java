
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para PrimaryCustomerKey complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PrimaryCustomerKey">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CustNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InternalCountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OwnerInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PrimaryCustomerKey", propOrder = {
    "custNo",
    "internalCountryCode",
    "ownerInd"
})
public class PrimaryCustomerKey {

    @XmlElement(name = "CustNo")
    protected String custNo;
    @XmlElement(name = "InternalCountryCode")
    protected String internalCountryCode;
    @XmlElement(name = "OwnerInd")
    protected String ownerInd;

    /**
     * Obtiene el valor de la propiedad custNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustNo() {
        return custNo;
    }

    /**
     * Define el valor de la propiedad custNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustNo(String value) {
        this.custNo = value;
    }

    /**
     * Obtiene el valor de la propiedad internalCountryCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInternalCountryCode() {
        return internalCountryCode;
    }

    /**
     * Define el valor de la propiedad internalCountryCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInternalCountryCode(String value) {
        this.internalCountryCode = value;
    }

    /**
     * Obtiene el valor de la propiedad ownerInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOwnerInd() {
        return ownerInd;
    }

    /**
     * Define el valor de la propiedad ownerInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOwnerInd(String value) {
        this.ownerInd = value;
    }

}
