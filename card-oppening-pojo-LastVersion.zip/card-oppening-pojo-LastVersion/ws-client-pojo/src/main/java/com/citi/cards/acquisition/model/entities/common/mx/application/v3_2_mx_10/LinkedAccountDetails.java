
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para LinkedAccountDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="LinkedAccountDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BSBCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BankName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Branch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LinkedAccountName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LinkedAccountNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RSPDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}RSPDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LinkedAccountDetails", propOrder = {
    "bsbCode",
    "bankName",
    "branch",
    "linkedAccountName",
    "linkedAccountNum",
    "rspDetails"
})
public class LinkedAccountDetails {

    @XmlElement(name = "BSBCode")
    protected String bsbCode;
    @XmlElement(name = "BankName")
    protected String bankName;
    @XmlElement(name = "Branch")
    protected String branch;
    @XmlElement(name = "LinkedAccountName")
    protected String linkedAccountName;
    @XmlElement(name = "LinkedAccountNum")
    protected String linkedAccountNum;
    @XmlElement(name = "RSPDetails")
    protected RSPDetails rspDetails;

    /**
     * Obtiene el valor de la propiedad bsbCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBSBCode() {
        return bsbCode;
    }

    /**
     * Define el valor de la propiedad bsbCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBSBCode(String value) {
        this.bsbCode = value;
    }

    /**
     * Obtiene el valor de la propiedad bankName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * Define el valor de la propiedad bankName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankName(String value) {
        this.bankName = value;
    }

    /**
     * Obtiene el valor de la propiedad branch.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranch() {
        return branch;
    }

    /**
     * Define el valor de la propiedad branch.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranch(String value) {
        this.branch = value;
    }

    /**
     * Obtiene el valor de la propiedad linkedAccountName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLinkedAccountName() {
        return linkedAccountName;
    }

    /**
     * Define el valor de la propiedad linkedAccountName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLinkedAccountName(String value) {
        this.linkedAccountName = value;
    }

    /**
     * Obtiene el valor de la propiedad linkedAccountNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLinkedAccountNum() {
        return linkedAccountNum;
    }

    /**
     * Define el valor de la propiedad linkedAccountNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLinkedAccountNum(String value) {
        this.linkedAccountNum = value;
    }

    /**
     * Obtiene el valor de la propiedad rspDetails.
     * 
     * @return
     *     possible object is
     *     {@link RSPDetails }
     *     
     */
    public RSPDetails getRSPDetails() {
        return rspDetails;
    }

    /**
     * Define el valor de la propiedad rspDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link RSPDetails }
     *     
     */
    public void setRSPDetails(RSPDetails value) {
        this.rspDetails = value;
    }

}
