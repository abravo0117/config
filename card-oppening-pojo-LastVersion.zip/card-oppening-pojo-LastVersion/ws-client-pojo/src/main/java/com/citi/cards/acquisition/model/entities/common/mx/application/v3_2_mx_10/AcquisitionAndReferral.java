
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para AcquisitionAndReferral complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="AcquisitionAndReferral">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AcqChannel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AcqUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AcqOfficer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefChannel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefOfficer" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CampaignSrcCd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RecType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProdCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AcquisitionAndReferral", propOrder = {
    "acqChannel",
    "acqUnit",
    "acqOfficer",
    "refChannel",
    "refUnit",
    "refOfficer",
    "campaignSrcCd",
    "recType",
    "prodCode"
})
public class AcquisitionAndReferral {

    @XmlElement(name = "AcqChannel")
    protected String acqChannel;
    @XmlElement(name = "AcqUnit")
    protected String acqUnit;
    @XmlElement(name = "AcqOfficer")
    protected String acqOfficer;
    @XmlElement(name = "RefChannel")
    protected String refChannel;
    @XmlElement(name = "RefUnit")
    protected String refUnit;
    @XmlElement(name = "RefOfficer")
    protected String refOfficer;
    @XmlElement(name = "CampaignSrcCd")
    protected String campaignSrcCd;
    @XmlElement(name = "RecType")
    protected String recType;
    @XmlElement(name = "ProdCode")
    protected String prodCode;

    /**
     * Obtiene el valor de la propiedad acqChannel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcqChannel() {
        return acqChannel;
    }

    /**
     * Define el valor de la propiedad acqChannel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcqChannel(String value) {
        this.acqChannel = value;
    }

    /**
     * Obtiene el valor de la propiedad acqUnit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcqUnit() {
        return acqUnit;
    }

    /**
     * Define el valor de la propiedad acqUnit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcqUnit(String value) {
        this.acqUnit = value;
    }

    /**
     * Obtiene el valor de la propiedad acqOfficer.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcqOfficer() {
        return acqOfficer;
    }

    /**
     * Define el valor de la propiedad acqOfficer.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcqOfficer(String value) {
        this.acqOfficer = value;
    }

    /**
     * Obtiene el valor de la propiedad refChannel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefChannel() {
        return refChannel;
    }

    /**
     * Define el valor de la propiedad refChannel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefChannel(String value) {
        this.refChannel = value;
    }

    /**
     * Obtiene el valor de la propiedad refUnit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefUnit() {
        return refUnit;
    }

    /**
     * Define el valor de la propiedad refUnit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefUnit(String value) {
        this.refUnit = value;
    }

    /**
     * Obtiene el valor de la propiedad refOfficer.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefOfficer() {
        return refOfficer;
    }

    /**
     * Define el valor de la propiedad refOfficer.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefOfficer(String value) {
        this.refOfficer = value;
    }

    /**
     * Obtiene el valor de la propiedad campaignSrcCd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCampaignSrcCd() {
        return campaignSrcCd;
    }

    /**
     * Define el valor de la propiedad campaignSrcCd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCampaignSrcCd(String value) {
        this.campaignSrcCd = value;
    }

    /**
     * Obtiene el valor de la propiedad recType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecType() {
        return recType;
    }

    /**
     * Define el valor de la propiedad recType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecType(String value) {
        this.recType = value;
    }

    /**
     * Obtiene el valor de la propiedad prodCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdCode() {
        return prodCode;
    }

    /**
     * Define el valor de la propiedad prodCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdCode(String value) {
        this.prodCode = value;
    }

}
