
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para RelationshipLevelDtls complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="RelationshipLevelDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RelationshipDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}RelationshipDetails" minOccurs="0"/>
 *         &lt;element name="SigningInstructionDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}SigningInstructionDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RelationshipLevelDtls", propOrder = {
    "relationshipDetails",
    "signingInstructionDetails"
})
public class RelationshipLevelDtls {

    @XmlElement(name = "RelationshipDetails")
    protected RelationshipDetails relationshipDetails;
    @XmlElement(name = "SigningInstructionDetails")
    protected SigningInstructionDetails signingInstructionDetails;

    /**
     * Obtiene el valor de la propiedad relationshipDetails.
     * 
     * @return
     *     possible object is
     *     {@link RelationshipDetails }
     *     
     */
    public RelationshipDetails getRelationshipDetails() {
        return relationshipDetails;
    }

    /**
     * Define el valor de la propiedad relationshipDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link RelationshipDetails }
     *     
     */
    public void setRelationshipDetails(RelationshipDetails value) {
        this.relationshipDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad signingInstructionDetails.
     * 
     * @return
     *     possible object is
     *     {@link SigningInstructionDetails }
     *     
     */
    public SigningInstructionDetails getSigningInstructionDetails() {
        return signingInstructionDetails;
    }

    /**
     * Define el valor de la propiedad signingInstructionDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link SigningInstructionDetails }
     *     
     */
    public void setSigningInstructionDetails(SigningInstructionDetails value) {
        this.signingInstructionDetails = value;
    }

}
