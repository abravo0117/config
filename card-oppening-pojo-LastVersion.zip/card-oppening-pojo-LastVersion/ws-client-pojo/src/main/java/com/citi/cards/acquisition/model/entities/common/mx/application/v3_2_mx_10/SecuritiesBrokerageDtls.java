
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para SecuritiesBrokerageDtls complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="SecuritiesBrokerageDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="Broker" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StockExchange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TradingStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Depository" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Remisier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RemisierName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DepositoryAcoountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BrokerTradingAccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SafeKeepingIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMaintID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMaintTStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SecuritiesBrokerageDtls", propOrder = {
    "seqNo",
    "broker",
    "stockExchange",
    "tradingStatus",
    "depository",
    "remisier",
    "remisierName",
    "depositoryAcoountNo",
    "brokerTradingAccountNo",
    "safeKeepingIndicator",
    "lastMaintID",
    "lastMaintTStamp"
})
public class SecuritiesBrokerageDtls {

    @XmlElement(name = "SeqNo")
    protected Integer seqNo;
    @XmlElement(name = "Broker")
    protected String broker;
    @XmlElement(name = "StockExchange")
    protected String stockExchange;
    @XmlElement(name = "TradingStatus")
    protected String tradingStatus;
    @XmlElement(name = "Depository")
    protected String depository;
    @XmlElement(name = "Remisier")
    protected String remisier;
    @XmlElement(name = "RemisierName")
    protected String remisierName;
    @XmlElement(name = "DepositoryAcoountNo")
    protected String depositoryAcoountNo;
    @XmlElement(name = "BrokerTradingAccountNo")
    protected String brokerTradingAccountNo;
    @XmlElement(name = "SafeKeepingIndicator")
    protected String safeKeepingIndicator;
    @XmlElement(name = "LastMaintID")
    protected String lastMaintID;
    @XmlElement(name = "LastMaintTStamp")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastMaintTStamp;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSeqNo(Integer value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad broker.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBroker() {
        return broker;
    }

    /**
     * Define el valor de la propiedad broker.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBroker(String value) {
        this.broker = value;
    }

    /**
     * Obtiene el valor de la propiedad stockExchange.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStockExchange() {
        return stockExchange;
    }

    /**
     * Define el valor de la propiedad stockExchange.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStockExchange(String value) {
        this.stockExchange = value;
    }

    /**
     * Obtiene el valor de la propiedad tradingStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTradingStatus() {
        return tradingStatus;
    }

    /**
     * Define el valor de la propiedad tradingStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTradingStatus(String value) {
        this.tradingStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad depository.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepository() {
        return depository;
    }

    /**
     * Define el valor de la propiedad depository.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepository(String value) {
        this.depository = value;
    }

    /**
     * Obtiene el valor de la propiedad remisier.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemisier() {
        return remisier;
    }

    /**
     * Define el valor de la propiedad remisier.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemisier(String value) {
        this.remisier = value;
    }

    /**
     * Obtiene el valor de la propiedad remisierName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemisierName() {
        return remisierName;
    }

    /**
     * Define el valor de la propiedad remisierName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemisierName(String value) {
        this.remisierName = value;
    }

    /**
     * Obtiene el valor de la propiedad depositoryAcoountNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepositoryAcoountNo() {
        return depositoryAcoountNo;
    }

    /**
     * Define el valor de la propiedad depositoryAcoountNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepositoryAcoountNo(String value) {
        this.depositoryAcoountNo = value;
    }

    /**
     * Obtiene el valor de la propiedad brokerTradingAccountNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrokerTradingAccountNo() {
        return brokerTradingAccountNo;
    }

    /**
     * Define el valor de la propiedad brokerTradingAccountNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrokerTradingAccountNo(String value) {
        this.brokerTradingAccountNo = value;
    }

    /**
     * Obtiene el valor de la propiedad safeKeepingIndicator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSafeKeepingIndicator() {
        return safeKeepingIndicator;
    }

    /**
     * Define el valor de la propiedad safeKeepingIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSafeKeepingIndicator(String value) {
        this.safeKeepingIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMaintID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastMaintID() {
        return lastMaintID;
    }

    /**
     * Define el valor de la propiedad lastMaintID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastMaintID(String value) {
        this.lastMaintID = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMaintTStamp.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastMaintTStamp() {
        return lastMaintTStamp;
    }

    /**
     * Define el valor de la propiedad lastMaintTStamp.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastMaintTStamp(XMLGregorianCalendar value) {
        this.lastMaintTStamp = value;
    }

}
