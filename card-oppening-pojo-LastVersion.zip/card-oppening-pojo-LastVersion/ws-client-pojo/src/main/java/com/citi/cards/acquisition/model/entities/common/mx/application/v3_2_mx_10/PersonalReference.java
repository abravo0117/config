
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.citi.cards.acquisition.model.shared.datatypes.v3_1_0_0.StructuredName;


/**
 * <p>Clase Java para PersonalReference complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PersonalReference">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Name" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}StructuredName" minOccurs="0"/>
 *         &lt;element name="RelationshipWithApplicant" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PersonalReference", propOrder = {
    "name",
    "relationshipWithApplicant"
})
public class PersonalReference {

    @XmlElement(name = "Name")
    protected StructuredName name;
    @XmlElement(name = "RelationshipWithApplicant")
    protected String relationshipWithApplicant;

    /**
     * Obtiene el valor de la propiedad name.
     * 
     * @return
     *     possible object is
     *     {@link StructuredName }
     *     
     */
    public StructuredName getName() {
        return name;
    }

    /**
     * Define el valor de la propiedad name.
     * 
     * @param value
     *     allowed object is
     *     {@link StructuredName }
     *     
     */
    public void setName(StructuredName value) {
        this.name = value;
    }

    /**
     * Obtiene el valor de la propiedad relationshipWithApplicant.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipWithApplicant() {
        return relationshipWithApplicant;
    }

    /**
     * Define el valor de la propiedad relationshipWithApplicant.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipWithApplicant(String value) {
        this.relationshipWithApplicant = value;
    }

}
