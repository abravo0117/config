
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Employment complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Employment">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CompanyNameEnglish" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}NameTitle" minOccurs="0"/>
 *         &lt;element name="CompanyNameLocal" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}NameTitle" minOccurs="0"/>
 *         &lt;element name="EmploymentType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JobTitle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OccupationCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NatureOfBusiness" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="YearsInEmployment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MonthsInEmployment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="YearsInIndustry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MonthsInIndustry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Department" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Employment", propOrder = {
    "companyNameEnglish",
    "companyNameLocal",
    "employmentType",
    "jobTitle",
    "occupationCode",
    "natureOfBusiness",
    "yearsInEmployment",
    "monthsInEmployment",
    "yearsInIndustry",
    "monthsInIndustry",
    "department"
})
public class Employment {

    @XmlElement(name = "CompanyNameEnglish")
    protected String companyNameEnglish;
    @XmlElement(name = "CompanyNameLocal")
    protected String companyNameLocal;
    @XmlElement(name = "EmploymentType")
    protected String employmentType;
    @XmlElement(name = "JobTitle")
    protected String jobTitle;
    @XmlElement(name = "OccupationCode")
    protected String occupationCode;
    @XmlElement(name = "NatureOfBusiness")
    protected String natureOfBusiness;
    @XmlElement(name = "YearsInEmployment")
    protected String yearsInEmployment;
    @XmlElement(name = "MonthsInEmployment")
    protected String monthsInEmployment;
    @XmlElement(name = "YearsInIndustry")
    protected String yearsInIndustry;
    @XmlElement(name = "MonthsInIndustry")
    protected String monthsInIndustry;
    @XmlElement(name = "Department")
    protected String department;

    /**
     * Obtiene el valor de la propiedad companyNameEnglish.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyNameEnglish() {
        return companyNameEnglish;
    }

    /**
     * Define el valor de la propiedad companyNameEnglish.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyNameEnglish(String value) {
        this.companyNameEnglish = value;
    }

    /**
     * Obtiene el valor de la propiedad companyNameLocal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompanyNameLocal() {
        return companyNameLocal;
    }

    /**
     * Define el valor de la propiedad companyNameLocal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompanyNameLocal(String value) {
        this.companyNameLocal = value;
    }

    /**
     * Obtiene el valor de la propiedad employmentType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmploymentType() {
        return employmentType;
    }

    /**
     * Define el valor de la propiedad employmentType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmploymentType(String value) {
        this.employmentType = value;
    }

    /**
     * Obtiene el valor de la propiedad jobTitle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * Define el valor de la propiedad jobTitle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobTitle(String value) {
        this.jobTitle = value;
    }

    /**
     * Obtiene el valor de la propiedad occupationCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOccupationCode() {
        return occupationCode;
    }

    /**
     * Define el valor de la propiedad occupationCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOccupationCode(String value) {
        this.occupationCode = value;
    }

    /**
     * Obtiene el valor de la propiedad natureOfBusiness.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNatureOfBusiness() {
        return natureOfBusiness;
    }

    /**
     * Define el valor de la propiedad natureOfBusiness.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNatureOfBusiness(String value) {
        this.natureOfBusiness = value;
    }

    /**
     * Obtiene el valor de la propiedad yearsInEmployment.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYearsInEmployment() {
        return yearsInEmployment;
    }

    /**
     * Define el valor de la propiedad yearsInEmployment.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYearsInEmployment(String value) {
        this.yearsInEmployment = value;
    }

    /**
     * Obtiene el valor de la propiedad monthsInEmployment.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMonthsInEmployment() {
        return monthsInEmployment;
    }

    /**
     * Define el valor de la propiedad monthsInEmployment.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMonthsInEmployment(String value) {
        this.monthsInEmployment = value;
    }

    /**
     * Obtiene el valor de la propiedad yearsInIndustry.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYearsInIndustry() {
        return yearsInIndustry;
    }

    /**
     * Define el valor de la propiedad yearsInIndustry.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYearsInIndustry(String value) {
        this.yearsInIndustry = value;
    }

    /**
     * Obtiene el valor de la propiedad monthsInIndustry.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMonthsInIndustry() {
        return monthsInIndustry;
    }

    /**
     * Define el valor de la propiedad monthsInIndustry.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMonthsInIndustry(String value) {
        this.monthsInIndustry = value;
    }

    /**
     * Obtiene el valor de la propiedad department.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepartment() {
        return department;
    }

    /**
     * Define el valor de la propiedad department.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepartment(String value) {
        this.department = value;
    }

}
