
package com.citi.cards.acquisition.model.shared.datatypes.v3_1_0_0;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Phone complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Phone">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Type" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Code"/>
 *         &lt;element name="SequenceNo" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="No" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CountryCode" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Code" minOccurs="0"/>
 *         &lt;element name="AreaCode" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Code" minOccurs="0"/>
 *         &lt;element name="Extension" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Exchange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PreferredCallTime" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Code" minOccurs="0"/>
 *         &lt;element name="TimeZone" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Code" minOccurs="0"/>
 *         &lt;element name="OKToCall" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="OKToSMS" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="BestTimeToCall" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Code" minOccurs="0"/>
 *         &lt;element name="ContactPersonName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Phone", propOrder = {
    "type",
    "sequenceNo",
    "no",
    "countryCode",
    "areaCode",
    "extension",
    "exchange",
    "preferredCallTime",
    "timeZone",
    "okToCall",
    "okToSMS",
    "bestTimeToCall",
    "contactPersonName"
})
public class Phone {

    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "SequenceNo")
    protected BigInteger sequenceNo;
    @XmlElement(name = "No")
    protected String no;
    @XmlElement(name = "CountryCode")
    protected String countryCode;
    @XmlElement(name = "AreaCode")
    protected String areaCode;
    @XmlElement(name = "Extension")
    protected String extension;
    @XmlElement(name = "Exchange")
    protected String exchange;
    @XmlElement(name = "PreferredCallTime")
    protected String preferredCallTime;
    @XmlElement(name = "TimeZone")
    protected String timeZone;
    @XmlElement(name = "OKToCall")
    protected String okToCall;
    @XmlElement(name = "OKToSMS")
    protected String okToSMS;
    @XmlElement(name = "BestTimeToCall")
    protected String bestTimeToCall;
    @XmlElement(name = "ContactPersonName")
    protected String contactPersonName;

    /**
     * Obtiene el valor de la propiedad type.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Define el valor de la propiedad type.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Obtiene el valor de la propiedad sequenceNo.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getSequenceNo() {
        return sequenceNo;
    }

    /**
     * Define el valor de la propiedad sequenceNo.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setSequenceNo(BigInteger value) {
        this.sequenceNo = value;
    }

    /**
     * Obtiene el valor de la propiedad no.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNo() {
        return no;
    }

    /**
     * Define el valor de la propiedad no.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNo(String value) {
        this.no = value;
    }

    /**
     * Obtiene el valor de la propiedad countryCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Define el valor de la propiedad countryCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String value) {
        this.countryCode = value;
    }

    /**
     * Obtiene el valor de la propiedad areaCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAreaCode() {
        return areaCode;
    }

    /**
     * Define el valor de la propiedad areaCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAreaCode(String value) {
        this.areaCode = value;
    }

    /**
     * Obtiene el valor de la propiedad extension.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExtension() {
        return extension;
    }

    /**
     * Define el valor de la propiedad extension.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExtension(String value) {
        this.extension = value;
    }

    /**
     * Obtiene el valor de la propiedad exchange.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExchange() {
        return exchange;
    }

    /**
     * Define el valor de la propiedad exchange.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExchange(String value) {
        this.exchange = value;
    }

    /**
     * Obtiene el valor de la propiedad preferredCallTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreferredCallTime() {
        return preferredCallTime;
    }

    /**
     * Define el valor de la propiedad preferredCallTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreferredCallTime(String value) {
        this.preferredCallTime = value;
    }

    /**
     * Obtiene el valor de la propiedad timeZone.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimeZone() {
        return timeZone;
    }

    /**
     * Define el valor de la propiedad timeZone.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimeZone(String value) {
        this.timeZone = value;
    }

    /**
     * Obtiene el valor de la propiedad okToCall.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOKToCall() {
        return okToCall;
    }

    /**
     * Define el valor de la propiedad okToCall.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOKToCall(String value) {
        this.okToCall = value;
    }

    /**
     * Obtiene el valor de la propiedad okToSMS.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOKToSMS() {
        return okToSMS;
    }

    /**
     * Define el valor de la propiedad okToSMS.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOKToSMS(String value) {
        this.okToSMS = value;
    }

    /**
     * Obtiene el valor de la propiedad bestTimeToCall.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBestTimeToCall() {
        return bestTimeToCall;
    }

    /**
     * Define el valor de la propiedad bestTimeToCall.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBestTimeToCall(String value) {
        this.bestTimeToCall = value;
    }

    /**
     * Obtiene el valor de la propiedad contactPersonName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContactPersonName() {
        return contactPersonName;
    }

    /**
     * Define el valor de la propiedad contactPersonName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContactPersonName(String value) {
        this.contactPersonName = value;
    }

}
