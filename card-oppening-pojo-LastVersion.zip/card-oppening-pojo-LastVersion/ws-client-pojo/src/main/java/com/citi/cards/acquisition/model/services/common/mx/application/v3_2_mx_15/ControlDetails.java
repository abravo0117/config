
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ControlDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ControlDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Ctrl" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BusinessType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustSeg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Ctrl3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ctrl4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OperatingLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ControlDetails", propOrder = {
    "ctrl",
    "countryCode",
    "businessType",
    "custSeg",
    "currencyCode",
    "ctrl3",
    "ctrl4",
    "operatingLevel"
})
public class ControlDetails {

    @XmlElement(name = "Ctrl", required = true)
    protected String ctrl;
    @XmlElement(name = "CountryCode", required = true)
    protected String countryCode;
    @XmlElement(name = "BusinessType")
    protected String businessType;
    @XmlElement(name = "CustSeg")
    protected String custSeg;
    @XmlElement(name = "CurrencyCode", required = true)
    protected String currencyCode;
    @XmlElement(name = "Ctrl3")
    protected String ctrl3;
    @XmlElement(name = "Ctrl4")
    protected String ctrl4;
    @XmlElement(name = "OperatingLevel")
    protected String operatingLevel;

    /**
     * Obtiene el valor de la propiedad ctrl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrl() {
        return ctrl;
    }

    /**
     * Define el valor de la propiedad ctrl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrl(String value) {
        this.ctrl = value;
    }

    /**
     * Obtiene el valor de la propiedad countryCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Define el valor de la propiedad countryCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryCode(String value) {
        this.countryCode = value;
    }

    /**
     * Obtiene el valor de la propiedad businessType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBusinessType() {
        return businessType;
    }

    /**
     * Define el valor de la propiedad businessType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBusinessType(String value) {
        this.businessType = value;
    }

    /**
     * Obtiene el valor de la propiedad custSeg.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustSeg() {
        return custSeg;
    }

    /**
     * Define el valor de la propiedad custSeg.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustSeg(String value) {
        this.custSeg = value;
    }

    /**
     * Obtiene el valor de la propiedad currencyCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Define el valor de la propiedad currencyCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrencyCode(String value) {
        this.currencyCode = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrl3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrl3() {
        return ctrl3;
    }

    /**
     * Define el valor de la propiedad ctrl3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrl3(String value) {
        this.ctrl3 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrl4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrl4() {
        return ctrl4;
    }

    /**
     * Define el valor de la propiedad ctrl4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrl4(String value) {
        this.ctrl4 = value;
    }

    /**
     * Obtiene el valor de la propiedad operatingLevel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperatingLevel() {
        return operatingLevel;
    }

    /**
     * Define el valor de la propiedad operatingLevel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperatingLevel(String value) {
        this.operatingLevel = value;
    }

}
