
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para IndividualCustomerBasicData complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="IndividualCustomerBasicData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SelfPFDecl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PFOfficeStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PFOfficeDtls" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PFOfficeStrtDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PFOfficeEndDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IndividualCustomerBasicData", propOrder = {
    "selfPFDecl",
    "pfOfficeStatus",
    "pfOfficeDtls",
    "pfOfficeStrtDt",
    "pfOfficeEndDt"
})
public class IndividualCustomerBasicData {

    @XmlElement(name = "SelfPFDecl")
    protected String selfPFDecl;
    @XmlElement(name = "PFOfficeStatus")
    protected String pfOfficeStatus;
    @XmlElement(name = "PFOfficeDtls")
    protected String pfOfficeDtls;
    @XmlElement(name = "PFOfficeStrtDt")
    protected String pfOfficeStrtDt;
    @XmlElement(name = "PFOfficeEndDt")
    protected String pfOfficeEndDt;

    /**
     * Obtiene el valor de la propiedad selfPFDecl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSelfPFDecl() {
        return selfPFDecl;
    }

    /**
     * Define el valor de la propiedad selfPFDecl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSelfPFDecl(String value) {
        this.selfPFDecl = value;
    }

    /**
     * Obtiene el valor de la propiedad pfOfficeStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPFOfficeStatus() {
        return pfOfficeStatus;
    }

    /**
     * Define el valor de la propiedad pfOfficeStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPFOfficeStatus(String value) {
        this.pfOfficeStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad pfOfficeDtls.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPFOfficeDtls() {
        return pfOfficeDtls;
    }

    /**
     * Define el valor de la propiedad pfOfficeDtls.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPFOfficeDtls(String value) {
        this.pfOfficeDtls = value;
    }

    /**
     * Obtiene el valor de la propiedad pfOfficeStrtDt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPFOfficeStrtDt() {
        return pfOfficeStrtDt;
    }

    /**
     * Define el valor de la propiedad pfOfficeStrtDt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPFOfficeStrtDt(String value) {
        this.pfOfficeStrtDt = value;
    }

    /**
     * Obtiene el valor de la propiedad pfOfficeEndDt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPFOfficeEndDt() {
        return pfOfficeEndDt;
    }

    /**
     * Define el valor de la propiedad pfOfficeEndDt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPFOfficeEndDt(String value) {
        this.pfOfficeEndDt = value;
    }

}
