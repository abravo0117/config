
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para LdInterestRates complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="LdInterestRates">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="FromDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ToDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InterestRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PreTermCharge" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChargePerAmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LdInterestRates", propOrder = {
    "fromDate",
    "toDate",
    "interestRate",
    "preTermCharge",
    "chargePerAmt"
})
public class LdInterestRates {

    @XmlElement(name = "FromDate")
    protected String fromDate;
    @XmlElement(name = "ToDate")
    protected String toDate;
    @XmlElement(name = "InterestRate")
    protected String interestRate;
    @XmlElement(name = "PreTermCharge")
    protected String preTermCharge;
    @XmlElement(name = "ChargePerAmt")
    protected String chargePerAmt;

    /**
     * Obtiene el valor de la propiedad fromDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromDate() {
        return fromDate;
    }

    /**
     * Define el valor de la propiedad fromDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromDate(String value) {
        this.fromDate = value;
    }

    /**
     * Obtiene el valor de la propiedad toDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToDate() {
        return toDate;
    }

    /**
     * Define el valor de la propiedad toDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToDate(String value) {
        this.toDate = value;
    }

    /**
     * Obtiene el valor de la propiedad interestRate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterestRate() {
        return interestRate;
    }

    /**
     * Define el valor de la propiedad interestRate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterestRate(String value) {
        this.interestRate = value;
    }

    /**
     * Obtiene el valor de la propiedad preTermCharge.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreTermCharge() {
        return preTermCharge;
    }

    /**
     * Define el valor de la propiedad preTermCharge.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreTermCharge(String value) {
        this.preTermCharge = value;
    }

    /**
     * Obtiene el valor de la propiedad chargePerAmt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChargePerAmt() {
        return chargePerAmt;
    }

    /**
     * Define el valor de la propiedad chargePerAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChargePerAmt(String value) {
        this.chargePerAmt = value;
    }

}
