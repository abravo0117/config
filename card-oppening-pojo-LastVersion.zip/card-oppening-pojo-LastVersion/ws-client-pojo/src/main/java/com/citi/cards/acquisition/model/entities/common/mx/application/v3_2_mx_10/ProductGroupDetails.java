
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ProductGroupDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ProductGroupDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ProductGroup" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ProductOrg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ProductType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ProductDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="isPrimaryCardsOnly" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ApplicationStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicationStage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MissingDocs" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}DocumentDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductGroupDetails", propOrder = {
    "productGroup",
    "productOrg",
    "productType",
    "productDescription",
    "isPrimaryCardsOnly",
    "applicationStatus",
    "applicationStage",
    "missingDocs"
})
public class ProductGroupDetails {

    @XmlElement(name = "ProductGroup", required = true)
    protected String productGroup;
    @XmlElement(name = "ProductOrg", required = true)
    protected String productOrg;
    @XmlElement(name = "ProductType", required = true)
    protected String productType;
    @XmlElement(name = "ProductDescription", required = true)
    protected String productDescription;
    protected boolean isPrimaryCardsOnly;
    @XmlElement(name = "ApplicationStatus", required = true)
    protected String applicationStatus;
    @XmlElement(name = "ApplicationStage", required = true)
    protected String applicationStage;
    @XmlElement(name = "MissingDocs")
    protected List<DocumentDetails> missingDocs;

    /**
     * Obtiene el valor de la propiedad productGroup.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductGroup() {
        return productGroup;
    }

    /**
     * Define el valor de la propiedad productGroup.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductGroup(String value) {
        this.productGroup = value;
    }

    /**
     * Obtiene el valor de la propiedad productOrg.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductOrg() {
        return productOrg;
    }

    /**
     * Define el valor de la propiedad productOrg.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductOrg(String value) {
        this.productOrg = value;
    }

    /**
     * Obtiene el valor de la propiedad productType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductType() {
        return productType;
    }

    /**
     * Define el valor de la propiedad productType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductType(String value) {
        this.productType = value;
    }

    /**
     * Obtiene el valor de la propiedad productDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductDescription() {
        return productDescription;
    }

    /**
     * Define el valor de la propiedad productDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductDescription(String value) {
        this.productDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad isPrimaryCardsOnly.
     * 
     */
    public boolean isIsPrimaryCardsOnly() {
        return isPrimaryCardsOnly;
    }

    /**
     * Define el valor de la propiedad isPrimaryCardsOnly.
     * 
     */
    public void setIsPrimaryCardsOnly(boolean value) {
        this.isPrimaryCardsOnly = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationStatus() {
        return applicationStatus;
    }

    /**
     * Define el valor de la propiedad applicationStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationStatus(String value) {
        this.applicationStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationStage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationStage() {
        return applicationStage;
    }

    /**
     * Define el valor de la propiedad applicationStage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationStage(String value) {
        this.applicationStage = value;
    }

    /**
     * Gets the value of the missingDocs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the missingDocs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMissingDocs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentDetails }
     * 
     * 
     */
    public List<DocumentDetails> getMissingDocs() {
        if (missingDocs == null) {
            missingDocs = new ArrayList<DocumentDetails>();
        }
        return this.missingDocs;
    }

}
