
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerServices complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerServices">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CustomerKey" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerKey" minOccurs="0"/>
 *         &lt;element name="TPin" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}TPin" minOccurs="0"/>
 *         &lt;element name="CitiCard" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CitiCard" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerServices", propOrder = {
    "customerKey",
    "tPin",
    "citiCard"
})
public class CustomerServices {

    @XmlElement(name = "CustomerKey")
    protected CustomerKey customerKey;
    @XmlElement(name = "TPin")
    protected TPin tPin;
    @XmlElement(name = "CitiCard")
    protected List<CitiCard> citiCard;

    /**
     * Obtiene el valor de la propiedad customerKey.
     * 
     * @return
     *     possible object is
     *     {@link CustomerKey }
     *     
     */
    public CustomerKey getCustomerKey() {
        return customerKey;
    }

    /**
     * Define el valor de la propiedad customerKey.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerKey }
     *     
     */
    public void setCustomerKey(CustomerKey value) {
        this.customerKey = value;
    }

    /**
     * Obtiene el valor de la propiedad tPin.
     * 
     * @return
     *     possible object is
     *     {@link TPin }
     *     
     */
    public TPin getTPin() {
        return tPin;
    }

    /**
     * Define el valor de la propiedad tPin.
     * 
     * @param value
     *     allowed object is
     *     {@link TPin }
     *     
     */
    public void setTPin(TPin value) {
        this.tPin = value;
    }

    /**
     * Gets the value of the citiCard property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the citiCard property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCitiCard().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CitiCard }
     * 
     * 
     */
    public List<CitiCard> getCitiCard() {
        if (citiCard == null) {
            citiCard = new ArrayList<CitiCard>();
        }
        return this.citiCard;
    }

}
