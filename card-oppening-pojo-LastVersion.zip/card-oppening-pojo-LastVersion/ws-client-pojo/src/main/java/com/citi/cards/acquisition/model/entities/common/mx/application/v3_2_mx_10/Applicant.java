
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.citi.cards.acquisition.model.shared.datatypes.v3_1_0_0.Phone;


/**
 * <p>Clase Java para Applicant complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Applicant">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BasicData" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}BasicData"/>
 *         &lt;element name="Address" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Address" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Phone" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Phone" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Employment" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Employment" minOccurs="0"/>
 *         &lt;element name="Income" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Income" minOccurs="0"/>
 *         &lt;element name="Product" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Product" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CounterOffersProductDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CounterOffersProductDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Applicant", propOrder = {
    "basicData",
    "address",
    "phone",
    "employment",
    "income",
    "product",
    "counterOffersProductDetails"
})
public class Applicant {

    @XmlElement(name = "BasicData", required = true)
    protected BasicData basicData;
    @XmlElement(name = "Address")
    protected List<Address> address;
    @XmlElement(name = "Phone")
    protected List<Phone> phone;
    @XmlElement(name = "Employment")
    protected Employment employment;
    @XmlElement(name = "Income")
    protected Income income;
    @XmlElement(name = "Product")
    protected List<Product> product;
    @XmlElement(name = "CounterOffersProductDetails")
    protected List<CounterOffersProductDetails> counterOffersProductDetails;

    /**
     * Obtiene el valor de la propiedad basicData.
     * 
     * @return
     *     possible object is
     *     {@link BasicData }
     *     
     */
    public BasicData getBasicData() {
        return basicData;
    }

    /**
     * Define el valor de la propiedad basicData.
     * 
     * @param value
     *     allowed object is
     *     {@link BasicData }
     *     
     */
    public void setBasicData(BasicData value) {
        this.basicData = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the address property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddress().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Address }
     * 
     * 
     */
    public List<Address> getAddress() {
        if (address == null) {
            address = new ArrayList<Address>();
        }
        return this.address;
    }

    /**
     * Gets the value of the phone property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the phone property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPhone().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Phone }
     * 
     * 
     */
    public List<Phone> getPhone() {
        if (phone == null) {
            phone = new ArrayList<Phone>();
        }
        return this.phone;
    }

    /**
     * Obtiene el valor de la propiedad employment.
     * 
     * @return
     *     possible object is
     *     {@link Employment }
     *     
     */
    public Employment getEmployment() {
        return employment;
    }

    /**
     * Define el valor de la propiedad employment.
     * 
     * @param value
     *     allowed object is
     *     {@link Employment }
     *     
     */
    public void setEmployment(Employment value) {
        this.employment = value;
    }

    /**
     * Obtiene el valor de la propiedad income.
     * 
     * @return
     *     possible object is
     *     {@link Income }
     *     
     */
    public Income getIncome() {
        return income;
    }

    /**
     * Define el valor de la propiedad income.
     * 
     * @param value
     *     allowed object is
     *     {@link Income }
     *     
     */
    public void setIncome(Income value) {
        this.income = value;
    }

    /**
     * Gets the value of the product property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the product property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Product }
     * 
     * 
     */
    public List<Product> getProduct() {
        if (product == null) {
            product = new ArrayList<Product>();
        }
        return this.product;
    }

    /**
     * Gets the value of the counterOffersProductDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the counterOffersProductDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCounterOffersProductDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CounterOffersProductDetails }
     * 
     * 
     */
    public List<CounterOffersProductDetails> getCounterOffersProductDetails() {
        if (counterOffersProductDetails == null) {
            counterOffersProductDetails = new ArrayList<CounterOffersProductDetails>();
        }
        return this.counterOffersProductDetails;
    }

}
