
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para OfferKey complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="OfferKey">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OfferID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ctrl1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ctrl2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ctrl3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ctrl4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OfferKey", propOrder = {
    "offerID",
    "ctrl1",
    "ctrl2",
    "ctrl3",
    "ctrl4"
})
public class OfferKey {

    @XmlElement(name = "OfferID")
    protected String offerID;
    @XmlElement(name = "Ctrl1")
    protected String ctrl1;
    @XmlElement(name = "Ctrl2")
    protected String ctrl2;
    @XmlElement(name = "Ctrl3")
    protected String ctrl3;
    @XmlElement(name = "Ctrl4")
    protected String ctrl4;

    /**
     * Obtiene el valor de la propiedad offerID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferID() {
        return offerID;
    }

    /**
     * Define el valor de la propiedad offerID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferID(String value) {
        this.offerID = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrl1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrl1() {
        return ctrl1;
    }

    /**
     * Define el valor de la propiedad ctrl1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrl1(String value) {
        this.ctrl1 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrl2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrl2() {
        return ctrl2;
    }

    /**
     * Define el valor de la propiedad ctrl2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrl2(String value) {
        this.ctrl2 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrl3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrl3() {
        return ctrl3;
    }

    /**
     * Define el valor de la propiedad ctrl3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrl3(String value) {
        this.ctrl3 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrl4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrl4() {
        return ctrl4;
    }

    /**
     * Define el valor de la propiedad ctrl4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrl4(String value) {
        this.ctrl4 = value;
    }

}
