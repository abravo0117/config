
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CounterOffersProductDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CounterOffersProductDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Logo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SuggestedPreCreatedCardCreditLimit" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="DecisionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RejectReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProductDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PlasticID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FinalCreditLimit" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="ExistingCardNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExistingCardCreditLimit" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="AdditionalOfferDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CounterOffersProductDetails", propOrder = {
    "type",
    "logo",
    "status",
    "suggestedPreCreatedCardCreditLimit",
    "decisionType",
    "rejectReasonCode",
    "productDescription",
    "orgCode",
    "plasticID",
    "sourceCode",
    "finalCreditLimit",
    "existingCardNo",
    "existingCardCreditLimit",
    "additionalOfferDescription"
})
public class CounterOffersProductDetails {

    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "Logo", required = true)
    protected String logo;
    @XmlElement(name = "Status", required = true)
    protected String status;
    @XmlElement(name = "SuggestedPreCreatedCardCreditLimit")
    protected Double suggestedPreCreatedCardCreditLimit;
    @XmlElement(name = "DecisionType")
    protected String decisionType;
    @XmlElement(name = "RejectReasonCode")
    protected String rejectReasonCode;
    @XmlElement(name = "ProductDescription")
    protected String productDescription;
    @XmlElement(name = "OrgCode")
    protected String orgCode;
    @XmlElement(name = "PlasticID")
    protected String plasticID;
    @XmlElement(name = "SourceCode")
    protected String sourceCode;
    @XmlElement(name = "FinalCreditLimit")
    protected Double finalCreditLimit;
    @XmlElement(name = "ExistingCardNo")
    protected String existingCardNo;
    @XmlElement(name = "ExistingCardCreditLimit")
    protected Double existingCardCreditLimit;
    @XmlElement(name = "AdditionalOfferDescription")
    protected String additionalOfferDescription;

    /**
     * Obtiene el valor de la propiedad type.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Define el valor de la propiedad type.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Obtiene el valor de la propiedad logo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogo() {
        return logo;
    }

    /**
     * Define el valor de la propiedad logo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogo(String value) {
        this.logo = value;
    }

    /**
     * Obtiene el valor de la propiedad status.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Define el valor de la propiedad status.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Obtiene el valor de la propiedad suggestedPreCreatedCardCreditLimit.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getSuggestedPreCreatedCardCreditLimit() {
        return suggestedPreCreatedCardCreditLimit;
    }

    /**
     * Define el valor de la propiedad suggestedPreCreatedCardCreditLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setSuggestedPreCreatedCardCreditLimit(Double value) {
        this.suggestedPreCreatedCardCreditLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad decisionType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecisionType() {
        return decisionType;
    }

    /**
     * Define el valor de la propiedad decisionType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecisionType(String value) {
        this.decisionType = value;
    }

    /**
     * Obtiene el valor de la propiedad rejectReasonCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRejectReasonCode() {
        return rejectReasonCode;
    }

    /**
     * Define el valor de la propiedad rejectReasonCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRejectReasonCode(String value) {
        this.rejectReasonCode = value;
    }

    /**
     * Obtiene el valor de la propiedad productDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductDescription() {
        return productDescription;
    }

    /**
     * Define el valor de la propiedad productDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductDescription(String value) {
        this.productDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad orgCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgCode() {
        return orgCode;
    }

    /**
     * Define el valor de la propiedad orgCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgCode(String value) {
        this.orgCode = value;
    }

    /**
     * Obtiene el valor de la propiedad plasticID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlasticID() {
        return plasticID;
    }

    /**
     * Define el valor de la propiedad plasticID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlasticID(String value) {
        this.plasticID = value;
    }

    /**
     * Obtiene el valor de la propiedad sourceCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceCode() {
        return sourceCode;
    }

    /**
     * Define el valor de la propiedad sourceCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceCode(String value) {
        this.sourceCode = value;
    }

    /**
     * Obtiene el valor de la propiedad finalCreditLimit.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getFinalCreditLimit() {
        return finalCreditLimit;
    }

    /**
     * Define el valor de la propiedad finalCreditLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setFinalCreditLimit(Double value) {
        this.finalCreditLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad existingCardNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExistingCardNo() {
        return existingCardNo;
    }

    /**
     * Define el valor de la propiedad existingCardNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExistingCardNo(String value) {
        this.existingCardNo = value;
    }

    /**
     * Obtiene el valor de la propiedad existingCardCreditLimit.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getExistingCardCreditLimit() {
        return existingCardCreditLimit;
    }

    /**
     * Define el valor de la propiedad existingCardCreditLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setExistingCardCreditLimit(Double value) {
        this.existingCardCreditLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad additionalOfferDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalOfferDescription() {
        return additionalOfferDescription;
    }

    /**
     * Define el valor de la propiedad additionalOfferDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalOfferDescription(String value) {
        this.additionalOfferDescription = value;
    }

}
