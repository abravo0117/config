@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0")
package com.citi.cards.acquisition.model.shared.datatypes.v3_1_0_0;
