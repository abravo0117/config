
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerBasicData complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerBasicData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CustType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExstCustSubType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReqCustSubType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PeakCustSubType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Salutation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Title" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LegalTitle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NationalityCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DomicileCtryCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PermResCtryCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VIPInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StaffInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MotherMaidenNm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MaritalStatusCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DOB" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LocalEngName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DataStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMaintID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMaintTStamp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LocalEngSurNm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BotCustType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PCBankInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CorrsLanguage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BizNature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EpadSignReq" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SafeBoxInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmergencyContact" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TPINInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BOIFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PriBizType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BizSize" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RPG" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OwnerInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InvolvedType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmergenceContactPh" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LocalWHTax" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UpdatedToHost" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Sex" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResidenceStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResidenceType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NoOfDependents" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SignImageID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LineOfBusiness" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResidingSinceDT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EducationLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CPFBank" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CPFInvmAcctNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CPFAcctNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SRSBank" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SRSAcctNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Title2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SaluteBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AliasName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OtherName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResidenceInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BUMIInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NRCCInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WPInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WPExpDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SecondHomeInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SecondHomeExpDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EthnicGrp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LocalLoanInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EPFAcctNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HoldIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MailInstruction" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TaxDomicile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustAssignCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FaxIndEmnity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OkToEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AnnualTurnoverAmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CompStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PlaceOfBirth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtryOfBirth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BankAtWorkInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Religion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CodeOfRegency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CCC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Village" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SubDistrict" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EStmntReqInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustDisableInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustBasicDtlUpd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CorpContactsUpd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndividualCustomerBasicData" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}IndividualCustomerBasicData" minOccurs="0"/>
 *         &lt;element name="MiddleName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExstCustStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SpokenLanguage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SuffixName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LocalName1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LocalName2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CITIATWORKChannel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CITIATWORKJoinDT" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SendSMSAdvice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SendEmailAdvice" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ANNHouseholdInc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NoOfChildren" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EstmtType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StmtMailOption" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StmtViewOption" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CompSearchDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="QuotedInStockMkt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MajorOprnCtry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LeadID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DeclCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DeclIdenType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DeclIdenValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerBasicData", propOrder = {
    "custType",
    "exstCustSubType",
    "reqCustSubType",
    "peakCustSubType",
    "custStatus",
    "salutation",
    "lastName",
    "firstName",
    "title",
    "legalTitle",
    "nationalityCD",
    "domicileCtryCD",
    "permResCtryCD",
    "vipInd",
    "staffInd",
    "motherMaidenNm",
    "maritalStatusCD",
    "dob",
    "localEngName",
    "dataStatus",
    "lastMaintID",
    "lastMaintTStamp",
    "localEngSurNm",
    "botCustType",
    "pcBankInd",
    "corrsLanguage",
    "bizNature",
    "epadSignReq",
    "safeBoxInd",
    "emergencyContact",
    "tpinInd",
    "boiFlag",
    "priBizType",
    "bizSize",
    "rpg",
    "ownerInd",
    "involvedType",
    "emergenceContactPh",
    "localWHTax",
    "updatedToHost",
    "sex",
    "residenceStatus",
    "residenceType",
    "noOfDependents",
    "signImageID",
    "lineOfBusiness",
    "residingSinceDT",
    "educationLevel",
    "cpfBank",
    "cpfInvmAcctNo",
    "cpfAcctNo",
    "srsBank",
    "srsAcctNo",
    "title2",
    "saluteBy",
    "aliasName",
    "otherName",
    "residenceInd",
    "bumiInd",
    "nrccInd",
    "wpInd",
    "wpExpDate",
    "secondHomeInd",
    "secondHomeExpDt",
    "ethnicGrp",
    "localLoanInd",
    "epfAcctNo",
    "holdIndicator",
    "mailInstruction",
    "taxDomicile",
    "hr",
    "custAssignCode",
    "faxIndEmnity",
    "okToEmail",
    "annualTurnoverAmt",
    "agentCode",
    "compStatus",
    "placeOfBirth",
    "ctryOfBirth",
    "bankAtWorkInd",
    "religion",
    "codeOfRegency",
    "ccc",
    "village",
    "subDistrict",
    "eStmntReqInd",
    "custDisableInd",
    "custBasicDtlUpd",
    "corpContactsUpd",
    "individualCustomerBasicData",
    "middleName",
    "exstCustStatus",
    "spokenLanguage",
    "suffixName",
    "localName1",
    "localName2",
    "citiatworkChannel",
    "citiatworkJoinDT",
    "sendSMSAdvice",
    "sendEmailAdvice",
    "annHouseholdInc",
    "noOfChildren",
    "estmtType",
    "stmtMailOption",
    "stmtViewOption",
    "compSearchDate",
    "quotedInStockMkt",
    "majorOprnCtry",
    "leadID",
    "declCategory",
    "declIdenType",
    "declIdenValue"
})
public class CustomerBasicData {

    @XmlElement(name = "CustType")
    protected String custType;
    @XmlElement(name = "ExstCustSubType")
    protected String exstCustSubType;
    @XmlElement(name = "ReqCustSubType")
    protected String reqCustSubType;
    @XmlElement(name = "PeakCustSubType")
    protected String peakCustSubType;
    @XmlElement(name = "CustStatus")
    protected String custStatus;
    @XmlElement(name = "Salutation")
    protected String salutation;
    @XmlElement(name = "LastName")
    protected String lastName;
    @XmlElement(name = "FirstName")
    protected String firstName;
    @XmlElement(name = "Title")
    protected String title;
    @XmlElement(name = "LegalTitle")
    protected String legalTitle;
    @XmlElement(name = "NationalityCD")
    protected String nationalityCD;
    @XmlElement(name = "DomicileCtryCD")
    protected String domicileCtryCD;
    @XmlElement(name = "PermResCtryCD")
    protected String permResCtryCD;
    @XmlElement(name = "VIPInd")
    protected String vipInd;
    @XmlElement(name = "StaffInd")
    protected String staffInd;
    @XmlElement(name = "MotherMaidenNm")
    protected String motherMaidenNm;
    @XmlElement(name = "MaritalStatusCD")
    protected String maritalStatusCD;
    @XmlElement(name = "DOB")
    protected String dob;
    @XmlElement(name = "LocalEngName")
    protected String localEngName;
    @XmlElement(name = "DataStatus")
    protected String dataStatus;
    @XmlElement(name = "LastMaintID")
    protected String lastMaintID;
    @XmlElement(name = "LastMaintTStamp")
    protected String lastMaintTStamp;
    @XmlElement(name = "LocalEngSurNm")
    protected String localEngSurNm;
    @XmlElement(name = "BotCustType")
    protected String botCustType;
    @XmlElement(name = "PCBankInd")
    protected String pcBankInd;
    @XmlElement(name = "CorrsLanguage")
    protected String corrsLanguage;
    @XmlElement(name = "BizNature")
    protected String bizNature;
    @XmlElement(name = "EpadSignReq")
    protected String epadSignReq;
    @XmlElement(name = "SafeBoxInd")
    protected String safeBoxInd;
    @XmlElement(name = "EmergencyContact")
    protected String emergencyContact;
    @XmlElement(name = "TPINInd")
    protected String tpinInd;
    @XmlElement(name = "BOIFlag")
    protected String boiFlag;
    @XmlElement(name = "PriBizType")
    protected String priBizType;
    @XmlElement(name = "BizSize")
    protected String bizSize;
    @XmlElement(name = "RPG")
    protected String rpg;
    @XmlElement(name = "OwnerInd")
    protected String ownerInd;
    @XmlElement(name = "InvolvedType")
    protected String involvedType;
    @XmlElement(name = "EmergenceContactPh")
    protected String emergenceContactPh;
    @XmlElement(name = "LocalWHTax")
    protected String localWHTax;
    @XmlElement(name = "UpdatedToHost")
    protected String updatedToHost;
    @XmlElement(name = "Sex")
    protected String sex;
    @XmlElement(name = "ResidenceStatus")
    protected String residenceStatus;
    @XmlElement(name = "ResidenceType")
    protected String residenceType;
    @XmlElement(name = "NoOfDependents")
    protected String noOfDependents;
    @XmlElement(name = "SignImageID")
    protected String signImageID;
    @XmlElement(name = "LineOfBusiness")
    protected String lineOfBusiness;
    @XmlElement(name = "ResidingSinceDT")
    protected String residingSinceDT;
    @XmlElement(name = "EducationLevel")
    protected String educationLevel;
    @XmlElement(name = "CPFBank")
    protected String cpfBank;
    @XmlElement(name = "CPFInvmAcctNo")
    protected String cpfInvmAcctNo;
    @XmlElement(name = "CPFAcctNo")
    protected String cpfAcctNo;
    @XmlElement(name = "SRSBank")
    protected String srsBank;
    @XmlElement(name = "SRSAcctNo")
    protected String srsAcctNo;
    @XmlElement(name = "Title2")
    protected String title2;
    @XmlElement(name = "SaluteBy")
    protected String saluteBy;
    @XmlElement(name = "AliasName")
    protected String aliasName;
    @XmlElement(name = "OtherName")
    protected String otherName;
    @XmlElement(name = "ResidenceInd")
    protected String residenceInd;
    @XmlElement(name = "BUMIInd")
    protected String bumiInd;
    @XmlElement(name = "NRCCInd")
    protected String nrccInd;
    @XmlElement(name = "WPInd")
    protected String wpInd;
    @XmlElement(name = "WPExpDate")
    protected String wpExpDate;
    @XmlElement(name = "SecondHomeInd")
    protected String secondHomeInd;
    @XmlElement(name = "SecondHomeExpDt")
    protected String secondHomeExpDt;
    @XmlElement(name = "EthnicGrp")
    protected String ethnicGrp;
    @XmlElement(name = "LocalLoanInd")
    protected String localLoanInd;
    @XmlElement(name = "EPFAcctNo")
    protected String epfAcctNo;
    @XmlElement(name = "HoldIndicator")
    protected String holdIndicator;
    @XmlElement(name = "MailInstruction")
    protected String mailInstruction;
    @XmlElement(name = "TaxDomicile")
    protected String taxDomicile;
    @XmlElement(name = "HR")
    protected String hr;
    @XmlElement(name = "CustAssignCode")
    protected String custAssignCode;
    @XmlElement(name = "FaxIndEmnity")
    protected String faxIndEmnity;
    @XmlElement(name = "OkToEmail")
    protected String okToEmail;
    @XmlElement(name = "AnnualTurnoverAmt")
    protected String annualTurnoverAmt;
    @XmlElement(name = "AgentCode")
    protected String agentCode;
    @XmlElement(name = "CompStatus")
    protected String compStatus;
    @XmlElement(name = "PlaceOfBirth")
    protected String placeOfBirth;
    @XmlElement(name = "CtryOfBirth")
    protected String ctryOfBirth;
    @XmlElement(name = "BankAtWorkInd")
    protected String bankAtWorkInd;
    @XmlElement(name = "Religion")
    protected String religion;
    @XmlElement(name = "CodeOfRegency")
    protected String codeOfRegency;
    @XmlElement(name = "CCC")
    protected String ccc;
    @XmlElement(name = "Village")
    protected String village;
    @XmlElement(name = "SubDistrict")
    protected String subDistrict;
    @XmlElement(name = "EStmntReqInd")
    protected String eStmntReqInd;
    @XmlElement(name = "CustDisableInd")
    protected String custDisableInd;
    @XmlElement(name = "CustBasicDtlUpd")
    protected String custBasicDtlUpd;
    @XmlElement(name = "CorpContactsUpd")
    protected String corpContactsUpd;
    @XmlElement(name = "IndividualCustomerBasicData")
    protected IndividualCustomerBasicData individualCustomerBasicData;
    @XmlElement(name = "MiddleName")
    protected String middleName;
    @XmlElement(name = "ExstCustStatus")
    protected String exstCustStatus;
    @XmlElement(name = "SpokenLanguage")
    protected String spokenLanguage;
    @XmlElement(name = "SuffixName")
    protected String suffixName;
    @XmlElement(name = "LocalName1")
    protected String localName1;
    @XmlElement(name = "LocalName2")
    protected String localName2;
    @XmlElement(name = "CITIATWORKChannel")
    protected String citiatworkChannel;
    @XmlElement(name = "CITIATWORKJoinDT")
    protected String citiatworkJoinDT;
    @XmlElement(name = "SendSMSAdvice")
    protected String sendSMSAdvice;
    @XmlElement(name = "SendEmailAdvice")
    protected String sendEmailAdvice;
    @XmlElement(name = "ANNHouseholdInc")
    protected String annHouseholdInc;
    @XmlElement(name = "NoOfChildren")
    protected String noOfChildren;
    @XmlElement(name = "EstmtType")
    protected String estmtType;
    @XmlElement(name = "StmtMailOption")
    protected String stmtMailOption;
    @XmlElement(name = "StmtViewOption")
    protected String stmtViewOption;
    @XmlElement(name = "CompSearchDate")
    protected String compSearchDate;
    @XmlElement(name = "QuotedInStockMkt")
    protected String quotedInStockMkt;
    @XmlElement(name = "MajorOprnCtry")
    protected String majorOprnCtry;
    @XmlElement(name = "LeadID")
    protected String leadID;
    @XmlElement(name = "DeclCategory")
    protected String declCategory;
    @XmlElement(name = "DeclIdenType")
    protected String declIdenType;
    @XmlElement(name = "DeclIdenValue")
    protected String declIdenValue;

    /**
     * Obtiene el valor de la propiedad custType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustType() {
        return custType;
    }

    /**
     * Define el valor de la propiedad custType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustType(String value) {
        this.custType = value;
    }

    /**
     * Obtiene el valor de la propiedad exstCustSubType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExstCustSubType() {
        return exstCustSubType;
    }

    /**
     * Define el valor de la propiedad exstCustSubType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExstCustSubType(String value) {
        this.exstCustSubType = value;
    }

    /**
     * Obtiene el valor de la propiedad reqCustSubType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReqCustSubType() {
        return reqCustSubType;
    }

    /**
     * Define el valor de la propiedad reqCustSubType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReqCustSubType(String value) {
        this.reqCustSubType = value;
    }

    /**
     * Obtiene el valor de la propiedad peakCustSubType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPeakCustSubType() {
        return peakCustSubType;
    }

    /**
     * Define el valor de la propiedad peakCustSubType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPeakCustSubType(String value) {
        this.peakCustSubType = value;
    }

    /**
     * Obtiene el valor de la propiedad custStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustStatus() {
        return custStatus;
    }

    /**
     * Define el valor de la propiedad custStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustStatus(String value) {
        this.custStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad salutation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalutation() {
        return salutation;
    }

    /**
     * Define el valor de la propiedad salutation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalutation(String value) {
        this.salutation = value;
    }

    /**
     * Obtiene el valor de la propiedad lastName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Define el valor de la propiedad lastName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    /**
     * Obtiene el valor de la propiedad firstName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Define el valor de la propiedad firstName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirstName(String value) {
        this.firstName = value;
    }

    /**
     * Obtiene el valor de la propiedad title.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Define el valor de la propiedad title.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Obtiene el valor de la propiedad legalTitle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalTitle() {
        return legalTitle;
    }

    /**
     * Define el valor de la propiedad legalTitle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalTitle(String value) {
        this.legalTitle = value;
    }

    /**
     * Obtiene el valor de la propiedad nationalityCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNationalityCD() {
        return nationalityCD;
    }

    /**
     * Define el valor de la propiedad nationalityCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNationalityCD(String value) {
        this.nationalityCD = value;
    }

    /**
     * Obtiene el valor de la propiedad domicileCtryCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDomicileCtryCD() {
        return domicileCtryCD;
    }

    /**
     * Define el valor de la propiedad domicileCtryCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDomicileCtryCD(String value) {
        this.domicileCtryCD = value;
    }

    /**
     * Obtiene el valor de la propiedad permResCtryCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPermResCtryCD() {
        return permResCtryCD;
    }

    /**
     * Define el valor de la propiedad permResCtryCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPermResCtryCD(String value) {
        this.permResCtryCD = value;
    }

    /**
     * Obtiene el valor de la propiedad vipInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIPInd() {
        return vipInd;
    }

    /**
     * Define el valor de la propiedad vipInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIPInd(String value) {
        this.vipInd = value;
    }

    /**
     * Obtiene el valor de la propiedad staffInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaffInd() {
        return staffInd;
    }

    /**
     * Define el valor de la propiedad staffInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaffInd(String value) {
        this.staffInd = value;
    }

    /**
     * Obtiene el valor de la propiedad motherMaidenNm.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotherMaidenNm() {
        return motherMaidenNm;
    }

    /**
     * Define el valor de la propiedad motherMaidenNm.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotherMaidenNm(String value) {
        this.motherMaidenNm = value;
    }

    /**
     * Obtiene el valor de la propiedad maritalStatusCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaritalStatusCD() {
        return maritalStatusCD;
    }

    /**
     * Define el valor de la propiedad maritalStatusCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaritalStatusCD(String value) {
        this.maritalStatusCD = value;
    }

    /**
     * Obtiene el valor de la propiedad dob.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDOB() {
        return dob;
    }

    /**
     * Define el valor de la propiedad dob.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDOB(String value) {
        this.dob = value;
    }

    /**
     * Obtiene el valor de la propiedad localEngName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalEngName() {
        return localEngName;
    }

    /**
     * Define el valor de la propiedad localEngName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalEngName(String value) {
        this.localEngName = value;
    }

    /**
     * Obtiene el valor de la propiedad dataStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataStatus() {
        return dataStatus;
    }

    /**
     * Define el valor de la propiedad dataStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataStatus(String value) {
        this.dataStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMaintID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastMaintID() {
        return lastMaintID;
    }

    /**
     * Define el valor de la propiedad lastMaintID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastMaintID(String value) {
        this.lastMaintID = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMaintTStamp.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastMaintTStamp() {
        return lastMaintTStamp;
    }

    /**
     * Define el valor de la propiedad lastMaintTStamp.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastMaintTStamp(String value) {
        this.lastMaintTStamp = value;
    }

    /**
     * Obtiene el valor de la propiedad localEngSurNm.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalEngSurNm() {
        return localEngSurNm;
    }

    /**
     * Define el valor de la propiedad localEngSurNm.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalEngSurNm(String value) {
        this.localEngSurNm = value;
    }

    /**
     * Obtiene el valor de la propiedad botCustType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBotCustType() {
        return botCustType;
    }

    /**
     * Define el valor de la propiedad botCustType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBotCustType(String value) {
        this.botCustType = value;
    }

    /**
     * Obtiene el valor de la propiedad pcBankInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPCBankInd() {
        return pcBankInd;
    }

    /**
     * Define el valor de la propiedad pcBankInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPCBankInd(String value) {
        this.pcBankInd = value;
    }

    /**
     * Obtiene el valor de la propiedad corrsLanguage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorrsLanguage() {
        return corrsLanguage;
    }

    /**
     * Define el valor de la propiedad corrsLanguage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorrsLanguage(String value) {
        this.corrsLanguage = value;
    }

    /**
     * Obtiene el valor de la propiedad bizNature.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBizNature() {
        return bizNature;
    }

    /**
     * Define el valor de la propiedad bizNature.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBizNature(String value) {
        this.bizNature = value;
    }

    /**
     * Obtiene el valor de la propiedad epadSignReq.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEpadSignReq() {
        return epadSignReq;
    }

    /**
     * Define el valor de la propiedad epadSignReq.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEpadSignReq(String value) {
        this.epadSignReq = value;
    }

    /**
     * Obtiene el valor de la propiedad safeBoxInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSafeBoxInd() {
        return safeBoxInd;
    }

    /**
     * Define el valor de la propiedad safeBoxInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSafeBoxInd(String value) {
        this.safeBoxInd = value;
    }

    /**
     * Obtiene el valor de la propiedad emergencyContact.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmergencyContact() {
        return emergencyContact;
    }

    /**
     * Define el valor de la propiedad emergencyContact.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmergencyContact(String value) {
        this.emergencyContact = value;
    }

    /**
     * Obtiene el valor de la propiedad tpinInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTPINInd() {
        return tpinInd;
    }

    /**
     * Define el valor de la propiedad tpinInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTPINInd(String value) {
        this.tpinInd = value;
    }

    /**
     * Obtiene el valor de la propiedad boiFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBOIFlag() {
        return boiFlag;
    }

    /**
     * Define el valor de la propiedad boiFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBOIFlag(String value) {
        this.boiFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad priBizType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriBizType() {
        return priBizType;
    }

    /**
     * Define el valor de la propiedad priBizType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriBizType(String value) {
        this.priBizType = value;
    }

    /**
     * Obtiene el valor de la propiedad bizSize.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBizSize() {
        return bizSize;
    }

    /**
     * Define el valor de la propiedad bizSize.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBizSize(String value) {
        this.bizSize = value;
    }

    /**
     * Obtiene el valor de la propiedad rpg.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRPG() {
        return rpg;
    }

    /**
     * Define el valor de la propiedad rpg.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRPG(String value) {
        this.rpg = value;
    }

    /**
     * Obtiene el valor de la propiedad ownerInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOwnerInd() {
        return ownerInd;
    }

    /**
     * Define el valor de la propiedad ownerInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOwnerInd(String value) {
        this.ownerInd = value;
    }

    /**
     * Obtiene el valor de la propiedad involvedType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvolvedType() {
        return involvedType;
    }

    /**
     * Define el valor de la propiedad involvedType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvolvedType(String value) {
        this.involvedType = value;
    }

    /**
     * Obtiene el valor de la propiedad emergenceContactPh.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmergenceContactPh() {
        return emergenceContactPh;
    }

    /**
     * Define el valor de la propiedad emergenceContactPh.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmergenceContactPh(String value) {
        this.emergenceContactPh = value;
    }

    /**
     * Obtiene el valor de la propiedad localWHTax.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalWHTax() {
        return localWHTax;
    }

    /**
     * Define el valor de la propiedad localWHTax.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalWHTax(String value) {
        this.localWHTax = value;
    }

    /**
     * Obtiene el valor de la propiedad updatedToHost.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedToHost() {
        return updatedToHost;
    }

    /**
     * Define el valor de la propiedad updatedToHost.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedToHost(String value) {
        this.updatedToHost = value;
    }

    /**
     * Obtiene el valor de la propiedad sex.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSex() {
        return sex;
    }

    /**
     * Define el valor de la propiedad sex.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSex(String value) {
        this.sex = value;
    }

    /**
     * Obtiene el valor de la propiedad residenceStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResidenceStatus() {
        return residenceStatus;
    }

    /**
     * Define el valor de la propiedad residenceStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResidenceStatus(String value) {
        this.residenceStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad residenceType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResidenceType() {
        return residenceType;
    }

    /**
     * Define el valor de la propiedad residenceType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResidenceType(String value) {
        this.residenceType = value;
    }

    /**
     * Obtiene el valor de la propiedad noOfDependents.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoOfDependents() {
        return noOfDependents;
    }

    /**
     * Define el valor de la propiedad noOfDependents.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoOfDependents(String value) {
        this.noOfDependents = value;
    }

    /**
     * Obtiene el valor de la propiedad signImageID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignImageID() {
        return signImageID;
    }

    /**
     * Define el valor de la propiedad signImageID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignImageID(String value) {
        this.signImageID = value;
    }

    /**
     * Obtiene el valor de la propiedad lineOfBusiness.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    /**
     * Define el valor de la propiedad lineOfBusiness.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLineOfBusiness(String value) {
        this.lineOfBusiness = value;
    }

    /**
     * Obtiene el valor de la propiedad residingSinceDT.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResidingSinceDT() {
        return residingSinceDT;
    }

    /**
     * Define el valor de la propiedad residingSinceDT.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResidingSinceDT(String value) {
        this.residingSinceDT = value;
    }

    /**
     * Obtiene el valor de la propiedad educationLevel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEducationLevel() {
        return educationLevel;
    }

    /**
     * Define el valor de la propiedad educationLevel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEducationLevel(String value) {
        this.educationLevel = value;
    }

    /**
     * Obtiene el valor de la propiedad cpfBank.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPFBank() {
        return cpfBank;
    }

    /**
     * Define el valor de la propiedad cpfBank.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPFBank(String value) {
        this.cpfBank = value;
    }

    /**
     * Obtiene el valor de la propiedad cpfInvmAcctNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPFInvmAcctNo() {
        return cpfInvmAcctNo;
    }

    /**
     * Define el valor de la propiedad cpfInvmAcctNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPFInvmAcctNo(String value) {
        this.cpfInvmAcctNo = value;
    }

    /**
     * Obtiene el valor de la propiedad cpfAcctNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCPFAcctNo() {
        return cpfAcctNo;
    }

    /**
     * Define el valor de la propiedad cpfAcctNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCPFAcctNo(String value) {
        this.cpfAcctNo = value;
    }

    /**
     * Obtiene el valor de la propiedad srsBank.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRSBank() {
        return srsBank;
    }

    /**
     * Define el valor de la propiedad srsBank.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRSBank(String value) {
        this.srsBank = value;
    }

    /**
     * Obtiene el valor de la propiedad srsAcctNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRSAcctNo() {
        return srsAcctNo;
    }

    /**
     * Define el valor de la propiedad srsAcctNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRSAcctNo(String value) {
        this.srsAcctNo = value;
    }

    /**
     * Obtiene el valor de la propiedad title2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle2() {
        return title2;
    }

    /**
     * Define el valor de la propiedad title2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle2(String value) {
        this.title2 = value;
    }

    /**
     * Obtiene el valor de la propiedad saluteBy.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSaluteBy() {
        return saluteBy;
    }

    /**
     * Define el valor de la propiedad saluteBy.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSaluteBy(String value) {
        this.saluteBy = value;
    }

    /**
     * Obtiene el valor de la propiedad aliasName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAliasName() {
        return aliasName;
    }

    /**
     * Define el valor de la propiedad aliasName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAliasName(String value) {
        this.aliasName = value;
    }

    /**
     * Obtiene el valor de la propiedad otherName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOtherName() {
        return otherName;
    }

    /**
     * Define el valor de la propiedad otherName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOtherName(String value) {
        this.otherName = value;
    }

    /**
     * Obtiene el valor de la propiedad residenceInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResidenceInd() {
        return residenceInd;
    }

    /**
     * Define el valor de la propiedad residenceInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResidenceInd(String value) {
        this.residenceInd = value;
    }

    /**
     * Obtiene el valor de la propiedad bumiInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBUMIInd() {
        return bumiInd;
    }

    /**
     * Define el valor de la propiedad bumiInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBUMIInd(String value) {
        this.bumiInd = value;
    }

    /**
     * Obtiene el valor de la propiedad nrccInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNRCCInd() {
        return nrccInd;
    }

    /**
     * Define el valor de la propiedad nrccInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNRCCInd(String value) {
        this.nrccInd = value;
    }

    /**
     * Obtiene el valor de la propiedad wpInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWPInd() {
        return wpInd;
    }

    /**
     * Define el valor de la propiedad wpInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWPInd(String value) {
        this.wpInd = value;
    }

    /**
     * Obtiene el valor de la propiedad wpExpDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWPExpDate() {
        return wpExpDate;
    }

    /**
     * Define el valor de la propiedad wpExpDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWPExpDate(String value) {
        this.wpExpDate = value;
    }

    /**
     * Obtiene el valor de la propiedad secondHomeInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecondHomeInd() {
        return secondHomeInd;
    }

    /**
     * Define el valor de la propiedad secondHomeInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecondHomeInd(String value) {
        this.secondHomeInd = value;
    }

    /**
     * Obtiene el valor de la propiedad secondHomeExpDt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecondHomeExpDt() {
        return secondHomeExpDt;
    }

    /**
     * Define el valor de la propiedad secondHomeExpDt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecondHomeExpDt(String value) {
        this.secondHomeExpDt = value;
    }

    /**
     * Obtiene el valor de la propiedad ethnicGrp.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEthnicGrp() {
        return ethnicGrp;
    }

    /**
     * Define el valor de la propiedad ethnicGrp.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEthnicGrp(String value) {
        this.ethnicGrp = value;
    }

    /**
     * Obtiene el valor de la propiedad localLoanInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalLoanInd() {
        return localLoanInd;
    }

    /**
     * Define el valor de la propiedad localLoanInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalLoanInd(String value) {
        this.localLoanInd = value;
    }

    /**
     * Obtiene el valor de la propiedad epfAcctNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEPFAcctNo() {
        return epfAcctNo;
    }

    /**
     * Define el valor de la propiedad epfAcctNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEPFAcctNo(String value) {
        this.epfAcctNo = value;
    }

    /**
     * Obtiene el valor de la propiedad holdIndicator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldIndicator() {
        return holdIndicator;
    }

    /**
     * Define el valor de la propiedad holdIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldIndicator(String value) {
        this.holdIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad mailInstruction.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailInstruction() {
        return mailInstruction;
    }

    /**
     * Define el valor de la propiedad mailInstruction.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailInstruction(String value) {
        this.mailInstruction = value;
    }

    /**
     * Obtiene el valor de la propiedad taxDomicile.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxDomicile() {
        return taxDomicile;
    }

    /**
     * Define el valor de la propiedad taxDomicile.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxDomicile(String value) {
        this.taxDomicile = value;
    }

    /**
     * Obtiene el valor de la propiedad hr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHR() {
        return hr;
    }

    /**
     * Define el valor de la propiedad hr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHR(String value) {
        this.hr = value;
    }

    /**
     * Obtiene el valor de la propiedad custAssignCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustAssignCode() {
        return custAssignCode;
    }

    /**
     * Define el valor de la propiedad custAssignCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustAssignCode(String value) {
        this.custAssignCode = value;
    }

    /**
     * Obtiene el valor de la propiedad faxIndEmnity.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFaxIndEmnity() {
        return faxIndEmnity;
    }

    /**
     * Define el valor de la propiedad faxIndEmnity.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFaxIndEmnity(String value) {
        this.faxIndEmnity = value;
    }

    /**
     * Obtiene el valor de la propiedad okToEmail.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOkToEmail() {
        return okToEmail;
    }

    /**
     * Define el valor de la propiedad okToEmail.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOkToEmail(String value) {
        this.okToEmail = value;
    }

    /**
     * Obtiene el valor de la propiedad annualTurnoverAmt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnnualTurnoverAmt() {
        return annualTurnoverAmt;
    }

    /**
     * Define el valor de la propiedad annualTurnoverAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnnualTurnoverAmt(String value) {
        this.annualTurnoverAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad agentCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentCode() {
        return agentCode;
    }

    /**
     * Define el valor de la propiedad agentCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentCode(String value) {
        this.agentCode = value;
    }

    /**
     * Obtiene el valor de la propiedad compStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompStatus() {
        return compStatus;
    }

    /**
     * Define el valor de la propiedad compStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompStatus(String value) {
        this.compStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad placeOfBirth.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlaceOfBirth() {
        return placeOfBirth;
    }

    /**
     * Define el valor de la propiedad placeOfBirth.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlaceOfBirth(String value) {
        this.placeOfBirth = value;
    }

    /**
     * Obtiene el valor de la propiedad ctryOfBirth.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtryOfBirth() {
        return ctryOfBirth;
    }

    /**
     * Define el valor de la propiedad ctryOfBirth.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtryOfBirth(String value) {
        this.ctryOfBirth = value;
    }

    /**
     * Obtiene el valor de la propiedad bankAtWorkInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankAtWorkInd() {
        return bankAtWorkInd;
    }

    /**
     * Define el valor de la propiedad bankAtWorkInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankAtWorkInd(String value) {
        this.bankAtWorkInd = value;
    }

    /**
     * Obtiene el valor de la propiedad religion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReligion() {
        return religion;
    }

    /**
     * Define el valor de la propiedad religion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReligion(String value) {
        this.religion = value;
    }

    /**
     * Obtiene el valor de la propiedad codeOfRegency.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeOfRegency() {
        return codeOfRegency;
    }

    /**
     * Define el valor de la propiedad codeOfRegency.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeOfRegency(String value) {
        this.codeOfRegency = value;
    }

    /**
     * Obtiene el valor de la propiedad ccc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCCC() {
        return ccc;
    }

    /**
     * Define el valor de la propiedad ccc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCCC(String value) {
        this.ccc = value;
    }

    /**
     * Obtiene el valor de la propiedad village.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVillage() {
        return village;
    }

    /**
     * Define el valor de la propiedad village.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVillage(String value) {
        this.village = value;
    }

    /**
     * Obtiene el valor de la propiedad subDistrict.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubDistrict() {
        return subDistrict;
    }

    /**
     * Define el valor de la propiedad subDistrict.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubDistrict(String value) {
        this.subDistrict = value;
    }

    /**
     * Obtiene el valor de la propiedad eStmntReqInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEStmntReqInd() {
        return eStmntReqInd;
    }

    /**
     * Define el valor de la propiedad eStmntReqInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEStmntReqInd(String value) {
        this.eStmntReqInd = value;
    }

    /**
     * Obtiene el valor de la propiedad custDisableInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustDisableInd() {
        return custDisableInd;
    }

    /**
     * Define el valor de la propiedad custDisableInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustDisableInd(String value) {
        this.custDisableInd = value;
    }

    /**
     * Obtiene el valor de la propiedad custBasicDtlUpd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustBasicDtlUpd() {
        return custBasicDtlUpd;
    }

    /**
     * Define el valor de la propiedad custBasicDtlUpd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustBasicDtlUpd(String value) {
        this.custBasicDtlUpd = value;
    }

    /**
     * Obtiene el valor de la propiedad corpContactsUpd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorpContactsUpd() {
        return corpContactsUpd;
    }

    /**
     * Define el valor de la propiedad corpContactsUpd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorpContactsUpd(String value) {
        this.corpContactsUpd = value;
    }

    /**
     * Obtiene el valor de la propiedad individualCustomerBasicData.
     * 
     * @return
     *     possible object is
     *     {@link IndividualCustomerBasicData }
     *     
     */
    public IndividualCustomerBasicData getIndividualCustomerBasicData() {
        return individualCustomerBasicData;
    }

    /**
     * Define el valor de la propiedad individualCustomerBasicData.
     * 
     * @param value
     *     allowed object is
     *     {@link IndividualCustomerBasicData }
     *     
     */
    public void setIndividualCustomerBasicData(IndividualCustomerBasicData value) {
        this.individualCustomerBasicData = value;
    }

    /**
     * Obtiene el valor de la propiedad middleName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Define el valor de la propiedad middleName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMiddleName(String value) {
        this.middleName = value;
    }

    /**
     * Obtiene el valor de la propiedad exstCustStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExstCustStatus() {
        return exstCustStatus;
    }

    /**
     * Define el valor de la propiedad exstCustStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExstCustStatus(String value) {
        this.exstCustStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad spokenLanguage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpokenLanguage() {
        return spokenLanguage;
    }

    /**
     * Define el valor de la propiedad spokenLanguage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpokenLanguage(String value) {
        this.spokenLanguage = value;
    }

    /**
     * Obtiene el valor de la propiedad suffixName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuffixName() {
        return suffixName;
    }

    /**
     * Define el valor de la propiedad suffixName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuffixName(String value) {
        this.suffixName = value;
    }

    /**
     * Obtiene el valor de la propiedad localName1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalName1() {
        return localName1;
    }

    /**
     * Define el valor de la propiedad localName1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalName1(String value) {
        this.localName1 = value;
    }

    /**
     * Obtiene el valor de la propiedad localName2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalName2() {
        return localName2;
    }

    /**
     * Define el valor de la propiedad localName2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalName2(String value) {
        this.localName2 = value;
    }

    /**
     * Obtiene el valor de la propiedad citiatworkChannel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCITIATWORKChannel() {
        return citiatworkChannel;
    }

    /**
     * Define el valor de la propiedad citiatworkChannel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCITIATWORKChannel(String value) {
        this.citiatworkChannel = value;
    }

    /**
     * Obtiene el valor de la propiedad citiatworkJoinDT.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCITIATWORKJoinDT() {
        return citiatworkJoinDT;
    }

    /**
     * Define el valor de la propiedad citiatworkJoinDT.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCITIATWORKJoinDT(String value) {
        this.citiatworkJoinDT = value;
    }

    /**
     * Obtiene el valor de la propiedad sendSMSAdvice.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendSMSAdvice() {
        return sendSMSAdvice;
    }

    /**
     * Define el valor de la propiedad sendSMSAdvice.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendSMSAdvice(String value) {
        this.sendSMSAdvice = value;
    }

    /**
     * Obtiene el valor de la propiedad sendEmailAdvice.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSendEmailAdvice() {
        return sendEmailAdvice;
    }

    /**
     * Define el valor de la propiedad sendEmailAdvice.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSendEmailAdvice(String value) {
        this.sendEmailAdvice = value;
    }

    /**
     * Obtiene el valor de la propiedad annHouseholdInc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getANNHouseholdInc() {
        return annHouseholdInc;
    }

    /**
     * Define el valor de la propiedad annHouseholdInc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setANNHouseholdInc(String value) {
        this.annHouseholdInc = value;
    }

    /**
     * Obtiene el valor de la propiedad noOfChildren.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoOfChildren() {
        return noOfChildren;
    }

    /**
     * Define el valor de la propiedad noOfChildren.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoOfChildren(String value) {
        this.noOfChildren = value;
    }

    /**
     * Obtiene el valor de la propiedad estmtType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEstmtType() {
        return estmtType;
    }

    /**
     * Define el valor de la propiedad estmtType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEstmtType(String value) {
        this.estmtType = value;
    }

    /**
     * Obtiene el valor de la propiedad stmtMailOption.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStmtMailOption() {
        return stmtMailOption;
    }

    /**
     * Define el valor de la propiedad stmtMailOption.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStmtMailOption(String value) {
        this.stmtMailOption = value;
    }

    /**
     * Obtiene el valor de la propiedad stmtViewOption.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStmtViewOption() {
        return stmtViewOption;
    }

    /**
     * Define el valor de la propiedad stmtViewOption.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStmtViewOption(String value) {
        this.stmtViewOption = value;
    }

    /**
     * Obtiene el valor de la propiedad compSearchDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCompSearchDate() {
        return compSearchDate;
    }

    /**
     * Define el valor de la propiedad compSearchDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCompSearchDate(String value) {
        this.compSearchDate = value;
    }

    /**
     * Obtiene el valor de la propiedad quotedInStockMkt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuotedInStockMkt() {
        return quotedInStockMkt;
    }

    /**
     * Define el valor de la propiedad quotedInStockMkt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuotedInStockMkt(String value) {
        this.quotedInStockMkt = value;
    }

    /**
     * Obtiene el valor de la propiedad majorOprnCtry.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMajorOprnCtry() {
        return majorOprnCtry;
    }

    /**
     * Define el valor de la propiedad majorOprnCtry.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMajorOprnCtry(String value) {
        this.majorOprnCtry = value;
    }

    /**
     * Obtiene el valor de la propiedad leadID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLeadID() {
        return leadID;
    }

    /**
     * Define el valor de la propiedad leadID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLeadID(String value) {
        this.leadID = value;
    }

    /**
     * Obtiene el valor de la propiedad declCategory.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeclCategory() {
        return declCategory;
    }

    /**
     * Define el valor de la propiedad declCategory.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeclCategory(String value) {
        this.declCategory = value;
    }

    /**
     * Obtiene el valor de la propiedad declIdenType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeclIdenType() {
        return declIdenType;
    }

    /**
     * Define el valor de la propiedad declIdenType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeclIdenType(String value) {
        this.declIdenType = value;
    }

    /**
     * Obtiene el valor de la propiedad declIdenValue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeclIdenValue() {
        return declIdenValue;
    }

    /**
     * Define el valor de la propiedad declIdenValue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeclIdenValue(String value) {
        this.declIdenValue = value;
    }

}
