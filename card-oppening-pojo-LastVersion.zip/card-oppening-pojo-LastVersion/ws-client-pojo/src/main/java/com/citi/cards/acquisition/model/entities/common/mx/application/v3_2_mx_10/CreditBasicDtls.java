
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CreditBasicDtls complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CreditBasicDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Org" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Logo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LoanPrdCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InstantInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditShield" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmbossName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmbossDest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmbossQueue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfficerIncharge" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OwnershipType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExistingCardNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AppRecFrmCust" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AppRecFrmSales" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HomeAddrRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfficeAddrRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BillTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PinTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GiftCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelnTOoPrimary" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PrivelegeCard" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SpendLimit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditAmount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DeliveryMthd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ConsentFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ConsentID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="KitasValidity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SignatureInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VIPInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PurposeOfLine" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OneBill" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EzlinkTopup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NFCFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="POS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesPromoCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DDBankBranch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DDAccountNum" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CampaignCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProgramID1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProgramID2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreditBasicDtls", propOrder = {
    "seqNo",
    "custNo",
    "sourceCode",
    "org",
    "logo",
    "loanPrdCD",
    "agentCode",
    "instantInd",
    "creditShield",
    "embossName",
    "embossDest",
    "embossQueue",
    "officerIncharge",
    "ownershipType",
    "existingCardNum",
    "appRecFrmCust",
    "appRecFrmSales",
    "homeAddrRef",
    "officeAddrRef",
    "billTo",
    "cardTo",
    "pinTo",
    "giftCD",
    "relnTOoPrimary",
    "privelegeCard",
    "spendLimit",
    "creditAmount",
    "deliveryMthd",
    "consentFlag",
    "consentID",
    "kitasValidity",
    "signatureInd",
    "vipInd",
    "purposeOfLine",
    "salNo",
    "oneBill",
    "ezlinkTopup",
    "nfcFlag",
    "pos",
    "salesPromoCD",
    "ddBankBranch",
    "ddAccountNum",
    "campaignCode",
    "programID1",
    "programID2"
})
public class CreditBasicDtls {

    @XmlElement(name = "SeqNo")
    protected String seqNo;
    @XmlElement(name = "CustNo")
    protected String custNo;
    @XmlElement(name = "SourceCode")
    protected String sourceCode;
    @XmlElement(name = "Org")
    protected String org;
    @XmlElement(name = "Logo")
    protected String logo;
    @XmlElement(name = "LoanPrdCD")
    protected String loanPrdCD;
    @XmlElement(name = "AgentCode")
    protected String agentCode;
    @XmlElement(name = "InstantInd")
    protected String instantInd;
    @XmlElement(name = "CreditShield")
    protected String creditShield;
    @XmlElement(name = "EmbossName")
    protected String embossName;
    @XmlElement(name = "EmbossDest")
    protected String embossDest;
    @XmlElement(name = "EmbossQueue")
    protected String embossQueue;
    @XmlElement(name = "OfficerIncharge")
    protected String officerIncharge;
    @XmlElement(name = "OwnershipType")
    protected String ownershipType;
    @XmlElement(name = "ExistingCardNum")
    protected String existingCardNum;
    @XmlElement(name = "AppRecFrmCust")
    protected String appRecFrmCust;
    @XmlElement(name = "AppRecFrmSales")
    protected String appRecFrmSales;
    @XmlElement(name = "HomeAddrRef")
    protected String homeAddrRef;
    @XmlElement(name = "OfficeAddrRef")
    protected String officeAddrRef;
    @XmlElement(name = "BillTo")
    protected String billTo;
    @XmlElement(name = "CardTo")
    protected String cardTo;
    @XmlElement(name = "PinTo")
    protected String pinTo;
    @XmlElement(name = "GiftCD")
    protected String giftCD;
    @XmlElement(name = "RelnTOoPrimary")
    protected String relnTOoPrimary;
    @XmlElement(name = "PrivelegeCard")
    protected String privelegeCard;
    @XmlElement(name = "SpendLimit")
    protected String spendLimit;
    @XmlElement(name = "CreditAmount")
    protected String creditAmount;
    @XmlElement(name = "DeliveryMthd")
    protected String deliveryMthd;
    @XmlElement(name = "ConsentFlag")
    protected String consentFlag;
    @XmlElement(name = "ConsentID")
    protected String consentID;
    @XmlElement(name = "KitasValidity")
    protected String kitasValidity;
    @XmlElement(name = "SignatureInd")
    protected String signatureInd;
    @XmlElement(name = "VIPInd")
    protected String vipInd;
    @XmlElement(name = "PurposeOfLine")
    protected String purposeOfLine;
    @XmlElement(name = "SalNo")
    protected String salNo;
    @XmlElement(name = "OneBill")
    protected String oneBill;
    @XmlElement(name = "EzlinkTopup")
    protected String ezlinkTopup;
    @XmlElement(name = "NFCFlag")
    protected String nfcFlag;
    @XmlElement(name = "POS")
    protected String pos;
    @XmlElement(name = "SalesPromoCD")
    protected String salesPromoCD;
    @XmlElement(name = "DDBankBranch")
    protected String ddBankBranch;
    @XmlElement(name = "DDAccountNum")
    protected String ddAccountNum;
    @XmlElement(name = "CampaignCode")
    protected String campaignCode;
    @XmlElement(name = "ProgramID1")
    protected String programID1;
    @XmlElement(name = "ProgramID2")
    protected String programID2;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad custNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustNo() {
        return custNo;
    }

    /**
     * Define el valor de la propiedad custNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustNo(String value) {
        this.custNo = value;
    }

    /**
     * Obtiene el valor de la propiedad sourceCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceCode() {
        return sourceCode;
    }

    /**
     * Define el valor de la propiedad sourceCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceCode(String value) {
        this.sourceCode = value;
    }

    /**
     * Obtiene el valor de la propiedad org.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrg() {
        return org;
    }

    /**
     * Define el valor de la propiedad org.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrg(String value) {
        this.org = value;
    }

    /**
     * Obtiene el valor de la propiedad logo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogo() {
        return logo;
    }

    /**
     * Define el valor de la propiedad logo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogo(String value) {
        this.logo = value;
    }

    /**
     * Obtiene el valor de la propiedad loanPrdCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanPrdCD() {
        return loanPrdCD;
    }

    /**
     * Define el valor de la propiedad loanPrdCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanPrdCD(String value) {
        this.loanPrdCD = value;
    }

    /**
     * Obtiene el valor de la propiedad agentCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentCode() {
        return agentCode;
    }

    /**
     * Define el valor de la propiedad agentCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentCode(String value) {
        this.agentCode = value;
    }

    /**
     * Obtiene el valor de la propiedad instantInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstantInd() {
        return instantInd;
    }

    /**
     * Define el valor de la propiedad instantInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstantInd(String value) {
        this.instantInd = value;
    }

    /**
     * Obtiene el valor de la propiedad creditShield.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditShield() {
        return creditShield;
    }

    /**
     * Define el valor de la propiedad creditShield.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditShield(String value) {
        this.creditShield = value;
    }

    /**
     * Obtiene el valor de la propiedad embossName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmbossName() {
        return embossName;
    }

    /**
     * Define el valor de la propiedad embossName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbossName(String value) {
        this.embossName = value;
    }

    /**
     * Obtiene el valor de la propiedad embossDest.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmbossDest() {
        return embossDest;
    }

    /**
     * Define el valor de la propiedad embossDest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbossDest(String value) {
        this.embossDest = value;
    }

    /**
     * Obtiene el valor de la propiedad embossQueue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmbossQueue() {
        return embossQueue;
    }

    /**
     * Define el valor de la propiedad embossQueue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbossQueue(String value) {
        this.embossQueue = value;
    }

    /**
     * Obtiene el valor de la propiedad officerIncharge.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfficerIncharge() {
        return officerIncharge;
    }

    /**
     * Define el valor de la propiedad officerIncharge.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfficerIncharge(String value) {
        this.officerIncharge = value;
    }

    /**
     * Obtiene el valor de la propiedad ownershipType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOwnershipType() {
        return ownershipType;
    }

    /**
     * Define el valor de la propiedad ownershipType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOwnershipType(String value) {
        this.ownershipType = value;
    }

    /**
     * Obtiene el valor de la propiedad existingCardNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExistingCardNum() {
        return existingCardNum;
    }

    /**
     * Define el valor de la propiedad existingCardNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExistingCardNum(String value) {
        this.existingCardNum = value;
    }

    /**
     * Obtiene el valor de la propiedad appRecFrmCust.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppRecFrmCust() {
        return appRecFrmCust;
    }

    /**
     * Define el valor de la propiedad appRecFrmCust.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppRecFrmCust(String value) {
        this.appRecFrmCust = value;
    }

    /**
     * Obtiene el valor de la propiedad appRecFrmSales.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppRecFrmSales() {
        return appRecFrmSales;
    }

    /**
     * Define el valor de la propiedad appRecFrmSales.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppRecFrmSales(String value) {
        this.appRecFrmSales = value;
    }

    /**
     * Obtiene el valor de la propiedad homeAddrRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomeAddrRef() {
        return homeAddrRef;
    }

    /**
     * Define el valor de la propiedad homeAddrRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomeAddrRef(String value) {
        this.homeAddrRef = value;
    }

    /**
     * Obtiene el valor de la propiedad officeAddrRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfficeAddrRef() {
        return officeAddrRef;
    }

    /**
     * Define el valor de la propiedad officeAddrRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfficeAddrRef(String value) {
        this.officeAddrRef = value;
    }

    /**
     * Obtiene el valor de la propiedad billTo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillTo() {
        return billTo;
    }

    /**
     * Define el valor de la propiedad billTo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillTo(String value) {
        this.billTo = value;
    }

    /**
     * Obtiene el valor de la propiedad cardTo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardTo() {
        return cardTo;
    }

    /**
     * Define el valor de la propiedad cardTo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardTo(String value) {
        this.cardTo = value;
    }

    /**
     * Obtiene el valor de la propiedad pinTo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPinTo() {
        return pinTo;
    }

    /**
     * Define el valor de la propiedad pinTo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPinTo(String value) {
        this.pinTo = value;
    }

    /**
     * Obtiene el valor de la propiedad giftCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGiftCD() {
        return giftCD;
    }

    /**
     * Define el valor de la propiedad giftCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGiftCD(String value) {
        this.giftCD = value;
    }

    /**
     * Obtiene el valor de la propiedad relnTOoPrimary.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnTOoPrimary() {
        return relnTOoPrimary;
    }

    /**
     * Define el valor de la propiedad relnTOoPrimary.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnTOoPrimary(String value) {
        this.relnTOoPrimary = value;
    }

    /**
     * Obtiene el valor de la propiedad privelegeCard.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrivelegeCard() {
        return privelegeCard;
    }

    /**
     * Define el valor de la propiedad privelegeCard.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrivelegeCard(String value) {
        this.privelegeCard = value;
    }

    /**
     * Obtiene el valor de la propiedad spendLimit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpendLimit() {
        return spendLimit;
    }

    /**
     * Define el valor de la propiedad spendLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpendLimit(String value) {
        this.spendLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad creditAmount.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditAmount() {
        return creditAmount;
    }

    /**
     * Define el valor de la propiedad creditAmount.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditAmount(String value) {
        this.creditAmount = value;
    }

    /**
     * Obtiene el valor de la propiedad deliveryMthd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveryMthd() {
        return deliveryMthd;
    }

    /**
     * Define el valor de la propiedad deliveryMthd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveryMthd(String value) {
        this.deliveryMthd = value;
    }

    /**
     * Obtiene el valor de la propiedad consentFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsentFlag() {
        return consentFlag;
    }

    /**
     * Define el valor de la propiedad consentFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsentFlag(String value) {
        this.consentFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad consentID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsentID() {
        return consentID;
    }

    /**
     * Define el valor de la propiedad consentID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsentID(String value) {
        this.consentID = value;
    }

    /**
     * Obtiene el valor de la propiedad kitasValidity.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKitasValidity() {
        return kitasValidity;
    }

    /**
     * Define el valor de la propiedad kitasValidity.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKitasValidity(String value) {
        this.kitasValidity = value;
    }

    /**
     * Obtiene el valor de la propiedad signatureInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignatureInd() {
        return signatureInd;
    }

    /**
     * Define el valor de la propiedad signatureInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignatureInd(String value) {
        this.signatureInd = value;
    }

    /**
     * Obtiene el valor de la propiedad vipInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIPInd() {
        return vipInd;
    }

    /**
     * Define el valor de la propiedad vipInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIPInd(String value) {
        this.vipInd = value;
    }

    /**
     * Obtiene el valor de la propiedad purposeOfLine.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPurposeOfLine() {
        return purposeOfLine;
    }

    /**
     * Define el valor de la propiedad purposeOfLine.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPurposeOfLine(String value) {
        this.purposeOfLine = value;
    }

    /**
     * Obtiene el valor de la propiedad salNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalNo() {
        return salNo;
    }

    /**
     * Define el valor de la propiedad salNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalNo(String value) {
        this.salNo = value;
    }

    /**
     * Obtiene el valor de la propiedad oneBill.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOneBill() {
        return oneBill;
    }

    /**
     * Define el valor de la propiedad oneBill.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOneBill(String value) {
        this.oneBill = value;
    }

    /**
     * Obtiene el valor de la propiedad ezlinkTopup.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEzlinkTopup() {
        return ezlinkTopup;
    }

    /**
     * Define el valor de la propiedad ezlinkTopup.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEzlinkTopup(String value) {
        this.ezlinkTopup = value;
    }

    /**
     * Obtiene el valor de la propiedad nfcFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNFCFlag() {
        return nfcFlag;
    }

    /**
     * Define el valor de la propiedad nfcFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNFCFlag(String value) {
        this.nfcFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad pos.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOS() {
        return pos;
    }

    /**
     * Define el valor de la propiedad pos.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOS(String value) {
        this.pos = value;
    }

    /**
     * Obtiene el valor de la propiedad salesPromoCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesPromoCD() {
        return salesPromoCD;
    }

    /**
     * Define el valor de la propiedad salesPromoCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesPromoCD(String value) {
        this.salesPromoCD = value;
    }

    /**
     * Obtiene el valor de la propiedad ddBankBranch.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDDBankBranch() {
        return ddBankBranch;
    }

    /**
     * Define el valor de la propiedad ddBankBranch.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDDBankBranch(String value) {
        this.ddBankBranch = value;
    }

    /**
     * Obtiene el valor de la propiedad ddAccountNum.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDDAccountNum() {
        return ddAccountNum;
    }

    /**
     * Define el valor de la propiedad ddAccountNum.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDDAccountNum(String value) {
        this.ddAccountNum = value;
    }

    /**
     * Obtiene el valor de la propiedad campaignCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCampaignCode() {
        return campaignCode;
    }

    /**
     * Define el valor de la propiedad campaignCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCampaignCode(String value) {
        this.campaignCode = value;
    }

    /**
     * Obtiene el valor de la propiedad programID1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgramID1() {
        return programID1;
    }

    /**
     * Define el valor de la propiedad programID1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgramID1(String value) {
        this.programID1 = value;
    }

    /**
     * Obtiene el valor de la propiedad programID2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgramID2() {
        return programID2;
    }

    /**
     * Define el valor de la propiedad programID2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgramID2(String value) {
        this.programID2 = value;
    }

}
