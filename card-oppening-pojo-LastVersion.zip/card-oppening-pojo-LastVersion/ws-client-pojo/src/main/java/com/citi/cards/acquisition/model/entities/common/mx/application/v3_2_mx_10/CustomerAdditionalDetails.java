
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerAdditionalDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerAdditionalDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DemInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OvrHomeAddr1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OvrHomeAddr2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OvrHomeAddr3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OvrHomeAddr4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OvrPhCtryCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OvrPhAreaCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OvrPhNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OvrPhExtnNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefrFirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefrLastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefrAddrLine1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefrAddrLine2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefrAddrLine3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefrAddrZipCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefrAddrCtryCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RefrPhNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StaffInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StaffGEID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SelfEmpAttest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SrcOthIncome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OthAnnIncome" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="YrsOfResidence" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MthOfResidence" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IncomeInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BalanceTransferDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}BalanceTransferDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="OtherBankDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}OtherBankDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerAdditionalDetails", propOrder = {
    "demInd",
    "ovrHomeAddr1",
    "ovrHomeAddr2",
    "ovrHomeAddr3",
    "ovrHomeAddr4",
    "ovrPhCtryCD",
    "ovrPhAreaCD",
    "ovrPhNo",
    "ovrPhExtnNo",
    "refrFirstName",
    "refrLastName",
    "refrAddrLine1",
    "refrAddrLine2",
    "refrAddrLine3",
    "refrAddrZipCD",
    "refrAddrCtryCD",
    "refrPhNo",
    "staffInd",
    "staffGEID",
    "selfEmpAttest",
    "srcOthIncome",
    "othAnnIncome",
    "yrsOfResidence",
    "mthOfResidence",
    "incomeInd",
    "balanceTransferDetails",
    "otherBankDetails"
})
public class CustomerAdditionalDetails {

    @XmlElement(name = "DemInd")
    protected String demInd;
    @XmlElement(name = "OvrHomeAddr1")
    protected String ovrHomeAddr1;
    @XmlElement(name = "OvrHomeAddr2")
    protected String ovrHomeAddr2;
    @XmlElement(name = "OvrHomeAddr3")
    protected String ovrHomeAddr3;
    @XmlElement(name = "OvrHomeAddr4")
    protected String ovrHomeAddr4;
    @XmlElement(name = "OvrPhCtryCD")
    protected String ovrPhCtryCD;
    @XmlElement(name = "OvrPhAreaCD")
    protected String ovrPhAreaCD;
    @XmlElement(name = "OvrPhNo")
    protected String ovrPhNo;
    @XmlElement(name = "OvrPhExtnNo")
    protected String ovrPhExtnNo;
    @XmlElement(name = "RefrFirstName")
    protected String refrFirstName;
    @XmlElement(name = "RefrLastName")
    protected String refrLastName;
    @XmlElement(name = "RefrAddrLine1")
    protected String refrAddrLine1;
    @XmlElement(name = "RefrAddrLine2")
    protected String refrAddrLine2;
    @XmlElement(name = "RefrAddrLine3")
    protected String refrAddrLine3;
    @XmlElement(name = "RefrAddrZipCD")
    protected String refrAddrZipCD;
    @XmlElement(name = "RefrAddrCtryCD")
    protected String refrAddrCtryCD;
    @XmlElement(name = "RefrPhNo")
    protected String refrPhNo;
    @XmlElement(name = "StaffInd")
    protected String staffInd;
    @XmlElement(name = "StaffGEID")
    protected String staffGEID;
    @XmlElement(name = "SelfEmpAttest")
    protected String selfEmpAttest;
    @XmlElement(name = "SrcOthIncome")
    protected String srcOthIncome;
    @XmlElement(name = "OthAnnIncome")
    protected String othAnnIncome;
    @XmlElement(name = "YrsOfResidence")
    protected String yrsOfResidence;
    @XmlElement(name = "MthOfResidence")
    protected String mthOfResidence;
    @XmlElement(name = "IncomeInd")
    protected String incomeInd;
    @XmlElement(name = "BalanceTransferDetails")
    protected List<BalanceTransferDetails> balanceTransferDetails;
    @XmlElement(name = "OtherBankDetails")
    protected List<OtherBankDetails> otherBankDetails;

    /**
     * Obtiene el valor de la propiedad demInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDemInd() {
        return demInd;
    }

    /**
     * Define el valor de la propiedad demInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDemInd(String value) {
        this.demInd = value;
    }

    /**
     * Obtiene el valor de la propiedad ovrHomeAddr1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOvrHomeAddr1() {
        return ovrHomeAddr1;
    }

    /**
     * Define el valor de la propiedad ovrHomeAddr1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOvrHomeAddr1(String value) {
        this.ovrHomeAddr1 = value;
    }

    /**
     * Obtiene el valor de la propiedad ovrHomeAddr2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOvrHomeAddr2() {
        return ovrHomeAddr2;
    }

    /**
     * Define el valor de la propiedad ovrHomeAddr2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOvrHomeAddr2(String value) {
        this.ovrHomeAddr2 = value;
    }

    /**
     * Obtiene el valor de la propiedad ovrHomeAddr3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOvrHomeAddr3() {
        return ovrHomeAddr3;
    }

    /**
     * Define el valor de la propiedad ovrHomeAddr3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOvrHomeAddr3(String value) {
        this.ovrHomeAddr3 = value;
    }

    /**
     * Obtiene el valor de la propiedad ovrHomeAddr4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOvrHomeAddr4() {
        return ovrHomeAddr4;
    }

    /**
     * Define el valor de la propiedad ovrHomeAddr4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOvrHomeAddr4(String value) {
        this.ovrHomeAddr4 = value;
    }

    /**
     * Obtiene el valor de la propiedad ovrPhCtryCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOvrPhCtryCD() {
        return ovrPhCtryCD;
    }

    /**
     * Define el valor de la propiedad ovrPhCtryCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOvrPhCtryCD(String value) {
        this.ovrPhCtryCD = value;
    }

    /**
     * Obtiene el valor de la propiedad ovrPhAreaCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOvrPhAreaCD() {
        return ovrPhAreaCD;
    }

    /**
     * Define el valor de la propiedad ovrPhAreaCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOvrPhAreaCD(String value) {
        this.ovrPhAreaCD = value;
    }

    /**
     * Obtiene el valor de la propiedad ovrPhNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOvrPhNo() {
        return ovrPhNo;
    }

    /**
     * Define el valor de la propiedad ovrPhNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOvrPhNo(String value) {
        this.ovrPhNo = value;
    }

    /**
     * Obtiene el valor de la propiedad ovrPhExtnNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOvrPhExtnNo() {
        return ovrPhExtnNo;
    }

    /**
     * Define el valor de la propiedad ovrPhExtnNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOvrPhExtnNo(String value) {
        this.ovrPhExtnNo = value;
    }

    /**
     * Obtiene el valor de la propiedad refrFirstName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefrFirstName() {
        return refrFirstName;
    }

    /**
     * Define el valor de la propiedad refrFirstName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefrFirstName(String value) {
        this.refrFirstName = value;
    }

    /**
     * Obtiene el valor de la propiedad refrLastName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefrLastName() {
        return refrLastName;
    }

    /**
     * Define el valor de la propiedad refrLastName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefrLastName(String value) {
        this.refrLastName = value;
    }

    /**
     * Obtiene el valor de la propiedad refrAddrLine1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefrAddrLine1() {
        return refrAddrLine1;
    }

    /**
     * Define el valor de la propiedad refrAddrLine1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefrAddrLine1(String value) {
        this.refrAddrLine1 = value;
    }

    /**
     * Obtiene el valor de la propiedad refrAddrLine2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefrAddrLine2() {
        return refrAddrLine2;
    }

    /**
     * Define el valor de la propiedad refrAddrLine2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefrAddrLine2(String value) {
        this.refrAddrLine2 = value;
    }

    /**
     * Obtiene el valor de la propiedad refrAddrLine3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefrAddrLine3() {
        return refrAddrLine3;
    }

    /**
     * Define el valor de la propiedad refrAddrLine3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefrAddrLine3(String value) {
        this.refrAddrLine3 = value;
    }

    /**
     * Obtiene el valor de la propiedad refrAddrZipCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefrAddrZipCD() {
        return refrAddrZipCD;
    }

    /**
     * Define el valor de la propiedad refrAddrZipCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefrAddrZipCD(String value) {
        this.refrAddrZipCD = value;
    }

    /**
     * Obtiene el valor de la propiedad refrAddrCtryCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefrAddrCtryCD() {
        return refrAddrCtryCD;
    }

    /**
     * Define el valor de la propiedad refrAddrCtryCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefrAddrCtryCD(String value) {
        this.refrAddrCtryCD = value;
    }

    /**
     * Obtiene el valor de la propiedad refrPhNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefrPhNo() {
        return refrPhNo;
    }

    /**
     * Define el valor de la propiedad refrPhNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefrPhNo(String value) {
        this.refrPhNo = value;
    }

    /**
     * Obtiene el valor de la propiedad staffInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaffInd() {
        return staffInd;
    }

    /**
     * Define el valor de la propiedad staffInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaffInd(String value) {
        this.staffInd = value;
    }

    /**
     * Obtiene el valor de la propiedad staffGEID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaffGEID() {
        return staffGEID;
    }

    /**
     * Define el valor de la propiedad staffGEID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaffGEID(String value) {
        this.staffGEID = value;
    }

    /**
     * Obtiene el valor de la propiedad selfEmpAttest.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSelfEmpAttest() {
        return selfEmpAttest;
    }

    /**
     * Define el valor de la propiedad selfEmpAttest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSelfEmpAttest(String value) {
        this.selfEmpAttest = value;
    }

    /**
     * Obtiene el valor de la propiedad srcOthIncome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcOthIncome() {
        return srcOthIncome;
    }

    /**
     * Define el valor de la propiedad srcOthIncome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcOthIncome(String value) {
        this.srcOthIncome = value;
    }

    /**
     * Obtiene el valor de la propiedad othAnnIncome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOthAnnIncome() {
        return othAnnIncome;
    }

    /**
     * Define el valor de la propiedad othAnnIncome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOthAnnIncome(String value) {
        this.othAnnIncome = value;
    }

    /**
     * Obtiene el valor de la propiedad yrsOfResidence.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYrsOfResidence() {
        return yrsOfResidence;
    }

    /**
     * Define el valor de la propiedad yrsOfResidence.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYrsOfResidence(String value) {
        this.yrsOfResidence = value;
    }

    /**
     * Obtiene el valor de la propiedad mthOfResidence.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMthOfResidence() {
        return mthOfResidence;
    }

    /**
     * Define el valor de la propiedad mthOfResidence.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMthOfResidence(String value) {
        this.mthOfResidence = value;
    }

    /**
     * Obtiene el valor de la propiedad incomeInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncomeInd() {
        return incomeInd;
    }

    /**
     * Define el valor de la propiedad incomeInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncomeInd(String value) {
        this.incomeInd = value;
    }

    /**
     * Gets the value of the balanceTransferDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the balanceTransferDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBalanceTransferDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BalanceTransferDetails }
     * 
     * 
     */
    public List<BalanceTransferDetails> getBalanceTransferDetails() {
        if (balanceTransferDetails == null) {
            balanceTransferDetails = new ArrayList<BalanceTransferDetails>();
        }
        return this.balanceTransferDetails;
    }

    /**
     * Gets the value of the otherBankDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the otherBankDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOtherBankDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OtherBankDetails }
     * 
     * 
     */
    public List<OtherBankDetails> getOtherBankDetails() {
        if (otherBankDetails == null) {
            otherBankDetails = new ArrayList<OtherBankDetails>();
        }
        return this.otherBankDetails;
    }

}
