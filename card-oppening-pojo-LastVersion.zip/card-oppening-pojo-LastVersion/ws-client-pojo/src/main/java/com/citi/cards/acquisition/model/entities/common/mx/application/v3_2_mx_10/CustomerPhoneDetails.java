
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerPhoneDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerPhoneDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhTyp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhCtryCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhAreaCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhNbr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhExt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhRefNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhOkToSms" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhOkToCall" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhOkToMail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BestContactTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhTypDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhFixedInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerPhoneDetails", propOrder = {
    "seqNo",
    "phTyp",
    "phCtryCD",
    "phAreaCD",
    "phNbr",
    "phExt",
    "phRefNo",
    "phOkToSms",
    "phOkToCall",
    "phOkToMail",
    "bestContactTime",
    "phTypDesc",
    "phFixedInd"
})
public class CustomerPhoneDetails {

    @XmlElement(name = "SeqNo")
    protected String seqNo;
    @XmlElement(name = "PhTyp")
    protected String phTyp;
    @XmlElement(name = "PhCtryCD")
    protected String phCtryCD;
    @XmlElement(name = "PhAreaCD")
    protected String phAreaCD;
    @XmlElement(name = "PhNbr")
    protected String phNbr;
    @XmlElement(name = "PhExt")
    protected String phExt;
    @XmlElement(name = "PhRefNo")
    protected String phRefNo;
    @XmlElement(name = "PhOkToSms")
    protected String phOkToSms;
    @XmlElement(name = "PhOkToCall")
    protected String phOkToCall;
    @XmlElement(name = "PhOkToMail")
    protected String phOkToMail;
    @XmlElement(name = "BestContactTime")
    protected String bestContactTime;
    @XmlElement(name = "PhTypDesc")
    protected String phTypDesc;
    @XmlElement(name = "PhFixedInd")
    protected String phFixedInd;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad phTyp.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhTyp() {
        return phTyp;
    }

    /**
     * Define el valor de la propiedad phTyp.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhTyp(String value) {
        this.phTyp = value;
    }

    /**
     * Obtiene el valor de la propiedad phCtryCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhCtryCD() {
        return phCtryCD;
    }

    /**
     * Define el valor de la propiedad phCtryCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhCtryCD(String value) {
        this.phCtryCD = value;
    }

    /**
     * Obtiene el valor de la propiedad phAreaCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhAreaCD() {
        return phAreaCD;
    }

    /**
     * Define el valor de la propiedad phAreaCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhAreaCD(String value) {
        this.phAreaCD = value;
    }

    /**
     * Obtiene el valor de la propiedad phNbr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhNbr() {
        return phNbr;
    }

    /**
     * Define el valor de la propiedad phNbr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhNbr(String value) {
        this.phNbr = value;
    }

    /**
     * Obtiene el valor de la propiedad phExt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhExt() {
        return phExt;
    }

    /**
     * Define el valor de la propiedad phExt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhExt(String value) {
        this.phExt = value;
    }

    /**
     * Obtiene el valor de la propiedad phRefNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhRefNo() {
        return phRefNo;
    }

    /**
     * Define el valor de la propiedad phRefNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhRefNo(String value) {
        this.phRefNo = value;
    }

    /**
     * Obtiene el valor de la propiedad phOkToSms.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhOkToSms() {
        return phOkToSms;
    }

    /**
     * Define el valor de la propiedad phOkToSms.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhOkToSms(String value) {
        this.phOkToSms = value;
    }

    /**
     * Obtiene el valor de la propiedad phOkToCall.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhOkToCall() {
        return phOkToCall;
    }

    /**
     * Define el valor de la propiedad phOkToCall.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhOkToCall(String value) {
        this.phOkToCall = value;
    }

    /**
     * Obtiene el valor de la propiedad phOkToMail.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhOkToMail() {
        return phOkToMail;
    }

    /**
     * Define el valor de la propiedad phOkToMail.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhOkToMail(String value) {
        this.phOkToMail = value;
    }

    /**
     * Obtiene el valor de la propiedad bestContactTime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBestContactTime() {
        return bestContactTime;
    }

    /**
     * Define el valor de la propiedad bestContactTime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBestContactTime(String value) {
        this.bestContactTime = value;
    }

    /**
     * Obtiene el valor de la propiedad phTypDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhTypDesc() {
        return phTypDesc;
    }

    /**
     * Define el valor de la propiedad phTypDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhTypDesc(String value) {
        this.phTypDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad phFixedInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhFixedInd() {
        return phFixedInd;
    }

    /**
     * Define el valor de la propiedad phFixedInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhFixedInd(String value) {
        this.phFixedInd = value;
    }

}
