
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para TimeDepositDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="TimeDepositDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OfferID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DepositFromDetailsList" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}DepositFromDetailsList" minOccurs="0"/>
 *         &lt;element name="DepositToDetailsList" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}DepositToDetailsList" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TimeDepositDetails", propOrder = {
    "offerID",
    "depositFromDetailsList",
    "depositToDetailsList"
})
public class TimeDepositDetails {

    @XmlElement(name = "OfferID")
    protected String offerID;
    @XmlElement(name = "DepositFromDetailsList")
    protected DepositFromDetailsList depositFromDetailsList;
    @XmlElement(name = "DepositToDetailsList")
    protected DepositToDetailsList depositToDetailsList;

    /**
     * Obtiene el valor de la propiedad offerID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferID() {
        return offerID;
    }

    /**
     * Define el valor de la propiedad offerID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferID(String value) {
        this.offerID = value;
    }

    /**
     * Obtiene el valor de la propiedad depositFromDetailsList.
     * 
     * @return
     *     possible object is
     *     {@link DepositFromDetailsList }
     *     
     */
    public DepositFromDetailsList getDepositFromDetailsList() {
        return depositFromDetailsList;
    }

    /**
     * Define el valor de la propiedad depositFromDetailsList.
     * 
     * @param value
     *     allowed object is
     *     {@link DepositFromDetailsList }
     *     
     */
    public void setDepositFromDetailsList(DepositFromDetailsList value) {
        this.depositFromDetailsList = value;
    }

    /**
     * Obtiene el valor de la propiedad depositToDetailsList.
     * 
     * @return
     *     possible object is
     *     {@link DepositToDetailsList }
     *     
     */
    public DepositToDetailsList getDepositToDetailsList() {
        return depositToDetailsList;
    }

    /**
     * Define el valor de la propiedad depositToDetailsList.
     * 
     * @param value
     *     allowed object is
     *     {@link DepositToDetailsList }
     *     
     */
    public void setDepositToDetailsList(DepositToDetailsList value) {
        this.depositToDetailsList = value;
    }

}
