
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _InvestmentAndInsuranceProductDtlsLastMaintTStamp_QNAME = new QName("http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10", "LastMaintTStamp");
    private final static QName _SourceOfFundSeqNo_QNAME = new QName("http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10", "SeqNo");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SecuritiesBrokerageDtls }
     * 
     */
    public SecuritiesBrokerageDtls createSecuritiesBrokerageDtls() {
        return new SecuritiesBrokerageDtls();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link InvestmentAndInsuranceProductDtls }
     * 
     */
    public InvestmentAndInsuranceProductDtls createInvestmentAndInsuranceProductDtls() {
        return new InvestmentAndInsuranceProductDtls();
    }

    /**
     * Create an instance of {@link TPin }
     * 
     */
    public TPin createTPin() {
        return new TPin();
    }

    /**
     * Create an instance of {@link Income }
     * 
     */
    public Income createIncome() {
        return new Income();
    }

    /**
     * Create an instance of {@link OfferKey }
     * 
     */
    public OfferKey createOfferKey() {
        return new OfferKey();
    }

    /**
     * Create an instance of {@link Product }
     * 
     */
    public Product createProduct() {
        return new Product();
    }

    /**
     * Create an instance of {@link RelationshipKey }
     * 
     */
    public RelationshipKey createRelationshipKey() {
        return new RelationshipKey();
    }

    /**
     * Create an instance of {@link ApplicationSummary }
     * 
     */
    public ApplicationSummary createApplicationSummary() {
        return new ApplicationSummary();
    }

    /**
     * Create an instance of {@link CustomerDetails }
     * 
     */
    public CustomerDetails createCustomerDetails() {
        return new CustomerDetails();
    }

    /**
     * Create an instance of {@link ApplicationFullDetails }
     * 
     */
    public ApplicationFullDetails createApplicationFullDetails() {
        return new ApplicationFullDetails();
    }

    /**
     * Create an instance of {@link CustomerEmailAddr }
     * 
     */
    public CustomerEmailAddr createCustomerEmailAddr() {
        return new CustomerEmailAddr();
    }

    /**
     * Create an instance of {@link MemoDetails }
     * 
     */
    public MemoDetails createMemoDetails() {
        return new MemoDetails();
    }

    /**
     * Create an instance of {@link MGMDetails }
     * 
     */
    public MGMDetails createMGMDetails() {
        return new MGMDetails();
    }

    /**
     * Create an instance of {@link SourceOfFund }
     * 
     */
    public SourceOfFund createSourceOfFund() {
        return new SourceOfFund();
    }

    /**
     * Create an instance of {@link CASAProductDtls }
     * 
     */
    public CASAProductDtls createCASAProductDtls() {
        return new CASAProductDtls();
    }

    /**
     * Create an instance of {@link RelationshipDetails }
     * 
     */
    public RelationshipDetails createRelationshipDetails() {
        return new RelationshipDetails();
    }

    /**
     * Create an instance of {@link CustomerAddressDetails }
     * 
     */
    public CustomerAddressDetails createCustomerAddressDetails() {
        return new CustomerAddressDetails();
    }

    /**
     * Create an instance of {@link CitiCard }
     * 
     */
    public CitiCard createCitiCard() {
        return new CitiCard();
    }

    /**
     * Create an instance of {@link ApplicationDetails }
     * 
     */
    public ApplicationDetails createApplicationDetails() {
        return new ApplicationDetails();
    }

    /**
     * Create an instance of {@link CustomerKYCDetails }
     * 
     */
    public CustomerKYCDetails createCustomerKYCDetails() {
        return new CustomerKYCDetails();
    }

    /**
     * Create an instance of {@link CustomerIDDetails }
     * 
     */
    public CustomerIDDetails createCustomerIDDetails() {
        return new CustomerIDDetails();
    }

    /**
     * Create an instance of {@link CustomerNoItem }
     * 
     */
    public CustomerNoItem createCustomerNoItem() {
        return new CustomerNoItem();
    }

    /**
     * Create an instance of {@link CustomerIDDetailsList }
     * 
     */
    public CustomerIDDetailsList createCustomerIDDetailsList() {
        return new CustomerIDDetailsList();
    }

    /**
     * Create an instance of {@link ProductGroupDetails }
     * 
     */
    public ProductGroupDetails createProductGroupDetails() {
        return new ProductGroupDetails();
    }

    /**
     * Create an instance of {@link LdInterestRates }
     * 
     */
    public LdInterestRates createLdInterestRates() {
        return new LdInterestRates();
    }

    /**
     * Create an instance of {@link CustomerServices }
     * 
     */
    public CustomerServices createCustomerServices() {
        return new CustomerServices();
    }

    /**
     * Create an instance of {@link TransactionProfilingList }
     * 
     */
    public TransactionProfilingList createTransactionProfilingList() {
        return new TransactionProfilingList();
    }

    /**
     * Create an instance of {@link CustomerDocumentDetailsList }
     * 
     */
    public CustomerDocumentDetailsList createCustomerDocumentDetailsList() {
        return new CustomerDocumentDetailsList();
    }

    /**
     * Create an instance of {@link RelationshipLevelDtls }
     * 
     */
    public RelationshipLevelDtls createRelationshipLevelDtls() {
        return new RelationshipLevelDtls();
    }

    /**
     * Create an instance of {@link ProviderInfoDetails }
     * 
     */
    public ProviderInfoDetails createProviderInfoDetails() {
        return new ProviderInfoDetails();
    }

    /**
     * Create an instance of {@link COBrandDetails }
     * 
     */
    public COBrandDetails createCOBrandDetails() {
        return new COBrandDetails();
    }

    /**
     * Create an instance of {@link LinkedAccountDetails }
     * 
     */
    public LinkedAccountDetails createLinkedAccountDetails() {
        return new LinkedAccountDetails();
    }

    /**
     * Create an instance of {@link DepositFromDetails }
     * 
     */
    public DepositFromDetails createDepositFromDetails() {
        return new DepositFromDetails();
    }

    /**
     * Create an instance of {@link TransactionProfiling }
     * 
     */
    public TransactionProfiling createTransactionProfiling() {
        return new TransactionProfiling();
    }

    /**
     * Create an instance of {@link DocumentDetails }
     * 
     */
    public DocumentDetails createDocumentDetails() {
        return new DocumentDetails();
    }

    /**
     * Create an instance of {@link CustomerCostCenterDetails }
     * 
     */
    public CustomerCostCenterDetails createCustomerCostCenterDetails() {
        return new CustomerCostCenterDetails();
    }

    /**
     * Create an instance of {@link CustomerBasicData }
     * 
     */
    public CustomerBasicData createCustomerBasicData() {
        return new CustomerBasicData();
    }

    /**
     * Create an instance of {@link LoanSpecificDtls }
     * 
     */
    public LoanSpecificDtls createLoanSpecificDtls() {
        return new LoanSpecificDtls();
    }

    /**
     * Create an instance of {@link CreditCardDetails }
     * 
     */
    public CreditCardDetails createCreditCardDetails() {
        return new CreditCardDetails();
    }

    /**
     * Create an instance of {@link SecuritiesBrokerageProductDtls }
     * 
     */
    public SecuritiesBrokerageProductDtls createSecuritiesBrokerageProductDtls() {
        return new SecuritiesBrokerageProductDtls();
    }

    /**
     * Create an instance of {@link LdInterestRatesDetails }
     * 
     */
    public LdInterestRatesDetails createLdInterestRatesDetails() {
        return new LdInterestRatesDetails();
    }

    /**
     * Create an instance of {@link CreditBasicDtls }
     * 
     */
    public CreditBasicDtls createCreditBasicDtls() {
        return new CreditBasicDtls();
    }

    /**
     * Create an instance of {@link LoanProductDtls }
     * 
     */
    public LoanProductDtls createLoanProductDtls() {
        return new LoanProductDtls();
    }

    /**
     * Create an instance of {@link SigningInstructionDetails }
     * 
     */
    public SigningInstructionDetails createSigningInstructionDetails() {
        return new SigningInstructionDetails();
    }

    /**
     * Create an instance of {@link StatementComDtl }
     * 
     */
    public StatementComDtl createStatementComDtl() {
        return new StatementComDtl();
    }

    /**
     * Create an instance of {@link CustomerPhoneDetailsList }
     * 
     */
    public CustomerPhoneDetailsList createCustomerPhoneDetailsList() {
        return new CustomerPhoneDetailsList();
    }

    /**
     * Create an instance of {@link Offer }
     * 
     */
    public Offer createOffer() {
        return new Offer();
    }

    /**
     * Create an instance of {@link RSPDetails }
     * 
     */
    public RSPDetails createRSPDetails() {
        return new RSPDetails();
    }

    /**
     * Create an instance of {@link DisbBankAcctDtls }
     * 
     */
    public DisbBankAcctDtls createDisbBankAcctDtls() {
        return new DisbBankAcctDtls();
    }

    /**
     * Create an instance of {@link TimeDepositProductDtls }
     * 
     */
    public TimeDepositProductDtls createTimeDepositProductDtls() {
        return new TimeDepositProductDtls();
    }

    /**
     * Create an instance of {@link IndividualCustomerBasicData }
     * 
     */
    public IndividualCustomerBasicData createIndividualCustomerBasicData() {
        return new IndividualCustomerBasicData();
    }

    /**
     * Create an instance of {@link CustomerNos }
     * 
     */
    public CustomerNos createCustomerNos() {
        return new CustomerNos();
    }

    /**
     * Create an instance of {@link Applicant }
     * 
     */
    public Applicant createApplicant() {
        return new Applicant();
    }

    /**
     * Create an instance of {@link Application }
     * 
     */
    public Application createApplication() {
        return new Application();
    }

    /**
     * Create an instance of {@link BalanceTransferDetails }
     * 
     */
    public BalanceTransferDetails createBalanceTransferDetails() {
        return new BalanceTransferDetails();
    }

    /**
     * Create an instance of {@link USLNDetails }
     * 
     */
    public USLNDetails createUSLNDetails() {
        return new USLNDetails();
    }

    /**
     * Create an instance of {@link SignatureDetails }
     * 
     */
    public SignatureDetails createSignatureDetails() {
        return new SignatureDetails();
    }

    /**
     * Create an instance of {@link PrimaryCustomerKey }
     * 
     */
    public PrimaryCustomerKey createPrimaryCustomerKey() {
        return new PrimaryCustomerKey();
    }

    /**
     * Create an instance of {@link CASADetail }
     * 
     */
    public CASADetail createCASADetail() {
        return new CASADetail();
    }

    /**
     * Create an instance of {@link PersonalReference }
     * 
     */
    public PersonalReference createPersonalReference() {
        return new PersonalReference();
    }

    /**
     * Create an instance of {@link CustomerPhoneDetails }
     * 
     */
    public CustomerPhoneDetails createCustomerPhoneDetails() {
        return new CustomerPhoneDetails();
    }

    /**
     * Create an instance of {@link CustomerKey }
     * 
     */
    public CustomerKey createCustomerKey() {
        return new CustomerKey();
    }

    /**
     * Create an instance of {@link TimeDepositDetails }
     * 
     */
    public TimeDepositDetails createTimeDepositDetails() {
        return new TimeDepositDetails();
    }

    /**
     * Create an instance of {@link CreditsAndLiabilitiesReferenceDetails }
     * 
     */
    public CreditsAndLiabilitiesReferenceDetails createCreditsAndLiabilitiesReferenceDetails() {
        return new CreditsAndLiabilitiesReferenceDetails();
    }

    /**
     * Create an instance of {@link CustomerEmploymentDetailsList }
     * 
     */
    public CustomerEmploymentDetailsList createCustomerEmploymentDetailsList() {
        return new CustomerEmploymentDetailsList();
    }

    /**
     * Create an instance of {@link StatementDtls }
     * 
     */
    public StatementDtls createStatementDtls() {
        return new StatementDtls();
    }

    /**
     * Create an instance of {@link ApplicationDtls }
     * 
     */
    public ApplicationDtls createApplicationDtls() {
        return new ApplicationDtls();
    }

    /**
     * Create an instance of {@link Employment }
     * 
     */
    public Employment createEmployment() {
        return new Employment();
    }

    /**
     * Create an instance of {@link DepositFromDetailsList }
     * 
     */
    public DepositFromDetailsList createDepositFromDetailsList() {
        return new DepositFromDetailsList();
    }

    /**
     * Create an instance of {@link CheckBook }
     * 
     */
    public CheckBook createCheckBook() {
        return new CheckBook();
    }

    /**
     * Create an instance of {@link DepositToDetails }
     * 
     */
    public DepositToDetails createDepositToDetails() {
        return new DepositToDetails();
    }

    /**
     * Create an instance of {@link CustomerAdditionalDetails }
     * 
     */
    public CustomerAdditionalDetails createCustomerAdditionalDetails() {
        return new CustomerAdditionalDetails();
    }

    /**
     * Create an instance of {@link CreditCardProductDtls }
     * 
     */
    public CreditCardProductDtls createCreditCardProductDtls() {
        return new CreditCardProductDtls();
    }

    /**
     * Create an instance of {@link DepositToDetailsList }
     * 
     */
    public DepositToDetailsList createDepositToDetailsList() {
        return new DepositToDetailsList();
    }

    /**
     * Create an instance of {@link OtherBankDetails }
     * 
     */
    public OtherBankDetails createOtherBankDetails() {
        return new OtherBankDetails();
    }

    /**
     * Create an instance of {@link CustomerEmploymentDetails }
     * 
     */
    public CustomerEmploymentDetails createCustomerEmploymentDetails() {
        return new CustomerEmploymentDetails();
    }

    /**
     * Create an instance of {@link ProductDetail }
     * 
     */
    public ProductDetail createProductDetail() {
        return new ProductDetail();
    }

    /**
     * Create an instance of {@link AcquisitionAndReferral }
     * 
     */
    public AcquisitionAndReferral createAcquisitionAndReferral() {
        return new AcquisitionAndReferral();
    }

    /**
     * Create an instance of {@link CounterOffersProductDetails }
     * 
     */
    public CounterOffersProductDetails createCounterOffersProductDetails() {
        return new CounterOffersProductDetails();
    }

    /**
     * Create an instance of {@link InvestmentProductDtls }
     * 
     */
    public InvestmentProductDtls createInvestmentProductDtls() {
        return new InvestmentProductDtls();
    }

    /**
     * Create an instance of {@link CitiClearDetails }
     * 
     */
    public CitiClearDetails createCitiClearDetails() {
        return new CitiClearDetails();
    }

    /**
     * Create an instance of {@link CustomerSignatureDetailsList }
     * 
     */
    public CustomerSignatureDetailsList createCustomerSignatureDetailsList() {
        return new CustomerSignatureDetailsList();
    }

    /**
     * Create an instance of {@link CustomerEmailAddrList }
     * 
     */
    public CustomerEmailAddrList createCustomerEmailAddrList() {
        return new CustomerEmailAddrList();
    }

    /**
     * Create an instance of {@link ReadyCreditSpecificDetails }
     * 
     */
    public ReadyCreditSpecificDetails createReadyCreditSpecificDetails() {
        return new ReadyCreditSpecificDetails();
    }

    /**
     * Create an instance of {@link BasicData }
     * 
     */
    public BasicData createBasicData() {
        return new BasicData();
    }

    /**
     * Create an instance of {@link CustomerBankInfo }
     * 
     */
    public CustomerBankInfo createCustomerBankInfo() {
        return new CustomerBankInfo();
    }

    /**
     * Create an instance of {@link AccountKey }
     * 
     */
    public AccountKey createAccountKey() {
        return new AccountKey();
    }

    /**
     * Create an instance of {@link StatementAdditional }
     * 
     */
    public StatementAdditional createStatementAdditional() {
        return new StatementAdditional();
    }

    /**
     * Create an instance of {@link CustomerAddressDetailsList }
     * 
     */
    public CustomerAddressDetailsList createCustomerAddressDetailsList() {
        return new CustomerAddressDetailsList();
    }

    /**
     * Create an instance of {@link MultiOfferProductDetails }
     * 
     */
    public MultiOfferProductDetails createMultiOfferProductDetails() {
        return new MultiOfferProductDetails();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10", name = "LastMaintTStamp", scope = InvestmentAndInsuranceProductDtls.class)
    public JAXBElement<XMLGregorianCalendar> createInvestmentAndInsuranceProductDtlsLastMaintTStamp(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_InvestmentAndInsuranceProductDtlsLastMaintTStamp_QNAME, XMLGregorianCalendar.class, InvestmentAndInsuranceProductDtls.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10", name = "SeqNo", scope = SourceOfFund.class)
    public JAXBElement<Integer> createSourceOfFundSeqNo(Integer value) {
        return new JAXBElement<Integer>(_SourceOfFundSeqNo_QNAME, Integer.class, SourceOfFund.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10", name = "LastMaintTStamp", scope = SourceOfFund.class)
    public JAXBElement<XMLGregorianCalendar> createSourceOfFundLastMaintTStamp(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_InvestmentAndInsuranceProductDtlsLastMaintTStamp_QNAME, XMLGregorianCalendar.class, SourceOfFund.class, value);
    }

}
