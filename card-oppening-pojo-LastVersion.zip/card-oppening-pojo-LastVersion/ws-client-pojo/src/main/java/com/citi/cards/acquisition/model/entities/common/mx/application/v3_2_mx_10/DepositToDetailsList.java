
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para DepositToDetailsList complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DepositToDetailsList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DepositToDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}DepositToDetails" maxOccurs="3" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DepositToDetailsList", propOrder = {
    "depositToDetails"
})
public class DepositToDetailsList {

    @XmlElement(name = "DepositToDetails")
    protected List<DepositToDetails> depositToDetails;

    /**
     * Gets the value of the depositToDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the depositToDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDepositToDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DepositToDetails }
     * 
     * 
     */
    public List<DepositToDetails> getDepositToDetails() {
        if (depositToDetails == null) {
            depositToDetails = new ArrayList<DepositToDetails>();
        }
        return this.depositToDetails;
    }

}
