
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ApplicationDtls complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ApplicationDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ApplicationType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IPAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplSubmissionDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CampaignID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WaveID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TransactionType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MemoDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}MemoDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ApplicationDtls", propOrder = {
    "applicationType",
    "applicationMode",
    "ipAddress",
    "applicationID",
    "applSubmissionDt",
    "campaignID",
    "waveID",
    "transactionType",
    "memoDetails"
})
public class ApplicationDtls {

    @XmlElement(name = "ApplicationType")
    protected String applicationType;
    @XmlElement(name = "ApplicationMode")
    protected String applicationMode;
    @XmlElement(name = "IPAddress")
    protected String ipAddress;
    @XmlElement(name = "ApplicationID")
    protected String applicationID;
    @XmlElement(name = "ApplSubmissionDt")
    protected String applSubmissionDt;
    @XmlElement(name = "CampaignID")
    protected String campaignID;
    @XmlElement(name = "WaveID")
    protected String waveID;
    @XmlElement(name = "TransactionType")
    protected String transactionType;
    @XmlElement(name = "MemoDetails")
    protected List<MemoDetails> memoDetails;

    /**
     * Obtiene el valor de la propiedad applicationType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationType() {
        return applicationType;
    }

    /**
     * Define el valor de la propiedad applicationType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationType(String value) {
        this.applicationType = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationMode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationMode() {
        return applicationMode;
    }

    /**
     * Define el valor de la propiedad applicationMode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationMode(String value) {
        this.applicationMode = value;
    }

    /**
     * Obtiene el valor de la propiedad ipAddress.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIPAddress() {
        return ipAddress;
    }

    /**
     * Define el valor de la propiedad ipAddress.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIPAddress(String value) {
        this.ipAddress = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationID() {
        return applicationID;
    }

    /**
     * Define el valor de la propiedad applicationID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationID(String value) {
        this.applicationID = value;
    }

    /**
     * Obtiene el valor de la propiedad applSubmissionDt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplSubmissionDt() {
        return applSubmissionDt;
    }

    /**
     * Define el valor de la propiedad applSubmissionDt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplSubmissionDt(String value) {
        this.applSubmissionDt = value;
    }

    /**
     * Obtiene el valor de la propiedad campaignID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCampaignID() {
        return campaignID;
    }

    /**
     * Define el valor de la propiedad campaignID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCampaignID(String value) {
        this.campaignID = value;
    }

    /**
     * Obtiene el valor de la propiedad waveID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaveID() {
        return waveID;
    }

    /**
     * Define el valor de la propiedad waveID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaveID(String value) {
        this.waveID = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionType() {
        return transactionType;
    }

    /**
     * Define el valor de la propiedad transactionType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionType(String value) {
        this.transactionType = value;
    }

    /**
     * Gets the value of the memoDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the memoDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMemoDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MemoDetails }
     * 
     * 
     */
    public List<MemoDetails> getMemoDetails() {
        if (memoDetails == null) {
            memoDetails = new ArrayList<MemoDetails>();
        }
        return this.memoDetails;
    }

}
