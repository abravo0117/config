
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.ApplicationDtls;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.CASAProductDtls;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.CreditCardProductDtls;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.CustomerDetails;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.InvestmentProductDtls;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.LoanProductDtls;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.RelationshipLevelDtls;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.SecuritiesBrokerageProductDtls;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.StatementDtls;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.TimeDepositProductDtls;


/**
 * <p>Clase Java para GenerateApplicationRq complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="GenerateApplicationRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AppID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}ApplicationDtls" minOccurs="0"/>
 *         &lt;element name="CustomerDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CASAProductDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CASAProductDtls" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="TimeDepositProductDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}TimeDepositProductDtls" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="InvestmentProductDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}InvestmentProductDtls" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="SecuritiesBrokerageProductDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}SecuritiesBrokerageProductDtls" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CreditCardProductDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CreditCardProductDtls" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="LoanProductDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}LoanProductDtls" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="RelationshipLevelDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}RelationshipLevelDtls" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="StatementDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}StatementDtls" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CustomerNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProductIdentifier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceOfDerivative" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelationshipNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Product" type="{http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15}Product" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CurrentBusinessDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="ControlDetails" type="{http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15}ControlDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GenerateApplicationRq", propOrder = {
    "appID",
    "applicationDtls",
    "customerDetails",
    "casaProductDtls",
    "timeDepositProductDtls",
    "investmentProductDtls",
    "securitiesBrokerageProductDtls",
    "creditCardProductDtls",
    "loanProductDtls",
    "relationshipLevelDtls",
    "statementDtls",
    "customerNo",
    "productIdentifier",
    "sourceOfDerivative",
    "relationshipNo",
    "product",
    "currentBusinessDate",
    "controlDetails"
})
public class GenerateApplicationRq {

    @XmlElement(name = "AppID")
    protected String appID;
    @XmlElement(name = "ApplicationDtls")
    protected ApplicationDtls applicationDtls;
    @XmlElement(name = "CustomerDetails")
    protected List<CustomerDetails> customerDetails;
    @XmlElement(name = "CASAProductDtls")
    protected List<CASAProductDtls> casaProductDtls;
    @XmlElement(name = "TimeDepositProductDtls")
    protected List<TimeDepositProductDtls> timeDepositProductDtls;
    @XmlElement(name = "InvestmentProductDtls")
    protected List<InvestmentProductDtls> investmentProductDtls;
    @XmlElement(name = "SecuritiesBrokerageProductDtls")
    protected List<SecuritiesBrokerageProductDtls> securitiesBrokerageProductDtls;
    @XmlElement(name = "CreditCardProductDtls")
    protected List<CreditCardProductDtls> creditCardProductDtls;
    @XmlElement(name = "LoanProductDtls")
    protected List<LoanProductDtls> loanProductDtls;
    @XmlElement(name = "RelationshipLevelDtls")
    protected List<RelationshipLevelDtls> relationshipLevelDtls;
    @XmlElement(name = "StatementDtls")
    protected List<StatementDtls> statementDtls;
    @XmlElement(name = "CustomerNo")
    protected String customerNo;
    @XmlElement(name = "ProductIdentifier")
    protected String productIdentifier;
    @XmlElement(name = "SourceOfDerivative")
    protected String sourceOfDerivative;
    @XmlElement(name = "RelationshipNo")
    protected String relationshipNo;
    @XmlElement(name = "Product")
    protected List<Product> product;
    @XmlElement(name = "CurrentBusinessDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar currentBusinessDate;
    @XmlElement(name = "ControlDetails")
    protected ControlDetails controlDetails;

    /**
     * Obtiene el valor de la propiedad appID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppID() {
        return appID;
    }

    /**
     * Define el valor de la propiedad appID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppID(String value) {
        this.appID = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationDtls.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationDtls }
     *     
     */
    public ApplicationDtls getApplicationDtls() {
        return applicationDtls;
    }

    /**
     * Define el valor de la propiedad applicationDtls.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationDtls }
     *     
     */
    public void setApplicationDtls(ApplicationDtls value) {
        this.applicationDtls = value;
    }

    /**
     * Gets the value of the customerDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customerDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomerDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CustomerDetails }
     * 
     * 
     */
    public List<CustomerDetails> getCustomerDetails() {
        if (customerDetails == null) {
            customerDetails = new ArrayList<CustomerDetails>();
        }
        return this.customerDetails;
    }

    /**
     * Gets the value of the casaProductDtls property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the casaProductDtls property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCASAProductDtls().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CASAProductDtls }
     * 
     * 
     */
    public List<CASAProductDtls> getCASAProductDtls() {
        if (casaProductDtls == null) {
            casaProductDtls = new ArrayList<CASAProductDtls>();
        }
        return this.casaProductDtls;
    }

    /**
     * Gets the value of the timeDepositProductDtls property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the timeDepositProductDtls property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTimeDepositProductDtls().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TimeDepositProductDtls }
     * 
     * 
     */
    public List<TimeDepositProductDtls> getTimeDepositProductDtls() {
        if (timeDepositProductDtls == null) {
            timeDepositProductDtls = new ArrayList<TimeDepositProductDtls>();
        }
        return this.timeDepositProductDtls;
    }

    /**
     * Gets the value of the investmentProductDtls property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the investmentProductDtls property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInvestmentProductDtls().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InvestmentProductDtls }
     * 
     * 
     */
    public List<InvestmentProductDtls> getInvestmentProductDtls() {
        if (investmentProductDtls == null) {
            investmentProductDtls = new ArrayList<InvestmentProductDtls>();
        }
        return this.investmentProductDtls;
    }

    /**
     * Gets the value of the securitiesBrokerageProductDtls property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the securitiesBrokerageProductDtls property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSecuritiesBrokerageProductDtls().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SecuritiesBrokerageProductDtls }
     * 
     * 
     */
    public List<SecuritiesBrokerageProductDtls> getSecuritiesBrokerageProductDtls() {
        if (securitiesBrokerageProductDtls == null) {
            securitiesBrokerageProductDtls = new ArrayList<SecuritiesBrokerageProductDtls>();
        }
        return this.securitiesBrokerageProductDtls;
    }

    /**
     * Gets the value of the creditCardProductDtls property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the creditCardProductDtls property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreditCardProductDtls().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreditCardProductDtls }
     * 
     * 
     */
    public List<CreditCardProductDtls> getCreditCardProductDtls() {
        if (creditCardProductDtls == null) {
            creditCardProductDtls = new ArrayList<CreditCardProductDtls>();
        }
        return this.creditCardProductDtls;
    }

    /**
     * Gets the value of the loanProductDtls property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the loanProductDtls property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLoanProductDtls().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LoanProductDtls }
     * 
     * 
     */
    public List<LoanProductDtls> getLoanProductDtls() {
        if (loanProductDtls == null) {
            loanProductDtls = new ArrayList<LoanProductDtls>();
        }
        return this.loanProductDtls;
    }

    /**
     * Gets the value of the relationshipLevelDtls property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the relationshipLevelDtls property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRelationshipLevelDtls().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RelationshipLevelDtls }
     * 
     * 
     */
    public List<RelationshipLevelDtls> getRelationshipLevelDtls() {
        if (relationshipLevelDtls == null) {
            relationshipLevelDtls = new ArrayList<RelationshipLevelDtls>();
        }
        return this.relationshipLevelDtls;
    }

    /**
     * Gets the value of the statementDtls property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the statementDtls property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatementDtls().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StatementDtls }
     * 
     * 
     */
    public List<StatementDtls> getStatementDtls() {
        if (statementDtls == null) {
            statementDtls = new ArrayList<StatementDtls>();
        }
        return this.statementDtls;
    }

    /**
     * Obtiene el valor de la propiedad customerNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerNo() {
        return customerNo;
    }

    /**
     * Define el valor de la propiedad customerNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerNo(String value) {
        this.customerNo = value;
    }

    /**
     * Obtiene el valor de la propiedad productIdentifier.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductIdentifier() {
        return productIdentifier;
    }

    /**
     * Define el valor de la propiedad productIdentifier.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductIdentifier(String value) {
        this.productIdentifier = value;
    }

    /**
     * Obtiene el valor de la propiedad sourceOfDerivative.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceOfDerivative() {
        return sourceOfDerivative;
    }

    /**
     * Define el valor de la propiedad sourceOfDerivative.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceOfDerivative(String value) {
        this.sourceOfDerivative = value;
    }

    /**
     * Obtiene el valor de la propiedad relationshipNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipNo() {
        return relationshipNo;
    }

    /**
     * Define el valor de la propiedad relationshipNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipNo(String value) {
        this.relationshipNo = value;
    }

    /**
     * Gets the value of the product property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the product property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProduct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Product }
     * 
     * 
     */
    public List<Product> getProduct() {
        if (product == null) {
            product = new ArrayList<Product>();
        }
        return this.product;
    }

    /**
     * Obtiene el valor de la propiedad currentBusinessDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCurrentBusinessDate() {
        return currentBusinessDate;
    }

    /**
     * Define el valor de la propiedad currentBusinessDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCurrentBusinessDate(XMLGregorianCalendar value) {
        this.currentBusinessDate = value;
    }

    /**
     * Obtiene el valor de la propiedad controlDetails.
     * 
     * @return
     *     possible object is
     *     {@link ControlDetails }
     *     
     */
    public ControlDetails getControlDetails() {
        return controlDetails;
    }

    /**
     * Define el valor de la propiedad controlDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link ControlDetails }
     *     
     */
    public void setControlDetails(ControlDetails value) {
        this.controlDetails = value;
    }

}
