
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.Applicant;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.Application;


/**
 * <p>Clase Java para PreprocessCardApplicationInqRq complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PreprocessCardApplicationInqRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Application" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Application"/>
 *         &lt;element name="Applicant" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Applicant" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PreprocessCardApplicationInqRq", propOrder = {
    "application",
    "applicant"
})
public class PreprocessCardApplicationInqRq {

    @XmlElement(name = "Application", required = true)
    protected Application application;
    @XmlElement(name = "Applicant")
    protected List<Applicant> applicant;

    /**
     * Obtiene el valor de la propiedad application.
     * 
     * @return
     *     possible object is
     *     {@link Application }
     *     
     */
    public Application getApplication() {
        return application;
    }

    /**
     * Define el valor de la propiedad application.
     * 
     * @param value
     *     allowed object is
     *     {@link Application }
     *     
     */
    public void setApplication(Application value) {
        this.application = value;
    }

    /**
     * Gets the value of the applicant property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the applicant property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getApplicant().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Applicant }
     * 
     * 
     */
    public List<Applicant> getApplicant() {
        if (applicant == null) {
            applicant = new ArrayList<Applicant>();
        }
        return this.applicant;
    }

}
