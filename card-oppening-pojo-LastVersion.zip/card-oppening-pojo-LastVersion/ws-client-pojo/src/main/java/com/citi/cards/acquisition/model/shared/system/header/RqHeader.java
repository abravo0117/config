
package com.citi.cards.acquisition.model.shared.system.header;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para RqHeader complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="RqHeader">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DateAndTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="UUID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ClientDetails" type="{http://www.citi.com/gcgi/shared/system/header}ClientDetails"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RqHeader", propOrder = {
    "dateAndTimeStamp",
    "uuid",
    "version",
    "clientDetails"
})
public class RqHeader {

    @XmlElement(name = "DateAndTimeStamp", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateAndTimeStamp;
    @XmlElement(name = "UUID", required = true)
    protected String uuid;
    @XmlElement(name = "Version")
    protected String version;
    @XmlElement(name = "ClientDetails", required = true)
    protected ClientDetails clientDetails;

    /**
     * Obtiene el valor de la propiedad dateAndTimeStamp.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateAndTimeStamp() {
        return dateAndTimeStamp;
    }

    /**
     * Define el valor de la propiedad dateAndTimeStamp.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateAndTimeStamp(XMLGregorianCalendar value) {
        this.dateAndTimeStamp = value;
    }

    /**
     * Obtiene el valor de la propiedad uuid.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUUID() {
        return uuid;
    }

    /**
     * Define el valor de la propiedad uuid.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUUID(String value) {
        this.uuid = value;
    }

    /**
     * Obtiene el valor de la propiedad version.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersion() {
        return version;
    }

    /**
     * Define el valor de la propiedad version.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersion(String value) {
        this.version = value;
    }

    /**
     * Obtiene el valor de la propiedad clientDetails.
     * 
     * @return
     *     possible object is
     *     {@link ClientDetails }
     *     
     */
    public ClientDetails getClientDetails() {
        return clientDetails;
    }

    /**
     * Define el valor de la propiedad clientDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link ClientDetails }
     *     
     */
    public void setClientDetails(ClientDetails value) {
        this.clientDetails = value;
    }

}
