
package com.citi.cards.acquisition.model.shared.util.v3_1_0_0;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para AccountKey complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="AccountKey">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AccountNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}AccountNo" minOccurs="0"/>
 *         &lt;element name="InternalCountryCode" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}InternalCountryCode" minOccurs="0"/>
 *         &lt;element name="Control2" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}AccountNoControl" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountKey", propOrder = {
    "accountNo",
    "internalCountryCode",
    "control2"
})
public class AccountKey {

    @XmlElement(name = "AccountNo")
    protected String accountNo;
    @XmlElement(name = "InternalCountryCode")
    protected String internalCountryCode;
    @XmlElement(name = "Control2")
    protected String control2;

    /**
     * Obtiene el valor de la propiedad accountNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNo() {
        return accountNo;
    }

    /**
     * Define el valor de la propiedad accountNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNo(String value) {
        this.accountNo = value;
    }

    /**
     * Obtiene el valor de la propiedad internalCountryCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInternalCountryCode() {
        return internalCountryCode;
    }

    /**
     * Define el valor de la propiedad internalCountryCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInternalCountryCode(String value) {
        this.internalCountryCode = value;
    }

    /**
     * Obtiene el valor de la propiedad control2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getControl2() {
        return control2;
    }

    /**
     * Define el valor de la propiedad control2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setControl2(String value) {
        this.control2 = value;
    }

}
