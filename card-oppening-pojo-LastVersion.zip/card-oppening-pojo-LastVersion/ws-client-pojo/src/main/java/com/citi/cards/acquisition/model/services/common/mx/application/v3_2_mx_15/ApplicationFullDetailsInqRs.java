
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.Applicant;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.Application;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.DocumentDetails;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.MemoDetails;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.GenericResponse;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.LastUpdate;

/**
 * <p>
 * Clase Java para ApplicationFullDetailsInqRs complex type.
 * 
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ApplicationFullDetailsInqRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="Date" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="Time" type="{http://www.w3.org/2001/XMLSchema}time" minOccurs="0"/>
 *         &lt;element name="System" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ServiceOperationName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Application" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Application" minOccurs="0"/>
 *         &lt;element name="ApplicationStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicationStage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ReasonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="LastUpdate" type="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}LastUpdate" minOccurs="0"/>
 *         &lt;element name="MissingDocs" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}DocumentDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Applicant" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Applicant" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="MemoDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}MemoDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "ApplicationFullDetailsInqRs",
    namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15")
@XmlType(name = "ApplicationFullDetailsInqRs",
    propOrder = {"date", "time", "system", "serviceOperationName",
        "application", "applicationStatus", "applicationStage", "reasonCode",
        "applicationDate", "lastUpdate", "missingDocs", "applicant",
        "memoDetails"})
public class ApplicationFullDetailsInqRs extends GenericResponse {

    @XmlElement(name = "Date")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar date;

    @XmlElement(name = "Time")
    @XmlSchemaType(name = "time")
    protected XMLGregorianCalendar time;

    @XmlElement(name = "System")
    protected String system;

    @XmlElement(name = "ServiceOperationName")
    protected String serviceOperationName;

    @XmlElement(name = "Application")
    protected Application application;

    @XmlElement(name = "ApplicationStatus", required = true)
    protected String applicationStatus;

    @XmlElement(name = "ApplicationStage", required = true)
    protected String applicationStage;

    @XmlElement(name = "ReasonCode")
    protected String reasonCode;

    @XmlElement(name = "ApplicationDate", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar applicationDate;

    @XmlElement(name = "LastUpdate")
    protected LastUpdate lastUpdate;

    @XmlElement(name = "MissingDocs")
    protected List<DocumentDetails> missingDocs;

    @XmlElement(name = "Applicant")
    protected List<Applicant> applicant;

    @XmlElement(name = "MemoDetails")
    protected List<MemoDetails> memoDetails;

    /**
     * Obtiene el valor de la propiedad date.
     * 
     * @return possible object is {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getDate() {

        return date;
    }

    /**
     * Define el valor de la propiedad date.
     * 
     * @param value
     *            allowed object is {@link XMLGregorianCalendar }
     * 
     */
    public void setDate(XMLGregorianCalendar value) {

        this.date = value;
    }

    /**
     * Obtiene el valor de la propiedad time.
     * 
     * @return possible object is {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getTime() {

        return time;
    }

    /**
     * Define el valor de la propiedad time.
     * 
     * @param value
     *            allowed object is {@link XMLGregorianCalendar }
     * 
     */
    public void setTime(XMLGregorianCalendar value) {

        this.time = value;
    }

    /**
     * Obtiene el valor de la propiedad system.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getSystem() {

        return system;
    }

    /**
     * Define el valor de la propiedad system.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setSystem(String value) {

        this.system = value;
    }

    /**
     * Obtiene el valor de la propiedad serviceOperationName.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getServiceOperationName() {

        return serviceOperationName;
    }

    /**
     * Define el valor de la propiedad serviceOperationName.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setServiceOperationName(String value) {

        this.serviceOperationName = value;
    }

    /**
     * Obtiene el valor de la propiedad application.
     * 
     * @return possible object is {@link Application }
     * 
     */
    public Application getApplication() {

        return application;
    }

    /**
     * Define el valor de la propiedad application.
     * 
     * @param value
     *            allowed object is {@link Application }
     * 
     */
    public void setApplication(Application value) {

        this.application = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationStatus.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getApplicationStatus() {

        return applicationStatus;
    }

    /**
     * Define el valor de la propiedad applicationStatus.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setApplicationStatus(String value) {

        this.applicationStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationStage.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getApplicationStage() {

        return applicationStage;
    }

    /**
     * Define el valor de la propiedad applicationStage.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setApplicationStage(String value) {

        this.applicationStage = value;
    }

    /**
     * Obtiene el valor de la propiedad reasonCode.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getReasonCode() {

        return reasonCode;
    }

    /**
     * Define el valor de la propiedad reasonCode.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setReasonCode(String value) {

        this.reasonCode = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationDate.
     * 
     * @return possible object is {@link XMLGregorianCalendar }
     * 
     */
    public XMLGregorianCalendar getApplicationDate() {

        return applicationDate;
    }

    /**
     * Define el valor de la propiedad applicationDate.
     * 
     * @param value
     *            allowed object is {@link XMLGregorianCalendar }
     * 
     */
    public void setApplicationDate(XMLGregorianCalendar value) {

        this.applicationDate = value;
    }

    /**
     * Obtiene el valor de la propiedad lastUpdate.
     * 
     * @return possible object is {@link LastUpdate }
     * 
     */
    public LastUpdate getLastUpdate() {

        return lastUpdate;
    }

    /**
     * Define el valor de la propiedad lastUpdate.
     * 
     * @param value
     *            allowed object is {@link LastUpdate }
     * 
     */
    public void setLastUpdate(LastUpdate value) {

        this.lastUpdate = value;
    }

    /**
     * Gets the value of the missingDocs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list, not a
     * snapshot. Therefore any modification you make to the returned list will
     * be present inside the JAXB object. This is why there is not a
     * <CODE>set</CODE> method for the missingDocs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * 
     * <pre>
     * getMissingDocs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentDetails }
     * 
     * 
     */
    public List<DocumentDetails> getMissingDocs() {

        if (missingDocs == null) {
            missingDocs = new ArrayList<DocumentDetails>();
        }
        return this.missingDocs;
    }

    /**
     * Gets the value of the applicant property.
     * 
     * <p>
     * This accessor method returns a reference to the live list, not a
     * snapshot. Therefore any modification you make to the returned list will
     * be present inside the JAXB object. This is why there is not a
     * <CODE>set</CODE> method for the applicant property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * 
     * <pre>
     * getApplicant().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list {@link Applicant
     * }
     * 
     * 
     */
    public List<Applicant> getApplicant() {

        if (applicant == null) {
            applicant = new ArrayList<Applicant>();
        }
        return this.applicant;
    }

    /**
     * Gets the value of the memoDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list, not a
     * snapshot. Therefore any modification you make to the returned list will
     * be present inside the JAXB object. This is why there is not a
     * <CODE>set</CODE> method for the memoDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * 
     * <pre>
     * getMemoDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MemoDetails }
     * 
     * 
     */
    public List<MemoDetails> getMemoDetails() {

        if (memoDetails == null) {
            memoDetails = new ArrayList<MemoDetails>();
        }
        return this.memoDetails;
    }

}
