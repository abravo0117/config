
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ReadyCreditSpecificDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ReadyCreditSpecificDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ATMInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChequeInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DChequeInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReadyCreditSpecificDetails", propOrder = {
    "atmInd",
    "chequeInd",
    "dChequeInd"
})
public class ReadyCreditSpecificDetails {

    @XmlElement(name = "ATMInd")
    protected String atmInd;
    @XmlElement(name = "ChequeInd")
    protected String chequeInd;
    @XmlElement(name = "DChequeInd")
    protected String dChequeInd;

    /**
     * Obtiene el valor de la propiedad atmInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getATMInd() {
        return atmInd;
    }

    /**
     * Define el valor de la propiedad atmInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setATMInd(String value) {
        this.atmInd = value;
    }

    /**
     * Obtiene el valor de la propiedad chequeInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChequeInd() {
        return chequeInd;
    }

    /**
     * Define el valor de la propiedad chequeInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChequeInd(String value) {
        this.chequeInd = value;
    }

    /**
     * Obtiene el valor de la propiedad dChequeInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDChequeInd() {
        return dChequeInd;
    }

    /**
     * Define el valor de la propiedad dChequeInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDChequeInd(String value) {
        this.dChequeInd = value;
    }

}
