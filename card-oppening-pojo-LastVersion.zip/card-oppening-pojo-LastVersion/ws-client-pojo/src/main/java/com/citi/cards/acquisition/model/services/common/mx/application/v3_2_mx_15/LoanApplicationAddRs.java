
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.GenericResponse;


/**
 * <p>Clase Java para LoanApplicationAddRs complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="LoanApplicationAddRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="ApplicationID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Stage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MobilePhoneCtryCd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MobilePhoneNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AgentPhoneNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MessageCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExternalApplicationID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationCreatedDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="ApplicationCreatedTime" type="{http://www.w3.org/2001/XMLSchema}time" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanApplicationAddRs", propOrder = {
    "applicationID",
    "stage",
    "status",
    "mobilePhoneCtryCd",
    "mobilePhoneNo",
    "agentType",
    "agentPhoneNo",
    "messageCode",
    "externalApplicationID",
    "applicationCreatedDate",
    "applicationCreatedTime"
})
public class LoanApplicationAddRs
    extends GenericResponse
{

    @XmlElement(name = "ApplicationID")
    protected String applicationID;
    @XmlElement(name = "Stage")
    protected String stage;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "MobilePhoneCtryCd")
    protected String mobilePhoneCtryCd;
    @XmlElement(name = "MobilePhoneNo")
    protected String mobilePhoneNo;
    @XmlElement(name = "AgentType")
    protected String agentType;
    @XmlElement(name = "AgentPhoneNo")
    protected String agentPhoneNo;
    @XmlElement(name = "MessageCode")
    protected String messageCode;
    @XmlElement(name = "ExternalApplicationID")
    protected String externalApplicationID;
    @XmlElement(name = "ApplicationCreatedDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar applicationCreatedDate;
    @XmlElement(name = "ApplicationCreatedTime")
    @XmlSchemaType(name = "time")
    protected XMLGregorianCalendar applicationCreatedTime;

    /**
     * Obtiene el valor de la propiedad applicationID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationID() {
        return applicationID;
    }

    /**
     * Define el valor de la propiedad applicationID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationID(String value) {
        this.applicationID = value;
    }

    /**
     * Obtiene el valor de la propiedad stage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStage() {
        return stage;
    }

    /**
     * Define el valor de la propiedad stage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStage(String value) {
        this.stage = value;
    }

    /**
     * Obtiene el valor de la propiedad status.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Define el valor de la propiedad status.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Obtiene el valor de la propiedad mobilePhoneCtryCd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobilePhoneCtryCd() {
        return mobilePhoneCtryCd;
    }

    /**
     * Define el valor de la propiedad mobilePhoneCtryCd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobilePhoneCtryCd(String value) {
        this.mobilePhoneCtryCd = value;
    }

    /**
     * Obtiene el valor de la propiedad mobilePhoneNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMobilePhoneNo() {
        return mobilePhoneNo;
    }

    /**
     * Define el valor de la propiedad mobilePhoneNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMobilePhoneNo(String value) {
        this.mobilePhoneNo = value;
    }

    /**
     * Obtiene el valor de la propiedad agentType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentType() {
        return agentType;
    }

    /**
     * Define el valor de la propiedad agentType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentType(String value) {
        this.agentType = value;
    }

    /**
     * Obtiene el valor de la propiedad agentPhoneNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentPhoneNo() {
        return agentPhoneNo;
    }

    /**
     * Define el valor de la propiedad agentPhoneNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentPhoneNo(String value) {
        this.agentPhoneNo = value;
    }

    /**
     * Obtiene el valor de la propiedad messageCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageCode() {
        return messageCode;
    }

    /**
     * Define el valor de la propiedad messageCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageCode(String value) {
        this.messageCode = value;
    }

    /**
     * Obtiene el valor de la propiedad externalApplicationID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalApplicationID() {
        return externalApplicationID;
    }

    /**
     * Define el valor de la propiedad externalApplicationID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalApplicationID(String value) {
        this.externalApplicationID = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationCreatedDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getApplicationCreatedDate() {
        return applicationCreatedDate;
    }

    /**
     * Define el valor de la propiedad applicationCreatedDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setApplicationCreatedDate(XMLGregorianCalendar value) {
        this.applicationCreatedDate = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationCreatedTime.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getApplicationCreatedTime() {
        return applicationCreatedTime;
    }

    /**
     * Define el valor de la propiedad applicationCreatedTime.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setApplicationCreatedTime(XMLGregorianCalendar value) {
        this.applicationCreatedTime = value;
    }

}
