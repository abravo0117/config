
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para PreCreatedCardAcceptUpdRq complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PreCreatedCardAcceptUpdRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Initiator" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BranchID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicantID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PreCreatedCardNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OrgCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PlasticID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ProductLogo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SourceCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CounterOfferProductType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PreCreatedCardAcceptUpdRq", propOrder = {
    "initiator",
    "branchID",
    "applicantID",
    "preCreatedCardNo",
    "orgCode",
    "plasticID",
    "productLogo",
    "sourceCode",
    "counterOfferProductType"
})
public class PreCreatedCardAcceptUpdRq {

    @XmlElement(name = "Initiator", required = true)
    protected String initiator;
    @XmlElement(name = "BranchID")
    protected String branchID;
    @XmlElement(name = "ApplicantID", required = true)
    protected String applicantID;
    @XmlElement(name = "PreCreatedCardNo", required = true)
    protected String preCreatedCardNo;
    @XmlElement(name = "OrgCode", required = true)
    protected String orgCode;
    @XmlElement(name = "PlasticID", required = true)
    protected String plasticID;
    @XmlElement(name = "ProductLogo", required = true)
    protected String productLogo;
    @XmlElement(name = "SourceCode", required = true)
    protected String sourceCode;
    @XmlElement(name = "CounterOfferProductType")
    protected String counterOfferProductType;

    /**
     * Obtiene el valor de la propiedad initiator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitiator() {
        return initiator;
    }

    /**
     * Define el valor de la propiedad initiator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitiator(String value) {
        this.initiator = value;
    }

    /**
     * Obtiene el valor de la propiedad branchID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchID() {
        return branchID;
    }

    /**
     * Define el valor de la propiedad branchID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchID(String value) {
        this.branchID = value;
    }

    /**
     * Obtiene el valor de la propiedad applicantID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicantID() {
        return applicantID;
    }

    /**
     * Define el valor de la propiedad applicantID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicantID(String value) {
        this.applicantID = value;
    }

    /**
     * Obtiene el valor de la propiedad preCreatedCardNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreCreatedCardNo() {
        return preCreatedCardNo;
    }

    /**
     * Define el valor de la propiedad preCreatedCardNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreCreatedCardNo(String value) {
        this.preCreatedCardNo = value;
    }

    /**
     * Obtiene el valor de la propiedad orgCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrgCode() {
        return orgCode;
    }

    /**
     * Define el valor de la propiedad orgCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrgCode(String value) {
        this.orgCode = value;
    }

    /**
     * Obtiene el valor de la propiedad plasticID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlasticID() {
        return plasticID;
    }

    /**
     * Define el valor de la propiedad plasticID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlasticID(String value) {
        this.plasticID = value;
    }

    /**
     * Obtiene el valor de la propiedad productLogo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductLogo() {
        return productLogo;
    }

    /**
     * Define el valor de la propiedad productLogo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductLogo(String value) {
        this.productLogo = value;
    }

    /**
     * Obtiene el valor de la propiedad sourceCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceCode() {
        return sourceCode;
    }

    /**
     * Define el valor de la propiedad sourceCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceCode(String value) {
        this.sourceCode = value;
    }

    /**
     * Obtiene el valor de la propiedad counterOfferProductType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCounterOfferProductType() {
        return counterOfferProductType;
    }

    /**
     * Define el valor de la propiedad counterOfferProductType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCounterOfferProductType(String value) {
        this.counterOfferProductType = value;
    }

}
