
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para StatementComDtl complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="StatementComDtl">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PrimaryCustNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StatementLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Frequency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CycleCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NoOfDays" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IncludeRcInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IncludeCCInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExistNewInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DataStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UpdatedToHost" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatementComDtl", propOrder = {
    "primaryCustNo",
    "statementLevel",
    "frequency",
    "cycleCode",
    "noOfDays",
    "includeRcInfo",
    "includeCCInfo",
    "existNewInd",
    "dataStatus",
    "updatedToHost"
})
public class StatementComDtl {

    @XmlElement(name = "PrimaryCustNo")
    protected String primaryCustNo;
    @XmlElement(name = "StatementLevel")
    protected String statementLevel;
    @XmlElement(name = "Frequency")
    protected String frequency;
    @XmlElement(name = "CycleCode")
    protected String cycleCode;
    @XmlElement(name = "NoOfDays")
    protected String noOfDays;
    @XmlElement(name = "IncludeRcInfo")
    protected String includeRcInfo;
    @XmlElement(name = "IncludeCCInfo")
    protected String includeCCInfo;
    @XmlElement(name = "ExistNewInd")
    protected String existNewInd;
    @XmlElement(name = "DataStatus")
    protected String dataStatus;
    @XmlElement(name = "UpdatedToHost")
    protected String updatedToHost;

    /**
     * Obtiene el valor de la propiedad primaryCustNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryCustNo() {
        return primaryCustNo;
    }

    /**
     * Define el valor de la propiedad primaryCustNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryCustNo(String value) {
        this.primaryCustNo = value;
    }

    /**
     * Obtiene el valor de la propiedad statementLevel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatementLevel() {
        return statementLevel;
    }

    /**
     * Define el valor de la propiedad statementLevel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatementLevel(String value) {
        this.statementLevel = value;
    }

    /**
     * Obtiene el valor de la propiedad frequency.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrequency() {
        return frequency;
    }

    /**
     * Define el valor de la propiedad frequency.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrequency(String value) {
        this.frequency = value;
    }

    /**
     * Obtiene el valor de la propiedad cycleCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCycleCode() {
        return cycleCode;
    }

    /**
     * Define el valor de la propiedad cycleCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCycleCode(String value) {
        this.cycleCode = value;
    }

    /**
     * Obtiene el valor de la propiedad noOfDays.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoOfDays() {
        return noOfDays;
    }

    /**
     * Define el valor de la propiedad noOfDays.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoOfDays(String value) {
        this.noOfDays = value;
    }

    /**
     * Obtiene el valor de la propiedad includeRcInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncludeRcInfo() {
        return includeRcInfo;
    }

    /**
     * Define el valor de la propiedad includeRcInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncludeRcInfo(String value) {
        this.includeRcInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad includeCCInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncludeCCInfo() {
        return includeCCInfo;
    }

    /**
     * Define el valor de la propiedad includeCCInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncludeCCInfo(String value) {
        this.includeCCInfo = value;
    }

    /**
     * Obtiene el valor de la propiedad existNewInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExistNewInd() {
        return existNewInd;
    }

    /**
     * Define el valor de la propiedad existNewInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExistNewInd(String value) {
        this.existNewInd = value;
    }

    /**
     * Obtiene el valor de la propiedad dataStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataStatus() {
        return dataStatus;
    }

    /**
     * Define el valor de la propiedad dataStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataStatus(String value) {
        this.dataStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad updatedToHost.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUpdatedToHost() {
        return updatedToHost;
    }

    /**
     * Define el valor de la propiedad updatedToHost.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedToHost(String value) {
        this.updatedToHost = value;
    }

}
