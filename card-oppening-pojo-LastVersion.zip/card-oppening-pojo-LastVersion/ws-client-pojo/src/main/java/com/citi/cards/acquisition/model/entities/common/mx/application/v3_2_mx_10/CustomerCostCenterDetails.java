
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerCostCenterDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerCostCenterDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RCNnmb" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Branch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Dept" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CostCenterDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CostCenter" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AOName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AONumb" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RCAO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CostRelPRCGGrp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AOTelNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AOEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerCostCenterDetails", propOrder = {
    "rcNnmb",
    "branch",
    "dept",
    "costCenterDesc",
    "costCenter",
    "aoName",
    "aoNumb",
    "rcao",
    "costRelPRCGGrp",
    "aoTelNo",
    "aoEmail"
})
public class CustomerCostCenterDetails {

    @XmlElement(name = "RCNnmb")
    protected String rcNnmb;
    @XmlElement(name = "Branch")
    protected String branch;
    @XmlElement(name = "Dept")
    protected String dept;
    @XmlElement(name = "CostCenterDesc")
    protected String costCenterDesc;
    @XmlElement(name = "CostCenter")
    protected String costCenter;
    @XmlElement(name = "AOName")
    protected String aoName;
    @XmlElement(name = "AONumb")
    protected String aoNumb;
    @XmlElement(name = "RCAO")
    protected String rcao;
    @XmlElement(name = "CostRelPRCGGrp")
    protected String costRelPRCGGrp;
    @XmlElement(name = "AOTelNo")
    protected String aoTelNo;
    @XmlElement(name = "AOEmail")
    protected String aoEmail;

    /**
     * Obtiene el valor de la propiedad rcNnmb.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRCNnmb() {
        return rcNnmb;
    }

    /**
     * Define el valor de la propiedad rcNnmb.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRCNnmb(String value) {
        this.rcNnmb = value;
    }

    /**
     * Obtiene el valor de la propiedad branch.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranch() {
        return branch;
    }

    /**
     * Define el valor de la propiedad branch.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranch(String value) {
        this.branch = value;
    }

    /**
     * Obtiene el valor de la propiedad dept.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDept() {
        return dept;
    }

    /**
     * Define el valor de la propiedad dept.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDept(String value) {
        this.dept = value;
    }

    /**
     * Obtiene el valor de la propiedad costCenterDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCostCenterDesc() {
        return costCenterDesc;
    }

    /**
     * Define el valor de la propiedad costCenterDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCostCenterDesc(String value) {
        this.costCenterDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad costCenter.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCostCenter() {
        return costCenter;
    }

    /**
     * Define el valor de la propiedad costCenter.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCostCenter(String value) {
        this.costCenter = value;
    }

    /**
     * Obtiene el valor de la propiedad aoName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAOName() {
        return aoName;
    }

    /**
     * Define el valor de la propiedad aoName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAOName(String value) {
        this.aoName = value;
    }

    /**
     * Obtiene el valor de la propiedad aoNumb.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAONumb() {
        return aoNumb;
    }

    /**
     * Define el valor de la propiedad aoNumb.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAONumb(String value) {
        this.aoNumb = value;
    }

    /**
     * Obtiene el valor de la propiedad rcao.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRCAO() {
        return rcao;
    }

    /**
     * Define el valor de la propiedad rcao.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRCAO(String value) {
        this.rcao = value;
    }

    /**
     * Obtiene el valor de la propiedad costRelPRCGGrp.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCostRelPRCGGrp() {
        return costRelPRCGGrp;
    }

    /**
     * Define el valor de la propiedad costRelPRCGGrp.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCostRelPRCGGrp(String value) {
        this.costRelPRCGGrp = value;
    }

    /**
     * Obtiene el valor de la propiedad aoTelNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAOTelNo() {
        return aoTelNo;
    }

    /**
     * Define el valor de la propiedad aoTelNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAOTelNo(String value) {
        this.aoTelNo = value;
    }

    /**
     * Obtiene el valor de la propiedad aoEmail.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAOEmail() {
        return aoEmail;
    }

    /**
     * Define el valor de la propiedad aoEmail.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAOEmail(String value) {
        this.aoEmail = value;
    }

}
