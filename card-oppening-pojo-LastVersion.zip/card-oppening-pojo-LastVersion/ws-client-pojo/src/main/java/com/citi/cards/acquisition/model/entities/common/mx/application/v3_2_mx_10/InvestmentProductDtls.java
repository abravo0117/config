
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para InvestmentProductDtls complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="InvestmentProductDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Offer" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Offer" minOccurs="0"/>
 *         &lt;element name="InvestmentAndInsuranceProductDtls" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}InvestmentAndInsuranceProductDtls" minOccurs="0"/>
 *         &lt;element name="AcquisitionAndReferral" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}AcquisitionAndReferral" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InvestmentProductDtls", propOrder = {
    "offer",
    "investmentAndInsuranceProductDtls",
    "acquisitionAndReferral"
})
public class InvestmentProductDtls {

    @XmlElement(name = "Offer")
    protected Offer offer;
    @XmlElement(name = "InvestmentAndInsuranceProductDtls")
    protected InvestmentAndInsuranceProductDtls investmentAndInsuranceProductDtls;
    @XmlElement(name = "AcquisitionAndReferral")
    protected AcquisitionAndReferral acquisitionAndReferral;

    /**
     * Obtiene el valor de la propiedad offer.
     * 
     * @return
     *     possible object is
     *     {@link Offer }
     *     
     */
    public Offer getOffer() {
        return offer;
    }

    /**
     * Define el valor de la propiedad offer.
     * 
     * @param value
     *     allowed object is
     *     {@link Offer }
     *     
     */
    public void setOffer(Offer value) {
        this.offer = value;
    }

    /**
     * Obtiene el valor de la propiedad investmentAndInsuranceProductDtls.
     * 
     * @return
     *     possible object is
     *     {@link InvestmentAndInsuranceProductDtls }
     *     
     */
    public InvestmentAndInsuranceProductDtls getInvestmentAndInsuranceProductDtls() {
        return investmentAndInsuranceProductDtls;
    }

    /**
     * Define el valor de la propiedad investmentAndInsuranceProductDtls.
     * 
     * @param value
     *     allowed object is
     *     {@link InvestmentAndInsuranceProductDtls }
     *     
     */
    public void setInvestmentAndInsuranceProductDtls(InvestmentAndInsuranceProductDtls value) {
        this.investmentAndInsuranceProductDtls = value;
    }

    /**
     * Obtiene el valor de la propiedad acquisitionAndReferral.
     * 
     * @return
     *     possible object is
     *     {@link AcquisitionAndReferral }
     *     
     */
    public AcquisitionAndReferral getAcquisitionAndReferral() {
        return acquisitionAndReferral;
    }

    /**
     * Define el valor de la propiedad acquisitionAndReferral.
     * 
     * @param value
     *     allowed object is
     *     {@link AcquisitionAndReferral }
     *     
     */
    public void setAcquisitionAndReferral(AcquisitionAndReferral value) {
        this.acquisitionAndReferral = value;
    }

}
