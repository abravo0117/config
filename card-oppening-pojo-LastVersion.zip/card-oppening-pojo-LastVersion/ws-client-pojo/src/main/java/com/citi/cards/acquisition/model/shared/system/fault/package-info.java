@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.citi.com/gcgi/shared/system/fault", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.citi.cards.acquisition.model.shared.system.fault;
