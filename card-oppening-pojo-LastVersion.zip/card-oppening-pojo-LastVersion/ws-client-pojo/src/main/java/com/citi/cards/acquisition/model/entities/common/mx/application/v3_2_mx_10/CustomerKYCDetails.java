
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerKYCDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerKYCDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AcctOpenMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TxnAmtPerMth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USTaxStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="USTaxID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustOpenObj" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfFunds" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SrcOfWealth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOF" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OkToCall" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OkToMail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HighCashIntensive" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InitNonCshAmtRng" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InitCshAmtRng" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SpecialKYCCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TxnCntPerMth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AmlRiskLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="W8BenDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="W9SignDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExpAnnlFund" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CountryOfReg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SIC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApproxAnnAmtFund" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AnnFundRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OccupationCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TxnProfPurpose" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMaintDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMaintID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TransactionProfilingList" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}TransactionProfilingList" minOccurs="0"/>
 *         &lt;element name="OkToEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OkToSMS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DisallowedToShare" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AMLCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AMLDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerKYCDetails", propOrder = {
    "acctOpenMode",
    "txnAmtPerMth",
    "usTaxStatus",
    "usTaxID",
    "custOpenObj",
    "typeOfFunds",
    "srcOfWealth",
    "sof",
    "okToCall",
    "okToMail",
    "highCashIntensive",
    "initNonCshAmtRng",
    "initCshAmtRng",
    "specialKYCCD",
    "txnCntPerMth",
    "amlRiskLevel",
    "w8BenDate",
    "w9SignDate",
    "expAnnlFund",
    "countryOfReg",
    "sic",
    "approxAnnAmtFund",
    "annFundRange",
    "occupationCD",
    "txnProfPurpose",
    "lastMaintDt",
    "lastMaintID",
    "transactionProfilingList",
    "okToEmail",
    "okToSMS",
    "disallowedToShare",
    "amlCode",
    "amlDate"
})
public class CustomerKYCDetails {

    @XmlElement(name = "AcctOpenMode")
    protected String acctOpenMode;
    @XmlElement(name = "TxnAmtPerMth")
    protected String txnAmtPerMth;
    @XmlElement(name = "USTaxStatus")
    protected String usTaxStatus;
    @XmlElement(name = "USTaxID")
    protected String usTaxID;
    @XmlElement(name = "CustOpenObj")
    protected String custOpenObj;
    @XmlElement(name = "TypeOfFunds")
    protected String typeOfFunds;
    @XmlElement(name = "SrcOfWealth")
    protected String srcOfWealth;
    @XmlElement(name = "SOF")
    protected String sof;
    @XmlElement(name = "OkToCall")
    protected String okToCall;
    @XmlElement(name = "OkToMail")
    protected String okToMail;
    @XmlElement(name = "HighCashIntensive")
    protected String highCashIntensive;
    @XmlElement(name = "InitNonCshAmtRng")
    protected String initNonCshAmtRng;
    @XmlElement(name = "InitCshAmtRng")
    protected String initCshAmtRng;
    @XmlElement(name = "SpecialKYCCD")
    protected String specialKYCCD;
    @XmlElement(name = "TxnCntPerMth")
    protected String txnCntPerMth;
    @XmlElement(name = "AmlRiskLevel")
    protected String amlRiskLevel;
    @XmlElement(name = "W8BenDate")
    protected String w8BenDate;
    @XmlElement(name = "W9SignDate")
    protected String w9SignDate;
    @XmlElement(name = "ExpAnnlFund")
    protected String expAnnlFund;
    @XmlElement(name = "CountryOfReg")
    protected String countryOfReg;
    @XmlElement(name = "SIC")
    protected String sic;
    @XmlElement(name = "ApproxAnnAmtFund")
    protected String approxAnnAmtFund;
    @XmlElement(name = "AnnFundRange")
    protected String annFundRange;
    @XmlElement(name = "OccupationCD")
    protected String occupationCD;
    @XmlElement(name = "TxnProfPurpose")
    protected String txnProfPurpose;
    @XmlElement(name = "LastMaintDt")
    protected String lastMaintDt;
    @XmlElement(name = "LastMaintID")
    protected String lastMaintID;
    @XmlElement(name = "TransactionProfilingList")
    protected TransactionProfilingList transactionProfilingList;
    @XmlElement(name = "OkToEmail")
    protected String okToEmail;
    @XmlElement(name = "OkToSMS")
    protected String okToSMS;
    @XmlElement(name = "DisallowedToShare")
    protected String disallowedToShare;
    @XmlElement(name = "AMLCode")
    protected String amlCode;
    @XmlElement(name = "AMLDate")
    protected String amlDate;

    /**
     * Obtiene el valor de la propiedad acctOpenMode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctOpenMode() {
        return acctOpenMode;
    }

    /**
     * Define el valor de la propiedad acctOpenMode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctOpenMode(String value) {
        this.acctOpenMode = value;
    }

    /**
     * Obtiene el valor de la propiedad txnAmtPerMth.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTxnAmtPerMth() {
        return txnAmtPerMth;
    }

    /**
     * Define el valor de la propiedad txnAmtPerMth.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTxnAmtPerMth(String value) {
        this.txnAmtPerMth = value;
    }

    /**
     * Obtiene el valor de la propiedad usTaxStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSTaxStatus() {
        return usTaxStatus;
    }

    /**
     * Define el valor de la propiedad usTaxStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSTaxStatus(String value) {
        this.usTaxStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad usTaxID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSTaxID() {
        return usTaxID;
    }

    /**
     * Define el valor de la propiedad usTaxID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSTaxID(String value) {
        this.usTaxID = value;
    }

    /**
     * Obtiene el valor de la propiedad custOpenObj.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustOpenObj() {
        return custOpenObj;
    }

    /**
     * Define el valor de la propiedad custOpenObj.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustOpenObj(String value) {
        this.custOpenObj = value;
    }

    /**
     * Obtiene el valor de la propiedad typeOfFunds.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfFunds() {
        return typeOfFunds;
    }

    /**
     * Define el valor de la propiedad typeOfFunds.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfFunds(String value) {
        this.typeOfFunds = value;
    }

    /**
     * Obtiene el valor de la propiedad srcOfWealth.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSrcOfWealth() {
        return srcOfWealth;
    }

    /**
     * Define el valor de la propiedad srcOfWealth.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSrcOfWealth(String value) {
        this.srcOfWealth = value;
    }

    /**
     * Obtiene el valor de la propiedad sof.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOF() {
        return sof;
    }

    /**
     * Define el valor de la propiedad sof.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOF(String value) {
        this.sof = value;
    }

    /**
     * Obtiene el valor de la propiedad okToCall.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOkToCall() {
        return okToCall;
    }

    /**
     * Define el valor de la propiedad okToCall.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOkToCall(String value) {
        this.okToCall = value;
    }

    /**
     * Obtiene el valor de la propiedad okToMail.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOkToMail() {
        return okToMail;
    }

    /**
     * Define el valor de la propiedad okToMail.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOkToMail(String value) {
        this.okToMail = value;
    }

    /**
     * Obtiene el valor de la propiedad highCashIntensive.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHighCashIntensive() {
        return highCashIntensive;
    }

    /**
     * Define el valor de la propiedad highCashIntensive.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHighCashIntensive(String value) {
        this.highCashIntensive = value;
    }

    /**
     * Obtiene el valor de la propiedad initNonCshAmtRng.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitNonCshAmtRng() {
        return initNonCshAmtRng;
    }

    /**
     * Define el valor de la propiedad initNonCshAmtRng.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitNonCshAmtRng(String value) {
        this.initNonCshAmtRng = value;
    }

    /**
     * Obtiene el valor de la propiedad initCshAmtRng.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitCshAmtRng() {
        return initCshAmtRng;
    }

    /**
     * Define el valor de la propiedad initCshAmtRng.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitCshAmtRng(String value) {
        this.initCshAmtRng = value;
    }

    /**
     * Obtiene el valor de la propiedad specialKYCCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecialKYCCD() {
        return specialKYCCD;
    }

    /**
     * Define el valor de la propiedad specialKYCCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecialKYCCD(String value) {
        this.specialKYCCD = value;
    }

    /**
     * Obtiene el valor de la propiedad txnCntPerMth.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTxnCntPerMth() {
        return txnCntPerMth;
    }

    /**
     * Define el valor de la propiedad txnCntPerMth.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTxnCntPerMth(String value) {
        this.txnCntPerMth = value;
    }

    /**
     * Obtiene el valor de la propiedad amlRiskLevel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmlRiskLevel() {
        return amlRiskLevel;
    }

    /**
     * Define el valor de la propiedad amlRiskLevel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmlRiskLevel(String value) {
        this.amlRiskLevel = value;
    }

    /**
     * Obtiene el valor de la propiedad w8BenDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getW8BenDate() {
        return w8BenDate;
    }

    /**
     * Define el valor de la propiedad w8BenDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setW8BenDate(String value) {
        this.w8BenDate = value;
    }

    /**
     * Obtiene el valor de la propiedad w9SignDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getW9SignDate() {
        return w9SignDate;
    }

    /**
     * Define el valor de la propiedad w9SignDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setW9SignDate(String value) {
        this.w9SignDate = value;
    }

    /**
     * Obtiene el valor de la propiedad expAnnlFund.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExpAnnlFund() {
        return expAnnlFund;
    }

    /**
     * Define el valor de la propiedad expAnnlFund.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpAnnlFund(String value) {
        this.expAnnlFund = value;
    }

    /**
     * Obtiene el valor de la propiedad countryOfReg.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryOfReg() {
        return countryOfReg;
    }

    /**
     * Define el valor de la propiedad countryOfReg.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryOfReg(String value) {
        this.countryOfReg = value;
    }

    /**
     * Obtiene el valor de la propiedad sic.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSIC() {
        return sic;
    }

    /**
     * Define el valor de la propiedad sic.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSIC(String value) {
        this.sic = value;
    }

    /**
     * Obtiene el valor de la propiedad approxAnnAmtFund.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApproxAnnAmtFund() {
        return approxAnnAmtFund;
    }

    /**
     * Define el valor de la propiedad approxAnnAmtFund.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApproxAnnAmtFund(String value) {
        this.approxAnnAmtFund = value;
    }

    /**
     * Obtiene el valor de la propiedad annFundRange.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnnFundRange() {
        return annFundRange;
    }

    /**
     * Define el valor de la propiedad annFundRange.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnnFundRange(String value) {
        this.annFundRange = value;
    }

    /**
     * Obtiene el valor de la propiedad occupationCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOccupationCD() {
        return occupationCD;
    }

    /**
     * Define el valor de la propiedad occupationCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOccupationCD(String value) {
        this.occupationCD = value;
    }

    /**
     * Obtiene el valor de la propiedad txnProfPurpose.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTxnProfPurpose() {
        return txnProfPurpose;
    }

    /**
     * Define el valor de la propiedad txnProfPurpose.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTxnProfPurpose(String value) {
        this.txnProfPurpose = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMaintDt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastMaintDt() {
        return lastMaintDt;
    }

    /**
     * Define el valor de la propiedad lastMaintDt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastMaintDt(String value) {
        this.lastMaintDt = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMaintID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastMaintID() {
        return lastMaintID;
    }

    /**
     * Define el valor de la propiedad lastMaintID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastMaintID(String value) {
        this.lastMaintID = value;
    }

    /**
     * Obtiene el valor de la propiedad transactionProfilingList.
     * 
     * @return
     *     possible object is
     *     {@link TransactionProfilingList }
     *     
     */
    public TransactionProfilingList getTransactionProfilingList() {
        return transactionProfilingList;
    }

    /**
     * Define el valor de la propiedad transactionProfilingList.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionProfilingList }
     *     
     */
    public void setTransactionProfilingList(TransactionProfilingList value) {
        this.transactionProfilingList = value;
    }

    /**
     * Obtiene el valor de la propiedad okToEmail.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOkToEmail() {
        return okToEmail;
    }

    /**
     * Define el valor de la propiedad okToEmail.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOkToEmail(String value) {
        this.okToEmail = value;
    }

    /**
     * Obtiene el valor de la propiedad okToSMS.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOkToSMS() {
        return okToSMS;
    }

    /**
     * Define el valor de la propiedad okToSMS.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOkToSMS(String value) {
        this.okToSMS = value;
    }

    /**
     * Obtiene el valor de la propiedad disallowedToShare.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDisallowedToShare() {
        return disallowedToShare;
    }

    /**
     * Define el valor de la propiedad disallowedToShare.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDisallowedToShare(String value) {
        this.disallowedToShare = value;
    }

    /**
     * Obtiene el valor de la propiedad amlCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAMLCode() {
        return amlCode;
    }

    /**
     * Define el valor de la propiedad amlCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAMLCode(String value) {
        this.amlCode = value;
    }

    /**
     * Obtiene el valor de la propiedad amlDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAMLDate() {
        return amlDate;
    }

    /**
     * Define el valor de la propiedad amlDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAMLDate(String value) {
        this.amlDate = value;
    }

}
