
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para Offer complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Offer">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OfferID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ctrl1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ctrl2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ctrl3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ctrl4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FKApplicationId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProductCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PPProductCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfferStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelnType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelnNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelnCtrl1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelnCtrl2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelnCtrl3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelnCtrl4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceChannel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BundleID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OrderSeq" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMainID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMaintTimeStamp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustomerNos" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerNos" minOccurs="0"/>
 *         &lt;element name="ProdFamily" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DataStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AcctCtl1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AcctCtl2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AcctCtl3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AcctCtl4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NtProdCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelnCatg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CampaignID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WaveID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProdCodeDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProdFamilyDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountTitle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountTitle1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FromAGInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CostRelPrcgGrp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SignInst" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SignInstRemark" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SignInstrReq" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MakerUserID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CheckerUserID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PrdSeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelnSeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CCY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfferPriority" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="OfferAvailability" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfferCreationMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CampaignCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfferStartDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="OfferEndDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="LatestOfferStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CampaignDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesScriptText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="WaveDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GetOfferResponseCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="GetOfferResponseText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField5" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField6" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField7" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField8" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField9" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField10" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField11" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField12" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField13" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField14" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField15" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField16" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField17" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField18" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField19" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField20" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField21" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField22" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField23" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField24" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField25" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField26" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField27" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField28" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField29" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserField30" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Offer", propOrder = {
    "offerID",
    "ctrl1",
    "ctrl2",
    "ctrl3",
    "ctrl4",
    "fkApplicationId",
    "productCode",
    "ppProductCode",
    "offerStatus",
    "relnType",
    "relnNo",
    "relnCtrl1",
    "relnCtrl2",
    "relnCtrl3",
    "relnCtrl4",
    "accountNo",
    "sourceChannel",
    "bundleID",
    "orderSeq",
    "lastMainID",
    "lastMaintTimeStamp",
    "customerNos",
    "prodFamily",
    "dataStatus",
    "acctCtl1",
    "acctCtl2",
    "acctCtl3",
    "acctCtl4",
    "ntProdCode",
    "relnCatg",
    "campaignID",
    "waveID",
    "prodCodeDesc",
    "prodFamilyDesc",
    "accountTitle",
    "accountTitle1",
    "fromAGInd",
    "costRelPrcgGrp",
    "signInst",
    "signInstRemark",
    "signInstrReq",
    "makerUserID",
    "checkerUserID",
    "prdSeqNo",
    "relnSeqNo",
    "ccy",
    "offerPriority",
    "offerAvailability",
    "offerCreationMode",
    "campaignCategory",
    "offerStartDate",
    "offerEndDate",
    "latestOfferStatus",
    "campaignDescription",
    "salesScriptText",
    "waveDescription",
    "getOfferResponseCode",
    "getOfferResponseText",
    "userField1",
    "userField2",
    "userField3",
    "userField4",
    "userField5",
    "userField6",
    "userField7",
    "userField8",
    "userField9",
    "userField10",
    "userField11",
    "userField12",
    "userField13",
    "userField14",
    "userField15",
    "userField16",
    "userField17",
    "userField18",
    "userField19",
    "userField20",
    "userField21",
    "userField22",
    "userField23",
    "userField24",
    "userField25",
    "userField26",
    "userField27",
    "userField28",
    "userField29",
    "userField30"
})
public class Offer {

    @XmlElement(name = "OfferID")
    protected String offerID;
    @XmlElement(name = "Ctrl1")
    protected String ctrl1;
    @XmlElement(name = "Ctrl2")
    protected String ctrl2;
    @XmlElement(name = "Ctrl3")
    protected String ctrl3;
    @XmlElement(name = "Ctrl4")
    protected String ctrl4;
    @XmlElement(name = "FKApplicationId")
    protected String fkApplicationId;
    @XmlElement(name = "ProductCode")
    protected String productCode;
    @XmlElement(name = "PPProductCode")
    protected String ppProductCode;
    @XmlElement(name = "OfferStatus")
    protected String offerStatus;
    @XmlElement(name = "RelnType")
    protected String relnType;
    @XmlElement(name = "RelnNo")
    protected String relnNo;
    @XmlElement(name = "RelnCtrl1")
    protected String relnCtrl1;
    @XmlElement(name = "RelnCtrl2")
    protected String relnCtrl2;
    @XmlElement(name = "RelnCtrl3")
    protected String relnCtrl3;
    @XmlElement(name = "RelnCtrl4")
    protected String relnCtrl4;
    @XmlElement(name = "AccountNo")
    protected String accountNo;
    @XmlElement(name = "SourceChannel")
    protected String sourceChannel;
    @XmlElement(name = "BundleID")
    protected String bundleID;
    @XmlElement(name = "OrderSeq")
    protected String orderSeq;
    @XmlElement(name = "LastMainID")
    protected String lastMainID;
    @XmlElement(name = "LastMaintTimeStamp")
    protected String lastMaintTimeStamp;
    @XmlElement(name = "CustomerNos")
    protected CustomerNos customerNos;
    @XmlElement(name = "ProdFamily")
    protected String prodFamily;
    @XmlElement(name = "DataStatus")
    protected String dataStatus;
    @XmlElement(name = "AcctCtl1")
    protected String acctCtl1;
    @XmlElement(name = "AcctCtl2")
    protected String acctCtl2;
    @XmlElement(name = "AcctCtl3")
    protected String acctCtl3;
    @XmlElement(name = "AcctCtl4")
    protected String acctCtl4;
    @XmlElement(name = "NtProdCode")
    protected String ntProdCode;
    @XmlElement(name = "RelnCatg")
    protected String relnCatg;
    @XmlElement(name = "CampaignID")
    protected String campaignID;
    @XmlElement(name = "WaveID")
    protected String waveID;
    @XmlElement(name = "ProdCodeDesc")
    protected String prodCodeDesc;
    @XmlElement(name = "ProdFamilyDesc")
    protected String prodFamilyDesc;
    @XmlElement(name = "AccountTitle")
    protected String accountTitle;
    @XmlElement(name = "AccountTitle1")
    protected String accountTitle1;
    @XmlElement(name = "FromAGInd")
    protected String fromAGInd;
    @XmlElement(name = "CostRelPrcgGrp")
    protected String costRelPrcgGrp;
    @XmlElement(name = "SignInst")
    protected String signInst;
    @XmlElement(name = "SignInstRemark")
    protected String signInstRemark;
    @XmlElement(name = "SignInstrReq")
    protected String signInstrReq;
    @XmlElement(name = "MakerUserID")
    protected String makerUserID;
    @XmlElement(name = "CheckerUserID")
    protected String checkerUserID;
    @XmlElement(name = "PrdSeqNo")
    protected String prdSeqNo;
    @XmlElement(name = "RelnSeqNo")
    protected String relnSeqNo;
    @XmlElement(name = "CCY")
    protected String ccy;
    @XmlElement(name = "OfferPriority")
    protected BigInteger offerPriority;
    @XmlElement(name = "OfferAvailability")
    protected String offerAvailability;
    @XmlElement(name = "OfferCreationMode")
    protected String offerCreationMode;
    @XmlElement(name = "CampaignCategory")
    protected String campaignCategory;
    @XmlElement(name = "OfferStartDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar offerStartDate;
    @XmlElement(name = "OfferEndDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar offerEndDate;
    @XmlElement(name = "LatestOfferStatus")
    protected String latestOfferStatus;
    @XmlElement(name = "CampaignDescription")
    protected String campaignDescription;
    @XmlElement(name = "SalesScriptText")
    protected String salesScriptText;
    @XmlElement(name = "WaveDescription")
    protected String waveDescription;
    @XmlElement(name = "GetOfferResponseCode")
    protected String getOfferResponseCode;
    @XmlElement(name = "GetOfferResponseText")
    protected String getOfferResponseText;
    @XmlElement(name = "UserField1")
    protected String userField1;
    @XmlElement(name = "UserField2")
    protected String userField2;
    @XmlElement(name = "UserField3")
    protected String userField3;
    @XmlElement(name = "UserField4")
    protected String userField4;
    @XmlElement(name = "UserField5")
    protected String userField5;
    @XmlElement(name = "UserField6")
    protected String userField6;
    @XmlElement(name = "UserField7")
    protected String userField7;
    @XmlElement(name = "UserField8")
    protected String userField8;
    @XmlElement(name = "UserField9")
    protected String userField9;
    @XmlElement(name = "UserField10")
    protected String userField10;
    @XmlElement(name = "UserField11")
    protected String userField11;
    @XmlElement(name = "UserField12")
    protected String userField12;
    @XmlElement(name = "UserField13")
    protected String userField13;
    @XmlElement(name = "UserField14")
    protected String userField14;
    @XmlElement(name = "UserField15")
    protected String userField15;
    @XmlElement(name = "UserField16")
    protected String userField16;
    @XmlElement(name = "UserField17")
    protected String userField17;
    @XmlElement(name = "UserField18")
    protected String userField18;
    @XmlElement(name = "UserField19")
    protected String userField19;
    @XmlElement(name = "UserField20")
    protected String userField20;
    @XmlElement(name = "UserField21")
    protected String userField21;
    @XmlElement(name = "UserField22")
    protected String userField22;
    @XmlElement(name = "UserField23")
    protected String userField23;
    @XmlElement(name = "UserField24")
    protected String userField24;
    @XmlElement(name = "UserField25")
    protected String userField25;
    @XmlElement(name = "UserField26")
    protected String userField26;
    @XmlElement(name = "UserField27")
    protected String userField27;
    @XmlElement(name = "UserField28")
    protected String userField28;
    @XmlElement(name = "UserField29")
    protected String userField29;
    @XmlElement(name = "UserField30")
    protected String userField30;

    /**
     * Obtiene el valor de la propiedad offerID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferID() {
        return offerID;
    }

    /**
     * Define el valor de la propiedad offerID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferID(String value) {
        this.offerID = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrl1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrl1() {
        return ctrl1;
    }

    /**
     * Define el valor de la propiedad ctrl1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrl1(String value) {
        this.ctrl1 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrl2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrl2() {
        return ctrl2;
    }

    /**
     * Define el valor de la propiedad ctrl2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrl2(String value) {
        this.ctrl2 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrl3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrl3() {
        return ctrl3;
    }

    /**
     * Define el valor de la propiedad ctrl3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrl3(String value) {
        this.ctrl3 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrl4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrl4() {
        return ctrl4;
    }

    /**
     * Define el valor de la propiedad ctrl4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrl4(String value) {
        this.ctrl4 = value;
    }

    /**
     * Obtiene el valor de la propiedad fkApplicationId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFKApplicationId() {
        return fkApplicationId;
    }

    /**
     * Define el valor de la propiedad fkApplicationId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFKApplicationId(String value) {
        this.fkApplicationId = value;
    }

    /**
     * Obtiene el valor de la propiedad productCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCode() {
        return productCode;
    }

    /**
     * Define el valor de la propiedad productCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCode(String value) {
        this.productCode = value;
    }

    /**
     * Obtiene el valor de la propiedad ppProductCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPPProductCode() {
        return ppProductCode;
    }

    /**
     * Define el valor de la propiedad ppProductCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPPProductCode(String value) {
        this.ppProductCode = value;
    }

    /**
     * Obtiene el valor de la propiedad offerStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferStatus() {
        return offerStatus;
    }

    /**
     * Define el valor de la propiedad offerStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferStatus(String value) {
        this.offerStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad relnType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnType() {
        return relnType;
    }

    /**
     * Define el valor de la propiedad relnType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnType(String value) {
        this.relnType = value;
    }

    /**
     * Obtiene el valor de la propiedad relnNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnNo() {
        return relnNo;
    }

    /**
     * Define el valor de la propiedad relnNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnNo(String value) {
        this.relnNo = value;
    }

    /**
     * Obtiene el valor de la propiedad relnCtrl1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnCtrl1() {
        return relnCtrl1;
    }

    /**
     * Define el valor de la propiedad relnCtrl1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnCtrl1(String value) {
        this.relnCtrl1 = value;
    }

    /**
     * Obtiene el valor de la propiedad relnCtrl2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnCtrl2() {
        return relnCtrl2;
    }

    /**
     * Define el valor de la propiedad relnCtrl2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnCtrl2(String value) {
        this.relnCtrl2 = value;
    }

    /**
     * Obtiene el valor de la propiedad relnCtrl3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnCtrl3() {
        return relnCtrl3;
    }

    /**
     * Define el valor de la propiedad relnCtrl3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnCtrl3(String value) {
        this.relnCtrl3 = value;
    }

    /**
     * Obtiene el valor de la propiedad relnCtrl4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnCtrl4() {
        return relnCtrl4;
    }

    /**
     * Define el valor de la propiedad relnCtrl4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnCtrl4(String value) {
        this.relnCtrl4 = value;
    }

    /**
     * Obtiene el valor de la propiedad accountNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountNo() {
        return accountNo;
    }

    /**
     * Define el valor de la propiedad accountNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountNo(String value) {
        this.accountNo = value;
    }

    /**
     * Obtiene el valor de la propiedad sourceChannel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceChannel() {
        return sourceChannel;
    }

    /**
     * Define el valor de la propiedad sourceChannel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceChannel(String value) {
        this.sourceChannel = value;
    }

    /**
     * Obtiene el valor de la propiedad bundleID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBundleID() {
        return bundleID;
    }

    /**
     * Define el valor de la propiedad bundleID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBundleID(String value) {
        this.bundleID = value;
    }

    /**
     * Obtiene el valor de la propiedad orderSeq.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderSeq() {
        return orderSeq;
    }

    /**
     * Define el valor de la propiedad orderSeq.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderSeq(String value) {
        this.orderSeq = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMainID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastMainID() {
        return lastMainID;
    }

    /**
     * Define el valor de la propiedad lastMainID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastMainID(String value) {
        this.lastMainID = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMaintTimeStamp.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastMaintTimeStamp() {
        return lastMaintTimeStamp;
    }

    /**
     * Define el valor de la propiedad lastMaintTimeStamp.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastMaintTimeStamp(String value) {
        this.lastMaintTimeStamp = value;
    }

    /**
     * Obtiene el valor de la propiedad customerNos.
     * 
     * @return
     *     possible object is
     *     {@link CustomerNos }
     *     
     */
    public CustomerNos getCustomerNos() {
        return customerNos;
    }

    /**
     * Define el valor de la propiedad customerNos.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerNos }
     *     
     */
    public void setCustomerNos(CustomerNos value) {
        this.customerNos = value;
    }

    /**
     * Obtiene el valor de la propiedad prodFamily.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdFamily() {
        return prodFamily;
    }

    /**
     * Define el valor de la propiedad prodFamily.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdFamily(String value) {
        this.prodFamily = value;
    }

    /**
     * Obtiene el valor de la propiedad dataStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataStatus() {
        return dataStatus;
    }

    /**
     * Define el valor de la propiedad dataStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataStatus(String value) {
        this.dataStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad acctCtl1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctCtl1() {
        return acctCtl1;
    }

    /**
     * Define el valor de la propiedad acctCtl1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctCtl1(String value) {
        this.acctCtl1 = value;
    }

    /**
     * Obtiene el valor de la propiedad acctCtl2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctCtl2() {
        return acctCtl2;
    }

    /**
     * Define el valor de la propiedad acctCtl2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctCtl2(String value) {
        this.acctCtl2 = value;
    }

    /**
     * Obtiene el valor de la propiedad acctCtl3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctCtl3() {
        return acctCtl3;
    }

    /**
     * Define el valor de la propiedad acctCtl3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctCtl3(String value) {
        this.acctCtl3 = value;
    }

    /**
     * Obtiene el valor de la propiedad acctCtl4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcctCtl4() {
        return acctCtl4;
    }

    /**
     * Define el valor de la propiedad acctCtl4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcctCtl4(String value) {
        this.acctCtl4 = value;
    }

    /**
     * Obtiene el valor de la propiedad ntProdCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNtProdCode() {
        return ntProdCode;
    }

    /**
     * Define el valor de la propiedad ntProdCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNtProdCode(String value) {
        this.ntProdCode = value;
    }

    /**
     * Obtiene el valor de la propiedad relnCatg.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnCatg() {
        return relnCatg;
    }

    /**
     * Define el valor de la propiedad relnCatg.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnCatg(String value) {
        this.relnCatg = value;
    }

    /**
     * Obtiene el valor de la propiedad campaignID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCampaignID() {
        return campaignID;
    }

    /**
     * Define el valor de la propiedad campaignID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCampaignID(String value) {
        this.campaignID = value;
    }

    /**
     * Obtiene el valor de la propiedad waveID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaveID() {
        return waveID;
    }

    /**
     * Define el valor de la propiedad waveID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaveID(String value) {
        this.waveID = value;
    }

    /**
     * Obtiene el valor de la propiedad prodCodeDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdCodeDesc() {
        return prodCodeDesc;
    }

    /**
     * Define el valor de la propiedad prodCodeDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdCodeDesc(String value) {
        this.prodCodeDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad prodFamilyDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdFamilyDesc() {
        return prodFamilyDesc;
    }

    /**
     * Define el valor de la propiedad prodFamilyDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdFamilyDesc(String value) {
        this.prodFamilyDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad accountTitle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountTitle() {
        return accountTitle;
    }

    /**
     * Define el valor de la propiedad accountTitle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountTitle(String value) {
        this.accountTitle = value;
    }

    /**
     * Obtiene el valor de la propiedad accountTitle1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountTitle1() {
        return accountTitle1;
    }

    /**
     * Define el valor de la propiedad accountTitle1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountTitle1(String value) {
        this.accountTitle1 = value;
    }

    /**
     * Obtiene el valor de la propiedad fromAGInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFromAGInd() {
        return fromAGInd;
    }

    /**
     * Define el valor de la propiedad fromAGInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromAGInd(String value) {
        this.fromAGInd = value;
    }

    /**
     * Obtiene el valor de la propiedad costRelPrcgGrp.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCostRelPrcgGrp() {
        return costRelPrcgGrp;
    }

    /**
     * Define el valor de la propiedad costRelPrcgGrp.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCostRelPrcgGrp(String value) {
        this.costRelPrcgGrp = value;
    }

    /**
     * Obtiene el valor de la propiedad signInst.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignInst() {
        return signInst;
    }

    /**
     * Define el valor de la propiedad signInst.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignInst(String value) {
        this.signInst = value;
    }

    /**
     * Obtiene el valor de la propiedad signInstRemark.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignInstRemark() {
        return signInstRemark;
    }

    /**
     * Define el valor de la propiedad signInstRemark.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignInstRemark(String value) {
        this.signInstRemark = value;
    }

    /**
     * Obtiene el valor de la propiedad signInstrReq.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSignInstrReq() {
        return signInstrReq;
    }

    /**
     * Define el valor de la propiedad signInstrReq.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignInstrReq(String value) {
        this.signInstrReq = value;
    }

    /**
     * Obtiene el valor de la propiedad makerUserID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMakerUserID() {
        return makerUserID;
    }

    /**
     * Define el valor de la propiedad makerUserID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMakerUserID(String value) {
        this.makerUserID = value;
    }

    /**
     * Obtiene el valor de la propiedad checkerUserID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckerUserID() {
        return checkerUserID;
    }

    /**
     * Define el valor de la propiedad checkerUserID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckerUserID(String value) {
        this.checkerUserID = value;
    }

    /**
     * Obtiene el valor de la propiedad prdSeqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrdSeqNo() {
        return prdSeqNo;
    }

    /**
     * Define el valor de la propiedad prdSeqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrdSeqNo(String value) {
        this.prdSeqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad relnSeqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnSeqNo() {
        return relnSeqNo;
    }

    /**
     * Define el valor de la propiedad relnSeqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnSeqNo(String value) {
        this.relnSeqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad ccy.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCCY() {
        return ccy;
    }

    /**
     * Define el valor de la propiedad ccy.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCCY(String value) {
        this.ccy = value;
    }

    /**
     * Obtiene el valor de la propiedad offerPriority.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getOfferPriority() {
        return offerPriority;
    }

    /**
     * Define el valor de la propiedad offerPriority.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setOfferPriority(BigInteger value) {
        this.offerPriority = value;
    }

    /**
     * Obtiene el valor de la propiedad offerAvailability.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferAvailability() {
        return offerAvailability;
    }

    /**
     * Define el valor de la propiedad offerAvailability.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferAvailability(String value) {
        this.offerAvailability = value;
    }

    /**
     * Obtiene el valor de la propiedad offerCreationMode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferCreationMode() {
        return offerCreationMode;
    }

    /**
     * Define el valor de la propiedad offerCreationMode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferCreationMode(String value) {
        this.offerCreationMode = value;
    }

    /**
     * Obtiene el valor de la propiedad campaignCategory.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCampaignCategory() {
        return campaignCategory;
    }

    /**
     * Define el valor de la propiedad campaignCategory.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCampaignCategory(String value) {
        this.campaignCategory = value;
    }

    /**
     * Obtiene el valor de la propiedad offerStartDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getOfferStartDate() {
        return offerStartDate;
    }

    /**
     * Define el valor de la propiedad offerStartDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setOfferStartDate(XMLGregorianCalendar value) {
        this.offerStartDate = value;
    }

    /**
     * Obtiene el valor de la propiedad offerEndDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getOfferEndDate() {
        return offerEndDate;
    }

    /**
     * Define el valor de la propiedad offerEndDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setOfferEndDate(XMLGregorianCalendar value) {
        this.offerEndDate = value;
    }

    /**
     * Obtiene el valor de la propiedad latestOfferStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLatestOfferStatus() {
        return latestOfferStatus;
    }

    /**
     * Define el valor de la propiedad latestOfferStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLatestOfferStatus(String value) {
        this.latestOfferStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad campaignDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCampaignDescription() {
        return campaignDescription;
    }

    /**
     * Define el valor de la propiedad campaignDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCampaignDescription(String value) {
        this.campaignDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad salesScriptText.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesScriptText() {
        return salesScriptText;
    }

    /**
     * Define el valor de la propiedad salesScriptText.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesScriptText(String value) {
        this.salesScriptText = value;
    }

    /**
     * Obtiene el valor de la propiedad waveDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWaveDescription() {
        return waveDescription;
    }

    /**
     * Define el valor de la propiedad waveDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWaveDescription(String value) {
        this.waveDescription = value;
    }

    /**
     * Obtiene el valor de la propiedad getOfferResponseCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGetOfferResponseCode() {
        return getOfferResponseCode;
    }

    /**
     * Define el valor de la propiedad getOfferResponseCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGetOfferResponseCode(String value) {
        this.getOfferResponseCode = value;
    }

    /**
     * Obtiene el valor de la propiedad getOfferResponseText.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGetOfferResponseText() {
        return getOfferResponseText;
    }

    /**
     * Define el valor de la propiedad getOfferResponseText.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGetOfferResponseText(String value) {
        this.getOfferResponseText = value;
    }

    /**
     * Obtiene el valor de la propiedad userField1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField1() {
        return userField1;
    }

    /**
     * Define el valor de la propiedad userField1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField1(String value) {
        this.userField1 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField2() {
        return userField2;
    }

    /**
     * Define el valor de la propiedad userField2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField2(String value) {
        this.userField2 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField3() {
        return userField3;
    }

    /**
     * Define el valor de la propiedad userField3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField3(String value) {
        this.userField3 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField4() {
        return userField4;
    }

    /**
     * Define el valor de la propiedad userField4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField4(String value) {
        this.userField4 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField5.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField5() {
        return userField5;
    }

    /**
     * Define el valor de la propiedad userField5.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField5(String value) {
        this.userField5 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField6.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField6() {
        return userField6;
    }

    /**
     * Define el valor de la propiedad userField6.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField6(String value) {
        this.userField6 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField7.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField7() {
        return userField7;
    }

    /**
     * Define el valor de la propiedad userField7.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField7(String value) {
        this.userField7 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField8.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField8() {
        return userField8;
    }

    /**
     * Define el valor de la propiedad userField8.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField8(String value) {
        this.userField8 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField9.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField9() {
        return userField9;
    }

    /**
     * Define el valor de la propiedad userField9.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField9(String value) {
        this.userField9 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField10.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField10() {
        return userField10;
    }

    /**
     * Define el valor de la propiedad userField10.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField10(String value) {
        this.userField10 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField11.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField11() {
        return userField11;
    }

    /**
     * Define el valor de la propiedad userField11.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField11(String value) {
        this.userField11 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField12.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField12() {
        return userField12;
    }

    /**
     * Define el valor de la propiedad userField12.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField12(String value) {
        this.userField12 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField13.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField13() {
        return userField13;
    }

    /**
     * Define el valor de la propiedad userField13.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField13(String value) {
        this.userField13 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField14.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField14() {
        return userField14;
    }

    /**
     * Define el valor de la propiedad userField14.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField14(String value) {
        this.userField14 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField15.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField15() {
        return userField15;
    }

    /**
     * Define el valor de la propiedad userField15.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField15(String value) {
        this.userField15 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField16.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField16() {
        return userField16;
    }

    /**
     * Define el valor de la propiedad userField16.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField16(String value) {
        this.userField16 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField17.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField17() {
        return userField17;
    }

    /**
     * Define el valor de la propiedad userField17.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField17(String value) {
        this.userField17 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField18.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField18() {
        return userField18;
    }

    /**
     * Define el valor de la propiedad userField18.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField18(String value) {
        this.userField18 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField19.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField19() {
        return userField19;
    }

    /**
     * Define el valor de la propiedad userField19.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField19(String value) {
        this.userField19 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField20.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField20() {
        return userField20;
    }

    /**
     * Define el valor de la propiedad userField20.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField20(String value) {
        this.userField20 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField21.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField21() {
        return userField21;
    }

    /**
     * Define el valor de la propiedad userField21.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField21(String value) {
        this.userField21 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField22.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField22() {
        return userField22;
    }

    /**
     * Define el valor de la propiedad userField22.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField22(String value) {
        this.userField22 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField23.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField23() {
        return userField23;
    }

    /**
     * Define el valor de la propiedad userField23.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField23(String value) {
        this.userField23 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField24.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField24() {
        return userField24;
    }

    /**
     * Define el valor de la propiedad userField24.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField24(String value) {
        this.userField24 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField25.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField25() {
        return userField25;
    }

    /**
     * Define el valor de la propiedad userField25.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField25(String value) {
        this.userField25 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField26.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField26() {
        return userField26;
    }

    /**
     * Define el valor de la propiedad userField26.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField26(String value) {
        this.userField26 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField27.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField27() {
        return userField27;
    }

    /**
     * Define el valor de la propiedad userField27.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField27(String value) {
        this.userField27 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField28.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField28() {
        return userField28;
    }

    /**
     * Define el valor de la propiedad userField28.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField28(String value) {
        this.userField28 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField29.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField29() {
        return userField29;
    }

    /**
     * Define el valor de la propiedad userField29.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField29(String value) {
        this.userField29 = value;
    }

    /**
     * Obtiene el valor de la propiedad userField30.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserField30() {
        return userField30;
    }

    /**
     * Define el valor de la propiedad userField30.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserField30(String value) {
        this.userField30 = value;
    }

}
