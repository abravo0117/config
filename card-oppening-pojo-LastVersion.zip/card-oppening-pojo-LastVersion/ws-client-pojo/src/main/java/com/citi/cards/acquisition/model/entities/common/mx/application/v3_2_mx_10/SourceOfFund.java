
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para SourceOfFund complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="SourceOfFund">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="SOFAccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOFAccountCcy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOFAccountTitle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOFAccountPrdType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Preference" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOFPrimaryCustNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOFPrimaryCustCTRL1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOFSystemID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOFAccountCTRL1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOFAccountCTRL2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMaintID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMaintTStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="RelationshipKey" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}RelationshipKey" minOccurs="0"/>
 *         &lt;element name="AccountStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SourceOfFund", propOrder = {
    "seqNo",
    "sofAccountNo",
    "sofAccountCcy",
    "sofAccountTitle",
    "sofAccountPrdType",
    "preference",
    "sofPrimaryCustNo",
    "sofPrimaryCustCTRL1",
    "sofSystemID",
    "sofAccountCTRL1",
    "sofAccountCTRL2",
    "lastMaintID",
    "lastMaintTStamp",
    "relationshipKey",
    "accountStatus"
})
public class SourceOfFund {

    @XmlElementRef(name = "SeqNo", namespace = "http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10", type = JAXBElement.class)
    protected JAXBElement<Integer> seqNo;
    @XmlElement(name = "SOFAccountNo")
    protected String sofAccountNo;
    @XmlElement(name = "SOFAccountCcy")
    protected String sofAccountCcy;
    @XmlElement(name = "SOFAccountTitle")
    protected String sofAccountTitle;
    @XmlElement(name = "SOFAccountPrdType")
    protected String sofAccountPrdType;
    @XmlElement(name = "Preference")
    protected String preference;
    @XmlElement(name = "SOFPrimaryCustNo")
    protected String sofPrimaryCustNo;
    @XmlElement(name = "SOFPrimaryCustCTRL1")
    protected String sofPrimaryCustCTRL1;
    @XmlElement(name = "SOFSystemID")
    protected String sofSystemID;
    @XmlElement(name = "SOFAccountCTRL1")
    protected String sofAccountCTRL1;
    @XmlElement(name = "SOFAccountCTRL2")
    protected String sofAccountCTRL2;
    @XmlElement(name = "LastMaintID")
    protected String lastMaintID;
    @XmlElementRef(name = "LastMaintTStamp", namespace = "http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> lastMaintTStamp;
    @XmlElement(name = "RelationshipKey")
    protected RelationshipKey relationshipKey;
    @XmlElement(name = "AccountStatus")
    protected String accountStatus;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setSeqNo(JAXBElement<Integer> value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad sofAccountNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOFAccountNo() {
        return sofAccountNo;
    }

    /**
     * Define el valor de la propiedad sofAccountNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOFAccountNo(String value) {
        this.sofAccountNo = value;
    }

    /**
     * Obtiene el valor de la propiedad sofAccountCcy.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOFAccountCcy() {
        return sofAccountCcy;
    }

    /**
     * Define el valor de la propiedad sofAccountCcy.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOFAccountCcy(String value) {
        this.sofAccountCcy = value;
    }

    /**
     * Obtiene el valor de la propiedad sofAccountTitle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOFAccountTitle() {
        return sofAccountTitle;
    }

    /**
     * Define el valor de la propiedad sofAccountTitle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOFAccountTitle(String value) {
        this.sofAccountTitle = value;
    }

    /**
     * Obtiene el valor de la propiedad sofAccountPrdType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOFAccountPrdType() {
        return sofAccountPrdType;
    }

    /**
     * Define el valor de la propiedad sofAccountPrdType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOFAccountPrdType(String value) {
        this.sofAccountPrdType = value;
    }

    /**
     * Obtiene el valor de la propiedad preference.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPreference() {
        return preference;
    }

    /**
     * Define el valor de la propiedad preference.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPreference(String value) {
        this.preference = value;
    }

    /**
     * Obtiene el valor de la propiedad sofPrimaryCustNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOFPrimaryCustNo() {
        return sofPrimaryCustNo;
    }

    /**
     * Define el valor de la propiedad sofPrimaryCustNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOFPrimaryCustNo(String value) {
        this.sofPrimaryCustNo = value;
    }

    /**
     * Obtiene el valor de la propiedad sofPrimaryCustCTRL1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOFPrimaryCustCTRL1() {
        return sofPrimaryCustCTRL1;
    }

    /**
     * Define el valor de la propiedad sofPrimaryCustCTRL1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOFPrimaryCustCTRL1(String value) {
        this.sofPrimaryCustCTRL1 = value;
    }

    /**
     * Obtiene el valor de la propiedad sofSystemID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOFSystemID() {
        return sofSystemID;
    }

    /**
     * Define el valor de la propiedad sofSystemID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOFSystemID(String value) {
        this.sofSystemID = value;
    }

    /**
     * Obtiene el valor de la propiedad sofAccountCTRL1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOFAccountCTRL1() {
        return sofAccountCTRL1;
    }

    /**
     * Define el valor de la propiedad sofAccountCTRL1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOFAccountCTRL1(String value) {
        this.sofAccountCTRL1 = value;
    }

    /**
     * Obtiene el valor de la propiedad sofAccountCTRL2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOFAccountCTRL2() {
        return sofAccountCTRL2;
    }

    /**
     * Define el valor de la propiedad sofAccountCTRL2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOFAccountCTRL2(String value) {
        this.sofAccountCTRL2 = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMaintID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastMaintID() {
        return lastMaintID;
    }

    /**
     * Define el valor de la propiedad lastMaintID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastMaintID(String value) {
        this.lastMaintID = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMaintTStamp.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getLastMaintTStamp() {
        return lastMaintTStamp;
    }

    /**
     * Define el valor de la propiedad lastMaintTStamp.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setLastMaintTStamp(JAXBElement<XMLGregorianCalendar> value) {
        this.lastMaintTStamp = value;
    }

    /**
     * Obtiene el valor de la propiedad relationshipKey.
     * 
     * @return
     *     possible object is
     *     {@link RelationshipKey }
     *     
     */
    public RelationshipKey getRelationshipKey() {
        return relationshipKey;
    }

    /**
     * Define el valor de la propiedad relationshipKey.
     * 
     * @param value
     *     allowed object is
     *     {@link RelationshipKey }
     *     
     */
    public void setRelationshipKey(RelationshipKey value) {
        this.relationshipKey = value;
    }

    /**
     * Obtiene el valor de la propiedad accountStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountStatus() {
        return accountStatus;
    }

    /**
     * Define el valor de la propiedad accountStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountStatus(String value) {
        this.accountStatus = value;
    }

}
