
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.citi.cards.acquisition.model.shared.datatypes.v3_1_0_0.Phone;
import com.citi.cards.acquisition.model.shared.datatypes.v3_1_0_0.StructuredName;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.LastUpdate;


/**
 * <p>Clase Java para ApplicationFullDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ApplicationFullDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CustomerNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResonCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReasonCodeDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicationDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="ApplicationStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicationStatusDesc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicationStage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ApplicantName" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}StructuredName"/>
 *         &lt;element name="DateOfBirth" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TaxID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Logo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Org" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PlasticID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditLineAmount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="LastUpdate" type="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}LastUpdate" minOccurs="0"/>
 *         &lt;element name="Address" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Address" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Phone" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Phone" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="MemoDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}MemoDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Gender" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Initiator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ApplicationFullDetails", propOrder = {
    "customerNo",
    "resonCode",
    "reasonCodeDesc",
    "applicationID",
    "applicationDate",
    "applicationStatus",
    "applicationStatusDesc",
    "applicationStage",
    "applicantName",
    "dateOfBirth",
    "taxID",
    "logo",
    "org",
    "sourceCode",
    "plasticID",
    "cardNo",
    "creditLineAmount",
    "lastUpdate",
    "address",
    "phone",
    "memoDetails",
    "gender",
    "initiator",
    "applicationType"
})
public class ApplicationFullDetails {

    @XmlElement(name = "CustomerNo")
    protected String customerNo;
    @XmlElement(name = "ResonCode")
    protected String resonCode;
    @XmlElement(name = "ReasonCodeDesc")
    protected String reasonCodeDesc;
    @XmlElement(name = "ApplicationID", required = true)
    protected String applicationID;
    @XmlElement(name = "ApplicationDate", required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar applicationDate;
    @XmlElement(name = "ApplicationStatus", required = true)
    protected String applicationStatus;
    @XmlElement(name = "ApplicationStatusDesc", required = true)
    protected String applicationStatusDesc;
    @XmlElement(name = "ApplicationStage", required = true)
    protected String applicationStage;
    @XmlElement(name = "ApplicantName", required = true)
    protected StructuredName applicantName;
    @XmlElement(name = "DateOfBirth", required = true)
    protected String dateOfBirth;
    @XmlElement(name = "TaxID")
    protected String taxID;
    @XmlElement(name = "Logo")
    protected String logo;
    @XmlElement(name = "Org")
    protected String org;
    @XmlElement(name = "SourceCode")
    protected String sourceCode;
    @XmlElement(name = "PlasticID")
    protected String plasticID;
    @XmlElement(name = "CardNo")
    protected String cardNo;
    @XmlElement(name = "CreditLineAmount")
    protected Double creditLineAmount;
    @XmlElement(name = "LastUpdate")
    protected LastUpdate lastUpdate;
    @XmlElement(name = "Address")
    protected List<Address> address;
    @XmlElement(name = "Phone")
    protected List<Phone> phone;
    @XmlElement(name = "MemoDetails")
    protected List<MemoDetails> memoDetails;
    @XmlElement(name = "Gender")
    protected String gender;
    @XmlElement(name = "Initiator")
    protected String initiator;
    @XmlElement(name = "ApplicationType")
    protected String applicationType;

    /**
     * Obtiene el valor de la propiedad customerNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerNo() {
        return customerNo;
    }

    /**
     * Define el valor de la propiedad customerNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerNo(String value) {
        this.customerNo = value;
    }

    /**
     * Obtiene el valor de la propiedad resonCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResonCode() {
        return resonCode;
    }

    /**
     * Define el valor de la propiedad resonCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResonCode(String value) {
        this.resonCode = value;
    }

    /**
     * Obtiene el valor de la propiedad reasonCodeDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReasonCodeDesc() {
        return reasonCodeDesc;
    }

    /**
     * Define el valor de la propiedad reasonCodeDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReasonCodeDesc(String value) {
        this.reasonCodeDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationID() {
        return applicationID;
    }

    /**
     * Define el valor de la propiedad applicationID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationID(String value) {
        this.applicationID = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationDate.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getApplicationDate() {
        return applicationDate;
    }

    /**
     * Define el valor de la propiedad applicationDate.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setApplicationDate(XMLGregorianCalendar value) {
        this.applicationDate = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationStatus() {
        return applicationStatus;
    }

    /**
     * Define el valor de la propiedad applicationStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationStatus(String value) {
        this.applicationStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationStatusDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationStatusDesc() {
        return applicationStatusDesc;
    }

    /**
     * Define el valor de la propiedad applicationStatusDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationStatusDesc(String value) {
        this.applicationStatusDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationStage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationStage() {
        return applicationStage;
    }

    /**
     * Define el valor de la propiedad applicationStage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationStage(String value) {
        this.applicationStage = value;
    }

    /**
     * Obtiene el valor de la propiedad applicantName.
     * 
     * @return
     *     possible object is
     *     {@link StructuredName }
     *     
     */
    public StructuredName getApplicantName() {
        return applicantName;
    }

    /**
     * Define el valor de la propiedad applicantName.
     * 
     * @param value
     *     allowed object is
     *     {@link StructuredName }
     *     
     */
    public void setApplicantName(StructuredName value) {
        this.applicantName = value;
    }

    /**
     * Obtiene el valor de la propiedad dateOfBirth.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Define el valor de la propiedad dateOfBirth.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateOfBirth(String value) {
        this.dateOfBirth = value;
    }

    /**
     * Obtiene el valor de la propiedad taxID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxID() {
        return taxID;
    }

    /**
     * Define el valor de la propiedad taxID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxID(String value) {
        this.taxID = value;
    }

    /**
     * Obtiene el valor de la propiedad logo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogo() {
        return logo;
    }

    /**
     * Define el valor de la propiedad logo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogo(String value) {
        this.logo = value;
    }

    /**
     * Obtiene el valor de la propiedad org.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrg() {
        return org;
    }

    /**
     * Define el valor de la propiedad org.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrg(String value) {
        this.org = value;
    }

    /**
     * Obtiene el valor de la propiedad sourceCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceCode() {
        return sourceCode;
    }

    /**
     * Define el valor de la propiedad sourceCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceCode(String value) {
        this.sourceCode = value;
    }

    /**
     * Obtiene el valor de la propiedad plasticID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlasticID() {
        return plasticID;
    }

    /**
     * Define el valor de la propiedad plasticID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlasticID(String value) {
        this.plasticID = value;
    }

    /**
     * Obtiene el valor de la propiedad cardNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardNo() {
        return cardNo;
    }

    /**
     * Define el valor de la propiedad cardNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardNo(String value) {
        this.cardNo = value;
    }

    /**
     * Obtiene el valor de la propiedad creditLineAmount.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getCreditLineAmount() {
        return creditLineAmount;
    }

    /**
     * Define el valor de la propiedad creditLineAmount.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setCreditLineAmount(Double value) {
        this.creditLineAmount = value;
    }

    /**
     * Obtiene el valor de la propiedad lastUpdate.
     * 
     * @return
     *     possible object is
     *     {@link LastUpdate }
     *     
     */
    public LastUpdate getLastUpdate() {
        return lastUpdate;
    }

    /**
     * Define el valor de la propiedad lastUpdate.
     * 
     * @param value
     *     allowed object is
     *     {@link LastUpdate }
     *     
     */
    public void setLastUpdate(LastUpdate value) {
        this.lastUpdate = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the address property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddress().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Address }
     * 
     * 
     */
    public List<Address> getAddress() {
        if (address == null) {
            address = new ArrayList<Address>();
        }
        return this.address;
    }

    /**
     * Gets the value of the phone property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the phone property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPhone().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Phone }
     * 
     * 
     */
    public List<Phone> getPhone() {
        if (phone == null) {
            phone = new ArrayList<Phone>();
        }
        return this.phone;
    }

    /**
     * Gets the value of the memoDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the memoDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMemoDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MemoDetails }
     * 
     * 
     */
    public List<MemoDetails> getMemoDetails() {
        if (memoDetails == null) {
            memoDetails = new ArrayList<MemoDetails>();
        }
        return this.memoDetails;
    }

    /**
     * Obtiene el valor de la propiedad gender.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGender() {
        return gender;
    }

    /**
     * Define el valor de la propiedad gender.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGender(String value) {
        this.gender = value;
    }

    /**
     * Obtiene el valor de la propiedad initiator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitiator() {
        return initiator;
    }

    /**
     * Define el valor de la propiedad initiator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitiator(String value) {
        this.initiator = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationType() {
        return applicationType;
    }

    /**
     * Define el valor de la propiedad applicationType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationType(String value) {
        this.applicationType = value;
    }

}
