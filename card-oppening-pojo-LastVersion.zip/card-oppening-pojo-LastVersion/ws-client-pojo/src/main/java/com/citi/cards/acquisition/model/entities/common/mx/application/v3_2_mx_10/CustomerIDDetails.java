
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerIDDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerIDDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="IDType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IDNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IDExpiryDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IDCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IDIssueDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IDIssuePlace" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IDIssueCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IssuingAuthority" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExistNewInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IDTypeDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerIDDetails", propOrder = {
    "seqNo",
    "idType",
    "idNumber",
    "idExpiryDate",
    "idCode",
    "idIssueDate",
    "idIssuePlace",
    "idIssueCountry",
    "issuingAuthority",
    "existNewInd",
    "idTypeDesc"
})
public class CustomerIDDetails {

    @XmlElement(name = "SeqNo", required = true)
    protected String seqNo;
    @XmlElement(name = "IDType")
    protected String idType;
    @XmlElement(name = "IDNumber")
    protected String idNumber;
    @XmlElement(name = "IDExpiryDate")
    protected String idExpiryDate;
    @XmlElement(name = "IDCode")
    protected String idCode;
    @XmlElement(name = "IDIssueDate")
    protected String idIssueDate;
    @XmlElement(name = "IDIssuePlace")
    protected String idIssuePlace;
    @XmlElement(name = "IDIssueCountry")
    protected String idIssueCountry;
    @XmlElement(name = "IssuingAuthority")
    protected String issuingAuthority;
    @XmlElement(name = "ExistNewInd")
    protected String existNewInd;
    @XmlElement(name = "IDTypeDesc")
    protected String idTypeDesc;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad idType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDType() {
        return idType;
    }

    /**
     * Define el valor de la propiedad idType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDType(String value) {
        this.idType = value;
    }

    /**
     * Obtiene el valor de la propiedad idNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDNumber() {
        return idNumber;
    }

    /**
     * Define el valor de la propiedad idNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDNumber(String value) {
        this.idNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad idExpiryDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDExpiryDate() {
        return idExpiryDate;
    }

    /**
     * Define el valor de la propiedad idExpiryDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDExpiryDate(String value) {
        this.idExpiryDate = value;
    }

    /**
     * Obtiene el valor de la propiedad idCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDCode() {
        return idCode;
    }

    /**
     * Define el valor de la propiedad idCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDCode(String value) {
        this.idCode = value;
    }

    /**
     * Obtiene el valor de la propiedad idIssueDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDIssueDate() {
        return idIssueDate;
    }

    /**
     * Define el valor de la propiedad idIssueDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDIssueDate(String value) {
        this.idIssueDate = value;
    }

    /**
     * Obtiene el valor de la propiedad idIssuePlace.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDIssuePlace() {
        return idIssuePlace;
    }

    /**
     * Define el valor de la propiedad idIssuePlace.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDIssuePlace(String value) {
        this.idIssuePlace = value;
    }

    /**
     * Obtiene el valor de la propiedad idIssueCountry.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDIssueCountry() {
        return idIssueCountry;
    }

    /**
     * Define el valor de la propiedad idIssueCountry.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDIssueCountry(String value) {
        this.idIssueCountry = value;
    }

    /**
     * Obtiene el valor de la propiedad issuingAuthority.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuingAuthority() {
        return issuingAuthority;
    }

    /**
     * Define el valor de la propiedad issuingAuthority.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuingAuthority(String value) {
        this.issuingAuthority = value;
    }

    /**
     * Obtiene el valor de la propiedad existNewInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExistNewInd() {
        return existNewInd;
    }

    /**
     * Define el valor de la propiedad existNewInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExistNewInd(String value) {
        this.existNewInd = value;
    }

    /**
     * Obtiene el valor de la propiedad idTypeDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDTypeDesc() {
        return idTypeDesc;
    }

    /**
     * Define el valor de la propiedad idTypeDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDTypeDesc(String value) {
        this.idTypeDesc = value;
    }

}
