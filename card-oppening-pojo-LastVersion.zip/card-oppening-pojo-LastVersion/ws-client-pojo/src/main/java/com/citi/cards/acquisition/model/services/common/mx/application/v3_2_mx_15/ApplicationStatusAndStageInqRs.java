
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.ApplicationDetails;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.GenericResponse;


/**
 * <p>Clase Java para ApplicationStatusAndStageInqRs complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ApplicationStatusAndStageInqRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/query.model/shared/util/v3_1_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="ApplicationDetails" type="{http://www.citi.com/query.model/entities/common/MX/application/v3_2_MX_10}ApplicationDetails" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ApplicationStatusAndStageInqRs", propOrder = {
    "applicationDetails"
})
public class ApplicationStatusAndStageInqRs
    extends GenericResponse
{

    @XmlElement(name = "ApplicationDetails")
    protected List<ApplicationDetails> applicationDetails;

    /**
     * Gets the value of the applicationDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the applicationDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getApplicationDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ApplicationDetails }
     * 
     * 
     */
    public List<ApplicationDetails> getApplicationDetails() {
        if (applicationDetails == null) {
            applicationDetails = new ArrayList<ApplicationDetails>();
        }
        return this.applicationDetails;
    }

}
