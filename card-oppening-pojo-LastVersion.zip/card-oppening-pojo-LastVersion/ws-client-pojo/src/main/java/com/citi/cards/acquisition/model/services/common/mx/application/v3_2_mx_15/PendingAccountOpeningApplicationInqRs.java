
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.ApplicationSummary;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.GenericResponse;


/**
 * <p>Clase Java para PendingAccountOpeningApplicationInqRs complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="PendingAccountOpeningApplicationInqRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="RespCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RespDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationSummary" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}ApplicationSummary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PendingAccountOpeningApplicationInqRs", propOrder = {
    "respCode",
    "respDesc",
    "applicationSummary"
})
public class PendingAccountOpeningApplicationInqRs
    extends GenericResponse
{

    @XmlElement(name = "RespCode")
    protected String respCode;
    @XmlElement(name = "RespDesc")
    protected String respDesc;
    @XmlElement(name = "ApplicationSummary")
    protected ApplicationSummary applicationSummary;

    /**
     * Obtiene el valor de la propiedad respCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRespCode() {
        return respCode;
    }

    /**
     * Define el valor de la propiedad respCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRespCode(String value) {
        this.respCode = value;
    }

    /**
     * Obtiene el valor de la propiedad respDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRespDesc() {
        return respDesc;
    }

    /**
     * Define el valor de la propiedad respDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRespDesc(String value) {
        this.respDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationSummary.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationSummary }
     *     
     */
    public ApplicationSummary getApplicationSummary() {
        return applicationSummary;
    }

    /**
     * Define el valor de la propiedad applicationSummary.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationSummary }
     *     
     */
    public void setApplicationSummary(ApplicationSummary value) {
        this.applicationSummary = value;
    }

}
