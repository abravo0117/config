
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CitiCard complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CitiCard">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CitiCardReq" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SubCardType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmbossName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmbossAt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardFace" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CardClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhotoCardInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BIN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ATMLimit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PosSpendingLimit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CashBackLimit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FundTransferLimit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CitiCardNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CBOL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CBP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PinBlock" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="POSSpLimitOverseas" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ATMWDLimitOtherBank" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ATMWDLimitOverSeas" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JockeyAccessInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ATMAccessInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CitiCard", propOrder = {
    "seqNo",
    "citiCardReq",
    "cardType",
    "subCardType",
    "cardStatus",
    "embossName",
    "embossAt",
    "cardFace",
    "cardClass",
    "photoCardInd",
    "bin",
    "atmLimit",
    "posSpendingLimit",
    "cashBackLimit",
    "fundTransferLimit",
    "citiCardNo",
    "cbol",
    "cbp",
    "pinBlock",
    "posSpLimitOverseas",
    "atmwdLimitOtherBank",
    "atmwdLimitOverSeas",
    "jockeyAccessInd",
    "atmAccessInd"
})
public class CitiCard {

    @XmlElement(name = "SeqNo")
    protected String seqNo;
    @XmlElement(name = "CitiCardReq")
    protected String citiCardReq;
    @XmlElement(name = "CardType")
    protected String cardType;
    @XmlElement(name = "SubCardType")
    protected String subCardType;
    @XmlElement(name = "CardStatus")
    protected String cardStatus;
    @XmlElement(name = "EmbossName")
    protected String embossName;
    @XmlElement(name = "EmbossAt")
    protected String embossAt;
    @XmlElement(name = "CardFace")
    protected String cardFace;
    @XmlElement(name = "CardClass")
    protected String cardClass;
    @XmlElement(name = "PhotoCardInd")
    protected String photoCardInd;
    @XmlElement(name = "BIN")
    protected String bin;
    @XmlElement(name = "ATMLimit")
    protected String atmLimit;
    @XmlElement(name = "PosSpendingLimit")
    protected String posSpendingLimit;
    @XmlElement(name = "CashBackLimit")
    protected String cashBackLimit;
    @XmlElement(name = "FundTransferLimit")
    protected String fundTransferLimit;
    @XmlElement(name = "CitiCardNo")
    protected String citiCardNo;
    @XmlElement(name = "CBOL")
    protected String cbol;
    @XmlElement(name = "CBP")
    protected String cbp;
    @XmlElement(name = "PinBlock")
    protected String pinBlock;
    @XmlElement(name = "POSSpLimitOverseas")
    protected String posSpLimitOverseas;
    @XmlElement(name = "ATMWDLimitOtherBank")
    protected String atmwdLimitOtherBank;
    @XmlElement(name = "ATMWDLimitOverSeas")
    protected String atmwdLimitOverSeas;
    @XmlElement(name = "JockeyAccessInd")
    protected String jockeyAccessInd;
    @XmlElement(name = "ATMAccessInd")
    protected String atmAccessInd;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad citiCardReq.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCitiCardReq() {
        return citiCardReq;
    }

    /**
     * Define el valor de la propiedad citiCardReq.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCitiCardReq(String value) {
        this.citiCardReq = value;
    }

    /**
     * Obtiene el valor de la propiedad cardType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardType() {
        return cardType;
    }

    /**
     * Define el valor de la propiedad cardType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardType(String value) {
        this.cardType = value;
    }

    /**
     * Obtiene el valor de la propiedad subCardType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubCardType() {
        return subCardType;
    }

    /**
     * Define el valor de la propiedad subCardType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubCardType(String value) {
        this.subCardType = value;
    }

    /**
     * Obtiene el valor de la propiedad cardStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardStatus() {
        return cardStatus;
    }

    /**
     * Define el valor de la propiedad cardStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardStatus(String value) {
        this.cardStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad embossName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmbossName() {
        return embossName;
    }

    /**
     * Define el valor de la propiedad embossName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbossName(String value) {
        this.embossName = value;
    }

    /**
     * Obtiene el valor de la propiedad embossAt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmbossAt() {
        return embossAt;
    }

    /**
     * Define el valor de la propiedad embossAt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmbossAt(String value) {
        this.embossAt = value;
    }

    /**
     * Obtiene el valor de la propiedad cardFace.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardFace() {
        return cardFace;
    }

    /**
     * Define el valor de la propiedad cardFace.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardFace(String value) {
        this.cardFace = value;
    }

    /**
     * Obtiene el valor de la propiedad cardClass.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardClass() {
        return cardClass;
    }

    /**
     * Define el valor de la propiedad cardClass.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardClass(String value) {
        this.cardClass = value;
    }

    /**
     * Obtiene el valor de la propiedad photoCardInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhotoCardInd() {
        return photoCardInd;
    }

    /**
     * Define el valor de la propiedad photoCardInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhotoCardInd(String value) {
        this.photoCardInd = value;
    }

    /**
     * Obtiene el valor de la propiedad bin.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBIN() {
        return bin;
    }

    /**
     * Define el valor de la propiedad bin.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBIN(String value) {
        this.bin = value;
    }

    /**
     * Obtiene el valor de la propiedad atmLimit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getATMLimit() {
        return atmLimit;
    }

    /**
     * Define el valor de la propiedad atmLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setATMLimit(String value) {
        this.atmLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad posSpendingLimit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPosSpendingLimit() {
        return posSpendingLimit;
    }

    /**
     * Define el valor de la propiedad posSpendingLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPosSpendingLimit(String value) {
        this.posSpendingLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad cashBackLimit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCashBackLimit() {
        return cashBackLimit;
    }

    /**
     * Define el valor de la propiedad cashBackLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCashBackLimit(String value) {
        this.cashBackLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad fundTransferLimit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundTransferLimit() {
        return fundTransferLimit;
    }

    /**
     * Define el valor de la propiedad fundTransferLimit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundTransferLimit(String value) {
        this.fundTransferLimit = value;
    }

    /**
     * Obtiene el valor de la propiedad citiCardNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCitiCardNo() {
        return citiCardNo;
    }

    /**
     * Define el valor de la propiedad citiCardNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCitiCardNo(String value) {
        this.citiCardNo = value;
    }

    /**
     * Obtiene el valor de la propiedad cbol.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCBOL() {
        return cbol;
    }

    /**
     * Define el valor de la propiedad cbol.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCBOL(String value) {
        this.cbol = value;
    }

    /**
     * Obtiene el valor de la propiedad cbp.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCBP() {
        return cbp;
    }

    /**
     * Define el valor de la propiedad cbp.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCBP(String value) {
        this.cbp = value;
    }

    /**
     * Obtiene el valor de la propiedad pinBlock.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPinBlock() {
        return pinBlock;
    }

    /**
     * Define el valor de la propiedad pinBlock.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPinBlock(String value) {
        this.pinBlock = value;
    }

    /**
     * Obtiene el valor de la propiedad posSpLimitOverseas.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOSSpLimitOverseas() {
        return posSpLimitOverseas;
    }

    /**
     * Define el valor de la propiedad posSpLimitOverseas.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOSSpLimitOverseas(String value) {
        this.posSpLimitOverseas = value;
    }

    /**
     * Obtiene el valor de la propiedad atmwdLimitOtherBank.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getATMWDLimitOtherBank() {
        return atmwdLimitOtherBank;
    }

    /**
     * Define el valor de la propiedad atmwdLimitOtherBank.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setATMWDLimitOtherBank(String value) {
        this.atmwdLimitOtherBank = value;
    }

    /**
     * Obtiene el valor de la propiedad atmwdLimitOverSeas.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getATMWDLimitOverSeas() {
        return atmwdLimitOverSeas;
    }

    /**
     * Define el valor de la propiedad atmwdLimitOverSeas.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setATMWDLimitOverSeas(String value) {
        this.atmwdLimitOverSeas = value;
    }

    /**
     * Obtiene el valor de la propiedad jockeyAccessInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJockeyAccessInd() {
        return jockeyAccessInd;
    }

    /**
     * Define el valor de la propiedad jockeyAccessInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJockeyAccessInd(String value) {
        this.jockeyAccessInd = value;
    }

    /**
     * Obtiene el valor de la propiedad atmAccessInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getATMAccessInd() {
        return atmAccessInd;
    }

    /**
     * Define el valor de la propiedad atmAccessInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setATMAccessInd(String value) {
        this.atmAccessInd = value;
    }

}
