
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para InvestmentAndInsuranceProductDtls complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="InvestmentAndInsuranceProductDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OfferId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccounttRemarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FeeModel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountMaintFeeIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountRelationType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountCommMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMaintID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastMaintTStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="AccountKey" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}AccountKey" minOccurs="0"/>
 *         &lt;element name="SourceOfFund" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}SourceOfFund" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InvestmentAndInsuranceProductDtls", propOrder = {
    "offerId",
    "accountType",
    "accounttRemarks",
    "feeModel",
    "accountMaintFeeIndicator",
    "accountRelationType",
    "accountCommMode",
    "lastMaintID",
    "lastMaintTStamp",
    "accountKey",
    "sourceOfFund"
})
public class InvestmentAndInsuranceProductDtls {

    @XmlElement(name = "OfferId")
    protected String offerId;
    @XmlElement(name = "AccountType")
    protected String accountType;
    @XmlElement(name = "AccounttRemarks")
    protected String accounttRemarks;
    @XmlElement(name = "FeeModel")
    protected String feeModel;
    @XmlElement(name = "AccountMaintFeeIndicator")
    protected String accountMaintFeeIndicator;
    @XmlElement(name = "AccountRelationType")
    protected String accountRelationType;
    @XmlElement(name = "AccountCommMode")
    protected String accountCommMode;
    @XmlElement(name = "LastMaintID")
    protected String lastMaintID;
    @XmlElementRef(name = "LastMaintTStamp", namespace = "http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10", type = JAXBElement.class)
    protected JAXBElement<XMLGregorianCalendar> lastMaintTStamp;
    @XmlElement(name = "AccountKey")
    protected AccountKey accountKey;
    @XmlElement(name = "SourceOfFund")
    protected List<SourceOfFund> sourceOfFund;

    /**
     * Obtiene el valor de la propiedad offerId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferId() {
        return offerId;
    }

    /**
     * Define el valor de la propiedad offerId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferId(String value) {
        this.offerId = value;
    }

    /**
     * Obtiene el valor de la propiedad accountType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountType() {
        return accountType;
    }

    /**
     * Define el valor de la propiedad accountType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountType(String value) {
        this.accountType = value;
    }

    /**
     * Obtiene el valor de la propiedad accounttRemarks.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccounttRemarks() {
        return accounttRemarks;
    }

    /**
     * Define el valor de la propiedad accounttRemarks.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccounttRemarks(String value) {
        this.accounttRemarks = value;
    }

    /**
     * Obtiene el valor de la propiedad feeModel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFeeModel() {
        return feeModel;
    }

    /**
     * Define el valor de la propiedad feeModel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFeeModel(String value) {
        this.feeModel = value;
    }

    /**
     * Obtiene el valor de la propiedad accountMaintFeeIndicator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountMaintFeeIndicator() {
        return accountMaintFeeIndicator;
    }

    /**
     * Define el valor de la propiedad accountMaintFeeIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountMaintFeeIndicator(String value) {
        this.accountMaintFeeIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad accountRelationType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountRelationType() {
        return accountRelationType;
    }

    /**
     * Define el valor de la propiedad accountRelationType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountRelationType(String value) {
        this.accountRelationType = value;
    }

    /**
     * Obtiene el valor de la propiedad accountCommMode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountCommMode() {
        return accountCommMode;
    }

    /**
     * Define el valor de la propiedad accountCommMode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountCommMode(String value) {
        this.accountCommMode = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMaintID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastMaintID() {
        return lastMaintID;
    }

    /**
     * Define el valor de la propiedad lastMaintID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastMaintID(String value) {
        this.lastMaintID = value;
    }

    /**
     * Obtiene el valor de la propiedad lastMaintTStamp.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getLastMaintTStamp() {
        return lastMaintTStamp;
    }

    /**
     * Define el valor de la propiedad lastMaintTStamp.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setLastMaintTStamp(JAXBElement<XMLGregorianCalendar> value) {
        this.lastMaintTStamp = value;
    }

    /**
     * Obtiene el valor de la propiedad accountKey.
     * 
     * @return
     *     possible object is
     *     {@link AccountKey }
     *     
     */
    public AccountKey getAccountKey() {
        return accountKey;
    }

    /**
     * Define el valor de la propiedad accountKey.
     * 
     * @param value
     *     allowed object is
     *     {@link AccountKey }
     *     
     */
    public void setAccountKey(AccountKey value) {
        this.accountKey = value;
    }

    /**
     * Gets the value of the sourceOfFund property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sourceOfFund property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSourceOfFund().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SourceOfFund }
     * 
     * 
     */
    public List<SourceOfFund> getSourceOfFund() {
        if (sourceOfFund == null) {
            sourceOfFund = new ArrayList<SourceOfFund>();
        }
        return this.sourceOfFund;
    }

}
