
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para Application complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="Application">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ApplicationID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Initiator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AppRecievedDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExistingCardNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="eStmtIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesAgentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OACCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UserID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExternalApplicationID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExternalApplicationImageID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesAgencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesAgentTaxID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesAgentName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesAgentExtensionNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SourceIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BranchID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationFilledState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Offer" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Offer" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ApplicationType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OfferErrorCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SupportType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EnhancedDueDiligenceFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Application", propOrder = {
    "applicationID",
    "initiator",
    "appRecievedDate",
    "existingCardNo",
    "eStmtIndicator",
    "salesAgentCode",
    "oacCode",
    "userID",
    "externalApplicationID",
    "externalApplicationImageID",
    "salesAgencyCode",
    "salesAgentTaxID",
    "salesAgentName",
    "salesAgentExtensionNo",
    "sourceIndicator",
    "branchID",
    "applicationFilledState",
    "offer",
    "applicationType",
    "offerErrorCode",
    "supportType",
    "enhancedDueDiligenceFlag"
})
public class Application {

    @XmlElement(name = "ApplicationID")
    protected String applicationID;
    @XmlElement(name = "Initiator")
    protected String initiator;
    @XmlElement(name = "AppRecievedDate")
    protected String appRecievedDate;
    @XmlElement(name = "ExistingCardNo")
    protected String existingCardNo;
    protected String eStmtIndicator;
    @XmlElement(name = "SalesAgentCode")
    protected String salesAgentCode;
    @XmlElement(name = "OACCode")
    protected String oacCode;
    @XmlElement(name = "UserID")
    protected String userID;
    @XmlElement(name = "ExternalApplicationID")
    protected String externalApplicationID;
    @XmlElement(name = "ExternalApplicationImageID")
    protected String externalApplicationImageID;
    @XmlElement(name = "SalesAgencyCode")
    protected String salesAgencyCode;
    @XmlElement(name = "SalesAgentTaxID")
    protected String salesAgentTaxID;
    @XmlElement(name = "SalesAgentName")
    protected String salesAgentName;
    @XmlElement(name = "SalesAgentExtensionNo")
    protected String salesAgentExtensionNo;
    @XmlElement(name = "SourceIndicator")
    protected String sourceIndicator;
    @XmlElement(name = "BranchID")
    protected String branchID;
    @XmlElement(name = "ApplicationFilledState")
    protected String applicationFilledState;
    @XmlElement(name = "Offer")
    protected List<Offer> offer;
    @XmlElement(name = "ApplicationType")
    protected String applicationType;
    @XmlElement(name = "OfferErrorCode")
    protected String offerErrorCode;
    @XmlElement(name = "SupportType")
    protected String supportType;
    @XmlElement(name = "EnhancedDueDiligenceFlag")
    protected String enhancedDueDiligenceFlag;

    /**
     * Obtiene el valor de la propiedad applicationID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationID() {
        return applicationID;
    }

    /**
     * Define el valor de la propiedad applicationID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationID(String value) {
        this.applicationID = value;
    }

    /**
     * Obtiene el valor de la propiedad initiator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitiator() {
        return initiator;
    }

    /**
     * Define el valor de la propiedad initiator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitiator(String value) {
        this.initiator = value;
    }

    /**
     * Obtiene el valor de la propiedad appRecievedDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppRecievedDate() {
        return appRecievedDate;
    }

    /**
     * Define el valor de la propiedad appRecievedDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppRecievedDate(String value) {
        this.appRecievedDate = value;
    }

    /**
     * Obtiene el valor de la propiedad existingCardNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExistingCardNo() {
        return existingCardNo;
    }

    /**
     * Define el valor de la propiedad existingCardNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExistingCardNo(String value) {
        this.existingCardNo = value;
    }

    /**
     * Obtiene el valor de la propiedad eStmtIndicator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEStmtIndicator() {
        return eStmtIndicator;
    }

    /**
     * Define el valor de la propiedad eStmtIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEStmtIndicator(String value) {
        this.eStmtIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad salesAgentCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesAgentCode() {
        return salesAgentCode;
    }

    /**
     * Define el valor de la propiedad salesAgentCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesAgentCode(String value) {
        this.salesAgentCode = value;
    }

    /**
     * Obtiene el valor de la propiedad oacCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOACCode() {
        return oacCode;
    }

    /**
     * Define el valor de la propiedad oacCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOACCode(String value) {
        this.oacCode = value;
    }

    /**
     * Obtiene el valor de la propiedad userID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Define el valor de la propiedad userID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

    /**
     * Obtiene el valor de la propiedad externalApplicationID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalApplicationID() {
        return externalApplicationID;
    }

    /**
     * Define el valor de la propiedad externalApplicationID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalApplicationID(String value) {
        this.externalApplicationID = value;
    }

    /**
     * Obtiene el valor de la propiedad externalApplicationImageID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalApplicationImageID() {
        return externalApplicationImageID;
    }

    /**
     * Define el valor de la propiedad externalApplicationImageID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalApplicationImageID(String value) {
        this.externalApplicationImageID = value;
    }

    /**
     * Obtiene el valor de la propiedad salesAgencyCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesAgencyCode() {
        return salesAgencyCode;
    }

    /**
     * Define el valor de la propiedad salesAgencyCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesAgencyCode(String value) {
        this.salesAgencyCode = value;
    }

    /**
     * Obtiene el valor de la propiedad salesAgentTaxID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesAgentTaxID() {
        return salesAgentTaxID;
    }

    /**
     * Define el valor de la propiedad salesAgentTaxID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesAgentTaxID(String value) {
        this.salesAgentTaxID = value;
    }

    /**
     * Obtiene el valor de la propiedad salesAgentName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesAgentName() {
        return salesAgentName;
    }

    /**
     * Define el valor de la propiedad salesAgentName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesAgentName(String value) {
        this.salesAgentName = value;
    }

    /**
     * Obtiene el valor de la propiedad salesAgentExtensionNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesAgentExtensionNo() {
        return salesAgentExtensionNo;
    }

    /**
     * Define el valor de la propiedad salesAgentExtensionNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesAgentExtensionNo(String value) {
        this.salesAgentExtensionNo = value;
    }

    /**
     * Obtiene el valor de la propiedad sourceIndicator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceIndicator() {
        return sourceIndicator;
    }

    /**
     * Define el valor de la propiedad sourceIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceIndicator(String value) {
        this.sourceIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad branchID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchID() {
        return branchID;
    }

    /**
     * Define el valor de la propiedad branchID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchID(String value) {
        this.branchID = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationFilledState.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationFilledState() {
        return applicationFilledState;
    }

    /**
     * Define el valor de la propiedad applicationFilledState.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationFilledState(String value) {
        this.applicationFilledState = value;
    }

    /**
     * Gets the value of the offer property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the offer property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOffer().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Offer }
     * 
     * 
     */
    public List<Offer> getOffer() {
        if (offer == null) {
            offer = new ArrayList<Offer>();
        }
        return this.offer;
    }

    /**
     * Obtiene el valor de la propiedad applicationType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationType() {
        return applicationType;
    }

    /**
     * Define el valor de la propiedad applicationType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationType(String value) {
        this.applicationType = value;
    }

    /**
     * Obtiene el valor de la propiedad offerErrorCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferErrorCode() {
        return offerErrorCode;
    }

    /**
     * Define el valor de la propiedad offerErrorCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferErrorCode(String value) {
        this.offerErrorCode = value;
    }

    /**
     * Obtiene el valor de la propiedad supportType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSupportType() {
        return supportType;
    }

    /**
     * Define el valor de la propiedad supportType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSupportType(String value) {
        this.supportType = value;
    }

    /**
     * Obtiene el valor de la propiedad enhancedDueDiligenceFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnhancedDueDiligenceFlag() {
        return enhancedDueDiligenceFlag;
    }

    /**
     * Define el valor de la propiedad enhancedDueDiligenceFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnhancedDueDiligenceFlag(String value) {
        this.enhancedDueDiligenceFlag = value;
    }

}
