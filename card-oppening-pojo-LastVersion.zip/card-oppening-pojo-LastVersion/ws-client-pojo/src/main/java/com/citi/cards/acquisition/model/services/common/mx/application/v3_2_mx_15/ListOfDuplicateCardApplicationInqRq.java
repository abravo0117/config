
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.Address;
import com.citi.cards.acquisition.model.shared.datatypes.v3_1_0_0.StructuredName;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.AccessLog;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.ListRq;


/**
 * <p>Clase Java para ListOfDuplicateCardApplicationInqRq complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ListOfDuplicateCardApplicationInqRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AccessLog" type="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}AccessLog" minOccurs="0"/>
 *         &lt;element name="ListRq" type="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}ListRq" minOccurs="0"/>
 *         &lt;element name="Initiator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BranchID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicantName" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}StructuredName" minOccurs="0"/>
 *         &lt;element name="TaxID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DateOfBirth" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="CustomerNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InquiryIndicator" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="SalesAgentCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Address" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}Address" minOccurs="0"/>
 *         &lt;element name="PhoneticKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfDuplicateCardApplicationInqRq", propOrder = {
    "accessLog",
    "listRq",
    "initiator",
    "branchID",
    "applicantName",
    "taxID",
    "dateOfBirth",
    "customerNo",
    "inquiryIndicator",
    "salesAgentCode",
    "address",
    "phoneticKey"
})
public class ListOfDuplicateCardApplicationInqRq {

    @XmlElement(name = "AccessLog")
    protected AccessLog accessLog;
    @XmlElement(name = "ListRq")
    protected ListRq listRq;
    @XmlElement(name = "Initiator")
    protected String initiator;
    @XmlElement(name = "BranchID")
    protected String branchID;
    @XmlElement(name = "ApplicantName")
    protected StructuredName applicantName;
    @XmlElement(name = "TaxID")
    protected String taxID;
    @XmlElement(name = "DateOfBirth")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateOfBirth;
    @XmlElement(name = "CustomerNo")
    protected String customerNo;
    @XmlElement(name = "InquiryIndicator")
    protected String inquiryIndicator;
    @XmlElement(name = "SalesAgentCode")
    protected String salesAgentCode;
    @XmlElement(name = "Address")
    protected Address address;
    @XmlElement(name = "PhoneticKey")
    protected String phoneticKey;

    /**
     * Obtiene el valor de la propiedad accessLog.
     * 
     * @return
     *     possible object is
     *     {@link AccessLog }
     *     
     */
    public AccessLog getAccessLog() {
        return accessLog;
    }

    /**
     * Define el valor de la propiedad accessLog.
     * 
     * @param value
     *     allowed object is
     *     {@link AccessLog }
     *     
     */
    public void setAccessLog(AccessLog value) {
        this.accessLog = value;
    }

    /**
     * Obtiene el valor de la propiedad listRq.
     * 
     * @return
     *     possible object is
     *     {@link ListRq }
     *     
     */
    public ListRq getListRq() {
        return listRq;
    }

    /**
     * Define el valor de la propiedad listRq.
     * 
     * @param value
     *     allowed object is
     *     {@link ListRq }
     *     
     */
    public void setListRq(ListRq value) {
        this.listRq = value;
    }

    /**
     * Obtiene el valor de la propiedad initiator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInitiator() {
        return initiator;
    }

    /**
     * Define el valor de la propiedad initiator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInitiator(String value) {
        this.initiator = value;
    }

    /**
     * Obtiene el valor de la propiedad branchID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchID() {
        return branchID;
    }

    /**
     * Define el valor de la propiedad branchID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchID(String value) {
        this.branchID = value;
    }

    /**
     * Obtiene el valor de la propiedad applicantName.
     * 
     * @return
     *     possible object is
     *     {@link StructuredName }
     *     
     */
    public StructuredName getApplicantName() {
        return applicantName;
    }

    /**
     * Define el valor de la propiedad applicantName.
     * 
     * @param value
     *     allowed object is
     *     {@link StructuredName }
     *     
     */
    public void setApplicantName(StructuredName value) {
        this.applicantName = value;
    }

    /**
     * Obtiene el valor de la propiedad taxID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxID() {
        return taxID;
    }

    /**
     * Define el valor de la propiedad taxID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxID(String value) {
        this.taxID = value;
    }

    /**
     * Obtiene el valor de la propiedad dateOfBirth.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Define el valor de la propiedad dateOfBirth.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateOfBirth(XMLGregorianCalendar value) {
        this.dateOfBirth = value;
    }

    /**
     * Obtiene el valor de la propiedad customerNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerNo() {
        return customerNo;
    }

    /**
     * Define el valor de la propiedad customerNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerNo(String value) {
        this.customerNo = value;
    }

    /**
     * Obtiene el valor de la propiedad inquiryIndicator.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInquiryIndicator() {
        return inquiryIndicator;
    }

    /**
     * Define el valor de la propiedad inquiryIndicator.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInquiryIndicator(String value) {
        this.inquiryIndicator = value;
    }

    /**
     * Obtiene el valor de la propiedad salesAgentCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesAgentCode() {
        return salesAgentCode;
    }

    /**
     * Define el valor de la propiedad salesAgentCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesAgentCode(String value) {
        this.salesAgentCode = value;
    }

    /**
     * Obtiene el valor de la propiedad address.
     * 
     * @return
     *     possible object is
     *     {@link Address }
     *     
     */
    public Address getAddress() {
        return address;
    }

    /**
     * Define el valor de la propiedad address.
     * 
     * @param value
     *     allowed object is
     *     {@link Address }
     *     
     */
    public void setAddress(Address value) {
        this.address = value;
    }

    /**
     * Obtiene el valor de la propiedad phoneticKey.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPhoneticKey() {
        return phoneticKey;
    }

    /**
     * Define el valor de la propiedad phoneticKey.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPhoneticKey(String value) {
        this.phoneticKey = value;
    }

}
