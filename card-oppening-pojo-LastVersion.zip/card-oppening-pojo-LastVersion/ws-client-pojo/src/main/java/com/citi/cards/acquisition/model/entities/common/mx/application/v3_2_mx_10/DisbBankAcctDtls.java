
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para DisbBankAcctDtls complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DisbBankAcctDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="OfferID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PaymentType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RoutingCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountTitle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TrxAccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DisbBankAcctDtls", propOrder = {
    "offerID",
    "seqNo",
    "custNo",
    "paymentType",
    "routingCD",
    "accountTitle",
    "trxAccountNo"
})
public class DisbBankAcctDtls {

    @XmlElement(name = "OfferID")
    protected String offerID;
    @XmlElement(name = "SeqNo")
    protected String seqNo;
    @XmlElement(name = "CustNo")
    protected String custNo;
    @XmlElement(name = "PaymentType")
    protected String paymentType;
    @XmlElement(name = "RoutingCD")
    protected String routingCD;
    @XmlElement(name = "AccountTitle")
    protected String accountTitle;
    @XmlElement(name = "TrxAccountNo")
    protected String trxAccountNo;

    /**
     * Obtiene el valor de la propiedad offerID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfferID() {
        return offerID;
    }

    /**
     * Define el valor de la propiedad offerID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfferID(String value) {
        this.offerID = value;
    }

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad custNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustNo() {
        return custNo;
    }

    /**
     * Define el valor de la propiedad custNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustNo(String value) {
        this.custNo = value;
    }

    /**
     * Obtiene el valor de la propiedad paymentType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentType() {
        return paymentType;
    }

    /**
     * Define el valor de la propiedad paymentType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentType(String value) {
        this.paymentType = value;
    }

    /**
     * Obtiene el valor de la propiedad routingCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoutingCD() {
        return routingCD;
    }

    /**
     * Define el valor de la propiedad routingCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoutingCD(String value) {
        this.routingCD = value;
    }

    /**
     * Obtiene el valor de la propiedad accountTitle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountTitle() {
        return accountTitle;
    }

    /**
     * Define el valor de la propiedad accountTitle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountTitle(String value) {
        this.accountTitle = value;
    }

    /**
     * Obtiene el valor de la propiedad trxAccountNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrxAccountNo() {
        return trxAccountNo;
    }

    /**
     * Define el valor de la propiedad trxAccountNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrxAccountNo(String value) {
        this.trxAccountNo = value;
    }

}
