
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10.ApplicationSummary;
import com.citi.cards.acquisition.model.shared.util.v3_1_0_0.GenericResponse;


/**
 * <p>Clase Java para GetApplicationSummaryRs complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="GetApplicationSummaryRs">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}GenericResponse">
 *       &lt;sequence>
 *         &lt;element name="ResponseDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicationSummary" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}ApplicationSummary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GetApplicationSummaryRs", propOrder = {
    "responseDesc",
    "applicationSummary"
})
public class GetApplicationSummaryRs
    extends GenericResponse
{

    @XmlElement(name = "ResponseDesc")
    protected String responseDesc;
    @XmlElement(name = "ApplicationSummary")
    protected ApplicationSummary applicationSummary;

    /**
     * Obtiene el valor de la propiedad responseDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseDesc() {
        return responseDesc;
    }

    /**
     * Define el valor de la propiedad responseDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseDesc(String value) {
        this.responseDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad applicationSummary.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationSummary }
     *     
     */
    public ApplicationSummary getApplicationSummary() {
        return applicationSummary;
    }

    /**
     * Define el valor de la propiedad applicationSummary.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationSummary }
     *     
     */
    public void setApplicationSummary(ApplicationSummary value) {
        this.applicationSummary = value;
    }

}
