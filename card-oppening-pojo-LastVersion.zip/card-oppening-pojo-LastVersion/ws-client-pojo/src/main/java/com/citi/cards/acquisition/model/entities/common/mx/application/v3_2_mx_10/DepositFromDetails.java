
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para DepositFromDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DepositFromDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DebitAcctNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAcctCtl1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAcctCtl2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAcctCtl3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAcctCtl4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAcctPrdCd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAcctCcy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAcctTitle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAcctstatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAcctBalance" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CheckNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CheckProcBrc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ValueDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FxRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BmFxRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FxMatchInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FxRefNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LcyEquiv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UsdEquiv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProdDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOF" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DebitAcctSysId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SOFDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DepositFromDetails", propOrder = {
    "debitAcctNo",
    "debitAcctCtl1",
    "debitAcctCtl2",
    "debitAcctCtl3",
    "debitAcctCtl4",
    "debitAcctPrdCd",
    "debitAcctCcy",
    "debitAcctTitle",
    "debitAcctstatus",
    "debitAcctBalance",
    "debitAmt",
    "checkNo",
    "checkProcBrc",
    "valueDate",
    "fxRate",
    "bmFxRate",
    "fxMatchInd",
    "fxRefNo",
    "lcyEquiv",
    "usdEquiv",
    "seqNo",
    "prodDesc",
    "sof",
    "debitAcctSysId",
    "sofDesc"
})
public class DepositFromDetails {

    @XmlElement(name = "DebitAcctNo")
    protected String debitAcctNo;
    @XmlElement(name = "DebitAcctCtl1")
    protected String debitAcctCtl1;
    @XmlElement(name = "DebitAcctCtl2")
    protected String debitAcctCtl2;
    @XmlElement(name = "DebitAcctCtl3")
    protected String debitAcctCtl3;
    @XmlElement(name = "DebitAcctCtl4")
    protected String debitAcctCtl4;
    @XmlElement(name = "DebitAcctPrdCd")
    protected String debitAcctPrdCd;
    @XmlElement(name = "DebitAcctCcy")
    protected String debitAcctCcy;
    @XmlElement(name = "DebitAcctTitle")
    protected String debitAcctTitle;
    @XmlElement(name = "DebitAcctstatus")
    protected String debitAcctstatus;
    @XmlElement(name = "DebitAcctBalance")
    protected String debitAcctBalance;
    @XmlElement(name = "DebitAmt")
    protected String debitAmt;
    @XmlElement(name = "CheckNo")
    protected String checkNo;
    @XmlElement(name = "CheckProcBrc")
    protected String checkProcBrc;
    @XmlElement(name = "ValueDate")
    protected String valueDate;
    @XmlElement(name = "FxRate")
    protected String fxRate;
    @XmlElement(name = "BmFxRate")
    protected String bmFxRate;
    @XmlElement(name = "FxMatchInd")
    protected String fxMatchInd;
    @XmlElement(name = "FxRefNo")
    protected String fxRefNo;
    @XmlElement(name = "LcyEquiv")
    protected String lcyEquiv;
    @XmlElement(name = "UsdEquiv")
    protected String usdEquiv;
    @XmlElement(name = "SeqNo")
    protected String seqNo;
    @XmlElement(name = "ProdDesc")
    protected String prodDesc;
    @XmlElement(name = "SOF")
    protected String sof;
    @XmlElement(name = "DebitAcctSysId")
    protected String debitAcctSysId;
    @XmlElement(name = "SOFDesc")
    protected String sofDesc;

    /**
     * Obtiene el valor de la propiedad debitAcctNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAcctNo() {
        return debitAcctNo;
    }

    /**
     * Define el valor de la propiedad debitAcctNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAcctNo(String value) {
        this.debitAcctNo = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAcctCtl1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAcctCtl1() {
        return debitAcctCtl1;
    }

    /**
     * Define el valor de la propiedad debitAcctCtl1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAcctCtl1(String value) {
        this.debitAcctCtl1 = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAcctCtl2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAcctCtl2() {
        return debitAcctCtl2;
    }

    /**
     * Define el valor de la propiedad debitAcctCtl2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAcctCtl2(String value) {
        this.debitAcctCtl2 = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAcctCtl3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAcctCtl3() {
        return debitAcctCtl3;
    }

    /**
     * Define el valor de la propiedad debitAcctCtl3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAcctCtl3(String value) {
        this.debitAcctCtl3 = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAcctCtl4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAcctCtl4() {
        return debitAcctCtl4;
    }

    /**
     * Define el valor de la propiedad debitAcctCtl4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAcctCtl4(String value) {
        this.debitAcctCtl4 = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAcctPrdCd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAcctPrdCd() {
        return debitAcctPrdCd;
    }

    /**
     * Define el valor de la propiedad debitAcctPrdCd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAcctPrdCd(String value) {
        this.debitAcctPrdCd = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAcctCcy.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAcctCcy() {
        return debitAcctCcy;
    }

    /**
     * Define el valor de la propiedad debitAcctCcy.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAcctCcy(String value) {
        this.debitAcctCcy = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAcctTitle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAcctTitle() {
        return debitAcctTitle;
    }

    /**
     * Define el valor de la propiedad debitAcctTitle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAcctTitle(String value) {
        this.debitAcctTitle = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAcctstatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAcctstatus() {
        return debitAcctstatus;
    }

    /**
     * Define el valor de la propiedad debitAcctstatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAcctstatus(String value) {
        this.debitAcctstatus = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAcctBalance.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAcctBalance() {
        return debitAcctBalance;
    }

    /**
     * Define el valor de la propiedad debitAcctBalance.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAcctBalance(String value) {
        this.debitAcctBalance = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAmt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAmt() {
        return debitAmt;
    }

    /**
     * Define el valor de la propiedad debitAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAmt(String value) {
        this.debitAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad checkNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckNo() {
        return checkNo;
    }

    /**
     * Define el valor de la propiedad checkNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckNo(String value) {
        this.checkNo = value;
    }

    /**
     * Obtiene el valor de la propiedad checkProcBrc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckProcBrc() {
        return checkProcBrc;
    }

    /**
     * Define el valor de la propiedad checkProcBrc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckProcBrc(String value) {
        this.checkProcBrc = value;
    }

    /**
     * Obtiene el valor de la propiedad valueDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValueDate() {
        return valueDate;
    }

    /**
     * Define el valor de la propiedad valueDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValueDate(String value) {
        this.valueDate = value;
    }

    /**
     * Obtiene el valor de la propiedad fxRate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFxRate() {
        return fxRate;
    }

    /**
     * Define el valor de la propiedad fxRate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFxRate(String value) {
        this.fxRate = value;
    }

    /**
     * Obtiene el valor de la propiedad bmFxRate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBmFxRate() {
        return bmFxRate;
    }

    /**
     * Define el valor de la propiedad bmFxRate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBmFxRate(String value) {
        this.bmFxRate = value;
    }

    /**
     * Obtiene el valor de la propiedad fxMatchInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFxMatchInd() {
        return fxMatchInd;
    }

    /**
     * Define el valor de la propiedad fxMatchInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFxMatchInd(String value) {
        this.fxMatchInd = value;
    }

    /**
     * Obtiene el valor de la propiedad fxRefNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFxRefNo() {
        return fxRefNo;
    }

    /**
     * Define el valor de la propiedad fxRefNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFxRefNo(String value) {
        this.fxRefNo = value;
    }

    /**
     * Obtiene el valor de la propiedad lcyEquiv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLcyEquiv() {
        return lcyEquiv;
    }

    /**
     * Define el valor de la propiedad lcyEquiv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLcyEquiv(String value) {
        this.lcyEquiv = value;
    }

    /**
     * Obtiene el valor de la propiedad usdEquiv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUsdEquiv() {
        return usdEquiv;
    }

    /**
     * Define el valor de la propiedad usdEquiv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUsdEquiv(String value) {
        this.usdEquiv = value;
    }

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad prodDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdDesc() {
        return prodDesc;
    }

    /**
     * Define el valor de la propiedad prodDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdDesc(String value) {
        this.prodDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad sof.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOF() {
        return sof;
    }

    /**
     * Define el valor de la propiedad sof.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOF(String value) {
        this.sof = value;
    }

    /**
     * Obtiene el valor de la propiedad debitAcctSysId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAcctSysId() {
        return debitAcctSysId;
    }

    /**
     * Define el valor de la propiedad debitAcctSysId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAcctSysId(String value) {
        this.debitAcctSysId = value;
    }

    /**
     * Obtiene el valor de la propiedad sofDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSOFDesc() {
        return sofDesc;
    }

    /**
     * Define el valor de la propiedad sofDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSOFDesc(String value) {
        this.sofDesc = value;
    }

}
