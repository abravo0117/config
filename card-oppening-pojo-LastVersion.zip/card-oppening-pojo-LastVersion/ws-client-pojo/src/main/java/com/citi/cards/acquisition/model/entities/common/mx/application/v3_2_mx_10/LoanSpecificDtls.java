
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para LoanSpecificDtls complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="LoanSpecificDtls">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Asset" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesVolume" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BillToDelivery" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CollateralVal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RCOFlag" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PromotionCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ChkBranchCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LoanRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditLnAmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Tenor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InterestRate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InvoiceAmt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanSpecificDtls", propOrder = {
    "asset",
    "salesVolume",
    "billToDelivery",
    "collateralVal",
    "rcoFlag",
    "promotionCD",
    "chkBranchCD",
    "loanRef",
    "creditLnAmt",
    "tenor",
    "interestRate",
    "invoiceAmt"
})
public class LoanSpecificDtls {

    @XmlElement(name = "Asset")
    protected String asset;
    @XmlElement(name = "SalesVolume")
    protected String salesVolume;
    @XmlElement(name = "BillToDelivery")
    protected String billToDelivery;
    @XmlElement(name = "CollateralVal")
    protected String collateralVal;
    @XmlElement(name = "RCOFlag")
    protected String rcoFlag;
    @XmlElement(name = "PromotionCD")
    protected String promotionCD;
    @XmlElement(name = "ChkBranchCD")
    protected String chkBranchCD;
    @XmlElement(name = "LoanRef")
    protected String loanRef;
    @XmlElement(name = "CreditLnAmt")
    protected String creditLnAmt;
    @XmlElement(name = "Tenor")
    protected String tenor;
    @XmlElement(name = "InterestRate")
    protected String interestRate;
    @XmlElement(name = "InvoiceAmt")
    protected String invoiceAmt;

    /**
     * Obtiene el valor de la propiedad asset.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAsset() {
        return asset;
    }

    /**
     * Define el valor de la propiedad asset.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAsset(String value) {
        this.asset = value;
    }

    /**
     * Obtiene el valor de la propiedad salesVolume.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesVolume() {
        return salesVolume;
    }

    /**
     * Define el valor de la propiedad salesVolume.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesVolume(String value) {
        this.salesVolume = value;
    }

    /**
     * Obtiene el valor de la propiedad billToDelivery.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillToDelivery() {
        return billToDelivery;
    }

    /**
     * Define el valor de la propiedad billToDelivery.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillToDelivery(String value) {
        this.billToDelivery = value;
    }

    /**
     * Obtiene el valor de la propiedad collateralVal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollateralVal() {
        return collateralVal;
    }

    /**
     * Define el valor de la propiedad collateralVal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollateralVal(String value) {
        this.collateralVal = value;
    }

    /**
     * Obtiene el valor de la propiedad rcoFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRCOFlag() {
        return rcoFlag;
    }

    /**
     * Define el valor de la propiedad rcoFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRCOFlag(String value) {
        this.rcoFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad promotionCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPromotionCD() {
        return promotionCD;
    }

    /**
     * Define el valor de la propiedad promotionCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPromotionCD(String value) {
        this.promotionCD = value;
    }

    /**
     * Obtiene el valor de la propiedad chkBranchCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChkBranchCD() {
        return chkBranchCD;
    }

    /**
     * Define el valor de la propiedad chkBranchCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChkBranchCD(String value) {
        this.chkBranchCD = value;
    }

    /**
     * Obtiene el valor de la propiedad loanRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanRef() {
        return loanRef;
    }

    /**
     * Define el valor de la propiedad loanRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanRef(String value) {
        this.loanRef = value;
    }

    /**
     * Obtiene el valor de la propiedad creditLnAmt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditLnAmt() {
        return creditLnAmt;
    }

    /**
     * Define el valor de la propiedad creditLnAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditLnAmt(String value) {
        this.creditLnAmt = value;
    }

    /**
     * Obtiene el valor de la propiedad tenor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTenor() {
        return tenor;
    }

    /**
     * Define el valor de la propiedad tenor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTenor(String value) {
        this.tenor = value;
    }

    /**
     * Obtiene el valor de la propiedad interestRate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInterestRate() {
        return interestRate;
    }

    /**
     * Define el valor de la propiedad interestRate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInterestRate(String value) {
        this.interestRate = value;
    }

    /**
     * Obtiene el valor de la propiedad invoiceAmt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvoiceAmt() {
        return invoiceAmt;
    }

    /**
     * Define el valor de la propiedad invoiceAmt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvoiceAmt(String value) {
        this.invoiceAmt = value;
    }

}
