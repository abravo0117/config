
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para RelationshipDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="RelationshipDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExistNewInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelationshipNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelationshipType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelationshipTitle1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelationshipTitle2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelationshipCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelationshipShortname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="HoldMailInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MailInstrCd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="StaffRateInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SubStaffInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InvRiskProfCd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TrsRiskProf" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DataStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RcNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Branch" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Dept" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CostCenterDesc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CostCenter" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AoName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AoNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RcAo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CostRelPrcgGrp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtpBasicAct" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtpBasicActCtl1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtpBasicActCtl2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PrimaryCustomerKey" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}PrimaryCustomerKey"/>
 *         &lt;element name="CustomerKey" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerKey" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="EstmtFlg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelnTitleTrunc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RelationshipDetails", propOrder = {
    "seqNo",
    "existNewInd",
    "relationshipNo",
    "relationshipType",
    "relationshipTitle1",
    "relationshipTitle2",
    "relationshipCategory",
    "relationshipShortname",
    "holdMailInd",
    "mailInstrCd",
    "staffRateInd",
    "subStaffInd",
    "invRiskProfCd",
    "trsRiskProf",
    "dataStatus",
    "rcNo",
    "branch",
    "dept",
    "costCenterDesc",
    "costCenter",
    "aoName",
    "aoNo",
    "rcAo",
    "costRelPrcgGrp",
    "ctpBasicAct",
    "ctpBasicActCtl1",
    "ctpBasicActCtl2",
    "primaryCustomerKey",
    "customerKey",
    "estmtFlg",
    "relnTitleTrunc"
})
public class RelationshipDetails {

    @XmlElement(name = "SeqNo")
    protected String seqNo;
    @XmlElement(name = "ExistNewInd")
    protected String existNewInd;
    @XmlElement(name = "RelationshipNo")
    protected String relationshipNo;
    @XmlElement(name = "RelationshipType")
    protected String relationshipType;
    @XmlElement(name = "RelationshipTitle1")
    protected String relationshipTitle1;
    @XmlElement(name = "RelationshipTitle2")
    protected String relationshipTitle2;
    @XmlElement(name = "RelationshipCategory")
    protected String relationshipCategory;
    @XmlElement(name = "RelationshipShortname")
    protected String relationshipShortname;
    @XmlElement(name = "HoldMailInd")
    protected String holdMailInd;
    @XmlElement(name = "MailInstrCd")
    protected String mailInstrCd;
    @XmlElement(name = "StaffRateInd")
    protected String staffRateInd;
    @XmlElement(name = "SubStaffInd")
    protected String subStaffInd;
    @XmlElement(name = "InvRiskProfCd")
    protected String invRiskProfCd;
    @XmlElement(name = "TrsRiskProf")
    protected String trsRiskProf;
    @XmlElement(name = "DataStatus")
    protected String dataStatus;
    @XmlElement(name = "RcNo")
    protected String rcNo;
    @XmlElement(name = "Branch")
    protected String branch;
    @XmlElement(name = "Dept")
    protected String dept;
    @XmlElement(name = "CostCenterDesc")
    protected String costCenterDesc;
    @XmlElement(name = "CostCenter")
    protected String costCenter;
    @XmlElement(name = "AoName")
    protected String aoName;
    @XmlElement(name = "AoNo")
    protected String aoNo;
    @XmlElement(name = "RcAo")
    protected String rcAo;
    @XmlElement(name = "CostRelPrcgGrp")
    protected String costRelPrcgGrp;
    @XmlElement(name = "CtpBasicAct")
    protected String ctpBasicAct;
    @XmlElement(name = "CtpBasicActCtl1")
    protected String ctpBasicActCtl1;
    @XmlElement(name = "CtpBasicActCtl2")
    protected String ctpBasicActCtl2;
    @XmlElement(name = "PrimaryCustomerKey", required = true)
    protected PrimaryCustomerKey primaryCustomerKey;
    @XmlElement(name = "CustomerKey")
    protected List<CustomerKey> customerKey;
    @XmlElement(name = "EstmtFlg")
    protected String estmtFlg;
    @XmlElement(name = "RelnTitleTrunc")
    protected String relnTitleTrunc;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad existNewInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExistNewInd() {
        return existNewInd;
    }

    /**
     * Define el valor de la propiedad existNewInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExistNewInd(String value) {
        this.existNewInd = value;
    }

    /**
     * Obtiene el valor de la propiedad relationshipNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipNo() {
        return relationshipNo;
    }

    /**
     * Define el valor de la propiedad relationshipNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipNo(String value) {
        this.relationshipNo = value;
    }

    /**
     * Obtiene el valor de la propiedad relationshipType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipType() {
        return relationshipType;
    }

    /**
     * Define el valor de la propiedad relationshipType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipType(String value) {
        this.relationshipType = value;
    }

    /**
     * Obtiene el valor de la propiedad relationshipTitle1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipTitle1() {
        return relationshipTitle1;
    }

    /**
     * Define el valor de la propiedad relationshipTitle1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipTitle1(String value) {
        this.relationshipTitle1 = value;
    }

    /**
     * Obtiene el valor de la propiedad relationshipTitle2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipTitle2() {
        return relationshipTitle2;
    }

    /**
     * Define el valor de la propiedad relationshipTitle2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipTitle2(String value) {
        this.relationshipTitle2 = value;
    }

    /**
     * Obtiene el valor de la propiedad relationshipCategory.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipCategory() {
        return relationshipCategory;
    }

    /**
     * Define el valor de la propiedad relationshipCategory.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipCategory(String value) {
        this.relationshipCategory = value;
    }

    /**
     * Obtiene el valor de la propiedad relationshipShortname.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelationshipShortname() {
        return relationshipShortname;
    }

    /**
     * Define el valor de la propiedad relationshipShortname.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelationshipShortname(String value) {
        this.relationshipShortname = value;
    }

    /**
     * Obtiene el valor de la propiedad holdMailInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldMailInd() {
        return holdMailInd;
    }

    /**
     * Define el valor de la propiedad holdMailInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldMailInd(String value) {
        this.holdMailInd = value;
    }

    /**
     * Obtiene el valor de la propiedad mailInstrCd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMailInstrCd() {
        return mailInstrCd;
    }

    /**
     * Define el valor de la propiedad mailInstrCd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMailInstrCd(String value) {
        this.mailInstrCd = value;
    }

    /**
     * Obtiene el valor de la propiedad staffRateInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStaffRateInd() {
        return staffRateInd;
    }

    /**
     * Define el valor de la propiedad staffRateInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStaffRateInd(String value) {
        this.staffRateInd = value;
    }

    /**
     * Obtiene el valor de la propiedad subStaffInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubStaffInd() {
        return subStaffInd;
    }

    /**
     * Define el valor de la propiedad subStaffInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubStaffInd(String value) {
        this.subStaffInd = value;
    }

    /**
     * Obtiene el valor de la propiedad invRiskProfCd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInvRiskProfCd() {
        return invRiskProfCd;
    }

    /**
     * Define el valor de la propiedad invRiskProfCd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInvRiskProfCd(String value) {
        this.invRiskProfCd = value;
    }

    /**
     * Obtiene el valor de la propiedad trsRiskProf.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrsRiskProf() {
        return trsRiskProf;
    }

    /**
     * Define el valor de la propiedad trsRiskProf.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrsRiskProf(String value) {
        this.trsRiskProf = value;
    }

    /**
     * Obtiene el valor de la propiedad dataStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataStatus() {
        return dataStatus;
    }

    /**
     * Define el valor de la propiedad dataStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataStatus(String value) {
        this.dataStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad rcNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcNo() {
        return rcNo;
    }

    /**
     * Define el valor de la propiedad rcNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcNo(String value) {
        this.rcNo = value;
    }

    /**
     * Obtiene el valor de la propiedad branch.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranch() {
        return branch;
    }

    /**
     * Define el valor de la propiedad branch.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranch(String value) {
        this.branch = value;
    }

    /**
     * Obtiene el valor de la propiedad dept.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDept() {
        return dept;
    }

    /**
     * Define el valor de la propiedad dept.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDept(String value) {
        this.dept = value;
    }

    /**
     * Obtiene el valor de la propiedad costCenterDesc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCostCenterDesc() {
        return costCenterDesc;
    }

    /**
     * Define el valor de la propiedad costCenterDesc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCostCenterDesc(String value) {
        this.costCenterDesc = value;
    }

    /**
     * Obtiene el valor de la propiedad costCenter.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCostCenter() {
        return costCenter;
    }

    /**
     * Define el valor de la propiedad costCenter.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCostCenter(String value) {
        this.costCenter = value;
    }

    /**
     * Obtiene el valor de la propiedad aoName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAoName() {
        return aoName;
    }

    /**
     * Define el valor de la propiedad aoName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAoName(String value) {
        this.aoName = value;
    }

    /**
     * Obtiene el valor de la propiedad aoNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAoNo() {
        return aoNo;
    }

    /**
     * Define el valor de la propiedad aoNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAoNo(String value) {
        this.aoNo = value;
    }

    /**
     * Obtiene el valor de la propiedad rcAo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRcAo() {
        return rcAo;
    }

    /**
     * Define el valor de la propiedad rcAo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRcAo(String value) {
        this.rcAo = value;
    }

    /**
     * Obtiene el valor de la propiedad costRelPrcgGrp.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCostRelPrcgGrp() {
        return costRelPrcgGrp;
    }

    /**
     * Define el valor de la propiedad costRelPrcgGrp.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCostRelPrcgGrp(String value) {
        this.costRelPrcgGrp = value;
    }

    /**
     * Obtiene el valor de la propiedad ctpBasicAct.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtpBasicAct() {
        return ctpBasicAct;
    }

    /**
     * Define el valor de la propiedad ctpBasicAct.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtpBasicAct(String value) {
        this.ctpBasicAct = value;
    }

    /**
     * Obtiene el valor de la propiedad ctpBasicActCtl1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtpBasicActCtl1() {
        return ctpBasicActCtl1;
    }

    /**
     * Define el valor de la propiedad ctpBasicActCtl1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtpBasicActCtl1(String value) {
        this.ctpBasicActCtl1 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctpBasicActCtl2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtpBasicActCtl2() {
        return ctpBasicActCtl2;
    }

    /**
     * Define el valor de la propiedad ctpBasicActCtl2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtpBasicActCtl2(String value) {
        this.ctpBasicActCtl2 = value;
    }

    /**
     * Obtiene el valor de la propiedad primaryCustomerKey.
     * 
     * @return
     *     possible object is
     *     {@link PrimaryCustomerKey }
     *     
     */
    public PrimaryCustomerKey getPrimaryCustomerKey() {
        return primaryCustomerKey;
    }

    /**
     * Define el valor de la propiedad primaryCustomerKey.
     * 
     * @param value
     *     allowed object is
     *     {@link PrimaryCustomerKey }
     *     
     */
    public void setPrimaryCustomerKey(PrimaryCustomerKey value) {
        this.primaryCustomerKey = value;
    }

    /**
     * Gets the value of the customerKey property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customerKey property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomerKey().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CustomerKey }
     * 
     * 
     */
    public List<CustomerKey> getCustomerKey() {
        if (customerKey == null) {
            customerKey = new ArrayList<CustomerKey>();
        }
        return this.customerKey;
    }

    /**
     * Obtiene el valor de la propiedad estmtFlg.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEstmtFlg() {
        return estmtFlg;
    }

    /**
     * Define el valor de la propiedad estmtFlg.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEstmtFlg(String value) {
        this.estmtFlg = value;
    }

    /**
     * Obtiene el valor de la propiedad relnTitleTrunc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnTitleTrunc() {
        return relnTitleTrunc;
    }

    /**
     * Define el valor de la propiedad relnTitleTrunc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnTitleTrunc(String value) {
        this.relnTitleTrunc = value;
    }

}
