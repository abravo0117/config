
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ProviderInfoDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ProviderInfoDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ProviderAccountNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProviderMobileNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProviderBillNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProviderInfoDetails", propOrder = {
    "providerAccountNo",
    "providerMobileNo",
    "providerBillNo"
})
public class ProviderInfoDetails {

    @XmlElement(name = "ProviderAccountNo")
    protected String providerAccountNo;
    @XmlElement(name = "ProviderMobileNo")
    protected String providerMobileNo;
    @XmlElement(name = "ProviderBillNo")
    protected String providerBillNo;

    /**
     * Obtiene el valor de la propiedad providerAccountNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderAccountNo() {
        return providerAccountNo;
    }

    /**
     * Define el valor de la propiedad providerAccountNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderAccountNo(String value) {
        this.providerAccountNo = value;
    }

    /**
     * Obtiene el valor de la propiedad providerMobileNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderMobileNo() {
        return providerMobileNo;
    }

    /**
     * Define el valor de la propiedad providerMobileNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderMobileNo(String value) {
        this.providerMobileNo = value;
    }

    /**
     * Obtiene el valor de la propiedad providerBillNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderBillNo() {
        return providerBillNo;
    }

    /**
     * Define el valor de la propiedad providerBillNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderBillNo(String value) {
        this.providerBillNo = value;
    }

}
