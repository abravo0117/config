
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para CustomerEmploymentDetails complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CustomerEmploymentDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SeqNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="EmprName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="JobTitle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="OccCD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmplStrtDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmplEndDt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmployeeID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MonthlySalary" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndustryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AnnlInc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AnnlIncRange" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SelfEmplInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmplSinceYrs" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmplOnMnth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmprStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NoOfEmployees" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Department" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmprAddrLine1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmprAddrLine2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmprAddrLine3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmprAddrLine4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmprCity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmprState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmprZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmprCountry" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmprConfirmation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TotalExprYrs" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CustomerEmploymentDetails", propOrder = {
    "seqNo",
    "emprName",
    "jobTitle",
    "occCD",
    "emplStrtDt",
    "emplEndDt",
    "employeeID",
    "monthlySalary",
    "industryCode",
    "annlInc",
    "annlIncRange",
    "selfEmplInd",
    "emplSinceYrs",
    "emplOnMnth",
    "emprStatus",
    "noOfEmployees",
    "department",
    "emprAddrLine1",
    "emprAddrLine2",
    "emprAddrLine3",
    "emprAddrLine4",
    "emprCity",
    "emprState",
    "emprZip",
    "emprCountry",
    "emprConfirmation",
    "totalExprYrs"
})
public class CustomerEmploymentDetails {

    @XmlElement(name = "SeqNo", required = true)
    protected String seqNo;
    @XmlElement(name = "EmprName")
    protected String emprName;
    @XmlElement(name = "JobTitle")
    protected String jobTitle;
    @XmlElement(name = "OccCD")
    protected String occCD;
    @XmlElement(name = "EmplStrtDt")
    protected String emplStrtDt;
    @XmlElement(name = "EmplEndDt")
    protected String emplEndDt;
    @XmlElement(name = "EmployeeID")
    protected String employeeID;
    @XmlElement(name = "MonthlySalary")
    protected String monthlySalary;
    @XmlElement(name = "IndustryCode")
    protected String industryCode;
    @XmlElement(name = "AnnlInc")
    protected String annlInc;
    @XmlElement(name = "AnnlIncRange")
    protected String annlIncRange;
    @XmlElement(name = "SelfEmplInd")
    protected String selfEmplInd;
    @XmlElement(name = "EmplSinceYrs")
    protected String emplSinceYrs;
    @XmlElement(name = "EmplOnMnth")
    protected String emplOnMnth;
    @XmlElement(name = "EmprStatus")
    protected String emprStatus;
    @XmlElement(name = "NoOfEmployees")
    protected String noOfEmployees;
    @XmlElement(name = "Department")
    protected String department;
    @XmlElement(name = "EmprAddrLine1")
    protected String emprAddrLine1;
    @XmlElement(name = "EmprAddrLine2")
    protected String emprAddrLine2;
    @XmlElement(name = "EmprAddrLine3")
    protected String emprAddrLine3;
    @XmlElement(name = "EmprAddrLine4")
    protected String emprAddrLine4;
    @XmlElement(name = "EmprCity")
    protected String emprCity;
    @XmlElement(name = "EmprState")
    protected String emprState;
    @XmlElement(name = "EmprZip")
    protected String emprZip;
    @XmlElement(name = "EmprCountry")
    protected String emprCountry;
    @XmlElement(name = "EmprConfirmation")
    protected String emprConfirmation;
    @XmlElement(name = "TotalExprYrs")
    protected String totalExprYrs;

    /**
     * Obtiene el valor de la propiedad seqNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqNo() {
        return seqNo;
    }

    /**
     * Define el valor de la propiedad seqNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqNo(String value) {
        this.seqNo = value;
    }

    /**
     * Obtiene el valor de la propiedad emprName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmprName() {
        return emprName;
    }

    /**
     * Define el valor de la propiedad emprName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmprName(String value) {
        this.emprName = value;
    }

    /**
     * Obtiene el valor de la propiedad jobTitle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * Define el valor de la propiedad jobTitle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobTitle(String value) {
        this.jobTitle = value;
    }

    /**
     * Obtiene el valor de la propiedad occCD.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOccCD() {
        return occCD;
    }

    /**
     * Define el valor de la propiedad occCD.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOccCD(String value) {
        this.occCD = value;
    }

    /**
     * Obtiene el valor de la propiedad emplStrtDt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmplStrtDt() {
        return emplStrtDt;
    }

    /**
     * Define el valor de la propiedad emplStrtDt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmplStrtDt(String value) {
        this.emplStrtDt = value;
    }

    /**
     * Obtiene el valor de la propiedad emplEndDt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmplEndDt() {
        return emplEndDt;
    }

    /**
     * Define el valor de la propiedad emplEndDt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmplEndDt(String value) {
        this.emplEndDt = value;
    }

    /**
     * Obtiene el valor de la propiedad employeeID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeID() {
        return employeeID;
    }

    /**
     * Define el valor de la propiedad employeeID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeID(String value) {
        this.employeeID = value;
    }

    /**
     * Obtiene el valor de la propiedad monthlySalary.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMonthlySalary() {
        return monthlySalary;
    }

    /**
     * Define el valor de la propiedad monthlySalary.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMonthlySalary(String value) {
        this.monthlySalary = value;
    }

    /**
     * Obtiene el valor de la propiedad industryCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndustryCode() {
        return industryCode;
    }

    /**
     * Define el valor de la propiedad industryCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndustryCode(String value) {
        this.industryCode = value;
    }

    /**
     * Obtiene el valor de la propiedad annlInc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnnlInc() {
        return annlInc;
    }

    /**
     * Define el valor de la propiedad annlInc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnnlInc(String value) {
        this.annlInc = value;
    }

    /**
     * Obtiene el valor de la propiedad annlIncRange.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnnlIncRange() {
        return annlIncRange;
    }

    /**
     * Define el valor de la propiedad annlIncRange.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnnlIncRange(String value) {
        this.annlIncRange = value;
    }

    /**
     * Obtiene el valor de la propiedad selfEmplInd.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSelfEmplInd() {
        return selfEmplInd;
    }

    /**
     * Define el valor de la propiedad selfEmplInd.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSelfEmplInd(String value) {
        this.selfEmplInd = value;
    }

    /**
     * Obtiene el valor de la propiedad emplSinceYrs.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmplSinceYrs() {
        return emplSinceYrs;
    }

    /**
     * Define el valor de la propiedad emplSinceYrs.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmplSinceYrs(String value) {
        this.emplSinceYrs = value;
    }

    /**
     * Obtiene el valor de la propiedad emplOnMnth.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmplOnMnth() {
        return emplOnMnth;
    }

    /**
     * Define el valor de la propiedad emplOnMnth.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmplOnMnth(String value) {
        this.emplOnMnth = value;
    }

    /**
     * Obtiene el valor de la propiedad emprStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmprStatus() {
        return emprStatus;
    }

    /**
     * Define el valor de la propiedad emprStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmprStatus(String value) {
        this.emprStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad noOfEmployees.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoOfEmployees() {
        return noOfEmployees;
    }

    /**
     * Define el valor de la propiedad noOfEmployees.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoOfEmployees(String value) {
        this.noOfEmployees = value;
    }

    /**
     * Obtiene el valor de la propiedad department.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepartment() {
        return department;
    }

    /**
     * Define el valor de la propiedad department.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepartment(String value) {
        this.department = value;
    }

    /**
     * Obtiene el valor de la propiedad emprAddrLine1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmprAddrLine1() {
        return emprAddrLine1;
    }

    /**
     * Define el valor de la propiedad emprAddrLine1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmprAddrLine1(String value) {
        this.emprAddrLine1 = value;
    }

    /**
     * Obtiene el valor de la propiedad emprAddrLine2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmprAddrLine2() {
        return emprAddrLine2;
    }

    /**
     * Define el valor de la propiedad emprAddrLine2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmprAddrLine2(String value) {
        this.emprAddrLine2 = value;
    }

    /**
     * Obtiene el valor de la propiedad emprAddrLine3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmprAddrLine3() {
        return emprAddrLine3;
    }

    /**
     * Define el valor de la propiedad emprAddrLine3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmprAddrLine3(String value) {
        this.emprAddrLine3 = value;
    }

    /**
     * Obtiene el valor de la propiedad emprAddrLine4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmprAddrLine4() {
        return emprAddrLine4;
    }

    /**
     * Define el valor de la propiedad emprAddrLine4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmprAddrLine4(String value) {
        this.emprAddrLine4 = value;
    }

    /**
     * Obtiene el valor de la propiedad emprCity.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmprCity() {
        return emprCity;
    }

    /**
     * Define el valor de la propiedad emprCity.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmprCity(String value) {
        this.emprCity = value;
    }

    /**
     * Obtiene el valor de la propiedad emprState.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmprState() {
        return emprState;
    }

    /**
     * Define el valor de la propiedad emprState.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmprState(String value) {
        this.emprState = value;
    }

    /**
     * Obtiene el valor de la propiedad emprZip.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmprZip() {
        return emprZip;
    }

    /**
     * Define el valor de la propiedad emprZip.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmprZip(String value) {
        this.emprZip = value;
    }

    /**
     * Obtiene el valor de la propiedad emprCountry.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmprCountry() {
        return emprCountry;
    }

    /**
     * Define el valor de la propiedad emprCountry.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmprCountry(String value) {
        this.emprCountry = value;
    }

    /**
     * Obtiene el valor de la propiedad emprConfirmation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmprConfirmation() {
        return emprConfirmation;
    }

    /**
     * Define el valor de la propiedad emprConfirmation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmprConfirmation(String value) {
        this.emprConfirmation = value;
    }

    /**
     * Obtiene el valor de la propiedad totalExprYrs.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTotalExprYrs() {
        return totalExprYrs;
    }

    /**
     * Define el valor de la propiedad totalExprYrs.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTotalExprYrs(String value) {
        this.totalExprYrs = value;
    }

}
