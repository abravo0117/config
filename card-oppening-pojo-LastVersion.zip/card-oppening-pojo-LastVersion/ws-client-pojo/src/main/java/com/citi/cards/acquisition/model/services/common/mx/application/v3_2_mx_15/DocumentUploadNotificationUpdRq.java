
package com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Clase Java para DocumentUploadNotificationUpdRq complex type.
 * 
 * <p>
 * El siguiente fragmento de esquema especifica el contenido que se espera que
 * haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="DocumentUploadNotificationUpdRq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ApplicantID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UserID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {"applicantID", "userID"})
public class DocumentUploadNotificationUpdRq {

    @XmlElement(name = "ApplicantID", required = true,
        namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_7")
    protected String applicantID;

    @XmlElement(name = "UserID",
        namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_7")
    protected String userID;

    /**
     * Obtiene el valor de la propiedad applicantID.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getApplicantID() {

        return applicantID;
    }

    /**
     * Define el valor de la propiedad applicantID.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setApplicantID(String value) {

        this.applicantID = value;
    }

    /**
     * Obtiene el valor de la propiedad userID.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getUserID() {

        return userID;
    }

    /**
     * Define el valor de la propiedad userID.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setUserID(String value) {

        this.userID = value;
    }

}
