
package com.citi.cards.acquisition.model.shared.util.v3_1_0_0;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.ApplicationFullDetailsInqRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.ApplicationStatusAndStageInqRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.CardApplicationAddRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.DocumentUploadNotificationUpdRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.GenerateApplicationRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.GetApplicationSummaryRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.ListOfCardApplicationInqRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.ListOfDuplicateCardApplicationInqRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.LoanApplicationAddRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.LoanApplicationFullDetailsInqRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.MemoAddRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PendingAccountOpeningApplicationInqRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardAcceptUpdRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardRejectUpdRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreprocessCardApplicationInqRs;
import com.citi.cards.acquisition.model.shared.system.header.RsHeader;


/**
 * <p>Clase Java para GenericResponse complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="GenericResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RsHeader" type="{http://www.citi.com/gcgi/shared/system/header}RsHeader" minOccurs="0"/>
 *         &lt;element name="ProviderInfo" type="{http://www.citi.com/gcgi/shared/util/v3_1_0_0}ProviderInfo" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GenericResponse", propOrder = {
    "rsHeader",
    "providerInfo"
})
@XmlSeeAlso({
    PreprocessCardApplicationInqRs.class,
    ApplicationStatusAndStageInqRs.class,
    LoanApplicationFullDetailsInqRs.class,
    PreCreatedCardAcceptUpdRs.class,
    LoanApplicationAddRs.class,
    PreCreatedCardRejectUpdRs.class,
    GetApplicationSummaryRs.class,
    ListOfCardApplicationInqRs.class,
    MemoAddRs.class,
    ListOfDuplicateCardApplicationInqRs.class,
    GenerateApplicationRs.class,
    ApplicationFullDetailsInqRs.class,
    DocumentUploadNotificationUpdRs.class,
    PendingAccountOpeningApplicationInqRs.class,
    CardApplicationAddRs.class
})
public class GenericResponse {

    @XmlElement(name = "RsHeader")
    protected RsHeader rsHeader;
    @XmlElement(name = "ProviderInfo")
    protected List<ProviderInfo> providerInfo;

    /**
     * Obtiene el valor de la propiedad rsHeader.
     * 
     * @return
     *     possible object is
     *     {@link RsHeader }
     *     
     */
    public RsHeader getRsHeader() {
        return rsHeader;
    }

    /**
     * Define el valor de la propiedad rsHeader.
     * 
     * @param value
     *     allowed object is
     *     {@link RsHeader }
     *     
     */
    public void setRsHeader(RsHeader value) {
        this.rsHeader = value;
    }

    /**
     * Gets the value of the providerInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the providerInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProviderInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProviderInfo }
     * 
     * 
     */
    public List<ProviderInfo> getProviderInfo() {
        if (providerInfo == null) {
            providerInfo = new ArrayList<ProviderInfo>();
        }
        return this.providerInfo;
    }

}
