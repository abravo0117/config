
package com.citi.cards.acquisition.model.entities.common.mx.application.v3_2_mx_10;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.citi.cards.acquisition.model.shared.datatypes.v3_1_0_0.StructuredName;


/**
 * <p>Clase Java para BasicData complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="BasicData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Prefix" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NameEnglish" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}StructuredName" minOccurs="0"/>
 *         &lt;element name="NameLocal" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}StructuredName" minOccurs="0"/>
 *         &lt;element name="PlaceofIssue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BirthDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Gender" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Nationality" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Domicile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PermanentResidence" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EducationLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MaritalStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PlaceOfResidence" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RelnWithApplicant" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MGMReferenceNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NoOfDependents" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CorrespondenceLangauge" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResidentType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ResidentStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="YearOfGraduation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicantRole" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="EmerContactName" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}StructuredName" minOccurs="0"/>
 *         &lt;element name="CtrySpecField1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CtrySpecField4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditBureauAuthenticationFlag" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}Indicator" minOccurs="0"/>
 *         &lt;element name="isBanamexCustomer" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isCreditCardHolder" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isProductUpgradeRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isCreditLineIncreaseRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isTermsAndConditionsAccepted" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isCreditBureauConsultingAccepted" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isRevolvingCreditContractAccepted" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isUserContractAccepted" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="isSpecificBankingSegmentCustomer" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="BankingSegment" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Division" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CollegeNoOfApprovedSubjects" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hasCollegeScholarship" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CollegeScholarshipLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CollegeScholarshipType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CollegeStartDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CollegeEndDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CollegeUniversityName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CollegeNoOfSubjects" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CollegeAverageMarks" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CollegeSemester" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditsAndLiabilitiesReferenceDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CreditsAndLiabilitiesReferenceDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ClubPremierMembershipNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CustomerNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AccountNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}AccountNo" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="SocialSecurityNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NationalIDIssueNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NationalIDOCR" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TypeOfPerson" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CountryOfBirth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PlaceOfBirth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isRetired" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="TypeOfRetirement" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isVIP" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ProviderNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ElectricCompanyServiceNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TVServiceCompany" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DataVerificationComments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ContractMemo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ReferenceMemo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApplicantMemo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SUSCControlNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BanamexCreditCardNo" type="{http://www.citi.com/gcgi/shared/datatypes/v3_1_0_0}CardNo" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="hasOtherBankCard" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="hasMortgageLoan" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="hasAutomobileLoan" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="hasDepartmentStoreCard" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="AuthenticationInstitution" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditBureauAuthenticationBank" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CreditCardLastFourDigits" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isOtherCreditEvaluationRequested" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="PersonalReferences" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}PersonalReference" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CustomerIDDetails" type="{http://www.citi.com/gcgi/entities/common/MX/application/v3_2_MX_10}CustomerIDDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="NationalTaxID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CURPUniqueNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FIELSerialNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PassportSerialNo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NationalIDCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isPrimaryAddress" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BasicData", propOrder = {
    "prefix",
    "nameEnglish",
    "nameLocal",
    "placeofIssue",
    "birthDate",
    "gender",
    "emailAddress",
    "nationality",
    "domicile",
    "permanentResidence",
    "educationLevel",
    "maritalStatus",
    "placeOfResidence",
    "relnWithApplicant",
    "mgmReferenceNo",
    "noOfDependents",
    "correspondenceLangauge",
    "residentType",
    "residentStatus",
    "yearOfGraduation",
    "applicantRole",
    "emerContactName",
    "ctrySpecField1",
    "ctrySpecField2",
    "ctrySpecField3",
    "ctrySpecField4",
    "creditBureauAuthenticationFlag",
    "isBanamexCustomer",
    "isCreditCardHolder",
    "isProductUpgradeRequested",
    "isCreditLineIncreaseRequested",
    "isTermsAndConditionsAccepted",
    "isCreditBureauConsultingAccepted",
    "isRevolvingCreditContractAccepted",
    "isUserContractAccepted",
    "isSpecificBankingSegmentCustomer",
    "bankingSegment",
    "division",
    "collegeNoOfApprovedSubjects",
    "hasCollegeScholarship",
    "collegeScholarshipLevel",
    "collegeScholarshipType",
    "collegeStartDate",
    "collegeEndDate",
    "collegeUniversityName",
    "collegeNoOfSubjects",
    "collegeAverageMarks",
    "collegeSemester",
    "creditsAndLiabilitiesReferenceDetails",
    "clubPremierMembershipNo",
    "customerNo",
    "accountNo",
    "socialSecurityNo",
    "nationalIDIssueNumber",
    "nationalIDOCR",
    "typeOfPerson",
    "countryOfBirth",
    "placeOfBirth",
    "isRetired",
    "typeOfRetirement",
    "isVIP",
    "providerNo",
    "electricCompanyServiceNo",
    "tvServiceCompany",
    "dataVerificationComments",
    "contractMemo",
    "referenceMemo",
    "applicantMemo",
    "suscControlNo",
    "banamexCreditCardNo",
    "hasOtherBankCard",
    "hasMortgageLoan",
    "hasAutomobileLoan",
    "hasDepartmentStoreCard",
    "authenticationInstitution",
    "creditBureauAuthenticationBank",
    "creditCardLastFourDigits",
    "isOtherCreditEvaluationRequested",
    "personalReferences",
    "customerIDDetails",
    "nationalTaxID",
    "curpUniqueNo",
    "fielSerialNo",
    "passportSerialNo",
    "nationalIDCode",
    "isPrimaryAddress"
})
public class BasicData {

    @XmlElement(name = "Prefix")
    protected String prefix;
    @XmlElement(name = "NameEnglish")
    protected StructuredName nameEnglish;
    @XmlElement(name = "NameLocal")
    protected StructuredName nameLocal;
    @XmlElement(name = "PlaceofIssue")
    protected String placeofIssue;
    @XmlElement(name = "BirthDate")
    protected String birthDate;
    @XmlElement(name = "Gender")
    protected String gender;
    @XmlElement(name = "EmailAddress")
    protected String emailAddress;
    @XmlElement(name = "Nationality")
    protected String nationality;
    @XmlElement(name = "Domicile")
    protected String domicile;
    @XmlElement(name = "PermanentResidence")
    protected String permanentResidence;
    @XmlElement(name = "EducationLevel")
    protected String educationLevel;
    @XmlElement(name = "MaritalStatus")
    protected String maritalStatus;
    @XmlElement(name = "PlaceOfResidence")
    protected String placeOfResidence;
    @XmlElement(name = "RelnWithApplicant")
    protected String relnWithApplicant;
    @XmlElement(name = "MGMReferenceNo")
    protected String mgmReferenceNo;
    @XmlElement(name = "NoOfDependents")
    protected String noOfDependents;
    @XmlElement(name = "CorrespondenceLangauge")
    protected String correspondenceLangauge;
    @XmlElement(name = "ResidentType")
    protected String residentType;
    @XmlElement(name = "ResidentStatus")
    protected String residentStatus;
    @XmlElement(name = "YearOfGraduation")
    protected String yearOfGraduation;
    @XmlElement(name = "ApplicantRole", required = true)
    protected String applicantRole;
    @XmlElement(name = "EmerContactName")
    protected StructuredName emerContactName;
    @XmlElement(name = "CtrySpecField1")
    protected String ctrySpecField1;
    @XmlElement(name = "CtrySpecField2")
    protected String ctrySpecField2;
    @XmlElement(name = "CtrySpecField3")
    protected String ctrySpecField3;
    @XmlElement(name = "CtrySpecField4")
    protected String ctrySpecField4;
    @XmlElement(name = "CreditBureauAuthenticationFlag")
    protected String creditBureauAuthenticationFlag;
    protected String isBanamexCustomer;
    protected String isCreditCardHolder;
    protected String isProductUpgradeRequested;
    protected String isCreditLineIncreaseRequested;
    protected String isTermsAndConditionsAccepted;
    protected String isCreditBureauConsultingAccepted;
    protected String isRevolvingCreditContractAccepted;
    protected String isUserContractAccepted;
    protected String isSpecificBankingSegmentCustomer;
    @XmlElement(name = "BankingSegment")
    protected String bankingSegment;
    @XmlElement(name = "Division")
    protected String division;
    @XmlElement(name = "CollegeNoOfApprovedSubjects")
    protected String collegeNoOfApprovedSubjects;
    protected String hasCollegeScholarship;
    @XmlElement(name = "CollegeScholarshipLevel")
    protected String collegeScholarshipLevel;
    @XmlElement(name = "CollegeScholarshipType")
    protected String collegeScholarshipType;
    @XmlElement(name = "CollegeStartDate")
    protected String collegeStartDate;
    @XmlElement(name = "CollegeEndDate")
    protected String collegeEndDate;
    @XmlElement(name = "CollegeUniversityName")
    protected String collegeUniversityName;
    @XmlElement(name = "CollegeNoOfSubjects")
    protected String collegeNoOfSubjects;
    @XmlElement(name = "CollegeAverageMarks")
    protected String collegeAverageMarks;
    @XmlElement(name = "CollegeSemester")
    protected String collegeSemester;
    @XmlElement(name = "CreditsAndLiabilitiesReferenceDetails")
    protected List<CreditsAndLiabilitiesReferenceDetails> creditsAndLiabilitiesReferenceDetails;
    @XmlElement(name = "ClubPremierMembershipNo")
    protected String clubPremierMembershipNo;
    @XmlElement(name = "CustomerNo")
    protected String customerNo;
    @XmlElement(name = "AccountNo")
    protected List<String> accountNo;
    @XmlElement(name = "SocialSecurityNo")
    protected String socialSecurityNo;
    @XmlElement(name = "NationalIDIssueNumber")
    protected String nationalIDIssueNumber;
    @XmlElement(name = "NationalIDOCR")
    protected String nationalIDOCR;
    @XmlElement(name = "TypeOfPerson")
    protected String typeOfPerson;
    @XmlElement(name = "CountryOfBirth")
    protected String countryOfBirth;
    @XmlElement(name = "PlaceOfBirth")
    protected String placeOfBirth;
    protected String isRetired;
    @XmlElement(name = "TypeOfRetirement")
    protected String typeOfRetirement;
    protected String isVIP;
    @XmlElement(name = "ProviderNo")
    protected String providerNo;
    @XmlElement(name = "ElectricCompanyServiceNo")
    protected String electricCompanyServiceNo;
    @XmlElement(name = "TVServiceCompany")
    protected String tvServiceCompany;
    @XmlElement(name = "DataVerificationComments")
    protected String dataVerificationComments;
    @XmlElement(name = "ContractMemo")
    protected String contractMemo;
    @XmlElement(name = "ReferenceMemo")
    protected String referenceMemo;
    @XmlElement(name = "ApplicantMemo")
    protected String applicantMemo;
    @XmlElement(name = "SUSCControlNo")
    protected String suscControlNo;
    @XmlElement(name = "BanamexCreditCardNo")
    protected List<String> banamexCreditCardNo;
    protected String hasOtherBankCard;
    protected String hasMortgageLoan;
    protected String hasAutomobileLoan;
    protected String hasDepartmentStoreCard;
    @XmlElement(name = "AuthenticationInstitution")
    protected String authenticationInstitution;
    @XmlElement(name = "CreditBureauAuthenticationBank")
    protected String creditBureauAuthenticationBank;
    @XmlElement(name = "CreditCardLastFourDigits")
    protected String creditCardLastFourDigits;
    protected String isOtherCreditEvaluationRequested;
    @XmlElement(name = "PersonalReferences")
    protected List<PersonalReference> personalReferences;
    @XmlElement(name = "CustomerIDDetails")
    protected List<CustomerIDDetails> customerIDDetails;
    @XmlElement(name = "NationalTaxID")
    protected String nationalTaxID;
    @XmlElement(name = "CURPUniqueNo")
    protected String curpUniqueNo;
    @XmlElement(name = "FIELSerialNo")
    protected String fielSerialNo;
    @XmlElement(name = "PassportSerialNo")
    protected String passportSerialNo;
    @XmlElement(name = "NationalIDCode")
    protected String nationalIDCode;
    protected String isPrimaryAddress;

    /**
     * Obtiene el valor de la propiedad prefix.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrefix() {
        return prefix;
    }

    /**
     * Define el valor de la propiedad prefix.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrefix(String value) {
        this.prefix = value;
    }

    /**
     * Obtiene el valor de la propiedad nameEnglish.
     * 
     * @return
     *     possible object is
     *     {@link StructuredName }
     *     
     */
    public StructuredName getNameEnglish() {
        return nameEnglish;
    }

    /**
     * Define el valor de la propiedad nameEnglish.
     * 
     * @param value
     *     allowed object is
     *     {@link StructuredName }
     *     
     */
    public void setNameEnglish(StructuredName value) {
        this.nameEnglish = value;
    }

    /**
     * Obtiene el valor de la propiedad nameLocal.
     * 
     * @return
     *     possible object is
     *     {@link StructuredName }
     *     
     */
    public StructuredName getNameLocal() {
        return nameLocal;
    }

    /**
     * Define el valor de la propiedad nameLocal.
     * 
     * @param value
     *     allowed object is
     *     {@link StructuredName }
     *     
     */
    public void setNameLocal(StructuredName value) {
        this.nameLocal = value;
    }

    /**
     * Obtiene el valor de la propiedad placeofIssue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlaceofIssue() {
        return placeofIssue;
    }

    /**
     * Define el valor de la propiedad placeofIssue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlaceofIssue(String value) {
        this.placeofIssue = value;
    }

    /**
     * Obtiene el valor de la propiedad birthDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBirthDate() {
        return birthDate;
    }

    /**
     * Define el valor de la propiedad birthDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBirthDate(String value) {
        this.birthDate = value;
    }

    /**
     * Obtiene el valor de la propiedad gender.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGender() {
        return gender;
    }

    /**
     * Define el valor de la propiedad gender.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGender(String value) {
        this.gender = value;
    }

    /**
     * Obtiene el valor de la propiedad emailAddress.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Define el valor de la propiedad emailAddress.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAddress(String value) {
        this.emailAddress = value;
    }

    /**
     * Obtiene el valor de la propiedad nationality.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNationality() {
        return nationality;
    }

    /**
     * Define el valor de la propiedad nationality.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNationality(String value) {
        this.nationality = value;
    }

    /**
     * Obtiene el valor de la propiedad domicile.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDomicile() {
        return domicile;
    }

    /**
     * Define el valor de la propiedad domicile.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDomicile(String value) {
        this.domicile = value;
    }

    /**
     * Obtiene el valor de la propiedad permanentResidence.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPermanentResidence() {
        return permanentResidence;
    }

    /**
     * Define el valor de la propiedad permanentResidence.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPermanentResidence(String value) {
        this.permanentResidence = value;
    }

    /**
     * Obtiene el valor de la propiedad educationLevel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEducationLevel() {
        return educationLevel;
    }

    /**
     * Define el valor de la propiedad educationLevel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEducationLevel(String value) {
        this.educationLevel = value;
    }

    /**
     * Obtiene el valor de la propiedad maritalStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * Define el valor de la propiedad maritalStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaritalStatus(String value) {
        this.maritalStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad placeOfResidence.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlaceOfResidence() {
        return placeOfResidence;
    }

    /**
     * Define el valor de la propiedad placeOfResidence.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlaceOfResidence(String value) {
        this.placeOfResidence = value;
    }

    /**
     * Obtiene el valor de la propiedad relnWithApplicant.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRelnWithApplicant() {
        return relnWithApplicant;
    }

    /**
     * Define el valor de la propiedad relnWithApplicant.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRelnWithApplicant(String value) {
        this.relnWithApplicant = value;
    }

    /**
     * Obtiene el valor de la propiedad mgmReferenceNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMGMReferenceNo() {
        return mgmReferenceNo;
    }

    /**
     * Define el valor de la propiedad mgmReferenceNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMGMReferenceNo(String value) {
        this.mgmReferenceNo = value;
    }

    /**
     * Obtiene el valor de la propiedad noOfDependents.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNoOfDependents() {
        return noOfDependents;
    }

    /**
     * Define el valor de la propiedad noOfDependents.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNoOfDependents(String value) {
        this.noOfDependents = value;
    }

    /**
     * Obtiene el valor de la propiedad correspondenceLangauge.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorrespondenceLangauge() {
        return correspondenceLangauge;
    }

    /**
     * Define el valor de la propiedad correspondenceLangauge.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorrespondenceLangauge(String value) {
        this.correspondenceLangauge = value;
    }

    /**
     * Obtiene el valor de la propiedad residentType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResidentType() {
        return residentType;
    }

    /**
     * Define el valor de la propiedad residentType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResidentType(String value) {
        this.residentType = value;
    }

    /**
     * Obtiene el valor de la propiedad residentStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResidentStatus() {
        return residentStatus;
    }

    /**
     * Define el valor de la propiedad residentStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResidentStatus(String value) {
        this.residentStatus = value;
    }

    /**
     * Obtiene el valor de la propiedad yearOfGraduation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getYearOfGraduation() {
        return yearOfGraduation;
    }

    /**
     * Define el valor de la propiedad yearOfGraduation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setYearOfGraduation(String value) {
        this.yearOfGraduation = value;
    }

    /**
     * Obtiene el valor de la propiedad applicantRole.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicantRole() {
        return applicantRole;
    }

    /**
     * Define el valor de la propiedad applicantRole.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicantRole(String value) {
        this.applicantRole = value;
    }

    /**
     * Obtiene el valor de la propiedad emerContactName.
     * 
     * @return
     *     possible object is
     *     {@link StructuredName }
     *     
     */
    public StructuredName getEmerContactName() {
        return emerContactName;
    }

    /**
     * Define el valor de la propiedad emerContactName.
     * 
     * @param value
     *     allowed object is
     *     {@link StructuredName }
     *     
     */
    public void setEmerContactName(StructuredName value) {
        this.emerContactName = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField1.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField1() {
        return ctrySpecField1;
    }

    /**
     * Define el valor de la propiedad ctrySpecField1.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField1(String value) {
        this.ctrySpecField1 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField2.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField2() {
        return ctrySpecField2;
    }

    /**
     * Define el valor de la propiedad ctrySpecField2.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField2(String value) {
        this.ctrySpecField2 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField3.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField3() {
        return ctrySpecField3;
    }

    /**
     * Define el valor de la propiedad ctrySpecField3.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField3(String value) {
        this.ctrySpecField3 = value;
    }

    /**
     * Obtiene el valor de la propiedad ctrySpecField4.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtrySpecField4() {
        return ctrySpecField4;
    }

    /**
     * Define el valor de la propiedad ctrySpecField4.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtrySpecField4(String value) {
        this.ctrySpecField4 = value;
    }

    /**
     * Obtiene el valor de la propiedad creditBureauAuthenticationFlag.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditBureauAuthenticationFlag() {
        return creditBureauAuthenticationFlag;
    }

    /**
     * Define el valor de la propiedad creditBureauAuthenticationFlag.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditBureauAuthenticationFlag(String value) {
        this.creditBureauAuthenticationFlag = value;
    }

    /**
     * Obtiene el valor de la propiedad isBanamexCustomer.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsBanamexCustomer() {
        return isBanamexCustomer;
    }

    /**
     * Define el valor de la propiedad isBanamexCustomer.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsBanamexCustomer(String value) {
        this.isBanamexCustomer = value;
    }

    /**
     * Obtiene el valor de la propiedad isCreditCardHolder.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsCreditCardHolder() {
        return isCreditCardHolder;
    }

    /**
     * Define el valor de la propiedad isCreditCardHolder.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsCreditCardHolder(String value) {
        this.isCreditCardHolder = value;
    }

    /**
     * Obtiene el valor de la propiedad isProductUpgradeRequested.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsProductUpgradeRequested() {
        return isProductUpgradeRequested;
    }

    /**
     * Define el valor de la propiedad isProductUpgradeRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsProductUpgradeRequested(String value) {
        this.isProductUpgradeRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad isCreditLineIncreaseRequested.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsCreditLineIncreaseRequested() {
        return isCreditLineIncreaseRequested;
    }

    /**
     * Define el valor de la propiedad isCreditLineIncreaseRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsCreditLineIncreaseRequested(String value) {
        this.isCreditLineIncreaseRequested = value;
    }

    /**
     * Obtiene el valor de la propiedad isTermsAndConditionsAccepted.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsTermsAndConditionsAccepted() {
        return isTermsAndConditionsAccepted;
    }

    /**
     * Define el valor de la propiedad isTermsAndConditionsAccepted.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsTermsAndConditionsAccepted(String value) {
        this.isTermsAndConditionsAccepted = value;
    }

    /**
     * Obtiene el valor de la propiedad isCreditBureauConsultingAccepted.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsCreditBureauConsultingAccepted() {
        return isCreditBureauConsultingAccepted;
    }

    /**
     * Define el valor de la propiedad isCreditBureauConsultingAccepted.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsCreditBureauConsultingAccepted(String value) {
        this.isCreditBureauConsultingAccepted = value;
    }

    /**
     * Obtiene el valor de la propiedad isRevolvingCreditContractAccepted.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsRevolvingCreditContractAccepted() {
        return isRevolvingCreditContractAccepted;
    }

    /**
     * Define el valor de la propiedad isRevolvingCreditContractAccepted.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsRevolvingCreditContractAccepted(String value) {
        this.isRevolvingCreditContractAccepted = value;
    }

    /**
     * Obtiene el valor de la propiedad isUserContractAccepted.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsUserContractAccepted() {
        return isUserContractAccepted;
    }

    /**
     * Define el valor de la propiedad isUserContractAccepted.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsUserContractAccepted(String value) {
        this.isUserContractAccepted = value;
    }

    /**
     * Obtiene el valor de la propiedad isSpecificBankingSegmentCustomer.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsSpecificBankingSegmentCustomer() {
        return isSpecificBankingSegmentCustomer;
    }

    /**
     * Define el valor de la propiedad isSpecificBankingSegmentCustomer.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsSpecificBankingSegmentCustomer(String value) {
        this.isSpecificBankingSegmentCustomer = value;
    }

    /**
     * Obtiene el valor de la propiedad bankingSegment.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankingSegment() {
        return bankingSegment;
    }

    /**
     * Define el valor de la propiedad bankingSegment.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankingSegment(String value) {
        this.bankingSegment = value;
    }

    /**
     * Obtiene el valor de la propiedad division.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDivision() {
        return division;
    }

    /**
     * Define el valor de la propiedad division.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDivision(String value) {
        this.division = value;
    }

    /**
     * Obtiene el valor de la propiedad collegeNoOfApprovedSubjects.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollegeNoOfApprovedSubjects() {
        return collegeNoOfApprovedSubjects;
    }

    /**
     * Define el valor de la propiedad collegeNoOfApprovedSubjects.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollegeNoOfApprovedSubjects(String value) {
        this.collegeNoOfApprovedSubjects = value;
    }

    /**
     * Obtiene el valor de la propiedad hasCollegeScholarship.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isHasCollegeScholarship() {
        return hasCollegeScholarship;
    }

    /**
     * Define el valor de la propiedad hasCollegeScholarship.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasCollegeScholarship(String value) {
        this.hasCollegeScholarship = value;
    }

    /**
     * Obtiene el valor de la propiedad collegeScholarshipLevel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollegeScholarshipLevel() {
        return collegeScholarshipLevel;
    }

    /**
     * Define el valor de la propiedad collegeScholarshipLevel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollegeScholarshipLevel(String value) {
        this.collegeScholarshipLevel = value;
    }

    /**
     * Obtiene el valor de la propiedad collegeScholarshipType.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollegeScholarshipType() {
        return collegeScholarshipType;
    }

    /**
     * Define el valor de la propiedad collegeScholarshipType.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollegeScholarshipType(String value) {
        this.collegeScholarshipType = value;
    }

    /**
     * Obtiene el valor de la propiedad collegeStartDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollegeStartDate() {
        return collegeStartDate;
    }

    /**
     * Define el valor de la propiedad collegeStartDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollegeStartDate(String value) {
        this.collegeStartDate = value;
    }

    /**
     * Obtiene el valor de la propiedad collegeEndDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollegeEndDate() {
        return collegeEndDate;
    }

    /**
     * Define el valor de la propiedad collegeEndDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollegeEndDate(String value) {
        this.collegeEndDate = value;
    }

    /**
     * Obtiene el valor de la propiedad collegeUniversityName.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollegeUniversityName() {
        return collegeUniversityName;
    }

    /**
     * Define el valor de la propiedad collegeUniversityName.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollegeUniversityName(String value) {
        this.collegeUniversityName = value;
    }

    /**
     * Obtiene el valor de la propiedad collegeNoOfSubjects.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollegeNoOfSubjects() {
        return collegeNoOfSubjects;
    }

    /**
     * Define el valor de la propiedad collegeNoOfSubjects.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollegeNoOfSubjects(String value) {
        this.collegeNoOfSubjects = value;
    }

    /**
     * Obtiene el valor de la propiedad collegeAverageMarks.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollegeAverageMarks() {
        return collegeAverageMarks;
    }

    /**
     * Define el valor de la propiedad collegeAverageMarks.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollegeAverageMarks(String value) {
        this.collegeAverageMarks = value;
    }

    /**
     * Obtiene el valor de la propiedad collegeSemester.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCollegeSemester() {
        return collegeSemester;
    }

    /**
     * Define el valor de la propiedad collegeSemester.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCollegeSemester(String value) {
        this.collegeSemester = value;
    }

    /**
     * Gets the value of the creditsAndLiabilitiesReferenceDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the creditsAndLiabilitiesReferenceDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCreditsAndLiabilitiesReferenceDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CreditsAndLiabilitiesReferenceDetails }
     * 
     * 
     */
    public List<CreditsAndLiabilitiesReferenceDetails> getCreditsAndLiabilitiesReferenceDetails() {
        if (creditsAndLiabilitiesReferenceDetails == null) {
            creditsAndLiabilitiesReferenceDetails = new ArrayList<CreditsAndLiabilitiesReferenceDetails>();
        }
        return this.creditsAndLiabilitiesReferenceDetails;
    }

    /**
     * Obtiene el valor de la propiedad clubPremierMembershipNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClubPremierMembershipNo() {
        return clubPremierMembershipNo;
    }

    /**
     * Define el valor de la propiedad clubPremierMembershipNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClubPremierMembershipNo(String value) {
        this.clubPremierMembershipNo = value;
    }

    /**
     * Obtiene el valor de la propiedad customerNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerNo() {
        return customerNo;
    }

    /**
     * Define el valor de la propiedad customerNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerNo(String value) {
        this.customerNo = value;
    }

    /**
     * Gets the value of the accountNo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the accountNo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccountNo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getAccountNo() {
        if (accountNo == null) {
            accountNo = new ArrayList<String>();
        }
        return this.accountNo;
    }

    /**
     * Obtiene el valor de la propiedad socialSecurityNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSocialSecurityNo() {
        return socialSecurityNo;
    }

    /**
     * Define el valor de la propiedad socialSecurityNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSocialSecurityNo(String value) {
        this.socialSecurityNo = value;
    }

    /**
     * Obtiene el valor de la propiedad nationalIDIssueNumber.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNationalIDIssueNumber() {
        return nationalIDIssueNumber;
    }

    /**
     * Define el valor de la propiedad nationalIDIssueNumber.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNationalIDIssueNumber(String value) {
        this.nationalIDIssueNumber = value;
    }

    /**
     * Obtiene el valor de la propiedad nationalIDOCR.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNationalIDOCR() {
        return nationalIDOCR;
    }

    /**
     * Define el valor de la propiedad nationalIDOCR.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNationalIDOCR(String value) {
        this.nationalIDOCR = value;
    }

    /**
     * Obtiene el valor de la propiedad typeOfPerson.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfPerson() {
        return typeOfPerson;
    }

    /**
     * Define el valor de la propiedad typeOfPerson.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfPerson(String value) {
        this.typeOfPerson = value;
    }

    /**
     * Obtiene el valor de la propiedad countryOfBirth.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountryOfBirth() {
        return countryOfBirth;
    }

    /**
     * Define el valor de la propiedad countryOfBirth.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountryOfBirth(String value) {
        this.countryOfBirth = value;
    }

    /**
     * Obtiene el valor de la propiedad placeOfBirth.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlaceOfBirth() {
        return placeOfBirth;
    }

    /**
     * Define el valor de la propiedad placeOfBirth.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlaceOfBirth(String value) {
        this.placeOfBirth = value;
    }

    /**
     * Obtiene el valor de la propiedad isRetired.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsRetired() {
        return isRetired;
    }

    /**
     * Define el valor de la propiedad isRetired.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsRetired(String value) {
        this.isRetired = value;
    }

    /**
     * Obtiene el valor de la propiedad typeOfRetirement.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOfRetirement() {
        return typeOfRetirement;
    }

    /**
     * Define el valor de la propiedad typeOfRetirement.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOfRetirement(String value) {
        this.typeOfRetirement = value;
    }

    /**
     * Obtiene el valor de la propiedad isVIP.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsVIP() {
        return isVIP;
    }

    /**
     * Define el valor de la propiedad isVIP.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsVIP(String value) {
        this.isVIP = value;
    }

    /**
     * Obtiene el valor de la propiedad providerNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderNo() {
        return providerNo;
    }

    /**
     * Define el valor de la propiedad providerNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderNo(String value) {
        this.providerNo = value;
    }

    /**
     * Obtiene el valor de la propiedad electricCompanyServiceNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getElectricCompanyServiceNo() {
        return electricCompanyServiceNo;
    }

    /**
     * Define el valor de la propiedad electricCompanyServiceNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setElectricCompanyServiceNo(String value) {
        this.electricCompanyServiceNo = value;
    }

    /**
     * Obtiene el valor de la propiedad tvServiceCompany.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTVServiceCompany() {
        return tvServiceCompany;
    }

    /**
     * Define el valor de la propiedad tvServiceCompany.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTVServiceCompany(String value) {
        this.tvServiceCompany = value;
    }

    /**
     * Obtiene el valor de la propiedad dataVerificationComments.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDataVerificationComments() {
        return dataVerificationComments;
    }

    /**
     * Define el valor de la propiedad dataVerificationComments.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDataVerificationComments(String value) {
        this.dataVerificationComments = value;
    }

    /**
     * Obtiene el valor de la propiedad contractMemo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractMemo() {
        return contractMemo;
    }

    /**
     * Define el valor de la propiedad contractMemo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractMemo(String value) {
        this.contractMemo = value;
    }

    /**
     * Obtiene el valor de la propiedad referenceMemo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenceMemo() {
        return referenceMemo;
    }

    /**
     * Define el valor de la propiedad referenceMemo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenceMemo(String value) {
        this.referenceMemo = value;
    }

    /**
     * Obtiene el valor de la propiedad applicantMemo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicantMemo() {
        return applicantMemo;
    }

    /**
     * Define el valor de la propiedad applicantMemo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicantMemo(String value) {
        this.applicantMemo = value;
    }

    /**
     * Obtiene el valor de la propiedad suscControlNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSUSCControlNo() {
        return suscControlNo;
    }

    /**
     * Define el valor de la propiedad suscControlNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSUSCControlNo(String value) {
        this.suscControlNo = value;
    }

    /**
     * Gets the value of the banamexCreditCardNo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the banamexCreditCardNo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBanamexCreditCardNo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getBanamexCreditCardNo() {
        if (banamexCreditCardNo == null) {
            banamexCreditCardNo = new ArrayList<String>();
        }
        return this.banamexCreditCardNo;
    }

    /**
     * Obtiene el valor de la propiedad hasOtherBankCard.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isHasOtherBankCard() {
        return hasOtherBankCard;
    }

    /**
     * Define el valor de la propiedad hasOtherBankCard.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasOtherBankCard(String value) {
        this.hasOtherBankCard = value;
    }

    /**
     * Obtiene el valor de la propiedad hasMortgageLoan.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isHasMortgageLoan() {
        return hasMortgageLoan;
    }

    /**
     * Define el valor de la propiedad hasMortgageLoan.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasMortgageLoan(String value) {
        this.hasMortgageLoan = value;
    }

    /**
     * Obtiene el valor de la propiedad hasAutomobileLoan.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isHasAutomobileLoan() {
        return hasAutomobileLoan;
    }

    /**
     * Define el valor de la propiedad hasAutomobileLoan.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasAutomobileLoan(String value) {
        this.hasAutomobileLoan = value;
    }

    /**
     * Obtiene el valor de la propiedad hasDepartmentStoreCard.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isHasDepartmentStoreCard() {
        return hasDepartmentStoreCard;
    }

    /**
     * Define el valor de la propiedad hasDepartmentStoreCard.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHasDepartmentStoreCard(String value) {
        this.hasDepartmentStoreCard = value;
    }

    /**
     * Obtiene el valor de la propiedad authenticationInstitution.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthenticationInstitution() {
        return authenticationInstitution;
    }

    /**
     * Define el valor de la propiedad authenticationInstitution.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthenticationInstitution(String value) {
        this.authenticationInstitution = value;
    }

    /**
     * Obtiene el valor de la propiedad creditBureauAuthenticationBank.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditBureauAuthenticationBank() {
        return creditBureauAuthenticationBank;
    }

    /**
     * Define el valor de la propiedad creditBureauAuthenticationBank.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditBureauAuthenticationBank(String value) {
        this.creditBureauAuthenticationBank = value;
    }

    /**
     * Obtiene el valor de la propiedad creditCardLastFourDigits.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreditCardLastFourDigits() {
        return creditCardLastFourDigits;
    }

    /**
     * Define el valor de la propiedad creditCardLastFourDigits.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreditCardLastFourDigits(String value) {
        this.creditCardLastFourDigits = value;
    }

    /**
     * Obtiene el valor de la propiedad isOtherCreditEvaluationRequested.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsOtherCreditEvaluationRequested() {
        return isOtherCreditEvaluationRequested;
    }

    /**
     * Define el valor de la propiedad isOtherCreditEvaluationRequested.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsOtherCreditEvaluationRequested(String value) {
        this.isOtherCreditEvaluationRequested = value;
    }

    /**
     * Gets the value of the personalReferences property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the personalReferences property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPersonalReferences().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PersonalReference }
     * 
     * 
     */
    public List<PersonalReference> getPersonalReferences() {
        if (personalReferences == null) {
            personalReferences = new ArrayList<PersonalReference>();
        }
        return this.personalReferences;
    }

    /**
     * Gets the value of the customerIDDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the customerIDDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCustomerIDDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CustomerIDDetails }
     * 
     * 
     */
    public List<CustomerIDDetails> getCustomerIDDetails() {
        if (customerIDDetails == null) {
            customerIDDetails = new ArrayList<CustomerIDDetails>();
        }
        return this.customerIDDetails;
    }

    /**
     * Obtiene el valor de la propiedad nationalTaxID.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNationalTaxID() {
        return nationalTaxID;
    }

    /**
     * Define el valor de la propiedad nationalTaxID.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNationalTaxID(String value) {
        this.nationalTaxID = value;
    }

    /**
     * Obtiene el valor de la propiedad curpUniqueNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCURPUniqueNo() {
        return curpUniqueNo;
    }

    /**
     * Define el valor de la propiedad curpUniqueNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCURPUniqueNo(String value) {
        this.curpUniqueNo = value;
    }

    /**
     * Obtiene el valor de la propiedad fielSerialNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFIELSerialNo() {
        return fielSerialNo;
    }

    /**
     * Define el valor de la propiedad fielSerialNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFIELSerialNo(String value) {
        this.fielSerialNo = value;
    }

    /**
     * Obtiene el valor de la propiedad passportSerialNo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPassportSerialNo() {
        return passportSerialNo;
    }

    /**
     * Define el valor de la propiedad passportSerialNo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPassportSerialNo(String value) {
        this.passportSerialNo = value;
    }

    /**
     * Obtiene el valor de la propiedad nationalIDCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNationalIDCode() {
        return nationalIDCode;
    }

    /**
     * Define el valor de la propiedad nationalIDCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNationalIDCode(String value) {
        this.nationalIDCode = value;
    }

    /**
     * Obtiene el valor de la propiedad isPrimaryAddress.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String isIsPrimaryAddress() {
        return isPrimaryAddress;
    }

    /**
     * Define el valor de la propiedad isPrimaryAddress.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsPrimaryAddress(String value) {
        this.isPrimaryAddress = value;
    }

}
