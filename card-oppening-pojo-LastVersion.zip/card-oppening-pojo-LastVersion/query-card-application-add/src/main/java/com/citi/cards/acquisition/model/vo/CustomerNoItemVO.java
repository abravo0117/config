/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CustomerNoItemVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

/**
 *  <code>CustomerNoItemVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class CustomerNoItemVO {

    /** cust no. */
    private String custNo;

    /**
     * Gets the cust no.
     *
     * @return cust no
     */
    public String getCustNo() {

        return custNo;
    }

    /**
     * Set the cust no.
     *
     * @param custNo  cust no
     */
    public void setCustNo(String custNo) {

        this.custNo = custNo;
    }

}
