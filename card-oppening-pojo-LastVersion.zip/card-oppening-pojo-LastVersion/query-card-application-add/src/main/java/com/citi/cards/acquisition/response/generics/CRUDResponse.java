/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CRUDResponse.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.response.generics;

import java.io.Serializable;

import org.springframework.http.HttpStatus;

/**
 *  <code>CRUDResponse</code>.
 *
 * @author vb44309
 * @version 1.0
 * @param <T> generic type
 */
public class CRUDResponse<T> extends AbstractBaseCrudResponse
    implements Serializable {

    /** data. */
    private T data; // NOSONAR

    /** The constant serialVersionUID. */
    private static final long serialVersionUID = 3863277132579863103L;

    /**
     * Creates a new instance of CRUD response.
     *
     * @param data data
     */
    public CRUDResponse(T data) {
        super(HttpStatus.OK);
        this.data = data;
    }

    /**
     * Gets the data.
     *
     * @return data
     */
    public T getData() {

        return data;
    }

}
