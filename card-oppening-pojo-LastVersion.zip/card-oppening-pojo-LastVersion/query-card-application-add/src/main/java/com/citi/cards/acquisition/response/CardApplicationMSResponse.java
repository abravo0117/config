/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CardApplicationMSResponse.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.response;

import java.util.GregorianCalendar;

/**
 *  <code>CardApplicationMSResponse</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class CardApplicationMSResponse {

    /** application ID. */
    private String applicationID;

    /** stage. */
    private String stage;

    /** status. */
    private String status;

    /** mobile phone ctry cd. */
    private String mobilePhoneCtryCd;

    /** mobile phone no. */
    private String mobilePhoneNo;

    /** agent type. */
    private String agentType;

    /** agent phone no. */
    private String agentPhoneNo;

    /** message code. */
    private String messageCode;

    /** external application ID. */
    private String externalApplicationID;

    /** application created date. */
    private GregorianCalendar applicationCreatedDate;

    /** application created time. */
    private GregorianCalendar applicationCreatedTime;

    /**
     * Gets the application ID.
     *
     * @return application ID
     */
    public String getApplicationID() {

        return applicationID;
    }

    /**
     * Set the application ID.
     *
     * @param applicationID  application ID
     */
    public void setApplicationID(String applicationID) {

        this.applicationID = applicationID;
    }

    /**
     * Gets the stage.
     *
     * @return stage
     */
    public String getStage() {

        return stage;
    }

    /**
     * Set the stage.
     *
     * @param stage  stage
     */
    public void setStage(String stage) {

        this.stage = stage;
    }

    /**
     * Gets the status.
     *
     * @return status
     */
    public String getStatus() {

        return status;
    }

    /**
     * Set the status.
     *
     * @param status  status
     */
    public void setStatus(String status) {

        this.status = status;
    }

    /**
     * Gets the mobile phone ctry cd.
     *
     * @return mobile phone ctry cd
     */
    public String getMobilePhoneCtryCd() {

        return mobilePhoneCtryCd;
    }

    /**
     * Set the mobile phone ctry cd.
     *
     * @param mobilePhoneCtryCd  mobile phone ctry cd
     */
    public void setMobilePhoneCtryCd(String mobilePhoneCtryCd) {

        this.mobilePhoneCtryCd = mobilePhoneCtryCd;
    }

    /**
     * Gets the mobile phone no.
     *
     * @return mobile phone no
     */
    public String getMobilePhoneNo() {

        return mobilePhoneNo;
    }

    /**
     * Set the mobile phone no.
     *
     * @param mobilePhoneNo  mobile phone no
     */
    public void setMobilePhoneNo(String mobilePhoneNo) {

        this.mobilePhoneNo = mobilePhoneNo;
    }

    /**
     * Gets the agent type.
     *
     * @return agent type
     */
    public String getAgentType() {

        return agentType;
    }

    /**
     * Set the agent type.
     *
     * @param agentType  agent type
     */
    public void setAgentType(String agentType) {

        this.agentType = agentType;
    }

    /**
     * Gets the agent phone no.
     *
     * @return agent phone no
     */
    public String getAgentPhoneNo() {

        return agentPhoneNo;
    }

    /**
     * Set the agent phone no.
     *
     * @param agentPhoneNo  agent phone no
     */
    public void setAgentPhoneNo(String agentPhoneNo) {

        this.agentPhoneNo = agentPhoneNo;
    }

    /**
     * Gets the message code.
     *
     * @return message code
     */
    public String getMessageCode() {

        return messageCode;
    }

    /**
     * Set the message code.
     *
     * @param messageCode  message code
     */
    public void setMessageCode(String messageCode) {

        this.messageCode = messageCode;
    }

    /**
     * Gets the external application ID.
     *
     * @return external application ID
     */
    public String getExternalApplicationID() {

        return externalApplicationID;
    }

    /**
     * Set the external application ID.
     *
     * @param externalApplicationID  external application ID
     */
    public void setExternalApplicationID(String externalApplicationID) {

        this.externalApplicationID = externalApplicationID;
    }

    /**
     * Gets the application created date.
     *
     * @return application created date
     */
    public GregorianCalendar getApplicationCreatedDate() {

        return applicationCreatedDate;
    }

    /**
     * Set the application created date.
     *
     * @param applicationCreatedDate  application created date
     */
    public void
        setApplicationCreatedDate(GregorianCalendar applicationCreatedDate) {

        this.applicationCreatedDate = applicationCreatedDate;
    }

    /**
     * Gets the application created time.
     *
     * @return application created time
     */
    public GregorianCalendar getApplicationCreatedTime() {

        return applicationCreatedTime;
    }

    /**
     * Set the application created time.
     *
     * @param applicationCreatedTime  application created time
     */
    public void
        setApplicationCreatedTime(GregorianCalendar applicationCreatedTime) {

        this.applicationCreatedTime = applicationCreatedTime;
    }

}
