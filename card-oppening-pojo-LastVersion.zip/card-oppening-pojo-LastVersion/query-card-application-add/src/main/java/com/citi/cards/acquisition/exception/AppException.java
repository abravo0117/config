/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: AppException.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.exception;

/**
 *  <code>AppException</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class AppException extends RuntimeException {

    /** The constant serialVersionUID. */
    private static final long serialVersionUID = -6416952141036798150L;

    /** The constant code. */
    private final int code;

    /** The constant description. */
    private final String description;

    /** The constant ex. */
    private final Throwable ex;

    /**
     * Creates a new instance of app exception.
     *
     * @param appCode app code
     */
    public AppException(AppExceptionCodeEnum appCode) {
        this(appCode.getCode(), appCode.getDescription(),
            new RuntimeException("Undescribed Error."));
    }

    /**
     * Creates a new instance of app exception.
     *
     * @param appCode app code
     * @param ex ex
     */
    public AppException(AppExceptionCodeEnum appCode, Throwable ex) {
        this(appCode.getCode(), appCode.getDescription(), ex);
    }

    /**
     * Creates a new instance of app exception.
     *
     * @param ex ex
     */
    public AppException(Throwable ex) {
        this(0, "Unhandled Error.", ex);
    }

    /**
     * Creates a new instance of app exception.
     *
     * @param code code
     * @param description description
     * @param ex ex
     */
    public AppException(int code, String description, Throwable ex) {
        this.code = code;
        this.description = description;
        this.ex = ex;
    }

    /**
     * Creates a new instance of app exception.
     */
    public AppException() {
        super("Unknown Error.", new RuntimeException());
        description = super.getMessage();
        code = 405;
        ex = super.getCause();
    }

    /**
     * Gets the code.
     *
     * @return code
     */
    public int getCode() {

        return code;
    }

    /**
     * Gets the description.
     *
     * @return description
     */
    public String getDescription() {

        return description;
    }

    /**
     * Gets the ex.
     *
     * @return ex
     */
    public Throwable getEx() {

        return ex;
    }

}
