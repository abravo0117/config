/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CRUDErrorResponse.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.response.generics;

import java.io.Serializable;

import org.springframework.http.HttpStatus;

import com.citi.cards.acquisition.exception.AppException;
import com.citi.cards.acquisition.exception.FaultException;
import com.citi.cards.acquisition.exception.WSClientException;

/**
 *  <code>CRUDErrorResponse</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class CRUDErrorResponse extends AbstractBaseCrudResponse
    implements Serializable {

    /** The constant serialVersionUID. */
    private static final long serialVersionUID = -5078037912560531182L;

    /** type. */
    private String type;

    /** code. */
    private int code;

    /** details. */
    private String details;

    /** location. */
    private String location;

    /** more info. */
    private String moreInfo;
    
    /**
     * Creates a new instance of CRUD error response.
     */
    public CRUDErrorResponse()
    {
        super();
    }

    /**
     * Creates a new instance of CRUD error response.
     *
     * @param exp exp
     */
    public CRUDErrorResponse(FaultException exp) {
        super(HttpStatus.valueOf(Integer.parseInt(exp.getCode())));
        type = exp.getType();
        code = Integer.parseInt(exp.getCode());
        details = exp.getDetails();
        location = exp.getLocation();
        moreInfo = exp.getMoreInfo();
    }

    /**
     * Creates a new instance of CRUD error response.
     *
     * @param exp exp
     */
    public CRUDErrorResponse(AppException exp) {
        super(HttpStatus.valueOf(exp.getCode()));
        code = exp.getCode();
        type = exp.getClass().getName();
        location = new String(exp.getStackTrace()[1].getMethodName() + " "
            + exp.getStackTrace()[exp.getStackTrace().length - 2]
                .getLineNumber());

    }

    /**
     * Creates a new instance of CRUD error response.
     *
     * @param exp exp
     */
    public CRUDErrorResponse(WSClientException exp) {
        this((AppException) exp);
        details = exp.getExCause();
    }

    /**
     * Gets the type.
     *
     * @return type
     */
    public String getType() {

        return type;
    }

    /**
     * Set the type.
     *
     * @param type  type
     */
    public void setType(String type) {

        this.type = type;
    }

    /**
     * Gets the code.
     *
     * @return code
     */
    public int getCode() {

        return code;
    }

    /**
     * Set the code.
     *
     * @param code  code
     */
    public void setCode(int code) {

        this.code = code;
    }

    /**
     * Gets the details.
     *
     * @return details
     */
    public String getDetails() {

        return details;
    }

    /**
     * Set the details.
     *
     * @param details  details
     */
    public void setDetails(String details) {

        this.details = details;
    }

    /**
     * Gets the location.
     *
     * @return location
     */
    public String getLocation() {

        return location;
    }

    /**
     * Set the location.
     *
     * @param location  location
     */
    public void setLocation(String location) {

        this.location = location;
    }

    /**
     * Gets the more info.
     *
     * @return more info
     */
    public String getMoreInfo() {

        return moreInfo;
    }

    /**
     * Set the more info.
     *
     * @param moreInfo  more info
     */
    public void setMoreInfo(String moreInfo) {

        this.moreInfo = moreInfo;
    }

}
