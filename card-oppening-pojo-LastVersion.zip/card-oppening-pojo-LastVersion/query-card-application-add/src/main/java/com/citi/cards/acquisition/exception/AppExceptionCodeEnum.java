/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: AppExceptionCodeEnum.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.exception;

/**
 *  <code>AppExceptionCodeEnum</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public enum AppExceptionCodeEnum {

    /** La constante JAXB_EXCEPTION. */
    JAXB_EXCEPTION(400,"Server internal Error (marshall error)."),
    
    /** La constante MALFORMED_URL_EXCEPTION. */
    MALFORMED_URL_EXCEPTION(400,"Remote Host URL Error, review in properties."),
    
    /** La constante SOAP_EXCEPTION. */
    SOAP_EXCEPTION (400,"Remote resources error."),
    
    /** La constante INPUT_STREAM_IO_EXCEPTION. */
    INPUT_STREAM_IO_EXCEPTION(400,"Remote Conecction Error."),
    
    /** La constante SOAP_IO_EXCEPTION. */
    SOAP_IO_EXCEPTION(400,"Error parsing remote response."),
    
    /** La constante GENERAL_IO_EXCEPTION. */
    GENERAL_IO_EXCEPTION(400,"Internal Error."),
    
    /** La constante AXIS_SERVER_ERROR_EXCEPTION. */
    AXIS_SERVER_ERROR_EXCEPTION(400,"Internal resource conecction error."),
    
    /** La constante AXIS_FAULT_ERROR_EXCEPTION. */
    AXIS_FAULT_ERROR_EXCEPTION(400, "Certificated Creation Exp."),
    
    /** La constante FILE_NOT_FOUNT_EXCEPTION. */
    FILE_NOT_FOUNT_EXCEPTION(404,"Internal resource not found."),
    
    /** La constante FAULT_CLIENT_WS_EXCEPTION. */
    FAULT_CLIENT_WS_EXCEPTION(500,"Fault message from WS Method.")
    ;

    /** code. */
    private int code;

    /** description. */
    private String description;

    /**
     * Creates a new instance of app exception code enum.
     *
     * @param code code
     * @param description description
     */
    private AppExceptionCodeEnum(int code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * Gets the code.
     *
     * @return code
     */
    public int getCode() {

        return code;
    }

    /**
     * Gets the description.
     *
     * @return description
     */
    public String getDescription() {

        return description;
    }

}
