/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: ApplicationVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

import java.util.List;

/**
 *  <code>ApplicationVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class ApplicationVO {

    /** application ID. */
    private String applicationID;

    /** initiator. */
    private String initiator;

    /** app recieved date. */
    private String appRecievedDate;

    /** existing card no. */
    private String existingCardNo;

    /** e stmt indicator. */
    private String eStmtIndicator;

    /** sales agent code. */
    private String salesAgentCode;

    /** oac code. */
    private String oacCode;

    /** user ID. */
    private String userID;

    /** external application ID. */
    private String externalApplicationID;

    /** external application image ID. */
    private String externalApplicationImageID;

    /** sales agency code. */
    private String salesAgencyCode;

    /** sales agent tax ID. */
    private String salesAgentTaxID;

    /** sales agent name. */
    private String salesAgentName;

    /** sales agent extension no. */
    private String salesAgentExtensionNo;

    /** source indicator. */
    private String sourceIndicator;

    /** branch ID. */
    private String branchID;

    /** application filled state. */
    private String applicationFilledState;

    /** offer. */
    private List<OfferVO> offer;

    /** application type. */
    private String applicationType;

    /** offer error code. */
    private String offerErrorCode;

    /** support type. */
    private String supportType;

    /** enhanced due diligence flag. */
    private String enhancedDueDiligenceFlag;

    /**
     * Gets the application ID.
     *
     * @return application ID
     */
    public String getApplicationID() {

        return applicationID;
    }

    /**
     * Set the application ID.
     *
     * @param applicationID  application ID
     */
    public void setApplicationID(String applicationID) {

        this.applicationID = applicationID;
    }

    /**
     * Gets the initiator.
     *
     * @return initiator
     */
    public String getInitiator() {

        return initiator;
    }

    /**
     * Set the initiator.
     *
     * @param initiator  initiator
     */
    public void setInitiator(String initiator) {

        this.initiator = initiator;
    }

    /**
     * Gets the app recieved date.
     *
     * @return app recieved date
     */
    public String getAppRecievedDate() {

        return appRecievedDate;
    }

    /**
     * Set the app recieved date.
     *
     * @param appRecievedDate  app recieved date
     */
    public void setAppRecievedDate(String appRecievedDate) {

        this.appRecievedDate = appRecievedDate;
    }

    /**
     * Gets the existing card no.
     *
     * @return existing card no
     */
    public String getExistingCardNo() {

        return existingCardNo;
    }

    /**
     * Set the existing card no.
     *
     * @param existingCardNo  existing card no
     */
    public void setExistingCardNo(String existingCardNo) {

        this.existingCardNo = existingCardNo;
    }

    /**
     * Gets the e stmt indicator.
     *
     * @return e stmt indicator
     */
    public String geteStmtIndicator() {

        return eStmtIndicator;
    }

    /**
     * Set the e stmt indicator.
     *
     * @param eStmtIndicator  e stmt indicator
     */
    public void seteStmtIndicator(String eStmtIndicator) {

        this.eStmtIndicator = eStmtIndicator;
    }

    /**
     * Gets the sales agent code.
     *
     * @return sales agent code
     */
    public String getSalesAgentCode() {

        return salesAgentCode;
    }

    /**
     * Set the sales agent code.
     *
     * @param salesAgentCode  sales agent code
     */
    public void setSalesAgentCode(String salesAgentCode) {

        this.salesAgentCode = salesAgentCode;
    }

    /**
     * Gets the oac code.
     *
     * @return oac code
     */
    public String getOacCode() {

        return oacCode;
    }

    /**
     * Set the oac code.
     *
     * @param oacCode  oac code
     */
    public void setOacCode(String oacCode) {

        this.oacCode = oacCode;
    }

    /**
     * Gets the user ID.
     *
     * @return user ID
     */
    public String getUserID() {

        return userID;
    }

    /**
     * Set the user ID.
     *
     * @param userID  user ID
     */
    public void setUserID(String userID) {

        this.userID = userID;
    }

    /**
     * Gets the external application ID.
     *
     * @return external application ID
     */
    public String getExternalApplicationID() {

        return externalApplicationID;
    }

    /**
     * Set the external application ID.
     *
     * @param externalApplicationID  external application ID
     */
    public void setExternalApplicationID(String externalApplicationID) {

        this.externalApplicationID = externalApplicationID;
    }

    /**
     * Gets the external application image ID.
     *
     * @return external application image ID
     */
    public String getExternalApplicationImageID() {

        return externalApplicationImageID;
    }

    /**
     * Set the external application image ID.
     *
     * @param externalApplicationImageID  external application image ID
     */
    public void
        setExternalApplicationImageID(String externalApplicationImageID) {

        this.externalApplicationImageID = externalApplicationImageID;
    }

    /**
     * Gets the sales agency code.
     *
     * @return sales agency code
     */
    public String getSalesAgencyCode() {

        return salesAgencyCode;
    }

    /**
     * Set the sales agency code.
     *
     * @param salesAgencyCode  sales agency code
     */
    public void setSalesAgencyCode(String salesAgencyCode) {

        this.salesAgencyCode = salesAgencyCode;
    }

    /**
     * Gets the sales agent tax ID.
     *
     * @return sales agent tax ID
     */
    public String getSalesAgentTaxID() {

        return salesAgentTaxID;
    }

    /**
     * Set the sales agent tax ID.
     *
     * @param salesAgentTaxID  sales agent tax ID
     */
    public void setSalesAgentTaxID(String salesAgentTaxID) {

        this.salesAgentTaxID = salesAgentTaxID;
    }

    /**
     * Gets the sales agent name.
     *
     * @return sales agent name
     */
    public String getSalesAgentName() {

        return salesAgentName;
    }

    /**
     * Set the sales agent name.
     *
     * @param salesAgentName  sales agent name
     */
    public void setSalesAgentName(String salesAgentName) {

        this.salesAgentName = salesAgentName;
    }

    /**
     * Gets the sales agent extension no.
     *
     * @return sales agent extension no
     */
    public String getSalesAgentExtensionNo() {

        return salesAgentExtensionNo;
    }

    /**
     * Set the sales agent extension no.
     *
     * @param salesAgentExtensionNo  sales agent extension no
     */
    public void setSalesAgentExtensionNo(String salesAgentExtensionNo) {

        this.salesAgentExtensionNo = salesAgentExtensionNo;
    }

    /**
     * Gets the source indicator.
     *
     * @return source indicator
     */
    public String getSourceIndicator() {

        return sourceIndicator;
    }

    /**
     * Set the source indicator.
     *
     * @param sourceIndicator  source indicator
     */
    public void setSourceIndicator(String sourceIndicator) {

        this.sourceIndicator = sourceIndicator;
    }

    /**
     * Gets the branch ID.
     *
     * @return branch ID
     */
    public String getBranchID() {

        return branchID;
    }

    /**
     * Set the branch ID.
     *
     * @param branchID  branch ID
     */
    public void setBranchID(String branchID) {

        this.branchID = branchID;
    }

    /**
     * Gets the application filled state.
     *
     * @return application filled state
     */
    public String getApplicationFilledState() {

        return applicationFilledState;
    }

    /**
     * Set the application filled state.
     *
     * @param applicationFilledState  application filled state
     */
    public void setApplicationFilledState(String applicationFilledState) {

        this.applicationFilledState = applicationFilledState;
    }

    /**
     * Gets the offer.
     *
     * @return offer
     */
    public List<OfferVO> getOffer() {

        return offer;
    }

    /**
     * Set the offer.
     *
     * @param offer  offer
     */
    public void setOffer(List<OfferVO> offer) {

        this.offer = offer;
    }

    /**
     * Gets the application type.
     *
     * @return application type
     */
    public String getApplicationType() {

        return applicationType;
    }

    /**
     * Set the application type.
     *
     * @param applicationType  application type
     */
    public void setApplicationType(String applicationType) {

        this.applicationType = applicationType;
    }

    /**
     * Gets the offer error code.
     *
     * @return offer error code
     */
    public String getOfferErrorCode() {

        return offerErrorCode;
    }

    /**
     * Set the offer error code.
     *
     * @param offerErrorCode  offer error code
     */
    public void setOfferErrorCode(String offerErrorCode) {

        this.offerErrorCode = offerErrorCode;
    }

    /**
     * Gets the support type.
     *
     * @return support type
     */
    public String getSupportType() {

        return supportType;
    }

    /**
     * Set the support type.
     *
     * @param supportType  support type
     */
    public void setSupportType(String supportType) {

        this.supportType = supportType;
    }

    /**
     * Gets the enhanced due diligence flag.
     *
     * @return enhanced due diligence flag
     */
    public String getEnhancedDueDiligenceFlag() {

        return enhancedDueDiligenceFlag;
    }

    /**
     * Set the enhanced due diligence flag.
     *
     * @param enhancedDueDiligenceFlag  enhanced due diligence flag
     */
    public void setEnhancedDueDiligenceFlag(String enhancedDueDiligenceFlag) {

        this.enhancedDueDiligenceFlag = enhancedDueDiligenceFlag;
    }

}
