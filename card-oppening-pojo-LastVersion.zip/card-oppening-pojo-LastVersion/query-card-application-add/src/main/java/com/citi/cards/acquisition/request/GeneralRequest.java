/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: GeneralRequest.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.request;

/**
 *  <code>GeneralRequest</code>.
 *
 * @author vb44309
 * @version 1.0
 * @param <BODY> generic type
 */
public class GeneralRequest<BODY> {

    /** header. */
    private GeneralHeader header;

    /** body. */
    private BODY body;

    /**
     * Gets the header.
     *
     * @return header
     */
    public GeneralHeader getHeader() {

        return header;
    }

    /**
     * Set the header.
     *
     * @param header  header
     */
    public void setHeader(GeneralHeader header) {

        this.header = header;
    }

    /**
     * Gets the body.
     *
     * @return body
     */
    public BODY getBody() {

        return body;
    }

    /**
     * Set the body.
     *
     * @param body  body
     */
    public void setBody(BODY body) {

        this.body = body;
    }

}
