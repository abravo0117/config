/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: AbstractBaseCrudResponse.java
 * Original Author: Softtek
 * Creation Date: 2/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.response.generics;

import org.springframework.http.HttpStatus;

/**
 *  <code>AbstractBaseCrudResponse</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public abstract class AbstractBaseCrudResponse {

    /** status. */
    private HttpStatus status;
    
    /**
     * Creates a new instance of abstract base crud response.
     */
    public AbstractBaseCrudResponse()
    {
        this(HttpStatus.FORBIDDEN);
    }

    /**
     * Creates a new instance of abstract base crud response.
     *
     * @param status status
     */
    public AbstractBaseCrudResponse(HttpStatus status) {
        this.status = status;
    }

    /**
     * Gets the response status.
     *
     * @return response status
     */
    public HttpStatus getResponseStatus() {

        return status;
    }

}
