/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CreditsAndLiabilitiesReferenceDetailsVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

/**
 *  <code>CreditsAndLiabilitiesReferenceDetailsVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class CreditsAndLiabilitiesReferenceDetailsVO {

    /** institution name. */
    private String institutionName;

    /** account no. */
    private String accountNo;

    /** account type. */
    private String accountType;

    /**
     * Gets the institution name.
     *
     * @return institution name
     */
    public String getInstitutionName() {

        return institutionName;
    }

    /**
     * Set the institution name.
     *
     * @param institutionName  institution name
     */
    public void setInstitutionName(String institutionName) {

        this.institutionName = institutionName;
    }

    /**
     * Gets the account no.
     *
     * @return account no
     */
    public String getAccountNo() {

        return accountNo;
    }

    /**
     * Set the account no.
     *
     * @param accountNo  account no
     */
    public void setAccountNo(String accountNo) {

        this.accountNo = accountNo;
    }

    /**
     * Gets the account type.
     *
     * @return account type
     */
    public String getAccountType() {

        return accountType;
    }

    /**
     * Set the account type.
     *
     * @param accountType  account type
     */
    public void setAccountType(String accountType) {

        this.accountType = accountType;
    }

}
