/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: WSInvoker.java
 * Original Author: Softtek
 * Creation Date: 15/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.aggregator;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.citi.cards.acquisition.exception.AppExceptionCodeEnum;
import com.citi.cards.acquisition.exception.CreditCardOpenningExceptionFactory;
import com.citi.cards.acquisition.exception.FaultException;
import com.citi.cards.acquisition.model.shared.system.fault.ErrorDetail;
import com.citi.cards.acquisition.model.shared.system.fault.Fault;
import com.citi.cards.acquisition.model.wsGenerics.GenericSOAPMessage;

/**
 * <code>WSInvoker</code>.
 *
 * @author vb44309
 * @version 1.0
 * @param <RESPONSE>
 *            generic type
 */
@Component
public class WSInvoker<RESPONSE> extends WebServiceGatewaySupport {

	private WSClientCertificateAgg wsAgg;

	/** The constant LOG. */
	private static final Logger LOG = Logger.getLogger(WSInvoker.class);

	/**
	 * Invoke WS.
	 *
	 * @param genReq
	 *            gen req
	 * @param uri
	 *            uri
	 * @param action
	 *            action
	 * @param responseClazz
	 *            response clazz
	 * @param contextPath
	 *            context path
	 * @return response
	 */
	public RESPONSE invokeWS(GenericSOAPMessage genReq, String uri, String action, Class<?> responseClazz,
			String contextPath) { // NOSONAR

		String xmlRequest = null;
		String xmlResponse = null;

		RESPONSE response = null;

		File trustStore = null;
		File keyStore = null;

		try {

			xmlRequest = requestToXml(genReq, contextPath);

			System.setProperty("javax.net.ssl.keyStorePassword", wsAgg.getKeystorePassword());
			System.setProperty("javax.net.ssl.keyStoreType", wsAgg.getKeystoreType());
			System.setProperty("javax.net.ssl.keyStore", wsAgg.getResourcePath(wsAgg.getKeystore()));

			System.setProperty("javax.net.ssl.trustStorePassword", wsAgg.getTsPass());
			System.setProperty("javax.net.ssl.trustStoreType", wsAgg.getTsType());
			System.setProperty("javax.net.ssl.trustStore", wsAgg.getResourcePath(wsAgg.getJskLocation()));

			System.setProperty("com.sun.net.ssl.checkRevocation", "false");
			System.setProperty("sun.security.ssl.allowUnsafeRenegotiation", "true");

			URL url = new URL(uri + action);
			
			LOG.info(">>>>>>>>>>>>The request:\n" + xmlRequest);
			HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
			
			con.setRequestMethod("POST");
			con.setDoOutput(true);

			con.setRequestProperty("Content-Type", "text/xml;charset=UTF-8");
			con.setRequestProperty("SOAPAction", action);
			con.setHostnameVerifier(new HostnameVerifier() {

				@Override
				public boolean verify(String hostname, SSLSession session) {
					//
					return true;
				}
			});

			con.connect();

			OutputStreamWriter write = new OutputStreamWriter(con.getOutputStream());
			write.write(xmlRequest);
			write.flush();
			write.close();

			LOG.info(">>>>>>> Response Code: \t" + con.getResponseCode());

			InputStreamReader reader = new InputStreamReader(con.getInputStream());
			StringBuilder buf = new StringBuilder();
			char[] cbuf = new char[2048];
			int num;
			while (-1 != (num = reader.read(cbuf))) {
				buf.append(cbuf, 0, num);
			}
			xmlResponse = buf.toString();
			
			validateResponse(xmlResponse);

			LOG.info("Response ->\n" + xmlResponse + "\n-----------------");

			response = buildResponse(xmlResponse, responseClazz);

		} catch (JAXBException e) {
			LOG.error(e, e);
			throw CreditCardOpenningExceptionFactory.throwWSClientException(AppExceptionCodeEnum.JAXB_EXCEPTION,
					e.getMessage());
		} catch (MalformedURLException e) {
			LOG.error(e, e);
			throw CreditCardOpenningExceptionFactory
					.throwWSClientException(AppExceptionCodeEnum.MALFORMED_URL_EXCEPTION, e.getMessage());
		} catch (IOException e) {
			LOG.error(e, e);
			throw CreditCardOpenningExceptionFactory.throwWSClientException(AppExceptionCodeEnum.SOAP_IO_EXCEPTION, e.getMessage());
		} catch (SOAPException e) {
			LOG.error(e, e);
			throw CreditCardOpenningExceptionFactory.throwWSClientException(AppExceptionCodeEnum.SOAP_EXCEPTION,
					e.getMessage());
		}finally
		{
			trustStore = new File(wsAgg.getResourcePath(wsAgg.getJskLocation()));
			keyStore = new File(wsAgg.getResourcePath(wsAgg.getKeystore()));
			trustStore.delete();
			keyStore.delete();
		}

		return response;
	}


	public void validateResponse(String xmlResponse) {
		// com.citi.cards.acquisition.model.shared.system.fault
		try {
			
			LOG.info(">>>>>>>>><Response: \n"+xmlResponse);
			
			Fault faul = null;

			Unmarshaller unmarshaller2;

			unmarshaller2 = JAXBContext.newInstance(Fault.class).createUnmarshaller();
			
			StringBuilder builder = new StringBuilder();

			SOAPMessage soapMessage = MessageFactory.newInstance().createMessage(null,
					new ByteArrayInputStream(xmlResponse.getBytes()));

			faul = (Fault) unmarshaller2.unmarshal(soapMessage.getSOAPBody().extractContentAsDocument());
			
			if(faul.getErrorDetail()!=null){
				List<ErrorDetail> list = faul.getErrorDetail();
				for( ErrorDetail iterator : list ){
					builder.append(iterator.getActor()).append(" - ").append(iterator.getType()).append(" - ").append(iterator.getCode()).append(" - ").append(iterator.getDescription()).append("\n");
				}
			}
			
			throw new FaultException(AppExceptionCodeEnum.FAULT_CLIENT_WS_EXCEPTION, new RuntimeException(),
					builder.toString());
		} catch (JAXBException | IOException | SOAPException e) {
			
			LOG.error(e,e);
		}

	}

	/**
	 * Request to xml.
	 *
	 * @param genReq
	 *            gen req
	 * @param contextPath
	 *            context path
	 * @return string
	 * @throws JAXBException
	 *             JAXB exception.
	 */
	private String requestToXml(GenericSOAPMessage genReq, String contextPath) throws JAXBException {

		StringWriter sw = new StringWriter();
		String xml = null;

		JAXBContext jc = JAXBContext.newInstance(contextPath);
		Marshaller marshaller = jc.createMarshaller();

		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

		marshaller.marshal(genReq, sw);

		xml = sw.toString();

		LOG.info("Request ->\n" + xml);

		return xml;
	}

	/**
	 * Builds the response.
	 *
	 * @param xmlResponse
	 *            xml response
	 * @param clazzResponse
	 *            clazz response
	 * @return response
	 * @throws JAXBException
	 *             JAXB exception.
	 * @throws IOException
	 *             the IO exception
	 * @throws SOAPException
	 *             SOAP exception.
	 */
	@SuppressWarnings("unchecked")
	private RESPONSE buildResponse(String xmlResponse, Class<?> clazzResponse)
			throws JAXBException, IOException, SOAPException {

		System.setProperty("javax.xml.soap.MessageFactory",
				"com.sun.xml.internal.messaging.saaj.soap.ver1_1.SOAPMessageFactory1_1Impl");
		System.setProperty("javax.xml.bind.JAXBContext", "com.sun.xml.internal.bind.v2.ContextFactory");

		Unmarshaller unmarshaller2 = JAXBContext.newInstance(clazzResponse).createUnmarshaller();

		SOAPMessage soapMessage = MessageFactory.newInstance().createMessage(null,
				new ByteArrayInputStream(xmlResponse.getBytes()));

		RESPONSE res = null;
		try {
			res = (RESPONSE) unmarshaller2.unmarshal(soapMessage.getSOAPBody().extractContentAsDocument());
		} catch (Exception e) {
			LOG.info("Error unmarshalling soap message 1.1.", e);
			res = buildResponse2(xmlResponse, clazzResponse);
		}

		return res;
	}

	/**
	 * Builds the response 2.
	 *
	 * @param xmlResponse
	 *            xml response
	 * @param clazzResponse
	 *            clazz response
	 * @return response
	 * @throws JAXBException
	 *             JAXB exception.
	 * @throws IOException
	 *             the IO exception
	 * @throws SOAPException
	 *             SOAP exception.
	 */
	@SuppressWarnings("unchecked")
	private RESPONSE buildResponse2(String xmlResponse, Class<?> clazzResponse)
			throws JAXBException, IOException, SOAPException {

		System.setProperty("javax.xml.soap.MessageFactory",
				"com.sun.xml.internal.messaging.saaj.soap.ver1_2.SOAPMessageFactory1_2Impl");
		System.setProperty("javax.xml.bind.JAXBContext", "com.sun.xml.internal.bind.v2.ContextFactory");

		Unmarshaller unmarshaller2 = JAXBContext.newInstance(clazzResponse).createUnmarshaller();

		SOAPMessage soapMessage = MessageFactory.newInstance().createMessage(null,
				new ByteArrayInputStream(xmlResponse.getBytes()));

		return (RESPONSE) unmarshaller2.unmarshal(soapMessage.getSOAPBody().extractContentAsDocument());
	}

	public void setWsAgg(WSClientCertificateAgg wsAgg) {
		this.wsAgg = wsAgg;
	}

}
