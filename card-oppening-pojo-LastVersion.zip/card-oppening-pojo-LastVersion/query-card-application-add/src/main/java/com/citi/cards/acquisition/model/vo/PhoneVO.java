/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: PhoneVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

import java.math.BigInteger;

/**
 *  <code>PhoneVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class PhoneVO {

    /** type. */
    private String type;

    /** sequence no. */
    private BigInteger sequenceNo;

    /** no. */
    private String no;

    /** country code. */
    private String countryCode;

    /** area code. */
    private String areaCode;

    /** extension. */
    private String extension;

    /** exchange. */
    private String exchange;

    /** preferred call time. */
    private String preferredCallTime;

    /** time zone. */
    private String timeZone;

    /** ok to call. */
    private String okToCall;

    /** ok to SMS. */
    private String okToSMS;

    /** best time to call. */
    private String bestTimeToCall;

    /** contact person name. */
    private String contactPersonName;

    /**
     * Gets the type.
     *
     * @return type
     */
    public String getType() {

        return type;
    }

    /**
     * Set the type.
     *
     * @param type  type
     */
    public void setType(String type) {

        this.type = type;
    }

    /**
     * Gets the sequence no.
     *
     * @return sequence no
     */
    public BigInteger getSequenceNo() {

        return sequenceNo;
    }

    /**
     * Set the sequence no.
     *
     * @param sequenceNo  sequence no
     */
    public void setSequenceNo(BigInteger sequenceNo) {

        this.sequenceNo = sequenceNo;
    }

    /**
     * Gets the no.
     *
     * @return no
     */
    public String getNo() {

        return no;
    }

    /**
     * Set the no.
     *
     * @param no  no
     */
    public void setNo(String no) {

        this.no = no;
    }

    /**
     * Gets the country code.
     *
     * @return country code
     */
    public String getCountryCode() {

        return countryCode;
    }

    /**
     * Set the country code.
     *
     * @param countryCode  country code
     */
    public void setCountryCode(String countryCode) {

        this.countryCode = countryCode;
    }

    /**
     * Gets the area code.
     *
     * @return area code
     */
    public String getAreaCode() {

        return areaCode;
    }

    /**
     * Set the area code.
     *
     * @param areaCode  area code
     */
    public void setAreaCode(String areaCode) {

        this.areaCode = areaCode;
    }

    /**
     * Gets the extension.
     *
     * @return extension
     */
    public String getExtension() {

        return extension;
    }

    /**
     * Set the extension.
     *
     * @param extension  extension
     */
    public void setExtension(String extension) {

        this.extension = extension;
    }

    /**
     * Gets the exchange.
     *
     * @return exchange
     */
    public String getExchange() {

        return exchange;
    }

    /**
     * Set the exchange.
     *
     * @param exchange  exchange
     */
    public void setExchange(String exchange) {

        this.exchange = exchange;
    }

    /**
     * Gets the preferred call time.
     *
     * @return preferred call time
     */
    public String getPreferredCallTime() {

        return preferredCallTime;
    }

    /**
     * Set the preferred call time.
     *
     * @param preferredCallTime  preferred call time
     */
    public void setPreferredCallTime(String preferredCallTime) {

        this.preferredCallTime = preferredCallTime;
    }

    /**
     * Gets the time zone.
     *
     * @return time zone
     */
    public String getTimeZone() {

        return timeZone;
    }

    /**
     * Set the time zone.
     *
     * @param timeZone  time zone
     */
    public void setTimeZone(String timeZone) {

        this.timeZone = timeZone;
    }

    /**
     * Gets the ok to call.
     *
     * @return ok to call
     */
    public String getOkToCall() {

        return okToCall;
    }

    /**
     * Set the ok to call.
     *
     * @param okToCall  ok to call
     */
    public void setOkToCall(String okToCall) {

        this.okToCall = okToCall;
    }

    /**
     * Gets the ok to SMS.
     *
     * @return ok to SMS
     */
    public String getOkToSMS() {

        return okToSMS;
    }

    /**
     * Set the ok to SMS.
     *
     * @param okToSMS  ok to SMS
     */
    public void setOkToSMS(String okToSMS) {

        this.okToSMS = okToSMS;
    }

    /**
     * Gets the best time to call.
     *
     * @return best time to call
     */
    public String getBestTimeToCall() {

        return bestTimeToCall;
    }

    /**
     * Set the best time to call.
     *
     * @param bestTimeToCall  best time to call
     */
    public void setBestTimeToCall(String bestTimeToCall) {

        this.bestTimeToCall = bestTimeToCall;
    }

    /**
     * Gets the contact person name.
     *
     * @return contact person name
     */
    public String getContactPersonName() {

        return contactPersonName;
    }

    /**
     * Set the contact person name.
     *
     * @param contactPersonName  contact person name
     */
    public void setContactPersonName(String contactPersonName) {

        this.contactPersonName = contactPersonName;
    }

}
