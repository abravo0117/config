/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: EmploymentVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

/**
 *  <code>EmploymentVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class EmploymentVO {

    /** company name english. */
    private String companyNameEnglish;

    /** company name local. */
    private String companyNameLocal;

    /** employment type. */
    private String employmentType;

    /** job title. */
    private String jobTitle;

    /** occupation code. */
    private String occupationCode;

    /** nature of business. */
    private String natureOfBusiness;

    /** years in employment. */
    private String yearsInEmployment;

    /** months in employment. */
    private String monthsInEmployment;

    /** years in industry. */
    private String yearsInIndustry;

    /** months in industry. */
    private String monthsInIndustry;

    /** department. */
    private String department;

    /**
     * Gets the company name english.
     *
     * @return company name english
     */
    public String getCompanyNameEnglish() {

        return companyNameEnglish;
    }

    /**
     * Set the company name english.
     *
     * @param companyNameEnglish  company name english
     */
    public void setCompanyNameEnglish(String companyNameEnglish) {

        this.companyNameEnglish = companyNameEnglish;
    }

    /**
     * Gets the company name local.
     *
     * @return company name local
     */
    public String getCompanyNameLocal() {

        return companyNameLocal;
    }

    /**
     * Set the company name local.
     *
     * @param companyNameLocal  company name local
     */
    public void setCompanyNameLocal(String companyNameLocal) {

        this.companyNameLocal = companyNameLocal;
    }

    /**
     * Gets the employment type.
     *
     * @return employment type
     */
    public String getEmploymentType() {

        return employmentType;
    }

    /**
     * Set the employment type.
     *
     * @param employmentType  employment type
     */
    public void setEmploymentType(String employmentType) {

        this.employmentType = employmentType;
    }

    /**
     * Gets the job title.
     *
     * @return job title
     */
    public String getJobTitle() {

        return jobTitle;
    }

    /**
     * Set the job title.
     *
     * @param jobTitle  job title
     */
    public void setJobTitle(String jobTitle) {

        this.jobTitle = jobTitle;
    }

    /**
     * Gets the occupation code.
     *
     * @return occupation code
     */
    public String getOccupationCode() {

        return occupationCode;
    }

    /**
     * Set the occupation code.
     *
     * @param occupationCode  occupation code
     */
    public void setOccupationCode(String occupationCode) {

        this.occupationCode = occupationCode;
    }

    /**
     * Gets the nature of business.
     *
     * @return nature of business
     */
    public String getNatureOfBusiness() {

        return natureOfBusiness;
    }

    /**
     * Set the nature of business.
     *
     * @param natureOfBusiness  nature of business
     */
    public void setNatureOfBusiness(String natureOfBusiness) {

        this.natureOfBusiness = natureOfBusiness;
    }

    /**
     * Gets the years in employment.
     *
     * @return years in employment
     */
    public String getYearsInEmployment() {

        return yearsInEmployment;
    }

    /**
     * Set the years in employment.
     *
     * @param yearsInEmployment  years in employment
     */
    public void setYearsInEmployment(String yearsInEmployment) {

        this.yearsInEmployment = yearsInEmployment;
    }

    /**
     * Gets the months in employment.
     *
     * @return months in employment
     */
    public String getMonthsInEmployment() {

        return monthsInEmployment;
    }

    /**
     * Set the months in employment.
     *
     * @param monthsInEmployment  months in employment
     */
    public void setMonthsInEmployment(String monthsInEmployment) {

        this.monthsInEmployment = monthsInEmployment;
    }

    /**
     * Gets the years in industry.
     *
     * @return years in industry
     */
    public String getYearsInIndustry() {

        return yearsInIndustry;
    }

    /**
     * Set the years in industry.
     *
     * @param yearsInIndustry  years in industry
     */
    public void setYearsInIndustry(String yearsInIndustry) {

        this.yearsInIndustry = yearsInIndustry;
    }

    /**
     * Gets the months in industry.
     *
     * @return months in industry
     */
    public String getMonthsInIndustry() {

        return monthsInIndustry;
    }

    /**
     * Set the months in industry.
     *
     * @param monthsInIndustry  months in industry
     */
    public void setMonthsInIndustry(String monthsInIndustry) {

        this.monthsInIndustry = monthsInIndustry;
    }

    /**
     * Gets the department.
     *
     * @return department
     */
    public String getDepartment() {

        return department;
    }

    /**
     * Set the department.
     *
     * @param department  department
     */
    public void setDepartment(String department) {

        this.department = department;
    }

}
