/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: App.java
 * Original Author: Softtek
 * Creation Date: 15/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.crud.creditCardOppening;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.annotation.ComponentScan;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 *  <code>App</code>.
 *
 * @author vb44309
 * @version 1.0
 */
@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan({"com.citi", "com.citi.cards.acquisition", "com.citi.cards.acquisition.aggregator",
    "com.citi.cards.acquisition.service", "com.citi.cards.acquisition.controller", "com.citi.cards.acquisition.*"})
@EnableSwagger2
@EnableHystrix
@EnableHystrixDashboard
public class App {

    /**
     * Execution initiation.
     *
     * @param args arguments
     */
    public static void main(String[] args) {

        SpringApplication.run(App.class, args);
        
    }
}
