/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CardApplicationWSData.java
 * Original Author: Softtek
 * Creation Date: 6/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.applicationFullDetails;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.ApplicationFullDetailsInqRq;
import com.citi.cards.acquisition.model.wsGenerics.GenericSOAPMessageBody;

/**
 * <code>CardApplicationWSData</code>.
 *
 * @author vb44309
 * @version 1.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Body")
@XmlType
public class ApplicationFullDetailsWSData implements Serializable {

    /** The constant serialVersionUID. */
    private static final long serialVersionUID = 6523948925942909374L;

    /** data. */
    @XmlElement(name = "ApplicationFullDetailsInqRq",
        namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15")
    protected ApplicationFullDetailsInqRq data; // NOSONAR

    /**
     * {@inheritDoc}
     */
    public ApplicationFullDetailsInqRq getData() {

        return data;
    }

    /**
     * {@inheritDoc}
     */
    public void setData(ApplicationFullDetailsInqRq t) {

        this.data = t;

    }

}
