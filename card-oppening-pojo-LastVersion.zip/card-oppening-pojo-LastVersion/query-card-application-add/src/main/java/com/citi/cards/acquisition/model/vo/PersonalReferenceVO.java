/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: PersonalReferenceVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

/**
 *  <code>PersonalReferenceVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class PersonalReferenceVO {

    /** name. */
    private StructuredNameVO name;

    /** relationship with applicant. */
    private String relationshipWithApplicant;

    /**
     * Gets the name.
     *
     * @return name
     */
    public StructuredNameVO getName() {

        return name;
    }

    /**
     * Set the name.
     *
     * @param name  name
     */
    public void setName(StructuredNameVO name) {

        this.name = name;
    }

    /**
     * Gets the relationship with applicant.
     *
     * @return relationship with applicant
     */
    public String getRelationshipWithApplicant() {

        return relationshipWithApplicant;
    }

    /**
     * Set the relationship with applicant.
     *
     * @param relationshipWithApplicant  relationship with applicant
     */
    public void setRelationshipWithApplicant(String relationshipWithApplicant) {

        this.relationshipWithApplicant = relationshipWithApplicant;
    }

}
