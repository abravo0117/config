/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: WSClientCertificateAgg.java
 * Original Author: Softtek
 * Creation Date: 9/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.aggregator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * <code>WSClientCertificateAgg</code>.
 *
 * @author vb44309
 * @version 1.0
 */
@Service
public class WSClientCertificateAgg {

	/** The constant LOG. */
	private static final Logger LOG = Logger.getLogger(WSClientCertificateAgg.class);

	/** keystore. */
	@Value("${ws.client.security.keystore}")
	private String keystore;

	/** keystore type. */
	@Value("${ws.client.security.keystoreType}")
	private String keystoreType;

	/** keystore password. */
	@Value("${ws.client.security.keystorePassword}")
	private String keystorePassword;

	/** jsk location. */
	@Value("${ws.client.ssl.config.jskLocation}")
	/** jsk location. */
	private String jskLocation;

	/** ts type. */
	@Value("${ws.client.ssl.config.tsType}")
	/** ts type. */
	private String tsType;

	/** ts pass. */
	@Value("${ws.client.ssl.config.tsPass}")
	private String tsPass;

	@SuppressWarnings("static-access")
	public String getResourcePath(String name) {

		String path = null;
		InputStream in = null;
		File file = null;
		OutputStream out = null;
		try {
			in = Thread.currentThread().getContextClassLoader().getResourceAsStream(name);

			file = new File(name);
			LOG.info("File ->" + file.getAbsolutePath());
			if (!file.exists()) {
				LOG.info("Building...");
				out = new FileOutputStream(file);
				int read = 0;
				byte[] bytes = new byte[1024];
				while ((read = in.read(bytes)) != -1) {
					out.write(bytes, 0, read);
				}
				LOG.info("File writing..." + file.getAbsolutePath());
				path = file.getAbsolutePath();
			}
			else
			{
				path = file.getAbsolutePath();
			}
			in.close();

		} catch (Exception e) {
			LOG.error(e, e);
		} finally {
			try {
				if (out != null)
					out.close();
			} catch (IOException e) {
				LOG.error(e, e);
			}
		}
		return path;
	}

	/**
	 * Set the keystore.
	 *
	 * @param keystore
	 *            keystore
	 */
	public void setKeystore(String keystore) {

		this.keystore = keystore;
	}

	/**
	 * Set the keystore type.
	 *
	 * @param keystoreType
	 *            keystore type
	 */
	public void setKeystoreType(String keystoreType) {

		this.keystoreType = keystoreType;
	}

	/**
	 * Set the keystore password.
	 *
	 * @param keystorePassword
	 *            keystore password
	 */
	public void setKeystorePassword(String keystorePassword) {

		this.keystorePassword = keystorePassword;
	}

	/**
	 * Set the jsk location.
	 *
	 * @param jskLocation
	 *            jsk location
	 */
	public void setJskLocation(String jskLocation) {

		this.jskLocation = jskLocation;
	}

	/**
	 * Set the ts type.
	 *
	 * @param tsType
	 *            ts type
	 */
	public void setTsType(String tsType) {

		this.tsType = tsType;
	}

	/**
	 * Set the ts pass.
	 *
	 * @param tsPass
	 *            ts pass
	 */
	public void setTsPass(String tsPass) {

		this.tsPass = tsPass;
	}

	public String getKeystore() {

		return keystore;
	}

	public String getKeystoreType() {

		return keystoreType;
	}

	public String getKeystorePassword() {

		return keystorePassword;
	}

	public String getJskLocation() {

		return jskLocation;
	}

	public String getTsType() {

		return tsType;
	}

	public String getTsPass() {

		return tsPass;
	}

}
