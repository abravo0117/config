/**
 * 
 */
/**
 * @author vb44309
 *
 */
package com.citi.cards.acquisition.model.preCreatedCardAccept;