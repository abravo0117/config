/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: DocumentUploadNotificationService.java
 * Original Author: Softtek
 * Creation Date: 15/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.citi.cards.acquisition.aggregator.WSClientCertificateAgg;
import com.citi.cards.acquisition.aggregator.WSInvoker;
import com.citi.cards.acquisition.exception.AppException;
import com.citi.cards.acquisition.exception.FaultException;
import com.citi.cards.acquisition.model.documentUploadNotification.DocumentUploadNotificationWSData;
import com.citi.cards.acquisition.model.documentUploadNotification.DocumentUploadNotificationWSRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.DocumentUploadNotificationUpdRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.DocumentUploadNotificationUpdRs;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.model.wsGenerics.GenericSOAPMessageHeader;
import com.citi.cards.acquisition.response.generics.AbstractBaseCrudResponse;
import com.citi.cards.acquisition.response.generics.CRUDErrorResponse;
import com.citi.cards.acquisition.response.generics.CRUDResponse;

/**
 *  <code>DocumentUploadNotificationService</code>.
 *
 * @author vb44309
 * @version 1.0
 */
@Service
public class DocumentUploadNotificationService {

    /** The constant LOG. */
    private static final Logger LOG =
        Logger.getLogger(DocumentUploadNotificationService.class);

    /** context path. */
    @Value("${ws.documentUploadNotification.object.context.path}")
    private String contextPath;

    /** uri. */
    @Value("${ws.location.uri}")
    private String uri;

    /** action. */
    @Value("${ws.documentUploadNotification.action}")
    private String action;

    /** load data. */
    @Autowired
    private WSClientCertificateAgg loadData;

    /** invoker. */
    protected WSInvoker< DocumentUploadNotificationUpdRs> invoker =
        new WSInvoker< >();

    /**
     * Execute.
     *
     * @param obj obj
     * @param msHeader ms header
     * @return abstract base crud response
     */
    public AbstractBaseCrudResponse execute(DocumentUploadNotificationUpdRq obj,
        RqHeader rqHeader) {

        AbstractBaseCrudResponse response = null;

        try {

            DocumentUploadNotificationWSRq request = new DocumentUploadNotificationWSRq();
            
            DocumentUploadNotificationWSData data = new DocumentUploadNotificationWSData();
            data.setData(obj);
            
            GenericSOAPMessageHeader header = new GenericSOAPMessageHeader();
            header.setHeader(rqHeader);
            
            
            request.setBody(data);
            request.setHeader(header);
            
            invoker.setWsAgg(loadData);

            DocumentUploadNotificationUpdRs wsRes =
                invoker.invokeWS(request, uri, action,
                    DocumentUploadNotificationUpdRs.class, contextPath);
            response = new CRUDResponse<DocumentUploadNotificationUpdRs>(wsRes);
        }
        catch (FaultException e) {
            LOG.error(e,e);
            response = new CRUDErrorResponse(e);
        }

        catch (AppException e) {
            LOG.error(e.getEx());
            response = new CRUDErrorResponse(e);
        }

        return response;
    }

    /**
     * Set the context path.
     *
     * @param contextPath  context path
     */
    public void setContextPath(String contextPath) {

        this.contextPath = contextPath;
    }

    /**
     * Set the uri.
     *
     * @param uri  uri
     */
    public void setUri(String uri) {

        this.uri = uri;
    }

    /**
     * Set the action.
     *
     * @param action  action
     */
    public void setAction(String action) {

        this.action = action;
    }

    /**
     * Set the load data.
     *
     * @param loadData  load data
     */
    public void setLoadData(WSClientCertificateAgg loadData) {

        this.loadData = loadData;
    }

}
