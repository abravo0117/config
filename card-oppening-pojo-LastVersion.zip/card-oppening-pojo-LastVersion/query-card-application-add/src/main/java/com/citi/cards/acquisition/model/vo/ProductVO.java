/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: ProductVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

import java.util.List;

/**
 *  <code>ProductVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class ProductVO {

    /** logo. */
    private String logo;

    /** org. */
    private String org;

    /** source code. */
    private String sourceCode;

    /** bill to. */
    private String billTo;

    /** card to. */
    private String cardTo;

    /** pin to. */
    private String pinTo;

    /** bill to delivery. */
    private String billToDelivery;

    /** card to delivery. */
    private String cardToDelivery;

    /** collection location. */
    private String collectionLocation;

    /** embosser name. */
    private String embosserName;

    /** instant indicator. */
    private String instantIndicator;

    /** atm card reqd flag. */
    private String atmCardReqdFlag;

    /** cheque book reqd flag. */
    private String chequeBookReqdFlag;

    /** credit shield indicator. */
    private String creditShieldIndicator;

    /** gift code. */
    private String giftCode;

    /** ccl flag. */
    private String cclFlag;

    /** spend limit amount. */
    private String spendLimitAmount;

    /** merchant id. */
    private String merchantId;

    /** merchant id org. */
    private String merchantIdOrg;

    /** sign indicator. */
    private String signIndicator;

    /** credit line amount. */
    private String creditLineAmount;

    /** campaign code. */
    private String campaignCode;

    /** account title. */
    private String accountTitle;

    /** loyalty bonus. */
    private String loyaltyBonus;

    /** program ID. */
    private String programID;

    /** ctry spec field 1. */
    private String ctrySpecField1;

    /** ctry spec field 2. */
    private String ctrySpecField2;

    /** ctry spec field 3. */
    private String ctrySpecField3;

    /** ctry spec field 4. */
    private String ctrySpecField4;

    /** ctry spec field 5. */
    private String ctrySpecField5;

    /** ctry spec field 6. */
    private String ctrySpecField6;

    /** ctry spec field 7. */
    private String ctrySpecField7;

    /** ctry spec field 8. */
    private String ctrySpecField8;

    /** ctry spec field 9. */
    private String ctrySpecField9;

    /** ctry spec field 10. */
    private String ctrySpecField10;

    /** ctry spec field 11. */
    private String ctrySpecField11;

    /** ctry spec field 12. */
    private String ctrySpecField12;

    /** ctry spec field 13. */
    private String ctrySpecField13;

    /** ctry spec field 14. */
    private String ctrySpecField14;

    /** ctry spec field 15. */
    private String ctrySpecField15;

    /** ctry spec field 16. */
    private String ctrySpecField16;

    /** ctry spec field 17. */
    private String ctrySpecField17;

    /** ctry spec field 18. */
    private String ctrySpecField18;

    /** ctry spec field 19. */
    private String ctrySpecField19;

    /** ctry spec field 20. */
    private String ctrySpecField20;

    /** plastic ID. */
    private String plasticID;

    /** pre created card no. */
    private String preCreatedCardNo;

    /** has acceptance signed. */
    private String hasAcceptanceSigned;

    /** has E banking request signed. */
    private String hasEBankingRequestSigned;

    /** has credit bureau check authorization signed. */
    private String hasCreditBureauCheckAuthorizationSigned;

    /** has auto charge consent signed. */
    private String hasAutoChargeConsentSigned;

    /** has terms and conditions acceptance signed. */
    private String hasTermsAndConditionsAcceptanceSigned;

    /** has credit line increase request signed. */
    private String hasCreditLineIncreaseRequestSigned;

    /** has insurance request signed. */
    private String hasInsuranceRequestSigned;

    /** has services payment request signed. */
    private String hasServicesPaymentRequestSigned;

    /** has marketing consent signed. */
    private String hasMarketingConsentSigned;

    /** has E bank PIN request signed. */
    private String hasEBankPINRequestSigned;

    /** has supplementary card application signed. */
    private String hasSupplementaryCardApplicationSigned;

    /** has upgrade product request signed. */
    private String hasUpgradeProductRequestSigned;

    /** reward type. */
    private String rewardType;

    /** max authorized amount. */
    private List<Double> maxAuthorizedAmount;

    /** max amount to charge. */
    private double maxAmountToCharge;

    /** credit card payment flag. */
    private String creditCardPaymentFlag;

    /** current owned product. */
    private String currentOwnedProduct;

    /** desired product. */
    private String desiredProduct;

    /** sms and email flag. */
    private String smsAndEmailFlag;

    /** is libra service requested. */
    private String isLibraServiceRequested;

    /** is balance protection insurance requested. */
    private String isBalanceProtectionInsuranceRequested;

    /** is deporteismo assistance requested. */
    private String isDeporteismoAssistanceRequested;

    /** is protection insurance requested. */
    private String isProtectionInsuranceRequested;

    /** is E statement requested. */
    private String isEStatementRequested;

    /** product family. */
    private String productFamily;

    /** loan request amount. */
    private double loanRequestAmount;

    /** is E banking requested. */
    private String isEBankingRequested;

    /** is priority pass card requested. */
    private String isPriorityPassCardRequested;

    /** requested credit line amount. */
    private double requestedCreditLineAmount;

    /** card no. */
    private String cardNo;

    /** suggested pre created card credit limit. */
    private double suggestedPreCreatedCardCreditLimit;

    /** dda account number. */
    private String ddaAccountNumber;

    /** dda branch number. */
    private String ddaBranchNumber;

    /** disbursement type. */
    private String disbursementType;

    /** requested tenor. */
    private String requestedTenor;

    /** fee collection mode. */
    private String feeCollectionMode;

    /** cli account number. */
    private String cliAccountNumber;

    /** reject reason code. */
    private String rejectReasonCode;

    /** special interest rate. */
    private double specialInterestRate;

    /**
     * Gets the logo.
     *
     * @return logo
     */
    public String getLogo() {

        return logo;
    }

    /**
     * Set the logo.
     *
     * @param logo  logo
     */
    public void setLogo(String logo) {

        this.logo = logo;
    }

    /**
     * Gets the org.
     *
     * @return org
     */
    public String getOrg() {

        return org;
    }

    /**
     * Set the org.
     *
     * @param org  org
     */
    public void setOrg(String org) {

        this.org = org;
    }

    /**
     * Gets the source code.
     *
     * @return source code
     */
    public String getSourceCode() {

        return sourceCode;
    }

    /**
     * Set the source code.
     *
     * @param sourceCode  source code
     */
    public void setSourceCode(String sourceCode) {

        this.sourceCode = sourceCode;
    }

    /**
     * Gets the bill to.
     *
     * @return bill to
     */
    public String getBillTo() {

        return billTo;
    }

    /**
     * Set the bill to.
     *
     * @param billTo  bill to
     */
    public void setBillTo(String billTo) {

        this.billTo = billTo;
    }

    /**
     * Gets the card to.
     *
     * @return card to
     */
    public String getCardTo() {

        return cardTo;
    }

    /**
     * Set the card to.
     *
     * @param cardTo  card to
     */
    public void setCardTo(String cardTo) {

        this.cardTo = cardTo;
    }

    /**
     * Gets the pin to.
     *
     * @return pin to
     */
    public String getPinTo() {

        return pinTo;
    }

    /**
     * Set the pin to.
     *
     * @param pinTo  pin to
     */
    public void setPinTo(String pinTo) {

        this.pinTo = pinTo;
    }

    /**
     * Gets the bill to delivery.
     *
     * @return bill to delivery
     */
    public String getBillToDelivery() {

        return billToDelivery;
    }

    /**
     * Set the bill to delivery.
     *
     * @param billToDelivery  bill to delivery
     */
    public void setBillToDelivery(String billToDelivery) {

        this.billToDelivery = billToDelivery;
    }

    /**
     * Gets the card to delivery.
     *
     * @return card to delivery
     */
    public String getCardToDelivery() {

        return cardToDelivery;
    }

    /**
     * Set the card to delivery.
     *
     * @param cardToDelivery  card to delivery
     */
    public void setCardToDelivery(String cardToDelivery) {

        this.cardToDelivery = cardToDelivery;
    }

    /**
     * Gets the collection location.
     *
     * @return collection location
     */
    public String getCollectionLocation() {

        return collectionLocation;
    }

    /**
     * Set the collection location.
     *
     * @param collectionLocation  collection location
     */
    public void setCollectionLocation(String collectionLocation) {

        this.collectionLocation = collectionLocation;
    }

    /**
     * Gets the embosser name.
     *
     * @return embosser name
     */
    public String getEmbosserName() {

        return embosserName;
    }

    /**
     * Set the embosser name.
     *
     * @param embosserName  embosser name
     */
    public void setEmbosserName(String embosserName) {

        this.embosserName = embosserName;
    }

    /**
     * Gets the instant indicator.
     *
     * @return instant indicator
     */
    public String getInstantIndicator() {

        return instantIndicator;
    }

    /**
     * Set the instant indicator.
     *
     * @param instantIndicator  instant indicator
     */
    public void setInstantIndicator(String instantIndicator) {

        this.instantIndicator = instantIndicator;
    }

    /**
     * Gets the atm card reqd flag.
     *
     * @return atm card reqd flag
     */
    public String getAtmCardReqdFlag() {

        return atmCardReqdFlag;
    }

    /**
     * Set the atm card reqd flag.
     *
     * @param atmCardReqdFlag  atm card reqd flag
     */
    public void setAtmCardReqdFlag(String atmCardReqdFlag) {

        this.atmCardReqdFlag = atmCardReqdFlag;
    }

    /**
     * Gets the cheque book reqd flag.
     *
     * @return cheque book reqd flag
     */
    public String getChequeBookReqdFlag() {

        return chequeBookReqdFlag;
    }

    /**
     * Set the cheque book reqd flag.
     *
     * @param chequeBookReqdFlag  cheque book reqd flag
     */
    public void setChequeBookReqdFlag(String chequeBookReqdFlag) {

        this.chequeBookReqdFlag = chequeBookReqdFlag;
    }

    /**
     * Gets the credit shield indicator.
     *
     * @return credit shield indicator
     */
    public String getCreditShieldIndicator() {

        return creditShieldIndicator;
    }

    /**
     * Set the credit shield indicator.
     *
     * @param creditShieldIndicator  credit shield indicator
     */
    public void setCreditShieldIndicator(String creditShieldIndicator) {

        this.creditShieldIndicator = creditShieldIndicator;
    }

    /**
     * Gets the gift code.
     *
     * @return gift code
     */
    public String getGiftCode() {

        return giftCode;
    }

    /**
     * Set the gift code.
     *
     * @param giftCode  gift code
     */
    public void setGiftCode(String giftCode) {

        this.giftCode = giftCode;
    }

    /**
     * Gets the ccl flag.
     *
     * @return ccl flag
     */
    public String getCclFlag() {

        return cclFlag;
    }

    /**
     * Set the ccl flag.
     *
     * @param cclFlag  ccl flag
     */
    public void setCclFlag(String cclFlag) {

        this.cclFlag = cclFlag;
    }

    /**
     * Gets the spend limit amount.
     *
     * @return spend limit amount
     */
    public String getSpendLimitAmount() {

        return spendLimitAmount;
    }

    /**
     * Set the spend limit amount.
     *
     * @param spendLimitAmount  spend limit amount
     */
    public void setSpendLimitAmount(String spendLimitAmount) {

        this.spendLimitAmount = spendLimitAmount;
    }

    /**
     * Gets the merchant id.
     *
     * @return merchant id
     */
    public String getMerchantId() {

        return merchantId;
    }

    /**
     * Set the merchant id.
     *
     * @param merchantId  merchant id
     */
    public void setMerchantId(String merchantId) {

        this.merchantId = merchantId;
    }

    /**
     * Gets the merchant id org.
     *
     * @return merchant id org
     */
    public String getMerchantIdOrg() {

        return merchantIdOrg;
    }

    /**
     * Set the merchant id org.
     *
     * @param merchantIdOrg  merchant id org
     */
    public void setMerchantIdOrg(String merchantIdOrg) {

        this.merchantIdOrg = merchantIdOrg;
    }

    /**
     * Gets the sign indicator.
     *
     * @return sign indicator
     */
    public String getSignIndicator() {

        return signIndicator;
    }

    /**
     * Set the sign indicator.
     *
     * @param signIndicator  sign indicator
     */
    public void setSignIndicator(String signIndicator) {

        this.signIndicator = signIndicator;
    }

    /**
     * Gets the credit line amount.
     *
     * @return credit line amount
     */
    public String getCreditLineAmount() {

        return creditLineAmount;
    }

    /**
     * Set the credit line amount.
     *
     * @param creditLineAmount  credit line amount
     */
    public void setCreditLineAmount(String creditLineAmount) {

        this.creditLineAmount = creditLineAmount;
    }

    /**
     * Gets the campaign code.
     *
     * @return campaign code
     */
    public String getCampaignCode() {

        return campaignCode;
    }

    /**
     * Set the campaign code.
     *
     * @param campaignCode  campaign code
     */
    public void setCampaignCode(String campaignCode) {

        this.campaignCode = campaignCode;
    }

    /**
     * Gets the account title.
     *
     * @return account title
     */
    public String getAccountTitle() {

        return accountTitle;
    }

    /**
     * Set the account title.
     *
     * @param accountTitle  account title
     */
    public void setAccountTitle(String accountTitle) {

        this.accountTitle = accountTitle;
    }

    /**
     * Gets the loyalty bonus.
     *
     * @return loyalty bonus
     */
    public String getLoyaltyBonus() {

        return loyaltyBonus;
    }

    /**
     * Set the loyalty bonus.
     *
     * @param loyaltyBonus  loyalty bonus
     */
    public void setLoyaltyBonus(String loyaltyBonus) {

        this.loyaltyBonus = loyaltyBonus;
    }

    /**
     * Gets the program ID.
     *
     * @return program ID
     */
    public String getProgramID() {

        return programID;
    }

    /**
     * Set the program ID.
     *
     * @param programID  program ID
     */
    public void setProgramID(String programID) {

        this.programID = programID;
    }

    /**
     * Gets the ctry spec field 1.
     *
     * @return ctry spec field 1
     */
    public String getCtrySpecField1() {

        return ctrySpecField1;
    }

    /**
     * Set the ctry spec field 1.
     *
     * @param ctrySpecField1  ctry spec field 1
     */
    public void setCtrySpecField1(String ctrySpecField1) {

        this.ctrySpecField1 = ctrySpecField1;
    }

    /**
     * Gets the ctry spec field 2.
     *
     * @return ctry spec field 2
     */
    public String getCtrySpecField2() {

        return ctrySpecField2;
    }

    /**
     * Set the ctry spec field 2.
     *
     * @param ctrySpecField2  ctry spec field 2
     */
    public void setCtrySpecField2(String ctrySpecField2) {

        this.ctrySpecField2 = ctrySpecField2;
    }

    /**
     * Gets the ctry spec field 3.
     *
     * @return ctry spec field 3
     */
    public String getCtrySpecField3() {

        return ctrySpecField3;
    }

    /**
     * Set the ctry spec field 3.
     *
     * @param ctrySpecField3  ctry spec field 3
     */
    public void setCtrySpecField3(String ctrySpecField3) {

        this.ctrySpecField3 = ctrySpecField3;
    }

    /**
     * Gets the ctry spec field 4.
     *
     * @return ctry spec field 4
     */
    public String getCtrySpecField4() {

        return ctrySpecField4;
    }

    /**
     * Set the ctry spec field 4.
     *
     * @param ctrySpecField4  ctry spec field 4
     */
    public void setCtrySpecField4(String ctrySpecField4) {

        this.ctrySpecField4 = ctrySpecField4;
    }

    /**
     * Gets the ctry spec field 5.
     *
     * @return ctry spec field 5
     */
    public String getCtrySpecField5() {

        return ctrySpecField5;
    }

    /**
     * Set the ctry spec field 5.
     *
     * @param ctrySpecField5  ctry spec field 5
     */
    public void setCtrySpecField5(String ctrySpecField5) {

        this.ctrySpecField5 = ctrySpecField5;
    }

    /**
     * Gets the ctry spec field 6.
     *
     * @return ctry spec field 6
     */
    public String getCtrySpecField6() {

        return ctrySpecField6;
    }

    /**
     * Set the ctry spec field 6.
     *
     * @param ctrySpecField6  ctry spec field 6
     */
    public void setCtrySpecField6(String ctrySpecField6) {

        this.ctrySpecField6 = ctrySpecField6;
    }

    /**
     * Gets the ctry spec field 7.
     *
     * @return ctry spec field 7
     */
    public String getCtrySpecField7() {

        return ctrySpecField7;
    }

    /**
     * Set the ctry spec field 7.
     *
     * @param ctrySpecField7  ctry spec field 7
     */
    public void setCtrySpecField7(String ctrySpecField7) {

        this.ctrySpecField7 = ctrySpecField7;
    }

    /**
     * Gets the ctry spec field 8.
     *
     * @return ctry spec field 8
     */
    public String getCtrySpecField8() {

        return ctrySpecField8;
    }

    /**
     * Set the ctry spec field 8.
     *
     * @param ctrySpecField8  ctry spec field 8
     */
    public void setCtrySpecField8(String ctrySpecField8) {

        this.ctrySpecField8 = ctrySpecField8;
    }

    /**
     * Gets the ctry spec field 9.
     *
     * @return ctry spec field 9
     */
    public String getCtrySpecField9() {

        return ctrySpecField9;
    }

    /**
     * Set the ctry spec field 9.
     *
     * @param ctrySpecField9  ctry spec field 9
     */
    public void setCtrySpecField9(String ctrySpecField9) {

        this.ctrySpecField9 = ctrySpecField9;
    }

    /**
     * Gets the ctry spec field 10.
     *
     * @return ctry spec field 10
     */
    public String getCtrySpecField10() {

        return ctrySpecField10;
    }

    /**
     * Set the ctry spec field 10.
     *
     * @param ctrySpecField10  ctry spec field 10
     */
    public void setCtrySpecField10(String ctrySpecField10) {

        this.ctrySpecField10 = ctrySpecField10;
    }

    /**
     * Gets the ctry spec field 11.
     *
     * @return ctry spec field 11
     */
    public String getCtrySpecField11() {

        return ctrySpecField11;
    }

    /**
     * Set the ctry spec field 11.
     *
     * @param ctrySpecField11  ctry spec field 11
     */
    public void setCtrySpecField11(String ctrySpecField11) {

        this.ctrySpecField11 = ctrySpecField11;
    }

    /**
     * Gets the ctry spec field 12.
     *
     * @return ctry spec field 12
     */
    public String getCtrySpecField12() {

        return ctrySpecField12;
    }

    /**
     * Set the ctry spec field 12.
     *
     * @param ctrySpecField12  ctry spec field 12
     */
    public void setCtrySpecField12(String ctrySpecField12) {

        this.ctrySpecField12 = ctrySpecField12;
    }

    /**
     * Gets the ctry spec field 13.
     *
     * @return ctry spec field 13
     */
    public String getCtrySpecField13() {

        return ctrySpecField13;
    }

    /**
     * Set the ctry spec field 13.
     *
     * @param ctrySpecField13  ctry spec field 13
     */
    public void setCtrySpecField13(String ctrySpecField13) {

        this.ctrySpecField13 = ctrySpecField13;
    }

    /**
     * Gets the ctry spec field 14.
     *
     * @return ctry spec field 14
     */
    public String getCtrySpecField14() {

        return ctrySpecField14;
    }

    /**
     * Set the ctry spec field 14.
     *
     * @param ctrySpecField14  ctry spec field 14
     */
    public void setCtrySpecField14(String ctrySpecField14) {

        this.ctrySpecField14 = ctrySpecField14;
    }

    /**
     * Gets the ctry spec field 15.
     *
     * @return ctry spec field 15
     */
    public String getCtrySpecField15() {

        return ctrySpecField15;
    }

    /**
     * Set the ctry spec field 15.
     *
     * @param ctrySpecField15  ctry spec field 15
     */
    public void setCtrySpecField15(String ctrySpecField15) {

        this.ctrySpecField15 = ctrySpecField15;
    }

    /**
     * Gets the ctry spec field 16.
     *
     * @return ctry spec field 16
     */
    public String getCtrySpecField16() {

        return ctrySpecField16;
    }

    /**
     * Set the ctry spec field 16.
     *
     * @param ctrySpecField16  ctry spec field 16
     */
    public void setCtrySpecField16(String ctrySpecField16) {

        this.ctrySpecField16 = ctrySpecField16;
    }

    /**
     * Gets the ctry spec field 17.
     *
     * @return ctry spec field 17
     */
    public String getCtrySpecField17() {

        return ctrySpecField17;
    }

    /**
     * Set the ctry spec field 17.
     *
     * @param ctrySpecField17  ctry spec field 17
     */
    public void setCtrySpecField17(String ctrySpecField17) {

        this.ctrySpecField17 = ctrySpecField17;
    }

    /**
     * Gets the ctry spec field 18.
     *
     * @return ctry spec field 18
     */
    public String getCtrySpecField18() {

        return ctrySpecField18;
    }

    /**
     * Set the ctry spec field 18.
     *
     * @param ctrySpecField18  ctry spec field 18
     */
    public void setCtrySpecField18(String ctrySpecField18) {

        this.ctrySpecField18 = ctrySpecField18;
    }

    /**
     * Gets the ctry spec field 19.
     *
     * @return ctry spec field 19
     */
    public String getCtrySpecField19() {

        return ctrySpecField19;
    }

    /**
     * Set the ctry spec field 19.
     *
     * @param ctrySpecField19  ctry spec field 19
     */
    public void setCtrySpecField19(String ctrySpecField19) {

        this.ctrySpecField19 = ctrySpecField19;
    }

    /**
     * Gets the ctry spec field 20.
     *
     * @return ctry spec field 20
     */
    public String getCtrySpecField20() {

        return ctrySpecField20;
    }

    /**
     * Set the ctry spec field 20.
     *
     * @param ctrySpecField20  ctry spec field 20
     */
    public void setCtrySpecField20(String ctrySpecField20) {

        this.ctrySpecField20 = ctrySpecField20;
    }

    /**
     * Gets the plastic ID.
     *
     * @return plastic ID
     */
    public String getPlasticID() {

        return plasticID;
    }

    /**
     * Set the plastic ID.
     *
     * @param plasticID  plastic ID
     */
    public void setPlasticID(String plasticID) {

        this.plasticID = plasticID;
    }

    /**
     * Gets the pre created card no.
     *
     * @return pre created card no
     */
    public String getPreCreatedCardNo() {

        return preCreatedCardNo;
    }

    /**
     * Set the pre created card no.
     *
     * @param preCreatedCardNo  pre created card no
     */
    public void setPreCreatedCardNo(String preCreatedCardNo) {

        this.preCreatedCardNo = preCreatedCardNo;
    }

    /**
     * Gets the has acceptance signed.
     *
     * @return has acceptance signed
     */
    public String getHasAcceptanceSigned() {

        return hasAcceptanceSigned;
    }

    /**
     * Set the has acceptance signed.
     *
     * @param hasAcceptanceSigned  has acceptance signed
     */
    public void setHasAcceptanceSigned(String hasAcceptanceSigned) {

        this.hasAcceptanceSigned = hasAcceptanceSigned;
    }

    /**
     * Gets the has E banking request signed.
     *
     * @return has E banking request signed
     */
    public String getHasEBankingRequestSigned() {

        return hasEBankingRequestSigned;
    }

    /**
     * Set the has E banking request signed.
     *
     * @param hasEBankingRequestSigned  has E banking request signed
     */
    public void setHasEBankingRequestSigned(String hasEBankingRequestSigned) {

        this.hasEBankingRequestSigned = hasEBankingRequestSigned;
    }

    /**
     * Gets the has credit bureau check authorization signed.
     *
     * @return has credit bureau check authorization signed
     */
    public String getHasCreditBureauCheckAuthorizationSigned() {

        return hasCreditBureauCheckAuthorizationSigned;
    }

    /**
     * Set the has credit bureau check authorization signed.
     *
     * @param hasCreditBureauCheckAuthorizationSigned  has credit bureau check authorization signed
     */
    public void setHasCreditBureauCheckAuthorizationSigned(
        String hasCreditBureauCheckAuthorizationSigned) {

        this.hasCreditBureauCheckAuthorizationSigned =
            hasCreditBureauCheckAuthorizationSigned;
    }

    /**
     * Gets the has auto charge consent signed.
     *
     * @return has auto charge consent signed
     */
    public String getHasAutoChargeConsentSigned() {

        return hasAutoChargeConsentSigned;
    }

    /**
     * Set the has auto charge consent signed.
     *
     * @param hasAutoChargeConsentSigned  has auto charge consent signed
     */
    public void
        setHasAutoChargeConsentSigned(String hasAutoChargeConsentSigned) {

        this.hasAutoChargeConsentSigned = hasAutoChargeConsentSigned;
    }

    /**
     * Gets the has terms and conditions acceptance signed.
     *
     * @return has terms and conditions acceptance signed
     */
    public String getHasTermsAndConditionsAcceptanceSigned() {

        return hasTermsAndConditionsAcceptanceSigned;
    }

    /**
     * Set the has terms and conditions acceptance signed.
     *
     * @param hasTermsAndConditionsAcceptanceSigned  has terms and conditions acceptance signed
     */
    public void setHasTermsAndConditionsAcceptanceSigned(
        String hasTermsAndConditionsAcceptanceSigned) {

        this.hasTermsAndConditionsAcceptanceSigned =
            hasTermsAndConditionsAcceptanceSigned;
    }

    /**
     * Gets the has credit line increase request signed.
     *
     * @return has credit line increase request signed
     */
    public String getHasCreditLineIncreaseRequestSigned() {

        return hasCreditLineIncreaseRequestSigned;
    }

    /**
     * Set the has credit line increase request signed.
     *
     * @param hasCreditLineIncreaseRequestSigned  has credit line increase request signed
     */
    public void setHasCreditLineIncreaseRequestSigned(
        String hasCreditLineIncreaseRequestSigned) {

        this.hasCreditLineIncreaseRequestSigned =
            hasCreditLineIncreaseRequestSigned;
    }

    /**
     * Gets the has insurance request signed.
     *
     * @return has insurance request signed
     */
    public String getHasInsuranceRequestSigned() {

        return hasInsuranceRequestSigned;
    }

    /**
     * Set the has insurance request signed.
     *
     * @param hasInsuranceRequestSigned  has insurance request signed
     */
    public void setHasInsuranceRequestSigned(String hasInsuranceRequestSigned) {

        this.hasInsuranceRequestSigned = hasInsuranceRequestSigned;
    }

    /**
     * Gets the has services payment request signed.
     *
     * @return has services payment request signed
     */
    public String getHasServicesPaymentRequestSigned() {

        return hasServicesPaymentRequestSigned;
    }

    /**
     * Set the has services payment request signed.
     *
     * @param hasServicesPaymentRequestSigned  has services payment request signed
     */
    public void setHasServicesPaymentRequestSigned(
        String hasServicesPaymentRequestSigned) {

        this.hasServicesPaymentRequestSigned = hasServicesPaymentRequestSigned;
    }

    /**
     * Gets the has marketing consent signed.
     *
     * @return has marketing consent signed
     */
    public String getHasMarketingConsentSigned() {

        return hasMarketingConsentSigned;
    }

    /**
     * Set the has marketing consent signed.
     *
     * @param hasMarketingConsentSigned  has marketing consent signed
     */
    public void setHasMarketingConsentSigned(String hasMarketingConsentSigned) {

        this.hasMarketingConsentSigned = hasMarketingConsentSigned;
    }

    /**
     * Gets the has E bank PIN request signed.
     *
     * @return has E bank PIN request signed
     */
    public String getHasEBankPINRequestSigned() {

        return hasEBankPINRequestSigned;
    }

    /**
     * Set the has E bank PIN request signed.
     *
     * @param hasEBankPINRequestSigned  has E bank PIN request signed
     */
    public void setHasEBankPINRequestSigned(String hasEBankPINRequestSigned) {

        this.hasEBankPINRequestSigned = hasEBankPINRequestSigned;
    }

    /**
     * Gets the has supplementary card application signed.
     *
     * @return has supplementary card application signed
     */
    public String getHasSupplementaryCardApplicationSigned() {

        return hasSupplementaryCardApplicationSigned;
    }

    /**
     * Set the has supplementary card application signed.
     *
     * @param hasSupplementaryCardApplicationSigned  has supplementary card application signed
     */
    public void setHasSupplementaryCardApplicationSigned(
        String hasSupplementaryCardApplicationSigned) {

        this.hasSupplementaryCardApplicationSigned =
            hasSupplementaryCardApplicationSigned;
    }

    /**
     * Gets the has upgrade product request signed.
     *
     * @return has upgrade product request signed
     */
    public String getHasUpgradeProductRequestSigned() {

        return hasUpgradeProductRequestSigned;
    }

    /**
     * Set the has upgrade product request signed.
     *
     * @param hasUpgradeProductRequestSigned  has upgrade product request signed
     */
    public void setHasUpgradeProductRequestSigned(
        String hasUpgradeProductRequestSigned) {

        this.hasUpgradeProductRequestSigned = hasUpgradeProductRequestSigned;
    }

    /**
     * Gets the reward type.
     *
     * @return reward type
     */
    public String getRewardType() {

        return rewardType;
    }

    /**
     * Set the reward type.
     *
     * @param rewardType  reward type
     */
    public void setRewardType(String rewardType) {

        this.rewardType = rewardType;
    }

    /**
     * Gets the max authorized amount.
     *
     * @return max authorized amount
     */
    public List<Double> getMaxAuthorizedAmount() {

        return maxAuthorizedAmount;
    }

    /**
     * Set the max authorized amount.
     *
     * @param maxAuthorizedAmount  max authorized amount
     */
    public void setMaxAuthorizedAmount(List<Double> maxAuthorizedAmount) {

        this.maxAuthorizedAmount = maxAuthorizedAmount;
    }

    /**
     * Gets the max amount to charge.
     *
     * @return max amount to charge
     */
    public double getMaxAmountToCharge() {

        return maxAmountToCharge;
    }

    /**
     * Set the max amount to charge.
     *
     * @param maxAmountToCharge  max amount to charge
     */
    public void setMaxAmountToCharge(double maxAmountToCharge) {

        this.maxAmountToCharge = maxAmountToCharge;
    }

    /**
     * Gets the credit card payment flag.
     *
     * @return credit card payment flag
     */
    public String getCreditCardPaymentFlag() {

        return creditCardPaymentFlag;
    }

    /**
     * Set the credit card payment flag.
     *
     * @param creditCardPaymentFlag  credit card payment flag
     */
    public void setCreditCardPaymentFlag(String creditCardPaymentFlag) {

        this.creditCardPaymentFlag = creditCardPaymentFlag;
    }

    /**
     * Gets the current owned product.
     *
     * @return current owned product
     */
    public String getCurrentOwnedProduct() {

        return currentOwnedProduct;
    }

    /**
     * Set the current owned product.
     *
     * @param currentOwnedProduct  current owned product
     */
    public void setCurrentOwnedProduct(String currentOwnedProduct) {

        this.currentOwnedProduct = currentOwnedProduct;
    }

    /**
     * Gets the desired product.
     *
     * @return desired product
     */
    public String getDesiredProduct() {

        return desiredProduct;
    }

    /**
     * Set the desired product.
     *
     * @param desiredProduct  desired product
     */
    public void setDesiredProduct(String desiredProduct) {

        this.desiredProduct = desiredProduct;
    }

    /**
     * Gets the sms and email flag.
     *
     * @return sms and email flag
     */
    public String getSmsAndEmailFlag() {

        return smsAndEmailFlag;
    }

    /**
     * Set the sms and email flag.
     *
     * @param smsAndEmailFlag  sms and email flag
     */
    public void setSmsAndEmailFlag(String smsAndEmailFlag) {

        this.smsAndEmailFlag = smsAndEmailFlag;
    }

    /**
     * Gets the is libra service requested.
     *
     * @return is libra service requested
     */
    public String getIsLibraServiceRequested() {

        return isLibraServiceRequested;
    }

    /**
     * Set the is libra service requested.
     *
     * @param isLibraServiceRequested  is libra service requested
     */
    public void setIsLibraServiceRequested(String isLibraServiceRequested) {

        this.isLibraServiceRequested = isLibraServiceRequested;
    }

    /**
     * Gets the is balance protection insurance requested.
     *
     * @return is balance protection insurance requested
     */
    public String getIsBalanceProtectionInsuranceRequested() {

        return isBalanceProtectionInsuranceRequested;
    }

    /**
     * Set the is balance protection insurance requested.
     *
     * @param isBalanceProtectionInsuranceRequested  is balance protection insurance requested
     */
    public void setIsBalanceProtectionInsuranceRequested(
        String isBalanceProtectionInsuranceRequested) {

        this.isBalanceProtectionInsuranceRequested =
            isBalanceProtectionInsuranceRequested;
    }

    /**
     * Gets the is deporteismo assistance requested.
     *
     * @return is deporteismo assistance requested
     */
    public String getIsDeporteismoAssistanceRequested() {

        return isDeporteismoAssistanceRequested;
    }

    /**
     * Set the is deporteismo assistance requested.
     *
     * @param isDeporteismoAssistanceRequested  is deporteismo assistance requested
     */
    public void setIsDeporteismoAssistanceRequested(
        String isDeporteismoAssistanceRequested) {

        this.isDeporteismoAssistanceRequested =
            isDeporteismoAssistanceRequested;
    }

    /**
     * Gets the is protection insurance requested.
     *
     * @return is protection insurance requested
     */
    public String getIsProtectionInsuranceRequested() {

        return isProtectionInsuranceRequested;
    }

    /**
     * Set the is protection insurance requested.
     *
     * @param isProtectionInsuranceRequested  is protection insurance requested
     */
    public void setIsProtectionInsuranceRequested(
        String isProtectionInsuranceRequested) {

        this.isProtectionInsuranceRequested = isProtectionInsuranceRequested;
    }

    /**
     * Gets the is E statement requested.
     *
     * @return is E statement requested
     */
    public String getIsEStatementRequested() {

        return isEStatementRequested;
    }

    /**
     * Set the is E statement requested.
     *
     * @param isEStatementRequested  is E statement requested
     */
    public void setIsEStatementRequested(String isEStatementRequested) {

        this.isEStatementRequested = isEStatementRequested;
    }

    /**
     * Gets the product family.
     *
     * @return product family
     */
    public String getProductFamily() {

        return productFamily;
    }

    /**
     * Set the product family.
     *
     * @param productFamily  product family
     */
    public void setProductFamily(String productFamily) {

        this.productFamily = productFamily;
    }

    /**
     * Gets the loan request amount.
     *
     * @return loan request amount
     */
    public double getLoanRequestAmount() {

        return loanRequestAmount;
    }

    /**
     * Set the loan request amount.
     *
     * @param loanRequestAmount  loan request amount
     */
    public void setLoanRequestAmount(double loanRequestAmount) {

        this.loanRequestAmount = loanRequestAmount;
    }

    /**
     * Gets the is E banking requested.
     *
     * @return is E banking requested
     */
    public String getIsEBankingRequested() {

        return isEBankingRequested;
    }

    /**
     * Set the is E banking requested.
     *
     * @param isEBankingRequested  is E banking requested
     */
    public void setIsEBankingRequested(String isEBankingRequested) {

        this.isEBankingRequested = isEBankingRequested;
    }

    /**
     * Gets the is priority pass card requested.
     *
     * @return is priority pass card requested
     */
    public String getIsPriorityPassCardRequested() {

        return isPriorityPassCardRequested;
    }

    /**
     * Set the is priority pass card requested.
     *
     * @param isPriorityPassCardRequested  is priority pass card requested
     */
    public void
        setIsPriorityPassCardRequested(String isPriorityPassCardRequested) {

        this.isPriorityPassCardRequested = isPriorityPassCardRequested;
    }

    /**
     * Gets the requested credit line amount.
     *
     * @return requested credit line amount
     */
    public double getRequestedCreditLineAmount() {

        return requestedCreditLineAmount;
    }

    /**
     * Set the requested credit line amount.
     *
     * @param requestedCreditLineAmount  requested credit line amount
     */
    public void setRequestedCreditLineAmount(double requestedCreditLineAmount) {

        this.requestedCreditLineAmount = requestedCreditLineAmount;
    }

    /**
     * Gets the card no.
     *
     * @return card no
     */
    public String getCardNo() {

        return cardNo;
    }

    /**
     * Set the card no.
     *
     * @param cardNo  card no
     */
    public void setCardNo(String cardNo) {

        this.cardNo = cardNo;
    }

    /**
     * Gets the suggested pre created card credit limit.
     *
     * @return suggested pre created card credit limit
     */
    public double getSuggestedPreCreatedCardCreditLimit() {

        return suggestedPreCreatedCardCreditLimit;
    }

    /**
     * Set the suggested pre created card credit limit.
     *
     * @param suggestedPreCreatedCardCreditLimit  suggested pre created card credit limit
     */
    public void setSuggestedPreCreatedCardCreditLimit(
        double suggestedPreCreatedCardCreditLimit) {

        this.suggestedPreCreatedCardCreditLimit =
            suggestedPreCreatedCardCreditLimit;
    }

    /**
     * Gets the dda account number.
     *
     * @return dda account number
     */
    public String getDdaAccountNumber() {

        return ddaAccountNumber;
    }

    /**
     * Set the dda account number.
     *
     * @param ddaAccountNumber  dda account number
     */
    public void setDdaAccountNumber(String ddaAccountNumber) {

        this.ddaAccountNumber = ddaAccountNumber;
    }

    /**
     * Gets the dda branch number.
     *
     * @return dda branch number
     */
    public String getDdaBranchNumber() {

        return ddaBranchNumber;
    }

    /**
     * Set the dda branch number.
     *
     * @param ddaBranchNumber  dda branch number
     */
    public void setDdaBranchNumber(String ddaBranchNumber) {

        this.ddaBranchNumber = ddaBranchNumber;
    }

    /**
     * Gets the disbursement type.
     *
     * @return disbursement type
     */
    public String getDisbursementType() {

        return disbursementType;
    }

    /**
     * Set the disbursement type.
     *
     * @param disbursementType  disbursement type
     */
    public void setDisbursementType(String disbursementType) {

        this.disbursementType = disbursementType;
    }

    /**
     * Gets the requested tenor.
     *
     * @return requested tenor
     */
    public String getRequestedTenor() {

        return requestedTenor;
    }

    /**
     * Set the requested tenor.
     *
     * @param requestedTenor  requested tenor
     */
    public void setRequestedTenor(String requestedTenor) {

        this.requestedTenor = requestedTenor;
    }

    /**
     * Gets the fee collection mode.
     *
     * @return fee collection mode
     */
    public String getFeeCollectionMode() {

        return feeCollectionMode;
    }

    /**
     * Set the fee collection mode.
     *
     * @param feeCollectionMode  fee collection mode
     */
    public void setFeeCollectionMode(String feeCollectionMode) {

        this.feeCollectionMode = feeCollectionMode;
    }

    /**
     * Gets the cli account number.
     *
     * @return cli account number
     */
    public String getCliAccountNumber() {

        return cliAccountNumber;
    }

    /**
     * Set the cli account number.
     *
     * @param cliAccountNumber  cli account number
     */
    public void setCliAccountNumber(String cliAccountNumber) {

        this.cliAccountNumber = cliAccountNumber;
    }

    /**
     * Gets the reject reason code.
     *
     * @return reject reason code
     */
    public String getRejectReasonCode() {

        return rejectReasonCode;
    }

    /**
     * Set the reject reason code.
     *
     * @param rejectReasonCode  reject reason code
     */
    public void setRejectReasonCode(String rejectReasonCode) {

        this.rejectReasonCode = rejectReasonCode;
    }

    /**
     * Gets the special interest rate.
     *
     * @return special interest rate
     */
    public double getSpecialInterestRate() {

        return specialInterestRate;
    }

    /**
     * Set the special interest rate.
     *
     * @param specialInterestRate  special interest rate
     */
    public void setSpecialInterestRate(double specialInterestRate) {

        this.specialInterestRate = specialInterestRate;
    }

}
