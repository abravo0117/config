/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: AppConfiguration.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.crud.creditCardOppening;

import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 *  <code>AppConfiguration</code>.
 *
 * @author vb44309
 * @version 1.0
 */
@Configuration
public class AppConfiguration {

    /**
     * Marshaller.
     *
     * @return jaxb 2 marshaller
     */
    //@Bean
    public Jaxb2Marshaller marshaller() {

        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        return marshaller;
    }

    /**
     * News api.
     *
     * @return docket
     */
    @Bean
    public Docket newsApi() {

        return new Docket(DocumentationType.SWAGGER_2).groupName("query")
            .apiInfo(apiInfo()).select().paths(regex("/v1/*.*")).build();
    }

    /**
     * Api info.
     *
     * @return api info
     */
    private ApiInfo apiInfo() {

        return new ApiInfoBuilder().title("Credit Card Add")
            .description("Calls the Credit Card Add SOAP WS").termsOfServiceUrl("")
            .contact("softtek.com").license("").licenseUrl("").version("1.0")
            .build();
    }

}
