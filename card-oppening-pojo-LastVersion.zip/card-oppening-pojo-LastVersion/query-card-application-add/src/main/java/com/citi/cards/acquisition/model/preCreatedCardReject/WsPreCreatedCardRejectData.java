/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: WsPreCreatedCardRejectData.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.preCreatedCardReject;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardRejectUpdRq;
import com.citi.cards.acquisition.model.wsGenerics.GenericSOAPMessageBody;

/**
 *  <code>WsPreCreatedCardRejectData</code>.
 *
 * @author vb44309
 * @version 1.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Body")
@XmlType
public class WsPreCreatedCardRejectData implements Serializable {

    /** The constant serialVersionUID. */
    private static final long serialVersionUID = 7546470977944133205L;

    /** data. */
    @XmlElement(name = "PreCreatedCardRejectUpdRq",
        namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15")
    protected PreCreatedCardRejectUpdRq data; // NOSONAR

    /**
     * Gets the data.
     *
     * @return data
     */
    public PreCreatedCardRejectUpdRq getData() {

        return data;
    }

    /**
     * Set the data.
     *
     * @param t  data
     */
    public void setData(PreCreatedCardRejectUpdRq t) {

        this.data = t;

    }

}
