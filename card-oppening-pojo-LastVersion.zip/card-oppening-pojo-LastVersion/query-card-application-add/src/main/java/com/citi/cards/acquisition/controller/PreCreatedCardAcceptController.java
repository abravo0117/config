/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: PreCreatedCardAcceptController.java
 * Original Author: Softtek - AGLV
 * Creation Date: 8/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.controller;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.validation.Valid;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardAcceptUpdRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardAcceptUpdRs;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.request.GeneralRequest;
import com.citi.cards.acquisition.response.generics.AbstractBaseCrudResponse;
import com.citi.cards.acquisition.response.generics.CRUDErrorResponse;
import com.citi.cards.acquisition.service.PreCreatedCardAcceptService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Class PreCreatedCardAcceptController.
 *
 * @author vb44309
 * @version 1.0
 */
@RestController
public class PreCreatedCardAcceptController {

    /** The Constant LOG. */
    private static final Logger LOG =
        Logger.getLogger(PreCreatedCardAcceptController.class);

    /** The service. */
    @Autowired
    private PreCreatedCardAcceptService service;

    /**
     * Execute.
     *
     * @param request            the request
     * @return the response entity
     * @throws DatatypeConfigurationException datatype configuration exception.
     */
    
    @ApiResponses(
        {
            @ApiResponse(response=PreCreatedCardAcceptUpdRs.class,message="OK",code=200),
            @ApiResponse(response=CRUDErrorResponse.class,message="",code=500),
            @ApiResponse(response=CRUDErrorResponse.class,message="",code=404),
            @ApiResponse(response=CRUDErrorResponse.class,message="",code=403)
        })
    @ApiOperation(value = "Pre Created Card Accept",
        response = PreCreatedCardAcceptUpdRs.class)
    @RequestMapping(value = "/v1/cards/creditinitiation/accept",
        consumes = {"application/json"}, produces = {"application/json"},
        method = {RequestMethod.POST})
    public ResponseEntity<AbstractBaseCrudResponse> execute(@RequestBody(
        required = true) @Valid GeneralRequest<PreCreatedCardAcceptUpdRq> request) throws DatatypeConfigurationException {

        LOG.info("Entering to PreCreated Card Accept Controller...");

        ResponseEntity<AbstractBaseCrudResponse> response = null;
        AbstractBaseCrudResponse res = null;
        
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(Calendar.getInstance().getTime());
        XMLGregorianCalendar xmlCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
        
        RqHeader rqHeader = new RqHeader();
        rqHeader.setDateAndTimeStamp(xmlCalendar);
        rqHeader.setClientDetails(request.getHeader().getClientDetails());
        rqHeader.setUUID(request.getHeader().getUuid());
        rqHeader.setVersion(request.getHeader().getVersion());

        res = service.execute(request.getBody(), rqHeader);

        response = new ResponseEntity<>(res, res.getResponseStatus());

        return response;
    }

    /**
     * Sets the service.
     *
     * @param service
     *            the new service
     */
    public void setService(PreCreatedCardAcceptService service) {

        this.service = service;
    }

}
