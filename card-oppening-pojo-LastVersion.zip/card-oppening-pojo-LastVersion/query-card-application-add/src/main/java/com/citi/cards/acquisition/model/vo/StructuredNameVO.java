/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: StructuredNameVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

/**
 *  <code>StructuredNameVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class StructuredNameVO {

    /** first. */
    private String first;

    /** middle. */
    private String middle;

    /** last. */
    private String last;

    /** full. */
    private String full;

    /**
     * Gets the first.
     *
     * @return first
     */
    public String getFirst() {

        return first;
    }

    /**
     * Set the first.
     *
     * @param first  first
     */
    public void setFirst(String first) {

        this.first = first;
    }

    /**
     * Gets the middle.
     *
     * @return middle
     */
    public String getMiddle() {

        return middle;
    }

    /**
     * Set the middle.
     *
     * @param middle  middle
     */
    public void setMiddle(String middle) {

        this.middle = middle;
    }

    /**
     * Gets the last.
     *
     * @return last
     */
    public String getLast() {

        return last;
    }

    /**
     * Set the last.
     *
     * @param last  last
     */
    public void setLast(String last) {

        this.last = last;
    }

    /**
     * Gets the full.
     *
     * @return full
     */
    public String getFull() {

        return full;
    }

    /**
     * Set the full.
     *
     * @param full  full
     */
    public void setFull(String full) {

        this.full = full;
    }

}
