/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: OfferVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

import java.math.BigInteger;
import java.util.Date;

/**
 *  <code>OfferVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class OfferVO {

    /** offer ID. */
    private String offerID;

    /** ctrl 1. */
    private String ctrl1;

    /** ctrl 2. */
    private String ctrl2;

    /** ctrl 3. */
    private String ctrl3;

    /** ctrl 4. */
    private String ctrl4;

    /** fk application id. */
    private String fkApplicationId;

    /** product code. */
    private String productCode;

    /** pp product code. */
    private String ppProductCode;

    /** offer status. */
    private String offerStatus;

    /** reln type. */
    private String relnType;

    /** reln no. */
    private String relnNo;

    /** reln ctrl 1. */
    private String relnCtrl1;

    /** reln ctrl 2. */
    private String relnCtrl2;

    /** reln ctrl 3. */
    private String relnCtrl3;

    /** reln ctrl 4. */
    private String relnCtrl4;

    /** account no. */
    private String accountNo;

    /** source channel. */
    private String sourceChannel;

    /** bundle ID. */
    private String bundleID;

    /** order seq. */
    private String orderSeq;

    /** last main ID. */
    private String lastMainID;

    /** last maint time stamp. */
    private String lastMaintTimeStamp;

    /** customer nos. */
    private CustomerNosVO customerNos;

    /** prod family. */
    private String prodFamily;

    /** data status. */
    private String dataStatus;

    /** acct ctl 1. */
    private String acctCtl1;

    /** acct ctl 2. */
    private String acctCtl2;

    /** acct ctl 3. */
    private String acctCtl3;

    /** acct ctl 4. */
    private String acctCtl4;

    /** nt prod code. */
    private String ntProdCode;

    /** reln catg. */
    private String relnCatg;

    /** campaign ID. */
    private String campaignID;

    /** wave ID. */
    private String waveID;

    /** prod code desc. */
    private String prodCodeDesc;

    /** prod family desc. */
    private String prodFamilyDesc;

    /** account title. */
    private String accountTitle;

    /** account title 1. */
    private String accountTitle1;

    /** from AG ind. */
    private String fromAGInd;

    /** cost rel prcg grp. */
    private String costRelPrcgGrp;

    /** sign inst. */
    private String signInst;

    /** sign inst remark. */
    private String signInstRemark;

    /** sign instr req. */
    private String signInstrReq;

    /** maker user ID. */
    private String makerUserID;

    /** checker user ID. */
    private String checkerUserID;

    /** prd seq no. */
    private String prdSeqNo;

    /** reln seq no. */
    private String relnSeqNo;

    /** ccy. */
    private String ccy;

    /** offer priority. */
    private BigInteger offerPriority;

    /** offer availability. */
    private String offerAvailability;

    /** offer creation mode. */
    private String offerCreationMode;

    /** campaign category. */
    private String campaignCategory;

    /** offer start date. */
    private Date offerStartDate;

    /** offer end date. */
    private Date offerEndDate;

    /** latest offer status. */
    private String latestOfferStatus;

    /** campaign description. */
    private String campaignDescription;

    /** sales script text. */
    private String salesScriptText;

    /** wave description. */
    private String waveDescription;

    /** get offer response code. */
    private String getOfferResponseCode;

    /** get offer response text. */
    private String getOfferResponseText;

    /** user field 1. */
    private String userField1;

    /** user field 2. */
    private String userField2;

    /** user field 3. */
    private String userField3;

    /** user field 4. */
    private String userField4;

    /** user field 5. */
    private String userField5;

    /** user field 6. */
    private String userField6;

    /** user field 7. */
    private String userField7;

    /** user field 8. */
    private String userField8;

    /** user field 9. */
    private String userField9;

    /** user field 10. */
    private String userField10;

    /** user field 11. */
    private String userField11;

    /** user field 12. */
    private String userField12;

    /** user field 13. */
    private String userField13;

    /** user field 14. */
    private String userField14;

    /** user field 15. */
    private String userField15;

    /** user field 16. */
    private String userField16;

    /** user field 17. */
    private String userField17;

    /** user field 18. */
    private String userField18;

    /** user field 19. */
    private String userField19;

    /** user field 20. */
    private String userField20;

    /** user field 21. */
    private String userField21;

    /** user field 22. */
    private String userField22;

    /** user field 23. */
    private String userField23;

    /** user field 24. */
    private String userField24;

    /** user field 25. */
    private String userField25;

    /** user field 26. */
    private String userField26;

    /** user field 27. */
    private String userField27;

    /** user field 28. */
    private String userField28;

    /** user field 29. */
    private String userField29;

    /** user field 30. */
    private String userField30;

    /**
     * Gets the offer ID.
     *
     * @return offer ID
     */
    public String getOfferID() {

        return offerID;
    }

    /**
     * Set the offer ID.
     *
     * @param offerID  offer ID
     */
    public void setOfferID(String offerID) {

        this.offerID = offerID;
    }

    /**
     * Gets the ctrl 1.
     *
     * @return ctrl 1
     */
    public String getCtrl1() {

        return ctrl1;
    }

    /**
     * Set the ctrl 1.
     *
     * @param ctrl1  ctrl 1
     */
    public void setCtrl1(String ctrl1) {

        this.ctrl1 = ctrl1;
    }

    /**
     * Gets the ctrl 2.
     *
     * @return ctrl 2
     */
    public String getCtrl2() {

        return ctrl2;
    }

    /**
     * Set the ctrl 2.
     *
     * @param ctrl2  ctrl 2
     */
    public void setCtrl2(String ctrl2) {

        this.ctrl2 = ctrl2;
    }

    /**
     * Gets the ctrl 3.
     *
     * @return ctrl 3
     */
    public String getCtrl3() {

        return ctrl3;
    }

    /**
     * Set the ctrl 3.
     *
     * @param ctrl3  ctrl 3
     */
    public void setCtrl3(String ctrl3) {

        this.ctrl3 = ctrl3;
    }

    /**
     * Gets the ctrl 4.
     *
     * @return ctrl 4
     */
    public String getCtrl4() {

        return ctrl4;
    }

    /**
     * Set the ctrl 4.
     *
     * @param ctrl4  ctrl 4
     */
    public void setCtrl4(String ctrl4) {

        this.ctrl4 = ctrl4;
    }

    /**
     * Gets the fk application id.
     *
     * @return fk application id
     */
    public String getFkApplicationId() {

        return fkApplicationId;
    }

    /**
     * Set the fk application id.
     *
     * @param fkApplicationId  fk application id
     */
    public void setFkApplicationId(String fkApplicationId) {

        this.fkApplicationId = fkApplicationId;
    }

    /**
     * Gets the product code.
     *
     * @return product code
     */
    public String getProductCode() {

        return productCode;
    }

    /**
     * Set the product code.
     *
     * @param productCode  product code
     */
    public void setProductCode(String productCode) {

        this.productCode = productCode;
    }

    /**
     * Gets the pp product code.
     *
     * @return pp product code
     */
    public String getPpProductCode() {

        return ppProductCode;
    }

    /**
     * Set the pp product code.
     *
     * @param ppProductCode  pp product code
     */
    public void setPpProductCode(String ppProductCode) {

        this.ppProductCode = ppProductCode;
    }

    /**
     * Gets the offer status.
     *
     * @return offer status
     */
    public String getOfferStatus() {

        return offerStatus;
    }

    /**
     * Set the offer status.
     *
     * @param offerStatus  offer status
     */
    public void setOfferStatus(String offerStatus) {

        this.offerStatus = offerStatus;
    }

    /**
     * Gets the reln type.
     *
     * @return reln type
     */
    public String getRelnType() {

        return relnType;
    }

    /**
     * Set the reln type.
     *
     * @param relnType  reln type
     */
    public void setRelnType(String relnType) {

        this.relnType = relnType;
    }

    /**
     * Gets the reln no.
     *
     * @return reln no
     */
    public String getRelnNo() {

        return relnNo;
    }

    /**
     * Set the reln no.
     *
     * @param relnNo  reln no
     */
    public void setRelnNo(String relnNo) {

        this.relnNo = relnNo;
    }

    /**
     * Gets the reln ctrl 1.
     *
     * @return reln ctrl 1
     */
    public String getRelnCtrl1() {

        return relnCtrl1;
    }

    /**
     * Set the reln ctrl 1.
     *
     * @param relnCtrl1  reln ctrl 1
     */
    public void setRelnCtrl1(String relnCtrl1) {

        this.relnCtrl1 = relnCtrl1;
    }

    /**
     * Gets the reln ctrl 2.
     *
     * @return reln ctrl 2
     */
    public String getRelnCtrl2() {

        return relnCtrl2;
    }

    /**
     * Set the reln ctrl 2.
     *
     * @param relnCtrl2  reln ctrl 2
     */
    public void setRelnCtrl2(String relnCtrl2) {

        this.relnCtrl2 = relnCtrl2;
    }

    /**
     * Gets the reln ctrl 3.
     *
     * @return reln ctrl 3
     */
    public String getRelnCtrl3() {

        return relnCtrl3;
    }

    /**
     * Set the reln ctrl 3.
     *
     * @param relnCtrl3  reln ctrl 3
     */
    public void setRelnCtrl3(String relnCtrl3) {

        this.relnCtrl3 = relnCtrl3;
    }

    /**
     * Gets the reln ctrl 4.
     *
     * @return reln ctrl 4
     */
    public String getRelnCtrl4() {

        return relnCtrl4;
    }

    /**
     * Set the reln ctrl 4.
     *
     * @param relnCtrl4  reln ctrl 4
     */
    public void setRelnCtrl4(String relnCtrl4) {

        this.relnCtrl4 = relnCtrl4;
    }

    /**
     * Gets the account no.
     *
     * @return account no
     */
    public String getAccountNo() {

        return accountNo;
    }

    /**
     * Set the account no.
     *
     * @param accountNo  account no
     */
    public void setAccountNo(String accountNo) {

        this.accountNo = accountNo;
    }

    /**
     * Gets the source channel.
     *
     * @return source channel
     */
    public String getSourceChannel() {

        return sourceChannel;
    }

    /**
     * Set the source channel.
     *
     * @param sourceChannel  source channel
     */
    public void setSourceChannel(String sourceChannel) {

        this.sourceChannel = sourceChannel;
    }

    /**
     * Gets the bundle ID.
     *
     * @return bundle ID
     */
    public String getBundleID() {

        return bundleID;
    }

    /**
     * Set the bundle ID.
     *
     * @param bundleID  bundle ID
     */
    public void setBundleID(String bundleID) {

        this.bundleID = bundleID;
    }

    /**
     * Gets the order seq.
     *
     * @return order seq
     */
    public String getOrderSeq() {

        return orderSeq;
    }

    /**
     * Set the order seq.
     *
     * @param orderSeq  order seq
     */
    public void setOrderSeq(String orderSeq) {

        this.orderSeq = orderSeq;
    }

    /**
     * Gets the last main ID.
     *
     * @return last main ID
     */
    public String getLastMainID() {

        return lastMainID;
    }

    /**
     * Set the last main ID.
     *
     * @param lastMainID  last main ID
     */
    public void setLastMainID(String lastMainID) {

        this.lastMainID = lastMainID;
    }

    /**
     * Gets the last maint time stamp.
     *
     * @return last maint time stamp
     */
    public String getLastMaintTimeStamp() {

        return lastMaintTimeStamp;
    }

    /**
     * Set the last maint time stamp.
     *
     * @param lastMaintTimeStamp  last maint time stamp
     */
    public void setLastMaintTimeStamp(String lastMaintTimeStamp) {

        this.lastMaintTimeStamp = lastMaintTimeStamp;
    }

    /**
     * Gets the customer nos.
     *
     * @return customer nos
     */
    public CustomerNosVO getCustomerNos() {

        return customerNos;
    }

    /**
     * Set the customer nos.
     *
     * @param customerNos  customer nos
     */
    public void setCustomerNos(CustomerNosVO customerNos) {

        this.customerNos = customerNos;
    }

    /**
     * Gets the prod family.
     *
     * @return prod family
     */
    public String getProdFamily() {

        return prodFamily;
    }

    /**
     * Set the prod family.
     *
     * @param prodFamily  prod family
     */
    public void setProdFamily(String prodFamily) {

        this.prodFamily = prodFamily;
    }

    /**
     * Gets the data status.
     *
     * @return data status
     */
    public String getDataStatus() {

        return dataStatus;
    }

    /**
     * Set the data status.
     *
     * @param dataStatus  data status
     */
    public void setDataStatus(String dataStatus) {

        this.dataStatus = dataStatus;
    }

    /**
     * Gets the acct ctl 1.
     *
     * @return acct ctl 1
     */
    public String getAcctCtl1() {

        return acctCtl1;
    }

    /**
     * Set the acct ctl 1.
     *
     * @param acctCtl1  acct ctl 1
     */
    public void setAcctCtl1(String acctCtl1) {

        this.acctCtl1 = acctCtl1;
    }

    /**
     * Gets the acct ctl 2.
     *
     * @return acct ctl 2
     */
    public String getAcctCtl2() {

        return acctCtl2;
    }

    /**
     * Set the acct ctl 2.
     *
     * @param acctCtl2  acct ctl 2
     */
    public void setAcctCtl2(String acctCtl2) {

        this.acctCtl2 = acctCtl2;
    }

    /**
     * Gets the acct ctl 3.
     *
     * @return acct ctl 3
     */
    public String getAcctCtl3() {

        return acctCtl3;
    }

    /**
     * Set the acct ctl 3.
     *
     * @param acctCtl3  acct ctl 3
     */
    public void setAcctCtl3(String acctCtl3) {

        this.acctCtl3 = acctCtl3;
    }

    /**
     * Gets the acct ctl 4.
     *
     * @return acct ctl 4
     */
    public String getAcctCtl4() {

        return acctCtl4;
    }

    /**
     * Set the acct ctl 4.
     *
     * @param acctCtl4  acct ctl 4
     */
    public void setAcctCtl4(String acctCtl4) {

        this.acctCtl4 = acctCtl4;
    }

    /**
     * Gets the nt prod code.
     *
     * @return nt prod code
     */
    public String getNtProdCode() {

        return ntProdCode;
    }

    /**
     * Set the nt prod code.
     *
     * @param ntProdCode  nt prod code
     */
    public void setNtProdCode(String ntProdCode) {

        this.ntProdCode = ntProdCode;
    }

    /**
     * Gets the reln catg.
     *
     * @return reln catg
     */
    public String getRelnCatg() {

        return relnCatg;
    }

    /**
     * Set the reln catg.
     *
     * @param relnCatg  reln catg
     */
    public void setRelnCatg(String relnCatg) {

        this.relnCatg = relnCatg;
    }

    /**
     * Gets the campaign ID.
     *
     * @return campaign ID
     */
    public String getCampaignID() {

        return campaignID;
    }

    /**
     * Set the campaign ID.
     *
     * @param campaignID  campaign ID
     */
    public void setCampaignID(String campaignID) {

        this.campaignID = campaignID;
    }

    /**
     * Gets the wave ID.
     *
     * @return wave ID
     */
    public String getWaveID() {

        return waveID;
    }

    /**
     * Set the wave ID.
     *
     * @param waveID  wave ID
     */
    public void setWaveID(String waveID) {

        this.waveID = waveID;
    }

    /**
     * Gets the prod code desc.
     *
     * @return prod code desc
     */
    public String getProdCodeDesc() {

        return prodCodeDesc;
    }

    /**
     * Set the prod code desc.
     *
     * @param prodCodeDesc  prod code desc
     */
    public void setProdCodeDesc(String prodCodeDesc) {

        this.prodCodeDesc = prodCodeDesc;
    }

    /**
     * Gets the prod family desc.
     *
     * @return prod family desc
     */
    public String getProdFamilyDesc() {

        return prodFamilyDesc;
    }

    /**
     * Set the prod family desc.
     *
     * @param prodFamilyDesc  prod family desc
     */
    public void setProdFamilyDesc(String prodFamilyDesc) {

        this.prodFamilyDesc = prodFamilyDesc;
    }

    /**
     * Gets the account title.
     *
     * @return account title
     */
    public String getAccountTitle() {

        return accountTitle;
    }

    /**
     * Set the account title.
     *
     * @param accountTitle  account title
     */
    public void setAccountTitle(String accountTitle) {

        this.accountTitle = accountTitle;
    }

    /**
     * Gets the account title 1.
     *
     * @return account title 1
     */
    public String getAccountTitle1() {

        return accountTitle1;
    }

    /**
     * Set the account title 1.
     *
     * @param accountTitle1  account title 1
     */
    public void setAccountTitle1(String accountTitle1) {

        this.accountTitle1 = accountTitle1;
    }

    /**
     * Gets the from AG ind.
     *
     * @return from AG ind
     */
    public String getFromAGInd() {

        return fromAGInd;
    }

    /**
     * Set the from AG ind.
     *
     * @param fromAGInd  from AG ind
     */
    public void setFromAGInd(String fromAGInd) {

        this.fromAGInd = fromAGInd;
    }

    /**
     * Gets the cost rel prcg grp.
     *
     * @return cost rel prcg grp
     */
    public String getCostRelPrcgGrp() {

        return costRelPrcgGrp;
    }

    /**
     * Set the cost rel prcg grp.
     *
     * @param costRelPrcgGrp  cost rel prcg grp
     */
    public void setCostRelPrcgGrp(String costRelPrcgGrp) {

        this.costRelPrcgGrp = costRelPrcgGrp;
    }

    /**
     * Gets the sign inst.
     *
     * @return sign inst
     */
    public String getSignInst() {

        return signInst;
    }

    /**
     * Set the sign inst.
     *
     * @param signInst  sign inst
     */
    public void setSignInst(String signInst) {

        this.signInst = signInst;
    }

    /**
     * Gets the sign inst remark.
     *
     * @return sign inst remark
     */
    public String getSignInstRemark() {

        return signInstRemark;
    }

    /**
     * Set the sign inst remark.
     *
     * @param signInstRemark  sign inst remark
     */
    public void setSignInstRemark(String signInstRemark) {

        this.signInstRemark = signInstRemark;
    }

    /**
     * Gets the sign instr req.
     *
     * @return sign instr req
     */
    public String getSignInstrReq() {

        return signInstrReq;
    }

    /**
     * Set the sign instr req.
     *
     * @param signInstrReq  sign instr req
     */
    public void setSignInstrReq(String signInstrReq) {

        this.signInstrReq = signInstrReq;
    }

    /**
     * Gets the maker user ID.
     *
     * @return maker user ID
     */
    public String getMakerUserID() {

        return makerUserID;
    }

    /**
     * Set the maker user ID.
     *
     * @param makerUserID  maker user ID
     */
    public void setMakerUserID(String makerUserID) {

        this.makerUserID = makerUserID;
    }

    /**
     * Gets the checker user ID.
     *
     * @return checker user ID
     */
    public String getCheckerUserID() {

        return checkerUserID;
    }

    /**
     * Set the checker user ID.
     *
     * @param checkerUserID  checker user ID
     */
    public void setCheckerUserID(String checkerUserID) {

        this.checkerUserID = checkerUserID;
    }

    /**
     * Gets the prd seq no.
     *
     * @return prd seq no
     */
    public String getPrdSeqNo() {

        return prdSeqNo;
    }

    /**
     * Set the prd seq no.
     *
     * @param prdSeqNo  prd seq no
     */
    public void setPrdSeqNo(String prdSeqNo) {

        this.prdSeqNo = prdSeqNo;
    }

    /**
     * Gets the reln seq no.
     *
     * @return reln seq no
     */
    public String getRelnSeqNo() {

        return relnSeqNo;
    }

    /**
     * Set the reln seq no.
     *
     * @param relnSeqNo  reln seq no
     */
    public void setRelnSeqNo(String relnSeqNo) {

        this.relnSeqNo = relnSeqNo;
    }

    /**
     * Gets the ccy.
     *
     * @return ccy
     */
    public String getCcy() {

        return ccy;
    }

    /**
     * Set the ccy.
     *
     * @param ccy  ccy
     */
    public void setCcy(String ccy) {

        this.ccy = ccy;
    }

    /**
     * Gets the offer priority.
     *
     * @return offer priority
     */
    public BigInteger getOfferPriority() {

        return offerPriority;
    }

    /**
     * Set the offer priority.
     *
     * @param offerPriority  offer priority
     */
    public void setOfferPriority(BigInteger offerPriority) {

        this.offerPriority = offerPriority;
    }

    /**
     * Gets the offer availability.
     *
     * @return offer availability
     */
    public String getOfferAvailability() {

        return offerAvailability;
    }

    /**
     * Set the offer availability.
     *
     * @param offerAvailability  offer availability
     */
    public void setOfferAvailability(String offerAvailability) {

        this.offerAvailability = offerAvailability;
    }

    /**
     * Gets the offer creation mode.
     *
     * @return offer creation mode
     */
    public String getOfferCreationMode() {

        return offerCreationMode;
    }

    /**
     * Set the offer creation mode.
     *
     * @param offerCreationMode  offer creation mode
     */
    public void setOfferCreationMode(String offerCreationMode) {

        this.offerCreationMode = offerCreationMode;
    }

    /**
     * Gets the campaign category.
     *
     * @return campaign category
     */
    public String getCampaignCategory() {

        return campaignCategory;
    }

    /**
     * Set the campaign category.
     *
     * @param campaignCategory  campaign category
     */
    public void setCampaignCategory(String campaignCategory) {

        this.campaignCategory = campaignCategory;
    }

    /**
     * Gets the offer start date.
     *
     * @return offer start date
     */
    public Date getOfferStartDate() {

        return offerStartDate;
    }

    /**
     * Set the offer start date.
     *
     * @param offerStartDate  offer start date
     */
    public void setOfferStartDate(Date offerStartDate) {

        this.offerStartDate = offerStartDate;
    }

    /**
     * Gets the offer end date.
     *
     * @return offer end date
     */
    public Date getOfferEndDate() {

        return offerEndDate;
    }

    /**
     * Set the offer end date.
     *
     * @param offerEndDate  offer end date
     */
    public void setOfferEndDate(Date offerEndDate) {

        this.offerEndDate = offerEndDate;
    }

    /**
     * Gets the latest offer status.
     *
     * @return latest offer status
     */
    public String getLatestOfferStatus() {

        return latestOfferStatus;
    }

    /**
     * Set the latest offer status.
     *
     * @param latestOfferStatus  latest offer status
     */
    public void setLatestOfferStatus(String latestOfferStatus) {

        this.latestOfferStatus = latestOfferStatus;
    }

    /**
     * Gets the campaign description.
     *
     * @return campaign description
     */
    public String getCampaignDescription() {

        return campaignDescription;
    }

    /**
     * Set the campaign description.
     *
     * @param campaignDescription  campaign description
     */
    public void setCampaignDescription(String campaignDescription) {

        this.campaignDescription = campaignDescription;
    }

    /**
     * Gets the sales script text.
     *
     * @return sales script text
     */
    public String getSalesScriptText() {

        return salesScriptText;
    }

    /**
     * Set the sales script text.
     *
     * @param salesScriptText  sales script text
     */
    public void setSalesScriptText(String salesScriptText) {

        this.salesScriptText = salesScriptText;
    }

    /**
     * Gets the wave description.
     *
     * @return wave description
     */
    public String getWaveDescription() {

        return waveDescription;
    }

    /**
     * Set the wave description.
     *
     * @param waveDescription  wave description
     */
    public void setWaveDescription(String waveDescription) {

        this.waveDescription = waveDescription;
    }

    /**
     * Gets the get offer response code.
     *
     * @return get offer response code
     */
    public String getGetOfferResponseCode() {

        return getOfferResponseCode;
    }

    /**
     * Set the get offer response code.
     *
     * @param getOfferResponseCode  get offer response code
     */
    public void setGetOfferResponseCode(String getOfferResponseCode) {

        this.getOfferResponseCode = getOfferResponseCode;
    }

    /**
     * Gets the get offer response text.
     *
     * @return get offer response text
     */
    public String getGetOfferResponseText() {

        return getOfferResponseText;
    }

    /**
     * Set the get offer response text.
     *
     * @param getOfferResponseText  get offer response text
     */
    public void setGetOfferResponseText(String getOfferResponseText) {

        this.getOfferResponseText = getOfferResponseText;
    }

    /**
     * Gets the user field 1.
     *
     * @return user field 1
     */
    public String getUserField1() {

        return userField1;
    }

    /**
     * Set the user field 1.
     *
     * @param userField1  user field 1
     */
    public void setUserField1(String userField1) {

        this.userField1 = userField1;
    }

    /**
     * Gets the user field 2.
     *
     * @return user field 2
     */
    public String getUserField2() {

        return userField2;
    }

    /**
     * Set the user field 2.
     *
     * @param userField2  user field 2
     */
    public void setUserField2(String userField2) {

        this.userField2 = userField2;
    }

    /**
     * Gets the user field 3.
     *
     * @return user field 3
     */
    public String getUserField3() {

        return userField3;
    }

    /**
     * Set the user field 3.
     *
     * @param userField3  user field 3
     */
    public void setUserField3(String userField3) {

        this.userField3 = userField3;
    }

    /**
     * Gets the user field 4.
     *
     * @return user field 4
     */
    public String getUserField4() {

        return userField4;
    }

    /**
     * Set the user field 4.
     *
     * @param userField4  user field 4
     */
    public void setUserField4(String userField4) {

        this.userField4 = userField4;
    }

    /**
     * Gets the user field 5.
     *
     * @return user field 5
     */
    public String getUserField5() {

        return userField5;
    }

    /**
     * Set the user field 5.
     *
     * @param userField5  user field 5
     */
    public void setUserField5(String userField5) {

        this.userField5 = userField5;
    }

    /**
     * Gets the user field 6.
     *
     * @return user field 6
     */
    public String getUserField6() {

        return userField6;
    }

    /**
     * Set the user field 6.
     *
     * @param userField6  user field 6
     */
    public void setUserField6(String userField6) {

        this.userField6 = userField6;
    }

    /**
     * Gets the user field 7.
     *
     * @return user field 7
     */
    public String getUserField7() {

        return userField7;
    }

    /**
     * Set the user field 7.
     *
     * @param userField7  user field 7
     */
    public void setUserField7(String userField7) {

        this.userField7 = userField7;
    }

    /**
     * Gets the user field 8.
     *
     * @return user field 8
     */
    public String getUserField8() {

        return userField8;
    }

    /**
     * Set the user field 8.
     *
     * @param userField8  user field 8
     */
    public void setUserField8(String userField8) {

        this.userField8 = userField8;
    }

    /**
     * Gets the user field 9.
     *
     * @return user field 9
     */
    public String getUserField9() {

        return userField9;
    }

    /**
     * Set the user field 9.
     *
     * @param userField9  user field 9
     */
    public void setUserField9(String userField9) {

        this.userField9 = userField9;
    }

    /**
     * Gets the user field 10.
     *
     * @return user field 10
     */
    public String getUserField10() {

        return userField10;
    }

    /**
     * Set the user field 10.
     *
     * @param userField10  user field 10
     */
    public void setUserField10(String userField10) {

        this.userField10 = userField10;
    }

    /**
     * Gets the user field 11.
     *
     * @return user field 11
     */
    public String getUserField11() {

        return userField11;
    }

    /**
     * Set the user field 11.
     *
     * @param userField11  user field 11
     */
    public void setUserField11(String userField11) {

        this.userField11 = userField11;
    }

    /**
     * Gets the user field 12.
     *
     * @return user field 12
     */
    public String getUserField12() {

        return userField12;
    }

    /**
     * Set the user field 12.
     *
     * @param userField12  user field 12
     */
    public void setUserField12(String userField12) {

        this.userField12 = userField12;
    }

    /**
     * Gets the user field 13.
     *
     * @return user field 13
     */
    public String getUserField13() {

        return userField13;
    }

    /**
     * Set the user field 13.
     *
     * @param userField13  user field 13
     */
    public void setUserField13(String userField13) {

        this.userField13 = userField13;
    }

    /**
     * Gets the user field 14.
     *
     * @return user field 14
     */
    public String getUserField14() {

        return userField14;
    }

    /**
     * Set the user field 14.
     *
     * @param userField14  user field 14
     */
    public void setUserField14(String userField14) {

        this.userField14 = userField14;
    }

    /**
     * Gets the user field 15.
     *
     * @return user field 15
     */
    public String getUserField15() {

        return userField15;
    }

    /**
     * Set the user field 15.
     *
     * @param userField15  user field 15
     */
    public void setUserField15(String userField15) {

        this.userField15 = userField15;
    }

    /**
     * Gets the user field 16.
     *
     * @return user field 16
     */
    public String getUserField16() {

        return userField16;
    }

    /**
     * Set the user field 16.
     *
     * @param userField16  user field 16
     */
    public void setUserField16(String userField16) {

        this.userField16 = userField16;
    }

    /**
     * Gets the user field 17.
     *
     * @return user field 17
     */
    public String getUserField17() {

        return userField17;
    }

    /**
     * Set the user field 17.
     *
     * @param userField17  user field 17
     */
    public void setUserField17(String userField17) {

        this.userField17 = userField17;
    }

    /**
     * Gets the user field 18.
     *
     * @return user field 18
     */
    public String getUserField18() {

        return userField18;
    }

    /**
     * Set the user field 18.
     *
     * @param userField18  user field 18
     */
    public void setUserField18(String userField18) {

        this.userField18 = userField18;
    }

    /**
     * Gets the user field 19.
     *
     * @return user field 19
     */
    public String getUserField19() {

        return userField19;
    }

    /**
     * Set the user field 19.
     *
     * @param userField19  user field 19
     */
    public void setUserField19(String userField19) {

        this.userField19 = userField19;
    }

    /**
     * Gets the user field 20.
     *
     * @return user field 20
     */
    public String getUserField20() {

        return userField20;
    }

    /**
     * Set the user field 20.
     *
     * @param userField20  user field 20
     */
    public void setUserField20(String userField20) {

        this.userField20 = userField20;
    }

    /**
     * Gets the user field 21.
     *
     * @return user field 21
     */
    public String getUserField21() {

        return userField21;
    }

    /**
     * Set the user field 21.
     *
     * @param userField21  user field 21
     */
    public void setUserField21(String userField21) {

        this.userField21 = userField21;
    }

    /**
     * Gets the user field 22.
     *
     * @return user field 22
     */
    public String getUserField22() {

        return userField22;
    }

    /**
     * Set the user field 22.
     *
     * @param userField22  user field 22
     */
    public void setUserField22(String userField22) {

        this.userField22 = userField22;
    }

    /**
     * Gets the user field 23.
     *
     * @return user field 23
     */
    public String getUserField23() {

        return userField23;
    }

    /**
     * Set the user field 23.
     *
     * @param userField23  user field 23
     */
    public void setUserField23(String userField23) {

        this.userField23 = userField23;
    }

    /**
     * Gets the user field 24.
     *
     * @return user field 24
     */
    public String getUserField24() {

        return userField24;
    }

    /**
     * Set the user field 24.
     *
     * @param userField24  user field 24
     */
    public void setUserField24(String userField24) {

        this.userField24 = userField24;
    }

    /**
     * Gets the user field 25.
     *
     * @return user field 25
     */
    public String getUserField25() {

        return userField25;
    }

    /**
     * Set the user field 25.
     *
     * @param userField25  user field 25
     */
    public void setUserField25(String userField25) {

        this.userField25 = userField25;
    }

    /**
     * Gets the user field 26.
     *
     * @return user field 26
     */
    public String getUserField26() {

        return userField26;
    }

    /**
     * Set the user field 26.
     *
     * @param userField26  user field 26
     */
    public void setUserField26(String userField26) {

        this.userField26 = userField26;
    }

    /**
     * Gets the user field 27.
     *
     * @return user field 27
     */
    public String getUserField27() {

        return userField27;
    }

    /**
     * Set the user field 27.
     *
     * @param userField27  user field 27
     */
    public void setUserField27(String userField27) {

        this.userField27 = userField27;
    }

    /**
     * Gets the user field 28.
     *
     * @return user field 28
     */
    public String getUserField28() {

        return userField28;
    }

    /**
     * Set the user field 28.
     *
     * @param userField28  user field 28
     */
    public void setUserField28(String userField28) {

        this.userField28 = userField28;
    }

    /**
     * Gets the user field 29.
     *
     * @return user field 29
     */
    public String getUserField29() {

        return userField29;
    }

    /**
     * Set the user field 29.
     *
     * @param userField29  user field 29
     */
    public void setUserField29(String userField29) {

        this.userField29 = userField29;
    }

    /**
     * Gets the user field 30.
     *
     * @return user field 30
     */
    public String getUserField30() {

        return userField30;
    }

    /**
     * Set the user field 30.
     *
     * @param userField30  user field 30
     */
    public void setUserField30(String userField30) {

        this.userField30 = userField30;
    }

}
