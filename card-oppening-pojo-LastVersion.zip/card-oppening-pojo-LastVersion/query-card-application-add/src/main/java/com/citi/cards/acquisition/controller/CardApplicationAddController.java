/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CardApplicationAddController.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.validation.Valid;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.CardApplicationAddRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.CardApplicationAddRs;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.model.vo.CardApplicationAddRqVO;
import com.citi.cards.acquisition.request.GeneralRequest;
import com.citi.cards.acquisition.response.generics.AbstractBaseCrudResponse;
import com.citi.cards.acquisition.response.generics.CRUDErrorResponse;
import com.citi.cards.acquisition.service.CardApplicationService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 *  <code>CardApplicationAddController</code>.
 *
 * @author vb44309
 * @version 1.0
 */
@RestController
public class CardApplicationAddController {

	/** The constant LOG. */
	private static final Logger LOG = Logger.getLogger(CardApplicationAddController.class);

	/** service. */
	@Autowired
	private CardApplicationService service;

	/**
	 * Execute.
	 *
	 * @param body body
	 * @return response entity
	 * @throws DatatypeConfigurationException datatype configuration exception.
	 */
	@ApiResponses({ @ApiResponse(response = CardApplicationAddRs.class, message = "OK", code = 200),
			@ApiResponse(response = CRUDErrorResponse.class, message = "", code = 500),
			@ApiResponse(response = CRUDErrorResponse.class, message = "", code = 404),
			@ApiResponse(response = CRUDErrorResponse.class, message = "", code = 403) })
	@ApiOperation(value = "Credit Card Add", response = CardApplicationAddRs.class)
	@RequestMapping(value = "/v1/cards/creditinitiation/onboarding", method = { RequestMethod.POST }, consumes = {
			"application/json" }, produces = { "application/json" })
	public ResponseEntity<AbstractBaseCrudResponse> execute(
			@RequestBody(required = true) @Valid GeneralRequest<CardApplicationAddRqVO> body)
			throws DatatypeConfigurationException {

		LOG.info("Entering to Card Application Controller...");
		ResponseEntity<AbstractBaseCrudResponse> response = null;

		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(Calendar.getInstance().getTime());
		XMLGregorianCalendar xmlCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);

		RqHeader rqHeader = new RqHeader();
		rqHeader.setDateAndTimeStamp(xmlCalendar);
		rqHeader.setClientDetails(body.getHeader().getClientDetails());
		rqHeader.setUUID(body.getHeader().getUuid());
		rqHeader.setVersion(body.getHeader().getVersion());

		CardApplicationAddRq rqBody = null;

		Mapper mapper = new DozerBeanMapper();
		List<String> list = new ArrayList<>();
		list.add("cardApplicationAddMapper.xml");
		((DozerBeanMapper) mapper).setMappingFiles(list);

		rqBody = mapper.map(body.getBody(), CardApplicationAddRq.class);

		AbstractBaseCrudResponse res = service.execute(rqBody, rqHeader);

		response = new ResponseEntity<>(res, res.getResponseStatus());

		return response;
	}

	/**
	 * Set the service.
	 *
	 * @param service  service
	 */
	public void setService(CardApplicationService service) {

		this.service = service;
	}

}
