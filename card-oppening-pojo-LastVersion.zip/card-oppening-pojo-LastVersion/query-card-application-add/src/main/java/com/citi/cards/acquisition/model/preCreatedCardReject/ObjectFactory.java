/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: ObjectFactory.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */

package com.citi.cards.acquisition.model.preCreatedCardReject;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardAcceptUpdRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardRejectUpdRq;
import com.citi.cards.acquisition.model.shared.system.header.ClientDetails;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.model.wsGenerics.GenericSOAPMessageHeader;

/**
 * This object contains factory methods for each Java content interface and Java
 * element interface generated in the
 * com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15 package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the
 * Java representation for XML content. The Java representation of XML content
 * can consist of schema derived interfaces and classes representing the binding
 * of schema type definitions, element declarations and model groups. Factory
 * methods for each of these are provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    /** The constant _RqHeader_QNAME. */
    private final static QName _RqHeader_QNAME =
        new QName("http://www.citi.com/gcgi/shared/system/header", "RqHeader");


    /** The constant _GENERIC_REQUEST. */
    private final static QName _GENERIC_REQUEST =
        new QName("http://schemas.xmlsoap.org/soap/envelope/", "Envelop");


    /** The constant _GENERIC_REQUEST_HEADER. */
    private final static QName _GENERIC_REQUEST_HEADER =
        new QName("http://schemas.xmlsoap.org/soap/envelope/", "Header");


    /** The constant _GENERIC_REQUEST_BODY. */
    private final static QName _GENERIC_REQUEST_BODY =
        new QName("http://schemas.xmlsoap.org/soap/envelope/", "Body");

    /** The constant _PreCreatedCardAcceptUpdRq_QNAME. */
    private final static QName _PreCreatedCardAcceptUpdRq_QNAME = new QName(
        "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15",
        "PreCreatedCardRejectUpdRq");

    /**
     * Create a new ObjectFactory that can be used to create new instances of
     * schema derived classes for package:
     * com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PreCreatedCardAcceptUpdRq }.
     *
     * @return the pre created card reject upd rq
     */
    public PreCreatedCardRejectUpdRq createPreCreatedCardRejectUpdRqq() {

        return new PreCreatedCardRejectUpdRq();
    }

    /**
     * Create an instance of {@link RqHeader }.
     *
     * @return the rq header
     */
    public RqHeader createRqHeader() {

        return new RqHeader();
    }

    /**
     * Create an instance of {@link ClientDetails }.
     *
     * @return the client details
     */
    public ClientDetails createClientDetails() {

        return new ClientDetails();
    }

    /**
     * Creates a new Object object.
     *
     * @param value value
     * @return the JAXB element< ws pre created card reject req>
     */
    @XmlElementDecl(namespace = "http://schemas.xmlsoap.org/soap/envelope/",
        name = "Envelop")
    public JAXBElement<WsPreCreatedCardRejectReq>
        createWsPreCreatedCardAcceptReq(WsPreCreatedCardRejectReq value) {

        return new JAXBElement<WsPreCreatedCardRejectReq>(_GENERIC_REQUEST,
            WsPreCreatedCardRejectReq.class, null, value);
    }

    /**
     * Creates a new Object object.
     *
     * @param value value
     * @return the JAXB element< ws pre created card reject data>
     */
    @XmlElementDecl(namespace = "http://schemas.xmlsoap.org/soap/envelope/",
        name = "Body")
    public JAXBElement<WsPreCreatedCardRejectData>
        createWsPreCreatedCardAcceptData(WsPreCreatedCardRejectData value) {

        return new JAXBElement<WsPreCreatedCardRejectData>(
            _GENERIC_REQUEST_BODY, WsPreCreatedCardRejectData.class, null,
            value);
    }


    /**
     * Creates a new Object object.
     *
     * @param value value
     * @return the JAXB element< pre created card reject upd rq>
     */
    @XmlElementDecl(
        namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_15",
        name = "PreCreatedCardAcceptUpdRq")
    public JAXBElement<PreCreatedCardRejectUpdRq>
        createPreCreatedCardRejectUpdRq(PreCreatedCardRejectUpdRq value) {

        return new JAXBElement<PreCreatedCardRejectUpdRq>(
            _PreCreatedCardAcceptUpdRq_QNAME, PreCreatedCardRejectUpdRq.class,
            null, value);
    }

    /**
     * Creates a new Object object.
     *
     * @return the generic SOAP message header
     */
    public GenericSOAPMessageHeader createGenericRequestHeader() {

        return new GenericSOAPMessageHeader();
    }

    /**
     * Creates a new Object object.
     *
     * @param value value
     * @return the JAXB element< generic SOAP message header>
     */
    @XmlElementDecl(namespace = "http://schemas.xmlsoap.org/soap/envelope/",
        name = "Header")
    public JAXBElement<GenericSOAPMessageHeader>
        createEnvelop(GenericSOAPMessageHeader value) {

        return new JAXBElement<GenericSOAPMessageHeader>(
            _GENERIC_REQUEST_HEADER, GenericSOAPMessageHeader.class, null,
            value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RqHeader
     * }{@code >}}.
     *
     * @param value value
     * @return the JAXB element< rq header>
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/shared/system/header",
        name = "RqHeader")
    public JAXBElement<RqHeader> createRqHeader(RqHeader value) {

        return new JAXBElement<RqHeader>(_RqHeader_QNAME, RqHeader.class, null,
            value);
    }
}
