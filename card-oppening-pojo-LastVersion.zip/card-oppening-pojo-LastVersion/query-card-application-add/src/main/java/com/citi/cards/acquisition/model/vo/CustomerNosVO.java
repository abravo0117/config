/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CustomerNosVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

import java.util.List;
/**
 *  <code>CustomerNosVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class CustomerNosVO {

    /** customer no item. */
    private List<CustomerNoItemVO> customerNoItem;

    /**
     * Gets the customer no item.
     *
     * @return customer no item
     */
    public List<CustomerNoItemVO> getCustomerNoItem() {

        return customerNoItem;
    }

    /**
     * Set the customer no item.
     *
     * @param customerNoItem  customer no item
     */
    public void setCustomerNoItem(List<CustomerNoItemVO> customerNoItem) {

        this.customerNoItem = customerNoItem;
    }

}
