/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: ObjectFactory.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.documentUploadNotification;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.DocumentUploadNotificationUpdRq;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.model.wsGenerics.GenericSOAPMessageHeader;

/**
 * A factory for creating Object objects.
 */
@XmlRegistry
public class ObjectFactory {

    /** The constant _RQ_HEADER_QNAME. */
    private final static QName _RQ_HEADER_QNAME =
        new QName("http://www.citi.com/gcgi/shared/system/header", "RqHeader");

    /** The constant _GENERIC_REQUEST_HEADER. */
    private final static QName _GENERIC_REQUEST_HEADER =
        new QName("http://schemas.xmlsoap.org/soap/envelope/", "Header");

    /** The constant _CARD_APPLICATION_REQUEST. */
    private final static QName _CARD_APPLICATION_REQUEST =
        new QName("http://schemas.xmlsoap.org/soap/envelope/", "Envelop");

    /** The constant _CARD_APPLICATION_DATA_QNAME. */
    private final static QName _CARD_APPLICATION_DATA_QNAME =
        new QName("http://schemas.xmlsoap.org/soap/envelope/", "Body");

    /** The constant _CARD_APPLICATION_BODY_QNAME. */
    private final static QName _CARD_APPLICATION_BODY_QNAME = new QName(
        "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_7",
        "DocumentUploadNotificationUpdRq");

    /**
     * Creates a new Object object.
     *
     * @param value value
     * @return the JAXB element< generic SOAP message header>
     */
    @XmlElementDecl(namespace = "http://schemas.xmlsoap.org/soap/envelope/",
        name = "Header")
    public JAXBElement<GenericSOAPMessageHeader>
        createEnvelop(GenericSOAPMessageHeader value) {

        return new JAXBElement<GenericSOAPMessageHeader>(
            _GENERIC_REQUEST_HEADER, GenericSOAPMessageHeader.class, null,
            value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RqHeader
     * }{@code >}}.
     *
     * @param value value
     * @return the JAXB element< rq header>
     */
    @XmlElementDecl(namespace = "http://www.citi.com/gcgi/shared/system/header",
        name = "RqHeader")
    public JAXBElement<RqHeader> createRqHeader(RqHeader value) {

        return new JAXBElement<RqHeader>(_RQ_HEADER_QNAME, RqHeader.class, null,
            value);
    }

    /**
     * Creates a new Object object.
     *
     * @param value value
     * @return the JAXB element< document upload notification WS rq>
     */
    @XmlElementDecl(namespace = "http://schemas.xmlsoap.org/soap/envelope/",
        name = "Envelop")
    public JAXBElement<DocumentUploadNotificationWSRq>
        createCardApplicationWSRq(DocumentUploadNotificationWSRq value) {

        return new JAXBElement<DocumentUploadNotificationWSRq>(
            _CARD_APPLICATION_REQUEST, DocumentUploadNotificationWSRq.class, null,
            value);
    }

    /**
     * Creates a new Object object.
     *
     * @param value value
     * @return the JAXB element< document upload notification WS data>
     */
    @XmlElementDecl(namespace = "http://schemas.xmlsoap.org/soap/envelope/",
        name = "Body")
    public JAXBElement<DocumentUploadNotificationWSData>
        createCardApplicationWSData(DocumentUploadNotificationWSData value) {

        return new JAXBElement<DocumentUploadNotificationWSData>(
            _CARD_APPLICATION_DATA_QNAME, DocumentUploadNotificationWSData.class,
            null, value);
    }

    /**
     * Creates a new Object object.
     *
     * @param value value
     * @return the JAXB element< document upload notification upd rq>
     */
    @XmlElementDecl(
        namespace = "http://www.citi.com/gcgi/services/common/MX/application/v3_2_MX_7",
        name = "DocumentUploadNotificationUpdRq")
    public JAXBElement<DocumentUploadNotificationUpdRq>
        createDocumentUploadNotificationUpdRq(DocumentUploadNotificationUpdRq value) {

        return new JAXBElement<DocumentUploadNotificationUpdRq>(
            _CARD_APPLICATION_BODY_QNAME, DocumentUploadNotificationUpdRq.class,
            null, value);
    }

}
