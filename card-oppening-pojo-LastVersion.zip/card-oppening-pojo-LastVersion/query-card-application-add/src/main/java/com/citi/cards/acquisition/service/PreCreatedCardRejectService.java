/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: PreCreatedCardRejectService.java
<<<<<<< HEAD
 * Original Author: Softtek
=======
 * Original Author: Softtek - SAZR
>>>>>>> branch 'develop' of http://victor.blanco@192.168.3.187:5000/r/~victor.blanco/card-oppening-pojo.git
 * Creation Date: 15/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.citi.cards.acquisition.aggregator.WSClientCertificateAgg;
import com.citi.cards.acquisition.aggregator.WSInvoker;
import com.citi.cards.acquisition.exception.AppException;
import com.citi.cards.acquisition.exception.FaultException;
import com.citi.cards.acquisition.exception.WSClientException;
import com.citi.cards.acquisition.model.preCreatedCardReject.WsPreCreatedCardRejectData;
import com.citi.cards.acquisition.model.preCreatedCardReject.WsPreCreatedCardRejectReq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardRejectUpdRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardRejectUpdRs;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.model.wsGenerics.GenericSOAPMessageHeader;
import com.citi.cards.acquisition.response.generics.AbstractBaseCrudResponse;
import com.citi.cards.acquisition.response.generics.CRUDErrorResponse;
import com.citi.cards.acquisition.response.generics.CRUDResponse;

/**
 * The Class PreCreatedCardRejectService.
 */
@Service
public class PreCreatedCardRejectService {

    /** The Constant LOG. */
    private static final Logger LOG =
        Logger.getLogger(PreCreatedCardRejectService.class);

    /** The context path. */
    @Value("${ws.preCreatedCardReject.object.context.path}")
    private String contextPath;

    /** The uri. */
    @Value("${ws.location.uri}")
    private String uri;
    
    /** The action. */
    @Value("${ws.preCreatedCardReject.action}")
    private String action;

    /** The load data. */
    @Autowired
    private WSClientCertificateAgg loadData;

    /** The invoker. */
    protected WSInvoker<PreCreatedCardRejectUpdRs> invoker =
        new WSInvoker<>();

    /**
     * Execute.
     *
     * @param rq the rq
     * @return the abstract base crud response
     */
    public AbstractBaseCrudResponse execute(PreCreatedCardRejectUpdRq rq, RqHeader rqHeader) {

        AbstractBaseCrudResponse response = null;

        PreCreatedCardRejectUpdRs wsResponse = null;

        try {

            WsPreCreatedCardRejectReq genReq =
                new WsPreCreatedCardRejectReq();

            GenericSOAPMessageHeader header = new GenericSOAPMessageHeader();

            WsPreCreatedCardRejectData data = new WsPreCreatedCardRejectData();

            header.setHeader(rqHeader);
            data.setData(rq);

            genReq.setHeader(header);
            genReq.setBody(data);

            invoker.setWsAgg(loadData);

            wsResponse = invoker.invokeWS(genReq, getUri(), action,
                PreCreatedCardRejectUpdRs.class, contextPath);

            response = new CRUDResponse<>(wsResponse);

        } catch (FaultException e) {
            LOG.error(e, e);
            response = new CRUDErrorResponse(e);
        } catch (WSClientException e) {

            LOG.error(e.getDescription(), e);
            response = new CRUDErrorResponse(e);
        } catch (AppException ex) {
            LOG.error(ex.getDescription(), ex);
            response = new CRUDErrorResponse(ex);
        }

        return response;

    }

    /**
<<<<<<< HEAD
     * Set the context path.
     *
     * @param contextPath  context path
=======
     * Sets the context path.
     *
     * @param contextPath the new context path
>>>>>>> branch 'develop' of http://victor.blanco@192.168.3.187:5000/r/~victor.blanco/card-oppening-pojo.git
     */
    public void setContextPath(String contextPath) {

        this.contextPath = contextPath;
    }

    /**
<<<<<<< HEAD
     * Set the uri.
     *
     * @param uri  uri
=======
     * Sets the uri.
     *
     * @param uri the new uri
>>>>>>> branch 'develop' of http://victor.blanco@192.168.3.187:5000/r/~victor.blanco/card-oppening-pojo.git
     */
    public void setUri(String uri) {

        this.uri = uri;
    }

    /**
<<<<<<< HEAD
     * Set the action.
     *
     * @param action  action
=======
     * Sets the action.
     *
     * @param action the new action
>>>>>>> branch 'develop' of http://victor.blanco@192.168.3.187:5000/r/~victor.blanco/card-oppening-pojo.git
     */
    public void setAction(String action) {

        this.action = action;
    }

    /**
<<<<<<< HEAD
     * Set the load data.
     *
     * @param loadData  load data
=======
     * Sets the load data.
     *
     * @param loadData the new load data
>>>>>>> branch 'develop' of http://victor.blanco@192.168.3.187:5000/r/~victor.blanco/card-oppening-pojo.git
     */
    public void setLoadData(WSClientCertificateAgg loadData) {

        this.loadData = loadData;
    }

    /**
     * Gets the uri.
     *
<<<<<<< HEAD
     * @return uri
=======
     * @return the uri
>>>>>>> branch 'develop' of http://victor.blanco@192.168.3.187:5000/r/~victor.blanco/card-oppening-pojo.git
     */
    public String getUri() {

        return uri;
    }

}
