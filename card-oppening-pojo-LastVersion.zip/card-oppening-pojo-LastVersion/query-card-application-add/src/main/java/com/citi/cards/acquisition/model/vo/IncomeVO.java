/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: IncomeVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

import java.util.List;

/**
 *  <code>IncomeVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class IncomeVO {

    /** declared income. */
    private String declaredIncome;

    /** variable income. */
    private String variableIncome;

    /** other income. */
    private String otherIncome;

    /** other income type. */
    private String otherIncomeType;

    /** income proof type. */
    private String incomeProofType;

    /** verified monthly income. */
    private List<Double> verifiedMonthlyIncome;

    /**
     * Gets the declared income.
     *
     * @return declared income
     */
    public String getDeclaredIncome() {

        return declaredIncome;
    }

    /**
     * Set the declared income.
     *
     * @param declaredIncome  declared income
     */
    public void setDeclaredIncome(String declaredIncome) {

        this.declaredIncome = declaredIncome;
    }

    /**
     * Gets the variable income.
     *
     * @return variable income
     */
    public String getVariableIncome() {

        return variableIncome;
    }

    /**
     * Set the variable income.
     *
     * @param variableIncome  variable income
     */
    public void setVariableIncome(String variableIncome) {

        this.variableIncome = variableIncome;
    }

    /**
     * Gets the other income.
     *
     * @return other income
     */
    public String getOtherIncome() {

        return otherIncome;
    }

    /**
     * Set the other income.
     *
     * @param otherIncome  other income
     */
    public void setOtherIncome(String otherIncome) {

        this.otherIncome = otherIncome;
    }

    /**
     * Gets the other income type.
     *
     * @return other income type
     */
    public String getOtherIncomeType() {

        return otherIncomeType;
    }

    /**
     * Set the other income type.
     *
     * @param otherIncomeType  other income type
     */
    public void setOtherIncomeType(String otherIncomeType) {

        this.otherIncomeType = otherIncomeType;
    }

    /**
     * Gets the income proof type.
     *
     * @return income proof type
     */
    public String getIncomeProofType() {

        return incomeProofType;
    }

    /**
     * Set the income proof type.
     *
     * @param incomeProofType  income proof type
     */
    public void setIncomeProofType(String incomeProofType) {

        this.incomeProofType = incomeProofType;
    }

    /**
     * Gets the verified monthly income.
     *
     * @return verified monthly income
     */
    public List<Double> getVerifiedMonthlyIncome() {

        return verifiedMonthlyIncome;
    }

    /**
     * Set the verified monthly income.
     *
     * @param verifiedMonthlyIncome  verified monthly income
     */
    public void setVerifiedMonthlyIncome(List<Double> verifiedMonthlyIncome) {

        this.verifiedMonthlyIncome = verifiedMonthlyIncome;
    }

}
