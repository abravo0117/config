/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CardApplicationAddRqVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

import java.util.List;

/**
 * <code>CardApplicationAddRqVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class CardApplicationAddRqVO {

	/** application. */
	private ApplicationVO application;

	/** applicant. */
	private List<ApplicantVO> applicant;

	/**
	 * Gets the application.
	 *
	 * @return application
	 */
	public ApplicationVO getApplication() {

		return application;
	}

	/**
	 * Set the application.
	 *
	 * @param application
	 *            application
	 */
	public void setApplication(ApplicationVO application) {

		this.application = application;
	}

	/**
	 * Gets the applicant.
	 *
	 * @return applicant
	 */
	public List<ApplicantVO> getApplicant() {

		return applicant;
	}

	/**
	 * Set the applicant.
	 *
	 * @param applicant
	 *            applicant
	 */
	public void setApplicant(List<ApplicantVO> applicant) {

		this.applicant = applicant;
	}

}
