/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: GenericSOAPMessageHeader.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.wsGenerics;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.citi.cards.acquisition.model.shared.system.header.RqHeader;

/**
 *  <code>GenericSOAPMessageHeader</code>.
 *
 * @author vb44309
 * @version 1.0
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="Header")
@XmlType(name = "Header")
public class GenericSOAPMessageHeader implements Serializable {

    /** The constant serialVersionUID. */
    private static final long serialVersionUID = 3156355627927593217L;
    
    /** header. */
    @XmlElement(name="RqHeader",namespace="http://www.citi.com/gcgi/shared/system/header")
    protected RqHeader header; // NOSONAR

    /**
     * Gets the header.
     *
     * @return header
     */
    public RqHeader getHeader() {

        return header;
    }

    /**
     * Set the header.
     *
     * @param header  header
     */
    public void setHeader(RqHeader header) {

        this.header = header;
    }

}
