/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: GeneralHeader.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.request;

import com.citi.cards.acquisition.model.shared.system.header.ClientDetails;

/**
 *  <code>GeneralHeader</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class GeneralHeader {

    /** uuid. */
    private String uuid;

    /** version. */
    private String version;

    /** client details. */
    private ClientDetails clientDetails;

    /**
     * Gets the uuid.
     *
     * @return uuid
     */
    public String getUuid() {

        return uuid;
    }

    /**
     * Set the uuid.
     *
     * @param uuid  uuid
     */
    public void setUuid(String uuid) {

        this.uuid = uuid;
    }

    /**
     * Gets the version.
     *
     * @return version
     */
    public String getVersion() {

        return version;
    }

    /**
     * Set the version.
     *
     * @param version  version
     */
    public void setVersion(String version) {

        this.version = version;
    }

    /**
     * Gets the client details.
     *
     * @return client details
     */
    public ClientDetails getClientDetails() {

        return clientDetails;
    }

    /**
     * Set the client details.
     *
     * @param clientDetails  client details
     */
    public void setClientDetails(ClientDetails clientDetails) {

        this.clientDetails = clientDetails;
    }

}
