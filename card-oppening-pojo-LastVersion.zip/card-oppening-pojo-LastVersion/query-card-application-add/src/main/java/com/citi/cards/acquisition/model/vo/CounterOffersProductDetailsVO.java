/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CounterOffersProductDetailsVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

/**
 *  <code>CounterOffersProductDetailsVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class CounterOffersProductDetailsVO {

    /** type. */
    private String type;

    /** logo. */
    private String logo;

    /** status. */
    private String status;

    /** suggested pre created card credit limit. */
    private double suggestedPreCreatedCardCreditLimit;

    /** decision type. */
    private String decisionType;

    /** reject reason code. */
    private String rejectReasonCode;

    /** product description. */
    private String productDescription;

    /** org code. */
    private String orgCode;

    /** plastic ID. */
    private String plasticID;

    /** source code. */
    private String sourceCode;

    /** final credit limit. */
    private double finalCreditLimit;

    /** existing card no. */
    private String existingCardNo;

    /** existing card credit limit. */
    private double existingCardCreditLimit;

    /** additional offer description. */
    private String additionalOfferDescription;

    /**
     * Gets the type.
     *
     * @return type
     */
    public String getType() {

        return type;
    }

    /**
     * Set the type.
     *
     * @param type  type
     */
    public void setType(String type) {

        this.type = type;
    }

    /**
     * Gets the logo.
     *
     * @return logo
     */
    public String getLogo() {

        return logo;
    }

    /**
     * Set the logo.
     *
     * @param logo  logo
     */
    public void setLogo(String logo) {

        this.logo = logo;
    }

    /**
     * Gets the status.
     *
     * @return status
     */
    public String getStatus() {

        return status;
    }

    /**
     * Set the status.
     *
     * @param status  status
     */
    public void setStatus(String status) {

        this.status = status;
    }

    /**
     * Gets the suggested pre created card credit limit.
     *
     * @return suggested pre created card credit limit
     */
    public double getSuggestedPreCreatedCardCreditLimit() {

        return suggestedPreCreatedCardCreditLimit;
    }

    /**
     * Set the suggested pre created card credit limit.
     *
     * @param suggestedPreCreatedCardCreditLimit  suggested pre created card credit limit
     */
    public void setSuggestedPreCreatedCardCreditLimit(
        double suggestedPreCreatedCardCreditLimit) {

        this.suggestedPreCreatedCardCreditLimit =
            suggestedPreCreatedCardCreditLimit;
    }

    /**
     * Gets the decision type.
     *
     * @return decision type
     */
    public String getDecisionType() {

        return decisionType;
    }

    /**
     * Set the decision type.
     *
     * @param decisionType  decision type
     */
    public void setDecisionType(String decisionType) {

        this.decisionType = decisionType;
    }

    /**
     * Gets the reject reason code.
     *
     * @return reject reason code
     */
    public String getRejectReasonCode() {

        return rejectReasonCode;
    }

    /**
     * Set the reject reason code.
     *
     * @param rejectReasonCode  reject reason code
     */
    public void setRejectReasonCode(String rejectReasonCode) {

        this.rejectReasonCode = rejectReasonCode;
    }

    /**
     * Gets the product description.
     *
     * @return product description
     */
    public String getProductDescription() {

        return productDescription;
    }

    /**
     * Set the product description.
     *
     * @param productDescription  product description
     */
    public void setProductDescription(String productDescription) {

        this.productDescription = productDescription;
    }

    /**
     * Gets the org code.
     *
     * @return org code
     */
    public String getOrgCode() {

        return orgCode;
    }

    /**
     * Set the org code.
     *
     * @param orgCode  org code
     */
    public void setOrgCode(String orgCode) {

        this.orgCode = orgCode;
    }

    /**
     * Gets the plastic ID.
     *
     * @return plastic ID
     */
    public String getPlasticID() {

        return plasticID;
    }

    /**
     * Set the plastic ID.
     *
     * @param plasticID  plastic ID
     */
    public void setPlasticID(String plasticID) {

        this.plasticID = plasticID;
    }

    /**
     * Gets the source code.
     *
     * @return source code
     */
    public String getSourceCode() {

        return sourceCode;
    }

    /**
     * Set the source code.
     *
     * @param sourceCode  source code
     */
    public void setSourceCode(String sourceCode) {

        this.sourceCode = sourceCode;
    }

    /**
     * Gets the final credit limit.
     *
     * @return final credit limit
     */
    public double getFinalCreditLimit() {

        return finalCreditLimit;
    }

    /**
     * Set the final credit limit.
     *
     * @param finalCreditLimit  final credit limit
     */
    public void setFinalCreditLimit(double finalCreditLimit) {

        this.finalCreditLimit = finalCreditLimit;
    }

    /**
     * Gets the existing card no.
     *
     * @return existing card no
     */
    public String getExistingCardNo() {

        return existingCardNo;
    }

    /**
     * Set the existing card no.
     *
     * @param existingCardNo  existing card no
     */
    public void setExistingCardNo(String existingCardNo) {

        this.existingCardNo = existingCardNo;
    }

    /**
     * Gets the existing card credit limit.
     *
     * @return existing card credit limit
     */
    public double getExistingCardCreditLimit() {

        return existingCardCreditLimit;
    }

    /**
     * Set the existing card credit limit.
     *
     * @param existingCardCreditLimit  existing card credit limit
     */
    public void setExistingCardCreditLimit(double existingCardCreditLimit) {

        this.existingCardCreditLimit = existingCardCreditLimit;
    }

    /**
     * Gets the additional offer description.
     *
     * @return additional offer description
     */
    public String getAdditionalOfferDescription() {

        return additionalOfferDescription;
    }

    /**
     * Set the additional offer description.
     *
     * @param additionalOfferDescription  additional offer description
     */
    public void
        setAdditionalOfferDescription(String additionalOfferDescription) {

        this.additionalOfferDescription = additionalOfferDescription;
    }

}
