/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CardApplicationService.java
 * Original Author: Softtek
 * Creation Date: 15/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.citi.cards.acquisition.aggregator.WSClientCertificateAgg;
import com.citi.cards.acquisition.aggregator.WSInvoker;
import com.citi.cards.acquisition.exception.AppException;
import com.citi.cards.acquisition.exception.FaultException;
import com.citi.cards.acquisition.model.cardApplication.CardApplicationWSData;
import com.citi.cards.acquisition.model.cardApplication.CardApplicationWSRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.CardApplicationAddRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.CardApplicationAddRs;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.model.wsGenerics.GenericSOAPMessageHeader;
import com.citi.cards.acquisition.response.generics.AbstractBaseCrudResponse;
import com.citi.cards.acquisition.response.generics.CRUDErrorResponse;
import com.citi.cards.acquisition.response.generics.CRUDResponse;

/**
 *  <code>CardApplicationService</code>.
 *
 * @author vb44309
 * @version 1.0
 */
@Service
public class CardApplicationService {

    /** The constant LOG. */
    private static final Logger LOG =
        Logger.getLogger(CardApplicationService.class);

    /** context path. */
    @Value("${ws.cardApplication.object.context.path}")
    private String contextPath;

    /** uri. */
    @Value("${ws.location.uri}")
    private String uri;

    /** action. */
    @Value("${ws.cardApplication.action}")
    private String action;

    /** load data. */
    @Autowired
    private WSClientCertificateAgg loadData;

    /** invoker. */
    protected WSInvoker< CardApplicationAddRs> invoker =
        new WSInvoker< >();

    /**
     * Execute.
     *
     * @param requestBody request body
     * @param requestHeader request header
     * @return abstract base crud response
     */
    public AbstractBaseCrudResponse execute(
        CardApplicationAddRq requestBody, RqHeader requestHeader) {

        AbstractBaseCrudResponse response = null;

        try {

            CardApplicationWSRq request = new CardApplicationWSRq();
            
            CardApplicationWSData data = new CardApplicationWSData();
            data.setData(requestBody);
            
            GenericSOAPMessageHeader header = new GenericSOAPMessageHeader();
            header.setHeader(requestHeader);
            
            request.setBody(data);
            request.setHeader(header);
            
            invoker.setWsAgg(loadData);

            CardApplicationAddRs wsRes = invoker.invokeWS(request, uri, action,
                CardApplicationAddRs.class, contextPath);
            response = new CRUDResponse<CardApplicationAddRs>(wsRes);
        }
        catch (FaultException e) {
            LOG.error(e,e);
            response = new CRUDErrorResponse(e);
        }

        catch (AppException e) {
            LOG.error(e.getEx());
            response = new CRUDErrorResponse(e);
        }
        return response;
    }

    /**
     * Set the context path.
     *
     * @param contextPath  context path
     */
    public void setContextPath(String contextPath) {

        this.contextPath = contextPath;
    }

    /**
     * Set the uri.
     *
     * @param uri  uri
     */
    public void setUri(String uri) {

        this.uri = uri;
    }

    /**
     * Set the action.
     *
     * @param action  action
     */
    public void setAction(String action) {

        this.action = action;
    }

    /**
     * Set the load data.
     *
     * @param loadData  load data
     */
    public void setLoadData(WSClientCertificateAgg loadData) {

        this.loadData = loadData;
    }

}
