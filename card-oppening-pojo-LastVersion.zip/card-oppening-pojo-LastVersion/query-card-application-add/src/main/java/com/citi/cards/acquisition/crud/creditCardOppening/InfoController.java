/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: InfoController.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.crud.creditCardOppening;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *  <code>InfoController</code>.
 *
 * @author vb44309
 * @version 1.0
 */
@Controller
public class InfoController {

    /**
     * App info.
     *
     * @return string
     */
    @RequestMapping("/info")
    public String AppInfo()
    {
        return "redirect:/swagger-ui.html";
    }
    
}
