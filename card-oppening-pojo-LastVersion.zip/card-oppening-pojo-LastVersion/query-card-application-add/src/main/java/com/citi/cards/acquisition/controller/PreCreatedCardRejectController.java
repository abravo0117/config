/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: PreCreatedCardRejectController.java
 * Original Author: Softtek - LAAR
 * Creation Date: 9/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.controller;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardRejectUpdRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardRejectUpdRs;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.request.GeneralRequest;
import com.citi.cards.acquisition.response.generics.AbstractBaseCrudResponse;
import com.citi.cards.acquisition.response.generics.CRUDErrorResponse;
import com.citi.cards.acquisition.service.PreCreatedCardRejectService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 *  <code>PreCreatedCardRejectController</code>.
 *
 * @author vb44309
 * @version 1.0
 */
@RestController
public class PreCreatedCardRejectController {

    /** The constant LOG. */
    private static final Logger LOG =
        Logger.getLogger(PreCreatedCardRejectController.class);

    /** service. */
    @Autowired
    private PreCreatedCardRejectService service;

    /**
     * Execute.
     *
     * @param request            request
     * @return response entity
     * @throws DatatypeConfigurationException datatype configuration exception.
     */
    @ApiResponses(
        {
            @ApiResponse(response=PreCreatedCardRejectUpdRs.class,message="OK",code=200),
            @ApiResponse(response=CRUDErrorResponse.class,message="",code=500),
            @ApiResponse(response=CRUDErrorResponse.class,message="",code=404),
            @ApiResponse(response=CRUDErrorResponse.class,message="",code=403)
        })
    @ApiOperation(value = "Pre Created Card Accept",
        response = PreCreatedCardRejectUpdRs.class)
    @RequestMapping(value = "/v1/cards/creditinitiation/reject",
        consumes = {"application/json"}, produces = {"application/json"},
        method = {RequestMethod.POST})
    public ResponseEntity<AbstractBaseCrudResponse> execute(
        @RequestBody GeneralRequest<PreCreatedCardRejectUpdRq> request) throws DatatypeConfigurationException {

        LOG.info("Entering to PreCreated Card Reject Controller...");

        ResponseEntity<AbstractBaseCrudResponse> response = null;
        AbstractBaseCrudResponse res = null;
        
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(Calendar.getInstance().getTime());
        XMLGregorianCalendar xmlCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
        
        RqHeader rqHeader = new RqHeader();
        rqHeader.setDateAndTimeStamp(xmlCalendar);
        rqHeader.setClientDetails(request.getHeader().getClientDetails());
        rqHeader.setUUID(request.getHeader().getUuid());
        rqHeader.setVersion(request.getHeader().getVersion());

        res = service.execute(request.getBody(), rqHeader);

        response = new ResponseEntity<>(res, res.getResponseStatus());

        return response;
    }

    /**
     * Set the service.
     *
     * @param service  service
     */
    public void setService(PreCreatedCardRejectService service) {

        this.service = service;
    }

}
