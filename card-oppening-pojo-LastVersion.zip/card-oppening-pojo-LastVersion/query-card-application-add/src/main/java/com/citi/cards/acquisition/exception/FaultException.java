/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: FaultException.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.exception;

/**
 *  <code>FaultException</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class FaultException extends RuntimeException {

    /** The constant serialVersionUID. */
    private static final long serialVersionUID = -5820061760408766569L;

    /** The constant type. */
    private final String type;

    /** The constant code. */
    private final String code;

    /** The constant details. */
    private final String details;

    /** The constant location. */
    private final String location;

    /** The constant moreInfo. */
    private final String moreInfo;

    /**
     * Creates a new instance of fault exception.
     *
     * @param code code
     * @param ex ex
     */
    public FaultException(AppExceptionCodeEnum code, Throwable ex) {
        this(code, ex, "");
    }

    /**
     * Creates a new instance of fault exception.
     *
     * @param code code
     * @param ex ex
     * @param moreInfo more info
     */
    public FaultException(AppExceptionCodeEnum code, Throwable ex,
        String moreInfo) {
        this(code.toString(), String.valueOf(code.getCode()),
            code.getDescription(), moreInfo, ex);

    }

    /**
     * Creates a new instance of fault exception.
     *
     * @param type type
     * @param details details
     */
    public FaultException(String type, String details) {
        this(type, details, "");
    }

    /**
     * Creates a new instance of fault exception.
     *
     * @param type type
     * @param details details
     * @param moreInfo more info
     */
    public FaultException(String type, String details, String moreInfo) {
        this(type, "405", details, moreInfo, new RuntimeException());
    }

    /**
     * Creates a new instance of fault exception.
     *
     * @param type type
     * @param code code
     * @param details details
     * @param moreInfo more info
     * @param ex ex
     */
    public FaultException(String type, String code, String details,
        String moreInfo, Throwable ex) {
        this(type, code, details, "", moreInfo, ex);

    }

    /**
     * Creates a new instance of fault exception.
     *
     * @param type type
     * @param code code
     * @param details details
     * @param location location
     * @param moreInfo more info
     * @param ex ex
     */
    public FaultException(String type, String code, String details,
        String location, String moreInfo, Throwable ex) {
        super(details, ex);
        this.type = type;
        this.code = code;
        this.details = details;
        this.moreInfo = moreInfo;
        StringBuilder builder = new StringBuilder(location);
        builder.append("File: ").append(
            ex.getStackTrace()[ex.getStackTrace().length - 3].getFileName());
        builder.append(" - Method: ").append(
            ex.getStackTrace()[ex.getStackTrace().length - 3].getMethodName());
        builder.append(" - Line: ").append(
            ex.getStackTrace()[ex.getStackTrace().length - 3].getLineNumber());
        this.location = builder.toString();
    }

    /**
     * Gets the type.
     *
     * @return type
     */
    public String getType() {

        return type;
    }

    /**
     * Gets the code.
     *
     * @return code
     */
    public String getCode() {

        return code;
    }

    /**
     * Gets the details.
     *
     * @return details
     */
    public String getDetails() {

        return details;
    }

    /**
     * Gets the location.
     *
     * @return location
     */
    public String getLocation() {

        return location;
    }

    /**
     * Gets the more info.
     *
     * @return more info
     */
    public String getMoreInfo() {

        return moreInfo;
    }

}
