/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: ApplicationFullDetailsController.java
 * Original Author: Softtek-ANBV
 * Creation Date: 12/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.controller;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.validation.Valid;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.citi.cards.acquisition.aggregator.WSInvoker;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.ApplicationFullDetailsInqRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.ApplicationFullDetailsInqRs;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.CardApplicationAddRs;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.request.GeneralRequest;
import com.citi.cards.acquisition.response.generics.AbstractBaseCrudResponse;
import com.citi.cards.acquisition.response.generics.CRUDErrorResponse;
import com.citi.cards.acquisition.service.ApplicationFullDetailsService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 *  <code>ApplicationFullDetailsController</code>.
 *
 * @author antonio.bravo
 * @version 1.0
 */
@RestController
public class ApplicationFullDetailsController {

    /** The constant LOG. */
    private static final Logger LOG =
        Logger.getLogger(ApplicationFullDetailsController.class);

    /** service. */
    @Autowired
    private ApplicationFullDetailsService service;

    /** invoker. */
    protected WSInvoker< CardApplicationAddRs> invoker =
        new WSInvoker<>();

    /**
     * Execute.
     *
     * @param request request
     * @return response entity
     * @throws DatatypeConfigurationException 
     */
    @ApiResponses(
        {
            @ApiResponse(response=ApplicationFullDetailsInqRs.class,message="OK",code=200),
            @ApiResponse(response=CRUDErrorResponse.class,message="",code=500),
            @ApiResponse(response=CRUDErrorResponse.class,message="",code=404),
            @ApiResponse(response=CRUDErrorResponse.class,message="",code=403)
        })
    @ApiOperation(value = "Application Full Details",
            response = ApplicationFullDetailsInqRs.class)
    @RequestMapping(value = "/v1/cards/creditinitiation/request",
        method = {RequestMethod.POST}, consumes = {"application/json"},
        produces = {"application/json"})
    public ResponseEntity<AbstractBaseCrudResponse>
        execute(@RequestBody(required = true) @Valid GeneralRequest<ApplicationFullDetailsInqRq> request ) throws DatatypeConfigurationException{

        LOG.info("Entering to Application Full Details Controller...");
        ResponseEntity<AbstractBaseCrudResponse> response = null;
        
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(Calendar.getInstance().getTime());
        XMLGregorianCalendar xmlCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
        
        RqHeader rqHeader = new RqHeader();
        rqHeader.setDateAndTimeStamp(xmlCalendar);
        rqHeader.setClientDetails(request.getHeader().getClientDetails());
        rqHeader.setUUID(request.getHeader().getUuid());
        rqHeader.setVersion(request.getHeader().getVersion());
        
        AbstractBaseCrudResponse res = service.execute(request.getBody(),rqHeader);

        response = new ResponseEntity<>(res,
            res.getResponseStatus());   
        

        return response;
    }

    /**
     * Set the service.
     *
     * @param service  service
     */
    public void setService(ApplicationFullDetailsService service) {

        this.service = service;
    }

}
