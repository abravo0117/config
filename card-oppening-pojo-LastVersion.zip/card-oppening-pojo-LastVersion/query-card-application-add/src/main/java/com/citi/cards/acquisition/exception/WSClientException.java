/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: WSClientException.java
 * Original Author: Softtek
 * Creation Date: 15/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.exception;

/**
 *  <code>WSClientException</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class WSClientException extends AppException {

    /** The constant exCause. */
    private final String exCause;

    /** The constant serialVersionUID. */
    private static final long serialVersionUID = 4616038341998394478L;

    /**
     * Creates a new instance of WS client exception.
     *
     * @param code code
     * @param description description
     * @param exCause ex cause
     */
    public WSClientException(int code, String description,String exCause) {
        super(code, description, null);
        this.exCause = exCause;
    }

    /**
     * Creates a new instance of WS client exception.
     *
     * @param code code
     */
    public WSClientException(AppExceptionCodeEnum code) {
        this(code.getCode(), code.getDescription(), "");
    }

    /**
     * Gets the ex cause.
     *
     * @return ex cause
     */
    public String getExCause() {

        return exCause;
    }

}
