/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: BasicDataVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

import java.util.List;

/**
 *  <code>BasicDataVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class BasicDataVO {

    /** prefix. */
    private String prefix;

    /** name english. */
    private StructuredNameVO nameEnglish;

    /** name local. */
    private StructuredNameVO nameLocal;

    /** placeof issue. */
    private String placeofIssue;

    /** birth date. */
    private String birthDate;

    /** gender. */
    private String gender;

    /** email address. */
    private String emailAddress;

    /** nationality. */
    private String nationality;

    /** domicile. */
    private String domicile;

    /** permanent residence. */
    private String permanentResidence;

    /** education level. */
    private String educationLevel;

    /** marital status. */
    private String maritalStatus;

    /** place of residence. */
    private String placeOfResidence;

    /** reln with applicant. */
    private String relnWithApplicant;

    /** mgm reference no. */
    private String mgmReferenceNo;

    /** no of dependents. */
    private String noOfDependents;

    /** correspondence langauge. */
    private String correspondenceLangauge;

    /** resident type. */
    private String residentType;

    /** resident status. */
    private String residentStatus;

    /** year of graduation. */
    private String yearOfGraduation;

    /** applicant role. */
    private String applicantRole;

    /** emer contact name. */
    private StructuredNameVO emerContactName;

    /** ctry spec field 1. */
    private String ctrySpecField1;

    /** ctry spec field 2. */
    private String ctrySpecField2;

    /** ctry spec field 3. */
    private String ctrySpecField3;

    /** ctry spec field 4. */
    private String ctrySpecField4;

    /** credit bureau authentication flag. */
    private String creditBureauAuthenticationFlag;

    /** is banamex customer. */
    private Boolean isBanamexCustomer;

    /** is credit card holder. */
    private Boolean isCreditCardHolder;

    /** is product upgrade requested. */
    private Boolean isProductUpgradeRequested;

    /** is credit line increase requested. */
    private Boolean isCreditLineIncreaseRequested;

    /** is terms and conditions accepted. */
    private Boolean isTermsAndConditionsAccepted;

    /** is credit bureau consulting accepted. */
    private Boolean isCreditBureauConsultingAccepted;

    /** is revolving credit contract accepted. */
    private Boolean isRevolvingCreditContractAccepted;

    /** is user contract accepted. */
    private Boolean isUserContractAccepted;

    /** is specific banking segment customer. */
    private Boolean isSpecificBankingSegmentCustomer;

    /** banking segment. */
    private String bankingSegment;

    /** division. */
    private String division;

    /** college no of approved subjects. */
    private String collegeNoOfApprovedSubjects;

    /** has college scholarship. */
    private Boolean hasCollegeScholarship;

    /** college scholarship level. */
    private String collegeScholarshipLevel;

    /** college scholarship type. */
    private String collegeScholarshipType;

    /** college start date. */
    private String collegeStartDate;

    /** college end date. */
    private String collegeEndDate;

    /** college university name. */
    private String collegeUniversityName;

    /** college no of subjects. */
    private String collegeNoOfSubjects;

    /** college average marks. */
    private String collegeAverageMarks;

    /** college semester. */
    private String collegeSemester;

    /** credits and liabilities reference details. */
    private List<CreditsAndLiabilitiesReferenceDetailsVO> creditsAndLiabilitiesReferenceDetails;

    /** club premier membership no. */
    private String clubPremierMembershipNo;

    /** customer no. */
    private String customerNo;

    /** account no. */
    private List<String> accountNo;

    /** social security no. */
    private String socialSecurityNo;

    /** national ID issue number. */
    private String nationalIDIssueNumber;

    /** national IDOCR. */
    private String nationalIDOCR;

    /** type of person. */
    private String typeOfPerson;

    /** country of birth. */
    private String countryOfBirth;

    /** place of birth. */
    private String placeOfBirth;

    /** is retired. */
    private Boolean isRetired;

    /** type of retirement. */
    private String typeOfRetirement;

    /** is VIP. */
    private Boolean isVIP;

    /** provider no. */
    private String providerNo;

    /** electric company service no. */
    private String electricCompanyServiceNo;

    /** tv service company. */
    private String tvServiceCompany;

    /** data verification comments. */
    private String dataVerificationComments;

    /** contract memo. */
    private String contractMemo;

    /** reference memo. */
    private String referenceMemo;

    /** applicant memo. */
    private String applicantMemo;

    /** susc control no. */
    private String suscControlNo;

    /** banamex credit card no. */
    private List<String> banamexCreditCardNo;

    /** has other bank card. */
    private Boolean hasOtherBankCard;

    /** has mortgage loan. */
    private Boolean hasMortgageLoan;

    /** has automobile loan. */
    private Boolean hasAutomobileLoan;

    /** has department store card. */
    private Boolean hasDepartmentStoreCard;

    /** authentication institution. */
    private String authenticationInstitution;

    /** credit bureau authentication bank. */
    private String creditBureauAuthenticationBank;

    /** credit card last four digits. */
    private String creditCardLastFourDigits;

    /** is other credit evaluation requested. */
    private Boolean isOtherCreditEvaluationRequested;

    /** personal references. */
    private List<PersonalReferenceVO> personalReferences;

    /** customer ID details. */
    private List<CustomerIDDetailsVO> customerIDDetails;

    /** national tax ID. */
    private String nationalTaxID;

    /** curp unique no. */
    private String curpUniqueNo;

    /** fiel serial no. */
    private String fielSerialNo;

    /** passport serial no. */
    private String passportSerialNo;

    /** national ID code. */
    private String nationalIDCode;

    /** is primary address. */
    private Boolean isPrimaryAddress;

    /**
     * Gets the prefix.
     *
     * @return prefix
     */
    public String getPrefix() {

        return prefix;
    }

    /**
     * Set the prefix.
     *
     * @param prefix  prefix
     */
    public void setPrefix(String prefix) {

        this.prefix = prefix;
    }

    /**
     * Gets the name english.
     *
     * @return name english
     */
    public StructuredNameVO getNameEnglish() {

        return nameEnglish;
    }

    /**
     * Set the name english.
     *
     * @param nameEnglish  name english
     */
    public void setNameEnglish(StructuredNameVO nameEnglish) {

        this.nameEnglish = nameEnglish;
    }

    /**
     * Gets the name local.
     *
     * @return name local
     */
    public StructuredNameVO getNameLocal() {

        return nameLocal;
    }

    /**
     * Set the name local.
     *
     * @param nameLocal  name local
     */
    public void setNameLocal(StructuredNameVO nameLocal) {

        this.nameLocal = nameLocal;
    }

    /**
     * Gets the placeof issue.
     *
     * @return placeof issue
     */
    public String getPlaceofIssue() {

        return placeofIssue;
    }

    /**
     * Set the placeof issue.
     *
     * @param placeofIssue  placeof issue
     */
    public void setPlaceofIssue(String placeofIssue) {

        this.placeofIssue = placeofIssue;
    }

    /**
     * Gets the birth date.
     *
     * @return birth date
     */
    public String getBirthDate() {

        return birthDate;
    }

    /**
     * Set the birth date.
     *
     * @param birthDate  birth date
     */
    public void setBirthDate(String birthDate) {

        this.birthDate = birthDate;
    }

    /**
     * Gets the gender.
     *
     * @return gender
     */
    public String getGender() {

        return gender;
    }

    /**
     * Set the gender.
     *
     * @param gender  gender
     */
    public void setGender(String gender) {

        this.gender = gender;
    }

    /**
     * Gets the email address.
     *
     * @return email address
     */
    public String getEmailAddress() {

        return emailAddress;
    }

    /**
     * Set the email address.
     *
     * @param emailAddress  email address
     */
    public void setEmailAddress(String emailAddress) {

        this.emailAddress = emailAddress;
    }

    /**
     * Gets the nationality.
     *
     * @return nationality
     */
    public String getNationality() {

        return nationality;
    }

    /**
     * Set the nationality.
     *
     * @param nationality  nationality
     */
    public void setNationality(String nationality) {

        this.nationality = nationality;
    }

    /**
     * Gets the domicile.
     *
     * @return domicile
     */
    public String getDomicile() {

        return domicile;
    }

    /**
     * Set the domicile.
     *
     * @param domicile  domicile
     */
    public void setDomicile(String domicile) {

        this.domicile = domicile;
    }

    /**
     * Gets the permanent residence.
     *
     * @return permanent residence
     */
    public String getPermanentResidence() {

        return permanentResidence;
    }

    /**
     * Set the permanent residence.
     *
     * @param permanentResidence  permanent residence
     */
    public void setPermanentResidence(String permanentResidence) {

        this.permanentResidence = permanentResidence;
    }

    /**
     * Gets the education level.
     *
     * @return education level
     */
    public String getEducationLevel() {

        return educationLevel;
    }

    /**
     * Set the education level.
     *
     * @param educationLevel  education level
     */
    public void setEducationLevel(String educationLevel) {

        this.educationLevel = educationLevel;
    }

    /**
     * Gets the marital status.
     *
     * @return marital status
     */
    public String getMaritalStatus() {

        return maritalStatus;
    }

    /**
     * Set the marital status.
     *
     * @param maritalStatus  marital status
     */
    public void setMaritalStatus(String maritalStatus) {

        this.maritalStatus = maritalStatus;
    }

    /**
     * Gets the place of residence.
     *
     * @return place of residence
     */
    public String getPlaceOfResidence() {

        return placeOfResidence;
    }

    /**
     * Set the place of residence.
     *
     * @param placeOfResidence  place of residence
     */
    public void setPlaceOfResidence(String placeOfResidence) {

        this.placeOfResidence = placeOfResidence;
    }

    /**
     * Gets the reln with applicant.
     *
     * @return reln with applicant
     */
    public String getRelnWithApplicant() {

        return relnWithApplicant;
    }

    /**
     * Set the reln with applicant.
     *
     * @param relnWithApplicant  reln with applicant
     */
    public void setRelnWithApplicant(String relnWithApplicant) {

        this.relnWithApplicant = relnWithApplicant;
    }

    /**
     * Gets the mgm reference no.
     *
     * @return mgm reference no
     */
    public String getMgmReferenceNo() {

        return mgmReferenceNo;
    }

    /**
     * Set the mgm reference no.
     *
     * @param mgmReferenceNo  mgm reference no
     */
    public void setMgmReferenceNo(String mgmReferenceNo) {

        this.mgmReferenceNo = mgmReferenceNo;
    }

    /**
     * Gets the no of dependents.
     *
     * @return no of dependents
     */
    public String getNoOfDependents() {

        return noOfDependents;
    }

    /**
     * Set the no of dependents.
     *
     * @param noOfDependents  no of dependents
     */
    public void setNoOfDependents(String noOfDependents) {

        this.noOfDependents = noOfDependents;
    }

    /**
     * Gets the correspondence langauge.
     *
     * @return correspondence langauge
     */
    public String getCorrespondenceLangauge() {

        return correspondenceLangauge;
    }

    /**
     * Set the correspondence langauge.
     *
     * @param correspondenceLangauge  correspondence langauge
     */
    public void setCorrespondenceLangauge(String correspondenceLangauge) {

        this.correspondenceLangauge = correspondenceLangauge;
    }

    /**
     * Gets the resident type.
     *
     * @return resident type
     */
    public String getResidentType() {

        return residentType;
    }

    /**
     * Set the resident type.
     *
     * @param residentType  resident type
     */
    public void setResidentType(String residentType) {

        this.residentType = residentType;
    }

    /**
     * Gets the resident status.
     *
     * @return resident status
     */
    public String getResidentStatus() {

        return residentStatus;
    }

    /**
     * Set the resident status.
     *
     * @param residentStatus  resident status
     */
    public void setResidentStatus(String residentStatus) {

        this.residentStatus = residentStatus;
    }

    /**
     * Gets the year of graduation.
     *
     * @return year of graduation
     */
    public String getYearOfGraduation() {

        return yearOfGraduation;
    }

    /**
     * Set the year of graduation.
     *
     * @param yearOfGraduation  year of graduation
     */
    public void setYearOfGraduation(String yearOfGraduation) {

        this.yearOfGraduation = yearOfGraduation;
    }

    /**
     * Gets the applicant role.
     *
     * @return applicant role
     */
    public String getApplicantRole() {

        return applicantRole;
    }

    /**
     * Set the applicant role.
     *
     * @param applicantRole  applicant role
     */
    public void setApplicantRole(String applicantRole) {

        this.applicantRole = applicantRole;
    }

    /**
     * Gets the emer contact name.
     *
     * @return emer contact name
     */
    public StructuredNameVO getEmerContactName() {

        return emerContactName;
    }

    /**
     * Set the emer contact name.
     *
     * @param emerContactName  emer contact name
     */
    public void setEmerContactName(StructuredNameVO emerContactName) {

        this.emerContactName = emerContactName;
    }

    /**
     * Gets the ctry spec field 1.
     *
     * @return ctry spec field 1
     */
    public String getCtrySpecField1() {

        return ctrySpecField1;
    }

    /**
     * Set the ctry spec field 1.
     *
     * @param ctrySpecField1  ctry spec field 1
     */
    public void setCtrySpecField1(String ctrySpecField1) {

        this.ctrySpecField1 = ctrySpecField1;
    }

    /**
     * Gets the ctry spec field 2.
     *
     * @return ctry spec field 2
     */
    public String getCtrySpecField2() {

        return ctrySpecField2;
    }

    /**
     * Set the ctry spec field 2.
     *
     * @param ctrySpecField2  ctry spec field 2
     */
    public void setCtrySpecField2(String ctrySpecField2) {

        this.ctrySpecField2 = ctrySpecField2;
    }

    /**
     * Gets the ctry spec field 3.
     *
     * @return ctry spec field 3
     */
    public String getCtrySpecField3() {

        return ctrySpecField3;
    }

    /**
     * Set the ctry spec field 3.
     *
     * @param ctrySpecField3  ctry spec field 3
     */
    public void setCtrySpecField3(String ctrySpecField3) {

        this.ctrySpecField3 = ctrySpecField3;
    }

    /**
     * Gets the ctry spec field 4.
     *
     * @return ctry spec field 4
     */
    public String getCtrySpecField4() {

        return ctrySpecField4;
    }

    /**
     * Set the ctry spec field 4.
     *
     * @param ctrySpecField4  ctry spec field 4
     */
    public void setCtrySpecField4(String ctrySpecField4) {

        this.ctrySpecField4 = ctrySpecField4;
    }

    /**
     * Gets the credit bureau authentication flag.
     *
     * @return credit bureau authentication flag
     */
    public String getCreditBureauAuthenticationFlag() {

        return creditBureauAuthenticationFlag;
    }

    /**
     * Set the credit bureau authentication flag.
     *
     * @param creditBureauAuthenticationFlag  credit bureau authentication flag
     */
    public void setCreditBureauAuthenticationFlag(
        String creditBureauAuthenticationFlag) {

        this.creditBureauAuthenticationFlag = creditBureauAuthenticationFlag;
    }

    /**
     * Gets the is banamex customer.
     *
     * @return is banamex customer
     */
    public Boolean getIsBanamexCustomer() {

        return isBanamexCustomer;
    }

    /**
     * Set the is banamex customer.
     *
     * @param isBanamexCustomer  is banamex customer
     */
    public void setIsBanamexCustomer(Boolean isBanamexCustomer) {

        this.isBanamexCustomer = isBanamexCustomer;
    }

    /**
     * Gets the is credit card holder.
     *
     * @return is credit card holder
     */
    public Boolean getIsCreditCardHolder() {

        return isCreditCardHolder;
    }

    /**
     * Set the is credit card holder.
     *
     * @param isCreditCardHolder  is credit card holder
     */
    public void setIsCreditCardHolder(Boolean isCreditCardHolder) {

        this.isCreditCardHolder = isCreditCardHolder;
    }

    /**
     * Gets the is product upgrade requested.
     *
     * @return is product upgrade requested
     */
    public Boolean getIsProductUpgradeRequested() {

        return isProductUpgradeRequested;
    }

    /**
     * Set the is product upgrade requested.
     *
     * @param isProductUpgradeRequested  is product upgrade requested
     */
    public void
        setIsProductUpgradeRequested(Boolean isProductUpgradeRequested) {

        this.isProductUpgradeRequested = isProductUpgradeRequested;
    }

    /**
     * Gets the is credit line increase requested.
     *
     * @return is credit line increase requested
     */
    public Boolean getIsCreditLineIncreaseRequested() {

        return isCreditLineIncreaseRequested;
    }

    /**
     * Set the is credit line increase requested.
     *
     * @param isCreditLineIncreaseRequested  is credit line increase requested
     */
    public void setIsCreditLineIncreaseRequested(
        Boolean isCreditLineIncreaseRequested) {

        this.isCreditLineIncreaseRequested = isCreditLineIncreaseRequested;
    }

    /**
     * Gets the is terms and conditions accepted.
     *
     * @return is terms and conditions accepted
     */
    public Boolean getIsTermsAndConditionsAccepted() {

        return isTermsAndConditionsAccepted;
    }

    /**
     * Set the is terms and conditions accepted.
     *
     * @param isTermsAndConditionsAccepted  is terms and conditions accepted
     */
    public void
        setIsTermsAndConditionsAccepted(Boolean isTermsAndConditionsAccepted) {

        this.isTermsAndConditionsAccepted = isTermsAndConditionsAccepted;
    }

    /**
     * Gets the is credit bureau consulting accepted.
     *
     * @return is credit bureau consulting accepted
     */
    public Boolean getIsCreditBureauConsultingAccepted() {

        return isCreditBureauConsultingAccepted;
    }

    /**
     * Set the is credit bureau consulting accepted.
     *
     * @param isCreditBureauConsultingAccepted  is credit bureau consulting accepted
     */
    public void setIsCreditBureauConsultingAccepted(
        Boolean isCreditBureauConsultingAccepted) {

        this.isCreditBureauConsultingAccepted =
            isCreditBureauConsultingAccepted;
    }

    /**
     * Gets the is revolving credit contract accepted.
     *
     * @return is revolving credit contract accepted
     */
    public Boolean getIsRevolvingCreditContractAccepted() {

        return isRevolvingCreditContractAccepted;
    }

    /**
     * Set the is revolving credit contract accepted.
     *
     * @param isRevolvingCreditContractAccepted  is revolving credit contract accepted
     */
    public void setIsRevolvingCreditContractAccepted(
        Boolean isRevolvingCreditContractAccepted) {

        this.isRevolvingCreditContractAccepted =
            isRevolvingCreditContractAccepted;
    }

    /**
     * Gets the is user contract accepted.
     *
     * @return is user contract accepted
     */
    public Boolean getIsUserContractAccepted() {

        return isUserContractAccepted;
    }

    /**
     * Set the is user contract accepted.
     *
     * @param isUserContractAccepted  is user contract accepted
     */
    public void setIsUserContractAccepted(Boolean isUserContractAccepted) {

        this.isUserContractAccepted = isUserContractAccepted;
    }

    /**
     * Gets the is specific banking segment customer.
     *
     * @return is specific banking segment customer
     */
    public Boolean getIsSpecificBankingSegmentCustomer() {

        return isSpecificBankingSegmentCustomer;
    }

    /**
     * Set the is specific banking segment customer.
     *
     * @param isSpecificBankingSegmentCustomer  is specific banking segment customer
     */
    public void setIsSpecificBankingSegmentCustomer(
        Boolean isSpecificBankingSegmentCustomer) {

        this.isSpecificBankingSegmentCustomer =
            isSpecificBankingSegmentCustomer;
    }

    /**
     * Gets the banking segment.
     *
     * @return banking segment
     */
    public String getBankingSegment() {

        return bankingSegment;
    }

    /**
     * Set the banking segment.
     *
     * @param bankingSegment  banking segment
     */
    public void setBankingSegment(String bankingSegment) {

        this.bankingSegment = bankingSegment;
    }

    /**
     * Gets the division.
     *
     * @return division
     */
    public String getDivision() {

        return division;
    }

    /**
     * Set the division.
     *
     * @param division  division
     */
    public void setDivision(String division) {

        this.division = division;
    }

    /**
     * Gets the college no of approved subjects.
     *
     * @return college no of approved subjects
     */
    public String getCollegeNoOfApprovedSubjects() {

        return collegeNoOfApprovedSubjects;
    }

    /**
     * Set the college no of approved subjects.
     *
     * @param collegeNoOfApprovedSubjects  college no of approved subjects
     */
    public void
        setCollegeNoOfApprovedSubjects(String collegeNoOfApprovedSubjects) {

        this.collegeNoOfApprovedSubjects = collegeNoOfApprovedSubjects;
    }

    /**
     * Gets the has college scholarship.
     *
     * @return has college scholarship
     */
    public Boolean getHasCollegeScholarship() {

        return hasCollegeScholarship;
    }

    /**
     * Set the has college scholarship.
     *
     * @param hasCollegeScholarship  has college scholarship
     */
    public void setHasCollegeScholarship(Boolean hasCollegeScholarship) {

        this.hasCollegeScholarship = hasCollegeScholarship;
    }

    /**
     * Gets the college scholarship level.
     *
     * @return college scholarship level
     */
    public String getCollegeScholarshipLevel() {

        return collegeScholarshipLevel;
    }

    /**
     * Set the college scholarship level.
     *
     * @param collegeScholarshipLevel  college scholarship level
     */
    public void setCollegeScholarshipLevel(String collegeScholarshipLevel) {

        this.collegeScholarshipLevel = collegeScholarshipLevel;
    }

    /**
     * Gets the college scholarship type.
     *
     * @return college scholarship type
     */
    public String getCollegeScholarshipType() {

        return collegeScholarshipType;
    }

    /**
     * Set the college scholarship type.
     *
     * @param collegeScholarshipType  college scholarship type
     */
    public void setCollegeScholarshipType(String collegeScholarshipType) {

        this.collegeScholarshipType = collegeScholarshipType;
    }

    /**
     * Gets the college start date.
     *
     * @return college start date
     */
    public String getCollegeStartDate() {

        return collegeStartDate;
    }

    /**
     * Set the college start date.
     *
     * @param collegeStartDate  college start date
     */
    public void setCollegeStartDate(String collegeStartDate) {

        this.collegeStartDate = collegeStartDate;
    }

    /**
     * Gets the college end date.
     *
     * @return college end date
     */
    public String getCollegeEndDate() {

        return collegeEndDate;
    }

    /**
     * Set the college end date.
     *
     * @param collegeEndDate  college end date
     */
    public void setCollegeEndDate(String collegeEndDate) {

        this.collegeEndDate = collegeEndDate;
    }

    /**
     * Gets the college university name.
     *
     * @return college university name
     */
    public String getCollegeUniversityName() {

        return collegeUniversityName;
    }

    /**
     * Set the college university name.
     *
     * @param collegeUniversityName  college university name
     */
    public void setCollegeUniversityName(String collegeUniversityName) {

        this.collegeUniversityName = collegeUniversityName;
    }

    /**
     * Gets the college no of subjects.
     *
     * @return college no of subjects
     */
    public String getCollegeNoOfSubjects() {

        return collegeNoOfSubjects;
    }

    /**
     * Set the college no of subjects.
     *
     * @param collegeNoOfSubjects  college no of subjects
     */
    public void setCollegeNoOfSubjects(String collegeNoOfSubjects) {

        this.collegeNoOfSubjects = collegeNoOfSubjects;
    }

    /**
     * Gets the college average marks.
     *
     * @return college average marks
     */
    public String getCollegeAverageMarks() {

        return collegeAverageMarks;
    }

    /**
     * Set the college average marks.
     *
     * @param collegeAverageMarks  college average marks
     */
    public void setCollegeAverageMarks(String collegeAverageMarks) {

        this.collegeAverageMarks = collegeAverageMarks;
    }

    /**
     * Gets the college semester.
     *
     * @return college semester
     */
    public String getCollegeSemester() {

        return collegeSemester;
    }

    /**
     * Set the college semester.
     *
     * @param collegeSemester  college semester
     */
    public void setCollegeSemester(String collegeSemester) {

        this.collegeSemester = collegeSemester;
    }

    /**
     * Gets the credits and liabilities reference details.
     *
     * @return credits and liabilities reference details
     */
    public List<CreditsAndLiabilitiesReferenceDetailsVO>
        getCreditsAndLiabilitiesReferenceDetails() {

        return creditsAndLiabilitiesReferenceDetails;
    }

    /**
     * Set the credits and liabilities reference details.
     *
     * @param creditsAndLiabilitiesReferenceDetails  credits and liabilities reference details
     */
    public void setCreditsAndLiabilitiesReferenceDetails(
        List<CreditsAndLiabilitiesReferenceDetailsVO> creditsAndLiabilitiesReferenceDetails) {

        this.creditsAndLiabilitiesReferenceDetails =
            creditsAndLiabilitiesReferenceDetails;
    }

    /**
     * Gets the club premier membership no.
     *
     * @return club premier membership no
     */
    public String getClubPremierMembershipNo() {

        return clubPremierMembershipNo;
    }

    /**
     * Set the club premier membership no.
     *
     * @param clubPremierMembershipNo  club premier membership no
     */
    public void setClubPremierMembershipNo(String clubPremierMembershipNo) {

        this.clubPremierMembershipNo = clubPremierMembershipNo;
    }

    /**
     * Gets the customer no.
     *
     * @return customer no
     */
    public String getCustomerNo() {

        return customerNo;
    }

    /**
     * Set the customer no.
     *
     * @param customerNo  customer no
     */
    public void setCustomerNo(String customerNo) {

        this.customerNo = customerNo;
    }

    /**
     * Gets the account no.
     *
     * @return account no
     */
    public List<String> getAccountNo() {

        return accountNo;
    }

    /**
     * Set the account no.
     *
     * @param accountNo  account no
     */
    public void setAccountNo(List<String> accountNo) {

        this.accountNo = accountNo;
    }

    /**
     * Gets the social security no.
     *
     * @return social security no
     */
    public String getSocialSecurityNo() {

        return socialSecurityNo;
    }

    /**
     * Set the social security no.
     *
     * @param socialSecurityNo  social security no
     */
    public void setSocialSecurityNo(String socialSecurityNo) {

        this.socialSecurityNo = socialSecurityNo;
    }

    /**
     * Gets the national ID issue number.
     *
     * @return national ID issue number
     */
    public String getNationalIDIssueNumber() {

        return nationalIDIssueNumber;
    }

    /**
     * Set the national ID issue number.
     *
     * @param nationalIDIssueNumber  national ID issue number
     */
    public void setNationalIDIssueNumber(String nationalIDIssueNumber) {

        this.nationalIDIssueNumber = nationalIDIssueNumber;
    }

    /**
     * Gets the national IDOCR.
     *
     * @return national IDOCR
     */
    public String getNationalIDOCR() {

        return nationalIDOCR;
    }

    /**
     * Set the national IDOCR.
     *
     * @param nationalIDOCR  national IDOCR
     */
    public void setNationalIDOCR(String nationalIDOCR) {

        this.nationalIDOCR = nationalIDOCR;
    }

    /**
     * Gets the type of person.
     *
     * @return type of person
     */
    public String getTypeOfPerson() {

        return typeOfPerson;
    }

    /**
     * Set the type of person.
     *
     * @param typeOfPerson  type of person
     */
    public void setTypeOfPerson(String typeOfPerson) {

        this.typeOfPerson = typeOfPerson;
    }

    /**
     * Gets the country of birth.
     *
     * @return country of birth
     */
    public String getCountryOfBirth() {

        return countryOfBirth;
    }

    /**
     * Set the country of birth.
     *
     * @param countryOfBirth  country of birth
     */
    public void setCountryOfBirth(String countryOfBirth) {

        this.countryOfBirth = countryOfBirth;
    }

    /**
     * Gets the place of birth.
     *
     * @return place of birth
     */
    public String getPlaceOfBirth() {

        return placeOfBirth;
    }

    /**
     * Set the place of birth.
     *
     * @param placeOfBirth  place of birth
     */
    public void setPlaceOfBirth(String placeOfBirth) {

        this.placeOfBirth = placeOfBirth;
    }

    /**
     * Gets the is retired.
     *
     * @return is retired
     */
    public Boolean getIsRetired() {

        return isRetired;
    }

    /**
     * Set the is retired.
     *
     * @param isRetired  is retired
     */
    public void setIsRetired(Boolean isRetired) {

        this.isRetired = isRetired;
    }

    /**
     * Gets the type of retirement.
     *
     * @return type of retirement
     */
    public String getTypeOfRetirement() {

        return typeOfRetirement;
    }

    /**
     * Set the type of retirement.
     *
     * @param typeOfRetirement  type of retirement
     */
    public void setTypeOfRetirement(String typeOfRetirement) {

        this.typeOfRetirement = typeOfRetirement;
    }

    /**
     * Gets the is VIP.
     *
     * @return is VIP
     */
    public Boolean getIsVIP() {

        return isVIP;
    }

    /**
     * Set the is VIP.
     *
     * @param isVIP  is VIP
     */
    public void setIsVIP(Boolean isVIP) {

        this.isVIP = isVIP;
    }

    /**
     * Gets the provider no.
     *
     * @return provider no
     */
    public String getProviderNo() {

        return providerNo;
    }

    /**
     * Set the provider no.
     *
     * @param providerNo  provider no
     */
    public void setProviderNo(String providerNo) {

        this.providerNo = providerNo;
    }

    /**
     * Gets the electric company service no.
     *
     * @return electric company service no
     */
    public String getElectricCompanyServiceNo() {

        return electricCompanyServiceNo;
    }

    /**
     * Set the electric company service no.
     *
     * @param electricCompanyServiceNo  electric company service no
     */
    public void setElectricCompanyServiceNo(String electricCompanyServiceNo) {

        this.electricCompanyServiceNo = electricCompanyServiceNo;
    }

    /**
     * Gets the tv service company.
     *
     * @return tv service company
     */
    public String getTvServiceCompany() {

        return tvServiceCompany;
    }

    /**
     * Set the tv service company.
     *
     * @param tvServiceCompany  tv service company
     */
    public void setTvServiceCompany(String tvServiceCompany) {

        this.tvServiceCompany = tvServiceCompany;
    }

    /**
     * Gets the data verification comments.
     *
     * @return data verification comments
     */
    public String getDataVerificationComments() {

        return dataVerificationComments;
    }

    /**
     * Set the data verification comments.
     *
     * @param dataVerificationComments  data verification comments
     */
    public void setDataVerificationComments(String dataVerificationComments) {

        this.dataVerificationComments = dataVerificationComments;
    }

    /**
     * Gets the contract memo.
     *
     * @return contract memo
     */
    public String getContractMemo() {

        return contractMemo;
    }

    /**
     * Set the contract memo.
     *
     * @param contractMemo  contract memo
     */
    public void setContractMemo(String contractMemo) {

        this.contractMemo = contractMemo;
    }

    /**
     * Gets the reference memo.
     *
     * @return reference memo
     */
    public String getReferenceMemo() {

        return referenceMemo;
    }

    /**
     * Set the reference memo.
     *
     * @param referenceMemo  reference memo
     */
    public void setReferenceMemo(String referenceMemo) {

        this.referenceMemo = referenceMemo;
    }

    /**
     * Gets the applicant memo.
     *
     * @return applicant memo
     */
    public String getApplicantMemo() {

        return applicantMemo;
    }

    /**
     * Set the applicant memo.
     *
     * @param applicantMemo  applicant memo
     */
    public void setApplicantMemo(String applicantMemo) {

        this.applicantMemo = applicantMemo;
    }

    /**
     * Gets the susc control no.
     *
     * @return susc control no
     */
    public String getSuscControlNo() {

        return suscControlNo;
    }

    /**
     * Set the susc control no.
     *
     * @param suscControlNo  susc control no
     */
    public void setSuscControlNo(String suscControlNo) {

        this.suscControlNo = suscControlNo;
    }

    /**
     * Gets the banamex credit card no.
     *
     * @return banamex credit card no
     */
    public List<String> getBanamexCreditCardNo() {

        return banamexCreditCardNo;
    }

    /**
     * Set the banamex credit card no.
     *
     * @param banamexCreditCardNo  banamex credit card no
     */
    public void setBanamexCreditCardNo(List<String> banamexCreditCardNo) {

        this.banamexCreditCardNo = banamexCreditCardNo;
    }

    /**
     * Gets the has other bank card.
     *
     * @return has other bank card
     */
    public Boolean getHasOtherBankCard() {

        return hasOtherBankCard;
    }

    /**
     * Set the has other bank card.
     *
     * @param hasOtherBankCard  has other bank card
     */
    public void setHasOtherBankCard(Boolean hasOtherBankCard) {

        this.hasOtherBankCard = hasOtherBankCard;
    }

    /**
     * Gets the has mortgage loan.
     *
     * @return has mortgage loan
     */
    public Boolean getHasMortgageLoan() {

        return hasMortgageLoan;
    }

    /**
     * Set the has mortgage loan.
     *
     * @param hasMortgageLoan  has mortgage loan
     */
    public void setHasMortgageLoan(Boolean hasMortgageLoan) {

        this.hasMortgageLoan = hasMortgageLoan;
    }

    /**
     * Gets the has automobile loan.
     *
     * @return has automobile loan
     */
    public Boolean getHasAutomobileLoan() {

        return hasAutomobileLoan;
    }

    /**
     * Set the has automobile loan.
     *
     * @param hasAutomobileLoan  has automobile loan
     */
    public void setHasAutomobileLoan(Boolean hasAutomobileLoan) {

        this.hasAutomobileLoan = hasAutomobileLoan;
    }

    /**
     * Gets the has department store card.
     *
     * @return has department store card
     */
    public Boolean getHasDepartmentStoreCard() {

        return hasDepartmentStoreCard;
    }

    /**
     * Set the has department store card.
     *
     * @param hasDepartmentStoreCard  has department store card
     */
    public void setHasDepartmentStoreCard(Boolean hasDepartmentStoreCard) {

        this.hasDepartmentStoreCard = hasDepartmentStoreCard;
    }

    /**
     * Gets the authentication institution.
     *
     * @return authentication institution
     */
    public String getAuthenticationInstitution() {

        return authenticationInstitution;
    }

    /**
     * Set the authentication institution.
     *
     * @param authenticationInstitution  authentication institution
     */
    public void setAuthenticationInstitution(String authenticationInstitution) {

        this.authenticationInstitution = authenticationInstitution;
    }

    /**
     * Gets the credit bureau authentication bank.
     *
     * @return credit bureau authentication bank
     */
    public String getCreditBureauAuthenticationBank() {

        return creditBureauAuthenticationBank;
    }

    /**
     * Set the credit bureau authentication bank.
     *
     * @param creditBureauAuthenticationBank  credit bureau authentication bank
     */
    public void setCreditBureauAuthenticationBank(
        String creditBureauAuthenticationBank) {

        this.creditBureauAuthenticationBank = creditBureauAuthenticationBank;
    }

    /**
     * Gets the credit card last four digits.
     *
     * @return credit card last four digits
     */
    public String getCreditCardLastFourDigits() {

        return creditCardLastFourDigits;
    }

    /**
     * Set the credit card last four digits.
     *
     * @param creditCardLastFourDigits  credit card last four digits
     */
    public void setCreditCardLastFourDigits(String creditCardLastFourDigits) {

        this.creditCardLastFourDigits = creditCardLastFourDigits;
    }

    /**
     * Gets the is other credit evaluation requested.
     *
     * @return is other credit evaluation requested
     */
    public Boolean getIsOtherCreditEvaluationRequested() {

        return isOtherCreditEvaluationRequested;
    }

    /**
     * Set the is other credit evaluation requested.
     *
     * @param isOtherCreditEvaluationRequested  is other credit evaluation requested
     */
    public void setIsOtherCreditEvaluationRequested(
        Boolean isOtherCreditEvaluationRequested) {

        this.isOtherCreditEvaluationRequested =
            isOtherCreditEvaluationRequested;
    }

    /**
     * Gets the personal references.
     *
     * @return personal references
     */
    public List<PersonalReferenceVO> getPersonalReferences() {

        return personalReferences;
    }

    /**
     * Set the personal references.
     *
     * @param personalReferences  personal references
     */
    public void
        setPersonalReferences(List<PersonalReferenceVO> personalReferences) {

        this.personalReferences = personalReferences;
    }

    /**
     * Gets the customer ID details.
     *
     * @return customer ID details
     */
    public List<CustomerIDDetailsVO> getCustomerIDDetails() {

        return customerIDDetails;
    }

    /**
     * Set the customer ID details.
     *
     * @param customerIDDetails  customer ID details
     */
    public void
        setCustomerIDDetails(List<CustomerIDDetailsVO> customerIDDetails) {

        this.customerIDDetails = customerIDDetails;
    }

    /**
     * Gets the national tax ID.
     *
     * @return national tax ID
     */
    public String getNationalTaxID() {

        return nationalTaxID;
    }

    /**
     * Set the national tax ID.
     *
     * @param nationalTaxID  national tax ID
     */
    public void setNationalTaxID(String nationalTaxID) {

        this.nationalTaxID = nationalTaxID;
    }

    /**
     * Gets the curp unique no.
     *
     * @return curp unique no
     */
    public String getCurpUniqueNo() {

        return curpUniqueNo;
    }

    /**
     * Set the curp unique no.
     *
     * @param curpUniqueNo  curp unique no
     */
    public void setCurpUniqueNo(String curpUniqueNo) {

        this.curpUniqueNo = curpUniqueNo;
    }

    /**
     * Gets the fiel serial no.
     *
     * @return fiel serial no
     */
    public String getFielSerialNo() {

        return fielSerialNo;
    }

    /**
     * Set the fiel serial no.
     *
     * @param fielSerialNo  fiel serial no
     */
    public void setFielSerialNo(String fielSerialNo) {

        this.fielSerialNo = fielSerialNo;
    }

    /**
     * Gets the passport serial no.
     *
     * @return passport serial no
     */
    public String getPassportSerialNo() {

        return passportSerialNo;
    }

    /**
     * Set the passport serial no.
     *
     * @param passportSerialNo  passport serial no
     */
    public void setPassportSerialNo(String passportSerialNo) {

        this.passportSerialNo = passportSerialNo;
    }

    /**
     * Gets the national ID code.
     *
     * @return national ID code
     */
    public String getNationalIDCode() {

        return nationalIDCode;
    }

    /**
     * Set the national ID code.
     *
     * @param nationalIDCode  national ID code
     */
    public void setNationalIDCode(String nationalIDCode) {

        this.nationalIDCode = nationalIDCode;
    }

    /**
     * Gets the is primary address.
     *
     * @return is primary address
     */
    public Boolean getIsPrimaryAddress() {

        return isPrimaryAddress;
    }

    /**
     * Set the is primary address.
     *
     * @param isPrimaryAddress  is primary address
     */
    public void setIsPrimaryAddress(Boolean isPrimaryAddress) {

        this.isPrimaryAddress = isPrimaryAddress;
    }

}
