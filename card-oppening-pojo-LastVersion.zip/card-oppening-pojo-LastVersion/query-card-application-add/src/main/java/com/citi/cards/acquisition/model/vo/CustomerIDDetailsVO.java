/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CustomerIDDetailsVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

/**
 *  <code>CustomerIDDetailsVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class CustomerIDDetailsVO {

    /** seq no. */
    private String seqNo;

    /** id type. */
    private String idType;

    /** id number. */
    private String idNumber;

    /** id expiry date. */
    private String idExpiryDate;

    /** id code. */
    private String idCode;

    /** id issue date. */
    private String idIssueDate;

    /** id issue place. */
    private String idIssuePlace;

    /** id issue country. */
    private String idIssueCountry;

    /** issuing authority. */
    private String issuingAuthority;

    /** exist new ind. */
    private String existNewInd;

    /** id type desc. */
    private String idTypeDesc;

    /**
     * Gets the seq no.
     *
     * @return seq no
     */
    public String getSeqNo() {

        return seqNo;
    }

    /**
     * Set the seq no.
     *
     * @param seqNo  seq no
     */
    public void setSeqNo(String seqNo) {

        this.seqNo = seqNo;
    }

    /**
     * Gets the id type.
     *
     * @return id type
     */
    public String getIdType() {

        return idType;
    }

    /**
     * Set the id type.
     *
     * @param idType  id type
     */
    public void setIdType(String idType) {

        this.idType = idType;
    }

    /**
     * Gets the id number.
     *
     * @return id number
     */
    public String getIdNumber() {

        return idNumber;
    }

    /**
     * Set the id number.
     *
     * @param idNumber  id number
     */
    public void setIdNumber(String idNumber) {

        this.idNumber = idNumber;
    }

    /**
     * Gets the id expiry date.
     *
     * @return id expiry date
     */
    public String getIdExpiryDate() {

        return idExpiryDate;
    }

    /**
     * Set the id expiry date.
     *
     * @param idExpiryDate  id expiry date
     */
    public void setIdExpiryDate(String idExpiryDate) {

        this.idExpiryDate = idExpiryDate;
    }

    /**
     * Gets the id code.
     *
     * @return id code
     */
    public String getIdCode() {

        return idCode;
    }

    /**
     * Set the id code.
     *
     * @param idCode  id code
     */
    public void setIdCode(String idCode) {

        this.idCode = idCode;
    }

    /**
     * Gets the id issue date.
     *
     * @return id issue date
     */
    public String getIdIssueDate() {

        return idIssueDate;
    }

    /**
     * Set the id issue date.
     *
     * @param idIssueDate  id issue date
     */
    public void setIdIssueDate(String idIssueDate) {

        this.idIssueDate = idIssueDate;
    }

    /**
     * Gets the id issue place.
     *
     * @return id issue place
     */
    public String getIdIssuePlace() {

        return idIssuePlace;
    }

    /**
     * Set the id issue place.
     *
     * @param idIssuePlace  id issue place
     */
    public void setIdIssuePlace(String idIssuePlace) {

        this.idIssuePlace = idIssuePlace;
    }

    /**
     * Gets the id issue country.
     *
     * @return id issue country
     */
    public String getIdIssueCountry() {

        return idIssueCountry;
    }

    /**
     * Set the id issue country.
     *
     * @param idIssueCountry  id issue country
     */
    public void setIdIssueCountry(String idIssueCountry) {

        this.idIssueCountry = idIssueCountry;
    }

    /**
     * Gets the issuing authority.
     *
     * @return issuing authority
     */
    public String getIssuingAuthority() {

        return issuingAuthority;
    }

    /**
     * Set the issuing authority.
     *
     * @param issuingAuthority  issuing authority
     */
    public void setIssuingAuthority(String issuingAuthority) {

        this.issuingAuthority = issuingAuthority;
    }

    /**
     * Gets the exist new ind.
     *
     * @return exist new ind
     */
    public String getExistNewInd() {

        return existNewInd;
    }

    /**
     * Set the exist new ind.
     *
     * @param existNewInd  exist new ind
     */
    public void setExistNewInd(String existNewInd) {

        this.existNewInd = existNewInd;
    }

    /**
     * Gets the id type desc.
     *
     * @return id type desc
     */
    public String getIdTypeDesc() {

        return idTypeDesc;
    }

    /**
     * Set the id type desc.
     *
     * @param idTypeDesc  id type desc
     */
    public void setIdTypeDesc(String idTypeDesc) {

        this.idTypeDesc = idTypeDesc;
    }

}
