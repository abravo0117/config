/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: AppExceptionBuilder.java
 * Original Author: Softtek
 * Creation Date: 2/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.exception;

/**
 * <code>AppExceptionBuilder</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public final class AppExceptionBuilder {

    private AppExceptionBuilder() {}

    /**
     * Builds the exception.
     *
     * @return app exception
     */
    public static AppException buildException() {

        return new AppException();
    }

    /**
     * Builds the exception.
     *
     * @param ex
     *            ex
     * @return app exception
     */
    public static AppException buildException(Throwable ex) {

        return new AppException(ex);
    }

    /**
     * Builds the exception.
     *
     * @param code
     *            code
     * @return app exception
     */
    public static AppException buildException(AppExceptionCodeEnum code) {

        return new AppException(code);
    }

    /**
     * Builds the exception.
     *
     * @param code
     *            code
     * @param ex
     *            ex
     * @return app exception
     */
    public static AppException buildException(AppExceptionCodeEnum code,
        Throwable ex) {

        return new AppException(code, ex);
    }

}
