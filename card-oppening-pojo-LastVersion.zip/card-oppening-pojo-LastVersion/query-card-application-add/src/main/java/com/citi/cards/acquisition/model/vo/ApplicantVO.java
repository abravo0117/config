/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: ApplicantVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.model.vo;

import java.util.List;

/**
 *  <code>ApplicantVO</code>.
 *
 * @author vb44309
 * @version 1.0
 */
public class ApplicantVO {

    /** basic data. */
    private BasicDataVO basicData;

    /** address. */
    private List<AddressVO> address;

    /** phone. */
    private List<PhoneVO> phone;

    /** employment. */
    private EmploymentVO employment;

    /** income. */
    private IncomeVO income;

    /** product. */
    private List<ProductVO> product;

    /** counter offers product details. */
    private List<CounterOffersProductDetailsVO> counterOffersProductDetails;

    /**
     * Gets the basic data.
     *
     * @return basic data
     */
    public BasicDataVO getBasicData() {

        return basicData;
    }

    /**
     * Set the basic data.
     *
     * @param basicData  basic data
     */
    public void setBasicData(BasicDataVO basicData) {

        this.basicData = basicData;
    }

    /**
     * Gets the address.
     *
     * @return address
     */
    public List<AddressVO> getAddress() {

        return address;
    }

    /**
     * Set the address.
     *
     * @param address  address
     */
    public void setAddress(List<AddressVO> address) {

        this.address = address;
    }

    /**
     * Gets the phone.
     *
     * @return phone
     */
    public List<PhoneVO> getPhone() {

        return phone;
    }

    /**
     * Set the phone.
     *
     * @param phone  phone
     */
    public void setPhone(List<PhoneVO> phone) {

        this.phone = phone;
    }

    /**
     * Gets the employment.
     *
     * @return employment
     */
    public EmploymentVO getEmployment() {

        return employment;
    }

    /**
     * Set the employment.
     *
     * @param employment  employment
     */
    public void setEmployment(EmploymentVO employment) {

        this.employment = employment;
    }

    /**
     * Gets the income.
     *
     * @return income
     */
    public IncomeVO getIncome() {

        return income;
    }

    /**
     * Set the income.
     *
     * @param income  income
     */
    public void setIncome(IncomeVO income) {

        this.income = income;
    }

    /**
     * Gets the product.
     *
     * @return product
     */
    public List<ProductVO> getProduct() {

        return product;
    }

    /**
     * Set the product.
     *
     * @param product  product
     */
    public void setProduct(List<ProductVO> product) {

        this.product = product;
    }

    /**
     * Gets the counter offers product details.
     *
     * @return counter offers product details
     */
    public List<CounterOffersProductDetailsVO>
        getCounterOffersProductDetails() {

        return counterOffersProductDetails;
    }

    /**
     * Set the counter offers product details.
     *
     * @param counterOffersProductDetails  counter offers product details
     */
    public void setCounterOffersProductDetails(
        List<CounterOffersProductDetailsVO> counterOffersProductDetails) {

        this.counterOffersProductDetails = counterOffersProductDetails;
    }

}
