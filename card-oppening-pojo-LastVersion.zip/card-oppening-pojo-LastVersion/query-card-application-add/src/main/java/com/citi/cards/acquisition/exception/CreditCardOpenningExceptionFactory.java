/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: CreditCardOpenningExceptionFactory.java
 * Original Author: Softtek
 * Creation Date: 8/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.exception;

/**
 * A factory for creating CreditCardOpenningException objects.
 */
public final class CreditCardOpenningExceptionFactory {

    /**
     * Creates a new instance of credit card openning exception factory.
     */
    private CreditCardOpenningExceptionFactory() { }

    /**
     * Throw WS client exception.
     *
     * @param code code
     * @param exCause ex cause
     * @return WS client exception
     */
    public static WSClientException
        throwWSClientException(AppExceptionCodeEnum code, String exCause) {

        return throwWSClientException(code.getCode(), code.getDescription(),
            exCause);
    }

    /**
     * Throw WS client exception.
     *
     * @param code
     *            code
     * @return WS client exception
     */
    public static WSClientException
        throwWSClientException(AppExceptionCodeEnum code) {

        return throwWSClientException(code.getCode(), code.getDescription(),
            "");
    }

    /**
     * Throw WS client exception.
     *
     * @param code            code
     * @param message            message
     * @param exCause ex cause
     * @return WS client exception
     */
    public static WSClientException throwWSClientException(int code,
        String message,
        String exCause) {

        return new WSClientException(code, message, exCause);
    }

}
