/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: AddressVO.java
 * Original Author: Softtek
 * Creation Date: 22/08/2017
 * ---------------------------------------------------------------------------
 */

package com.citi.cards.acquisition.model.vo;

/**
 * The Class AddressVO.
 *
 * @author vb44309
 * @version 1.0
 */
public class AddressVO {

    /** The address type. */
    private String addressType;

    /** The address line 1. */
    private String addressLine1;

    /** The address line 2. */
    private String addressLine2;

    /** The address line 3. */
    private String addressLine3;

    /** The address line 4. */
    private String addressLine4;

    /** The city. */
    private String city;

    /** The district. */
    private String district;

    /** The province. */
    private String province;

    /** The zip code. */
    private String zipCode;

    /** The country. */
    private String country;

    /** The ok to mail. */
    private String okToMail;

    /** The years in residence. */
    private String yearsInResidence;

    /** The months in residence. */
    private String monthsInResidence;

    /** The address proof type. */
    private String addressProofType;

    /**
     * Gets the address type.
     *
     * @return the address type
     */
    public String getAddressType() {

        return addressType;
    }

    /**
     * Sets the address type.
     *
     * @param addressType the new address type
     */
    public void setAddressType(String addressType) {

        this.addressType = addressType;
    }

    /**
     * Gets the address line 1.
     *
     * @return the address line 1
     */
    public String getAddressLine1() {

        return addressLine1;
    }

    /**
     * Sets the address line 1.
     *
     * @param addressLine1 the new address line 1
     */
    public void setAddressLine1(String addressLine1) {

        this.addressLine1 = addressLine1;
    }

    /**
     * Gets the address line 2.
     *
     * @return the address line 2
     */
    public String getAddressLine2() {

        return addressLine2;
    }

    /**
     * Sets the address line 2.
     *
     * @param addressLine2 the new address line 2
     */
    public void setAddressLine2(String addressLine2) {

        this.addressLine2 = addressLine2;
    }

    /**
     * Gets the address line 3.
     *
     * @return the address line 3
     */
    public String getAddressLine3() {

        return addressLine3;
    }

    /**
     * Sets the address line 3.
     *
     * @param addressLine3 the new address line 3
     */
    public void setAddressLine3(String addressLine3) {

        this.addressLine3 = addressLine3;
    }

    /**
     * Gets the address line 4.
     *
     * @return the address line 4
     */
    public String getAddressLine4() {

        return addressLine4;
    }

    /**
     * Sets the address line 4.
     *
     * @param addressLine4 the new address line 4
     */
    public void setAddressLine4(String addressLine4) {

        this.addressLine4 = addressLine4;
    }

    /**
     * Gets the city.
     *
     * @return the city
     */
    public String getCity() {

        return city;
    }

    /**
     * Sets the city.
     *
     * @param city the new city
     */
    public void setCity(String city) {

        this.city = city;
    }

    /**
     * Gets the district.
     *
     * @return the district
     */
    public String getDistrict() {

        return district;
    }

    /**
     * Sets the district.
     *
     * @param district the new district
     */
    public void setDistrict(String district) {

        this.district = district;
    }

    /**
     * Gets the province.
     *
     * @return the province
     */
    public String getProvince() {

        return province;
    }

    /**
     * Sets the province.
     *
     * @param province the new province
     */
    public void setProvince(String province) {

        this.province = province;
    }

    /**
     * Gets the zip code.
     *
     * @return the zip code
     */
    public String getZipCode() {

        return zipCode;
    }

    /**
     * Sets the zip code.
     *
     * @param zipCode the new zip code
     */
    public void setZipCode(String zipCode) {

        this.zipCode = zipCode;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {

        return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {

        this.country = country;
    }

    /**
     * Gets the ok to mail.
     *
     * @return the ok to mail
     */
    public String getOkToMail() {

        return okToMail;
    }

    /**
     * Sets the ok to mail.
     *
     * @param okToMail the new ok to mail
     */
    public void setOkToMail(String okToMail) {

        this.okToMail = okToMail;
    }

    /**
     * Gets the years in residence.
     *
     * @return the years in residence
     */
    public String getYearsInResidence() {

        return yearsInResidence;
    }

    /**
     * Sets the years in residence.
     *
     * @param yearsInResidence the new years in residence
     */
    public void setYearsInResidence(String yearsInResidence) {

        this.yearsInResidence = yearsInResidence;
    }

    /**
     * Gets the months in residence.
     *
     * @return the months in residence
     */
    public String getMonthsInResidence() {

        return monthsInResidence;
    }

    /**
     * Sets the months in residence.
     *
     * @param monthsInResidence the new months in residence
     */
    public void setMonthsInResidence(String monthsInResidence) {

        this.monthsInResidence = monthsInResidence;
    }

    /**
     * Gets the address proof type.
     *
     * @return the address proof type
     */
    public String getAddressProofType() {

        return addressProofType;
    }

    /**
     * Sets the address proof type.
     *
     * @param addressProofType the new address proof type
     */
    public void setAddressProofType(String addressProofType) {

        this.addressProofType = addressProofType;
    }

}
