package com.citi.cards.acquisition.controller;

import static org.junit.Assert.*;

import javax.xml.datatype.DatatypeConfigurationException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.citi.cards.acquisition.model.shared.system.header.ClientDetails;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.model.vo.CardApplicationAddRqVO;
import com.citi.cards.acquisition.request.GeneralHeader;
import com.citi.cards.acquisition.request.GeneralRequest;
import com.citi.cards.acquisition.response.generics.CRUDErrorResponse;
import com.citi.cards.acquisition.service.CardApplicationService;


public class CardApplicationControllerTest {

    CardApplicationAddController obj;
    GeneralRequest<CardApplicationAddRqVO> req;
    GeneralHeader header;
    
    @Before
    public void setUp() throws Exception {
        
        obj = new CardApplicationAddController();
        header = new GeneralHeader();
        req = new GeneralRequest<>();
        header.setClientDetails(new ClientDetails());
        req.setHeader(header);
        req.setBody(new CardApplicationAddRqVO());
        
        
        CardApplicationService service = Mockito.mock(CardApplicationService.class,Mockito.RETURNS_MOCKS);
        Mockito.when(service.execute(null, null)).thenReturn(new CRUDErrorResponse());
        
        obj.setService(service);

    }

    @Test
    public void testExecute() {

        try {
            assertNotNull(obj.execute(req));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
