package com.citi.cards.acquisition.exception;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class CreditCardOpenningExceptionFactoryTest {


    @Test(expected=WSClientException.class)
    public void testThrowWSClientExceptionAppExceptionCodeEnumString() {

        throw CreditCardOpenningExceptionFactory.throwWSClientException(AppExceptionCodeEnum.FAULT_CLIENT_WS_EXCEPTION, "Cause");
        
    }

    @Test(expected=WSClientException.class)
    public void testThrowWSClientExceptionAppExceptionCodeEnum() {

        throw CreditCardOpenningExceptionFactory.throwWSClientException(AppExceptionCodeEnum.FAULT_CLIENT_WS_EXCEPTION);
    }

    @Test(expected=WSClientException.class)
    public void testThrowWSClientExceptionIntStringString() {

        throw CreditCardOpenningExceptionFactory.throwWSClientException(500, "message", "cause");
    }

}
