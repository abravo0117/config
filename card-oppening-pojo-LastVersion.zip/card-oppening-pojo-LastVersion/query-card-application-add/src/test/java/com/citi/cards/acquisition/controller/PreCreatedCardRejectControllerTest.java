/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: PreCreatedCardRejectControllerTest.java
 * Original Author: Softtek - LAAR
 * Creation Date: 22/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.controller;

import static org.junit.Assert.assertNotNull;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardRejectUpdRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardRejectUpdRs;
import com.citi.cards.acquisition.model.shared.system.header.ClientDetails;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.request.GeneralHeader;
import com.citi.cards.acquisition.request.GeneralRequest;
import com.citi.cards.acquisition.response.generics.AbstractBaseCrudResponse;
import com.citi.cards.acquisition.response.generics.CRUDResponse;
import com.citi.cards.acquisition.service.PreCreatedCardRejectService;

/**
 * <code>PreCreatedCardRejectControllerTest</code>.
 *
 * @author luisa.acosta
 * @version 1.0
 */
public class PreCreatedCardRejectControllerTest {

    /** pre created card reject controller. */
    PreCreatedCardRejectController preCreatedCardRejectController =
        new PreCreatedCardRejectController();

    /** service. */
    private PreCreatedCardRejectService service =
        Mockito.mock(PreCreatedCardRejectService.class, Mockito.RETURNS_MOCKS);

    private PreCreatedCardRejectUpdRq request = new PreCreatedCardRejectUpdRq();

    /** general request. */
    GeneralRequest<PreCreatedCardRejectUpdRq> generalRequest =
        new GeneralRequest<PreCreatedCardRejectUpdRq>();

    /** rq header. */
    RqHeader rqHeader = new RqHeader();

    /** g header. */
    GeneralHeader gHeader = new GeneralHeader();

    /**
     * Inits the data.
     */
    @Before
    public void initData() {

        service.setUri("");
        service.setContextPath("");
        service.setAction("");

        preCreatedCardRejectController.setService(service);

        request.setInitiator("100001");
        request.setBranchID("branchID");
        request.setApplicantID("Application");
        request.setReasonCode("Reason Code");
        request.setApplicationStatus("Status");

        gHeader.setClientDetails(new ClientDetails());
        gHeader.setUuid("UUID");
        gHeader.setVersion("Version 1.0");

        generalRequest.setBody(request);
        generalRequest.setHeader(gHeader);

    }

    /**
     * Should verify pre created card reject controller.
     *
     * @throws DatatypeConfigurationException
     *             datatype configuration exception.
     */
    @Test
    public void shouldVerifyPreCreatedCardRejectController()
        throws DatatypeConfigurationException {

        PreCreatedCardRejectUpdRs wsResponseMock = Mockito
            .mock(PreCreatedCardRejectUpdRs.class, Mockito.RETURNS_MOCKS);
        Mockito.when(service.execute(request, rqHeader)).thenReturn(
            new CRUDResponse<PreCreatedCardRejectUpdRs>(wsResponseMock));

        AbstractBaseCrudResponse abstractBaseCrudResponse =
            new AbstractBaseCrudResponse() {

                public HttpStatus getResponseStatus() {

                    return HttpStatus.ACCEPTED;
                }
            };

        Mockito
            .when(service.execute(Mockito.eq(generalRequest.getBody()),
                Mockito.any(RqHeader.class)))
            .thenReturn(abstractBaseCrudResponse);
       
            assertNotNull(
                preCreatedCardRejectController.execute(generalRequest));
    }

}
