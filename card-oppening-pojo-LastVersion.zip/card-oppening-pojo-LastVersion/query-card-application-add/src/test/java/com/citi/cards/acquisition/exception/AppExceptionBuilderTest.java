package com.citi.cards.acquisition.exception;

import org.junit.Test;

public class AppExceptionBuilderTest {

    @Test(expected = AppException.class)
    public void test() {

        throw AppExceptionBuilder.buildException();
    }

    @Test(expected = AppException.class)
    public void test2() {

        throw AppExceptionBuilder
            .buildException(AppExceptionCodeEnum.INPUT_STREAM_IO_EXCEPTION);
    }

    @Test(expected = AppException.class)
    public void test3() {

        throw AppExceptionBuilder.buildException(new RuntimeException());
    }

    @Test(expected = AppException.class)
    public void test4() {

        throw AppExceptionBuilder.buildException(
            AppExceptionCodeEnum.GENERAL_IO_EXCEPTION, new RuntimeException());
    }

}
