package com.citi.cards.acquisition.model.preCreatedCardReject;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardRejectUpdRq;


public class WsPreCreatedCardRejectDataTest {

    WsPreCreatedCardRejectData obj;
    @Before
    public void setUp() throws Exception {

        obj = new WsPreCreatedCardRejectData();
        obj.setData(new PreCreatedCardRejectUpdRq());
    }

    @Test
    public void testGetData() {

        assertNotNull(obj.getData());
    }

}
