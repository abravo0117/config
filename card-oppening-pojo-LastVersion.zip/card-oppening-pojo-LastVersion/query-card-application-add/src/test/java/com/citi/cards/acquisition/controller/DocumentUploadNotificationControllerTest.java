/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: DocumentUploadNotificationControllerTest.java
 * Original Author: Softtek - ABHV
 * Creation Date: 22/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.controller;

import static org.junit.Assert.*;

import javax.xml.datatype.DatatypeConfigurationException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.DocumentUploadNotificationUpdRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.DocumentUploadNotificationUpdRs;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.request.GeneralHeader;
import com.citi.cards.acquisition.request.GeneralRequest;
import com.citi.cards.acquisition.response.generics.AbstractBaseCrudResponse;
import com.citi.cards.acquisition.response.generics.CRUDResponse;
import com.citi.cards.acquisition.service.DocumentUploadNotificationService;

// TODO: Auto-generated Javadoc
/**
 * The Class DocumentUploadNotificationControllerTest.
 */
public class DocumentUploadNotificationControllerTest {

    /** The document upload controller. */
    DocumentUploadNotificationController documentUploadController =
        new DocumentUploadNotificationController();

    /** The request UP. */
    DocumentUploadNotificationUpdRq requestUP =
        new DocumentUploadNotificationUpdRq();

    /** The service mock. */
    DocumentUploadNotificationService serviceMock = Mockito
        .mock(DocumentUploadNotificationService.class, Mockito.RETURNS_MOCKS);

    /**
     * Inits the data.
     */
    @Before
    public void initData() {

        AbstractBaseCrudResponse response =
            new CRUDResponse<DocumentUploadNotificationUpdRs>(
                new DocumentUploadNotificationUpdRs());

        Mockito.when(serviceMock.execute(Mockito.eq(requestUP),
            Mockito.any(RqHeader.class))).thenReturn(response);

        documentUploadController.setService(serviceMock);

    }

    /**
     * Shou id verify document upload.
     *
     * @throws DatatypeConfigurationException
     *             the datatype configuration exception
     */
    @Test
    public void shouIdVerifyDocumentUpload()
        throws DatatypeConfigurationException {

        GeneralRequest<DocumentUploadNotificationUpdRq> rq =
            new GeneralRequest<DocumentUploadNotificationUpdRq>();
        GeneralHeader header = new GeneralHeader();
        rq.setHeader(header);
        rq.setBody(requestUP);

        ResponseEntity<AbstractBaseCrudResponse> res =
            documentUploadController.execute(rq);
        assertNotNull(res);

    }
}
