package com.citi.cards.acquisition.crud.creditCardOppening;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class InfoControllerTest {

    InfoController obj;

    @Before
    public void setUp() throws Exception {

        obj = new InfoController();
    }

    @Test
    public void test() {

        assertNotNull(obj.AppInfo());
    }

}
