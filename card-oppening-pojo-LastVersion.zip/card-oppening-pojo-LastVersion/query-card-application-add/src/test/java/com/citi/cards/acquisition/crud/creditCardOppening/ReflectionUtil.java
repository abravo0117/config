package com.citi.cards.acquisition.crud.creditCardOppening;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

import org.apache.commons.lang.ClassUtils;
import org.apache.log4j.Logger;

@SuppressWarnings("rawtypes")
public final class ReflectionUtil {

    private static final Logger LOGGER = Logger.getLogger(ReflectionUtil.class);

    private ReflectionUtil() {

    }

    private static Object buildDefaultObjectWrapper(Class clazz)
        throws InstantiationException,
        IllegalAccessException,
        IllegalArgumentException,
        InvocationTargetException {

        Object obj = null;

        Constructor[] constructors = clazz.getConstructors();
        LOGGER.info("Wrapper constructors -> " + constructors.length);
        for (Constructor constructor : constructors) {
            if(obj!=null )
            {
                break;
            }
            LOGGER.info("Constructor : " + constructor.getName()
                + " ( Parameters" + constructor.getParameterCount() + " ) ");
            Parameter[] parameters = constructor.getParameters();
            for (Parameter parameter : parameters) {

                if (parameter.getType().getCanonicalName()
                    .split("\\.").length <= 0
                    || !parameter.getType().getCanonicalName()
                        .contains("String")) {
                    continue;
                }
                LOGGER.info("Parameter type: "
                    + parameter.getType().getCanonicalName());

                obj = constructor.newInstance("1");
                if (obj != null) {
                    break;
                }
            }
        }

        return obj;
    }

    private static Object buildDefaultPrimitive(Class clazz)
        throws InstantiationException,
        IllegalAccessException,
        NoSuchMethodException,
        SecurityException,
        IllegalArgumentException,
        InvocationTargetException,
        ClassNotFoundException {

        Object obj = null;
        Class wrapper = ClassUtils.primitiveToWrapper(clazz);
        obj = buildDefaultObjectWrapper(wrapper);
        return obj;
    }

    public static Object buildDefaultObj(String className)
        throws NoSuchMethodException,
        SecurityException,
        InstantiationException,
        IllegalAccessException,
        IllegalArgumentException,
        InvocationTargetException,
        ClassNotFoundException {

        LOGGER.info(className);
        Object obj = null;
        Class<?> clazz = Class.forName(className);
        Constructor[] constructors = clazz.getDeclaredConstructors();
        LOGGER.info("Constructors - > " + constructors.length);
        for (Constructor constructor : constructors) {
            if (constructor.getParameterCount() != 0) {
                continue;
            }
            LOGGER.info("Constructor: " + constructor.getName());
            obj = constructor.newInstance();
            if (obj != null) {
                break;
            }
        }

        return obj;
    }

    public static Object useSetters(Object obj, Class clazz)
        throws NoSuchMethodException,
        SecurityException,
        InstantiationException,
        IllegalAccessException,
        IllegalArgumentException,
        InvocationTargetException,
        ClassNotFoundException {

        Method[] methods = obj.getClass().getMethods();
        LOGGER.info("Methods -> " + methods.length);
        for (Method method : methods) {
            if (method.getName().startsWith("set")) {
                LOGGER.info("Method -> " + method.getName());
                Class<?>[] parameters = method.getParameterTypes();
                Object[] arguments = new Object[parameters.length];
                int i = 0;
                for (Class clazzIterator : parameters) {
                    LOGGER.info(method.getName() + " "
                        + clazzIterator.getCanonicalName());

                    arguments[i++] = clazzIterator.isPrimitive()
                        ? buildDefaultPrimitive(clazzIterator)
                        : buildDefaultObj(clazzIterator.getCanonicalName());
                }
                LOGGER.info(arguments.length);
                LOGGER.info(
                    "Are nulls? " + (obj == null) + " - " + arguments.length);
                method.invoke(obj, arguments);
            }
        }
        return obj;
    }

    public static void useGetterMethods(Object obj)
        throws IllegalAccessException,
        IllegalArgumentException,
        InvocationTargetException {

        Method[] methods = obj.getClass().getMethods();
        for (Method method : methods) {
            if (method.getName().startsWith("is")
                || method.getName().startsWith("get")) {
                if (method.getParameterCount() > 0) {
                    continue;
                }
                LOGGER.info("Method -> " + method.getName());
                method.invoke(obj);
            }
        }
    }

}
