/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: ApplicationFullDetailsControllerTest.java
 * Original Author: Softtek-ANBV
 * Creation Date: 12/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.controller;

import static org.junit.Assert.assertNotNull;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.ApplicationFullDetailsInqRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.ApplicationFullDetailsInqRs;
import com.citi.cards.acquisition.model.shared.system.header.ClientDetails;
import com.citi.cards.acquisition.model.shared.system.header.RqHeader;
import com.citi.cards.acquisition.request.GeneralHeader;
import com.citi.cards.acquisition.request.GeneralRequest;
import com.citi.cards.acquisition.response.generics.AbstractBaseCrudResponse;
import com.citi.cards.acquisition.response.generics.CRUDResponse;
import com.citi.cards.acquisition.service.ApplicationFullDetailsService;

/**
 *  <code>ApplicationFullDetailsControllerTest</code>.
 *
 * @author antonio.bravo
 * @version 1.0
 */
public class ApplicationFullDetailsControllerTest {
	
	private static final Logger log = Logger.getLogger(ApplicationFullDetailsControllerTest.class);
	
	/** application full details controller. */
	ApplicationFullDetailsController applicationFullDetailsController = new ApplicationFullDetailsController();

	/** service. */
	private ApplicationFullDetailsService service = Mockito.mock(ApplicationFullDetailsService.class, Mockito.RETURNS_MOCKS);
	
	/** application full details inq rq. */
	private ApplicationFullDetailsInqRq applicationFullDetailsInqRq = new ApplicationFullDetailsInqRq();

	/**
	 * Inits the data.
	 */
	@Before
	public void InitData() {
		service.setUri("http://127.0.0.1:8080/MockWS");
		service.setAction("/SvcImpl/common/MX/application/v3_2_MX_15/SOAPEndpoint/ApplicationService.serviceagent/OpEndpointHTTP/ApplicationFullDetailsInq");
		service.setContextPath("com.citi.cards.acquisition.model.applicationFullDetails");
		
		applicationFullDetailsController.setService(service);

		applicationFullDetailsInqRq.setApplicationID("ApplicationId");
		applicationFullDetailsInqRq.setBranchID("BranchId");
		applicationFullDetailsInqRq.setInitiator("initiator");
		applicationFullDetailsInqRq.setUserID("UserId");

	}

	/**
	 * Should verify application full details controller.
	 */
	@Test
	public void ShouldVerifyApplicationFullDetailsController() {
		ApplicationFullDetailsInqRs wsResMock = Mockito.mock(ApplicationFullDetailsInqRs.class,Mockito.RETURNS_MOCKS);
		Mockito.when(service.execute (applicationFullDetailsInqRq, new RqHeader ())).thenReturn(new CRUDResponse<ApplicationFullDetailsInqRs>(wsResMock));
		GeneralRequest<ApplicationFullDetailsInqRq> request = new GeneralRequest<> ();
		request.setBody(new ApplicationFullDetailsInqRq ());
		GeneralHeader header = new GeneralHeader ();
		header.setClientDetails(new ClientDetails ());
		header.setUuid("");
		header.setVersion("");
		
		request.setHeader(header);
		
		AbstractBaseCrudResponse abstractBaseCrudResponse = new AbstractBaseCrudResponse () {
			public HttpStatus getResponseStatus() {

		        return HttpStatus.ACCEPTED;
		    }
		};
		
		Mockito.when(service.execute(Mockito.eq(request.getBody()), Mockito.any(RqHeader.class))).thenReturn(abstractBaseCrudResponse);
		try {
		assertNotNull (applicationFullDetailsController.execute(request));
		}catch (Exception e) {
			log.error(e);
		}
		
	}

}
