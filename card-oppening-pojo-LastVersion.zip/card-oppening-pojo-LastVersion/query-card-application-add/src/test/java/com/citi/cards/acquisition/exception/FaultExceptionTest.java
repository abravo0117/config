package com.citi.cards.acquisition.exception;

import static org.junit.Assert.*;

import java.lang.reflect.InvocationTargetException;

import org.junit.Before;
import org.junit.Test;

import com.citi.cards.acquisition.crud.creditCardOppening.ReflectionUtil;;

public class FaultExceptionTest {

    FaultException obj;
    
    @Before
    public void setUp() throws Exception {

        obj = new FaultException(AppExceptionCodeEnum.FAULT_CLIENT_WS_EXCEPTION, new RuntimeException(), "Info");
    }
    
    @Test
    public void build() throws Exception {

        obj = new FaultException(AppExceptionCodeEnum.FAULT_CLIENT_WS_EXCEPTION, new RuntimeException());
    }
    
    @Test
    public void build2() throws Exception {

        obj = new FaultException("","");
    }

    @Test
    public void testGetters() {

        try {
            ReflectionUtil.useGetterMethods(obj);
        } catch (IllegalAccessException | IllegalArgumentException
            | InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
    
    @Test
    public void testSetters()
    {
        try {
            obj = (FaultException)ReflectionUtil.useSetters(obj, obj.getClass());
        } catch (NoSuchMethodException | SecurityException
            | InstantiationException | IllegalAccessException
            | IllegalArgumentException | InvocationTargetException
            | ClassNotFoundException e) {
            // TODO Auto-generated catch block
        }
    }

}
