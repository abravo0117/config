/* ----------------------------------------------------------------------------
 * All rights reserved © 2017 Citi Banamex.
 *  
 * This software contains information that is exclusive property of Citi
 * Banamex, this information is considered confidential.
 * It is strictly forbidden the copy or spreading of any part of this document 
 * in any format, whether mechanic or electronic.
 * ---------------------------------------------------------------------------
 * File name: PreCreatedCardAcceptControllerTest.java
 * Original Author: Softtek - AGLV
 * Creation Date: 22/06/2017
 * ---------------------------------------------------------------------------
 */
package com.citi.cards.acquisition.controller;

import static org.junit.Assert.assertNotNull;

import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardAcceptUpdRq;
import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.PreCreatedCardAcceptUpdRs;
import com.citi.cards.acquisition.model.shared.system.header.ClientDetails;
import com.citi.cards.acquisition.request.GeneralHeader;
import com.citi.cards.acquisition.request.GeneralRequest;
import com.citi.cards.acquisition.response.generics.AbstractBaseCrudResponse;
import com.citi.cards.acquisition.response.generics.CRUDResponse;
import com.citi.cards.acquisition.service.PreCreatedCardAcceptService;

/**
 * The Class PreCreatedCardAcceptControllerTest.
 */
public class PreCreatedCardAcceptControllerTest {
    
    /** The controller. */
    PreCreatedCardAcceptController controller = new PreCreatedCardAcceptController();
    
    /** The service. */
    PreCreatedCardAcceptService service;
    
    /** The response. */
    AbstractBaseCrudResponse response;
    
    GeneralRequest<PreCreatedCardAcceptUpdRq> generalReq = new GeneralRequest<PreCreatedCardAcceptUpdRq>();
    
    /** The Constant LOG. */
    private static final Logger LOG =
        Logger.getLogger(PreCreatedCardAcceptService.class);
    
    /**
     * Inits the data.
     */
    @Before
    public void initData(){
        MockitoAnnotations.initMocks(this);
        
        PreCreatedCardAcceptUpdRq request = new PreCreatedCardAcceptUpdRq();
        
        request.setApplicantID("1");
        request.setBranchID("1");
        request.setCounterOfferProductType("2");
        request.setInitiator("1");
        request.setOrgCode("123");
        request.setPlasticID("2345678");
        request.setPreCreatedCardNo("1");
        request.setProductLogo("Banamex");
        request.setSourceCode("Code");
        
        GeneralHeader gh = new GeneralHeader();
        gh.setClientDetails(new ClientDetails());
        gh.setUuid("uui");
        gh.setVersion("1.0");
        
        generalReq.setBody(request);
        generalReq.setHeader(gh);
        
        service = Mockito.mock(PreCreatedCardAcceptService.class, Mockito.RETURNS_MOCKS);
        controller.setService(service);
        
        Mockito.when(service.execute(Mockito.eq(request), Mockito.any())).thenReturn(new CRUDResponse<PreCreatedCardAcceptUpdRs>(new PreCreatedCardAcceptUpdRs()));
    }
    
    /**
     * Should verify pre created accept controller.
     */
    @Test
    public void shouldVerifyPreCreatedAcceptController(){
        ResponseEntity<AbstractBaseCrudResponse> resp;
        try {
            resp = controller.execute(generalReq);
            assertNotNull(resp); 
        } catch (DatatypeConfigurationException e) {
            LOG.info(e);
        }
        
    }
}
