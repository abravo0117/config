package com.citi.cards.acquisition.model.documentUploadNotification;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.citi.cards.acquisition.model.services.common.mx.application.v3_2_mx_15.DocumentUploadNotificationUpdRq;

public class DocumentUploadNotificationWSDataTest {

    DocumentUploadNotificationWSData obj;

    @Before
    public void setUp() throws Exception {

        obj = new DocumentUploadNotificationWSData();
        obj.setData(new DocumentUploadNotificationUpdRq());
    }

    @Test
    public void testGetData() {

        assertNotNull(obj.getData());
    }

}
