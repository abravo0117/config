package com.citi.cards.acquisition.model.vo;

import static org.junit.Assert.*;

import java.lang.reflect.InvocationTargetException;

import org.junit.Before;
import org.junit.Test;

import com.citi.cards.acquisition.ms.testProject.victor.ReflectionUtil;


public class CreditsAndLiabilitiesReferenceDetailsVOTest {


CreditsAndLiabilitiesReferenceDetailsVO obj;
    
    @Before
    public void setUp() throws Exception {

        obj = new CreditsAndLiabilitiesReferenceDetailsVO();
        
    }

    @Test
    public void testGetters() {

        try {
            ReflectionUtil.useGetterMethods(obj);
        } catch (IllegalAccessException | IllegalArgumentException
            | InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    @Test
    public void testSetters()
    {
        try {
            obj = (CreditsAndLiabilitiesReferenceDetailsVO)ReflectionUtil.useSetters(obj, obj.getClass());
        } catch (NoSuchMethodException | SecurityException
            | InstantiationException | IllegalAccessException
            | IllegalArgumentException | InvocationTargetException
            | ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
