package com.citi.cards.acquisition.response;

import static org.junit.Assert.*;

import java.lang.reflect.InvocationTargetException;

import org.junit.Before;
import org.junit.Test;

import com.citi.cards.acquisition.ms.testProject.victor.ReflectionUtil;


public class CardApplicationMSResponseTest {
    
    CardApplicationMSResponse obj;

    @Before
    public void setUp() throws Exception {
        
        obj = new CardApplicationMSResponse();

    }

    @Test
    public void testGetters() {

        try {
            ReflectionUtil.useGetterMethods(obj);
        } catch (IllegalAccessException | IllegalArgumentException
            | InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            fail(e.getMessage());
        }
    }
    
    @Test
    public void testSetters()
    {
        try {
            obj = (CardApplicationMSResponse)ReflectionUtil.useSetters(obj, obj.getClass());
        } catch (NoSuchMethodException | SecurityException
            | InstantiationException | IllegalAccessException
            | IllegalArgumentException | InvocationTargetException
            | ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            fail(e.getMessage());
        }
    }

}
