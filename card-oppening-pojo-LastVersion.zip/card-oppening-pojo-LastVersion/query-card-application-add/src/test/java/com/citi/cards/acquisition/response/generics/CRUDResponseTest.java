package com.citi.cards.acquisition.response.generics;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class CRUDResponseTest {

    CRUDResponse<Object> obj;
    
    @Before
    public void setUp() throws Exception {
        obj = new CRUDResponse<>(new Object());
    }

    @Test
    public void testCRUDResponse() {

        obj = new CRUDResponse<>(new Object());
    }

    @Test
    public void testGetData() {

        assertNotNull(obj.getData());
    }

}
