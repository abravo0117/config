package com.citi.cards.acquisition.response.generics;

import static org.junit.Assert.*;

import java.lang.reflect.InvocationTargetException;

import org.junit.Before;
import org.junit.Test;

import com.citi.cards.acquisition.crud.creditCardOppening.ReflectionUtil;
import com.citi.cards.acquisition.exception.AppException;
import com.citi.cards.acquisition.exception.AppExceptionCodeEnum;
import com.citi.cards.acquisition.exception.FaultException;
import com.citi.cards.acquisition.exception.WSClientException;


public class CRUDErrorResponseTest {

    CRUDErrorResponse obj;
    
    @Before
    public void setUp() throws Exception {
        obj = new CRUDErrorResponse();
    }
    
    @Test
    public void testConstructor()
    {
        obj = new CRUDErrorResponse(new FaultException(AppExceptionCodeEnum.FAULT_CLIENT_WS_EXCEPTION, new RuntimeException()));
    }
    
    @Test
    public void testConstructor2()
    {
        obj = new CRUDErrorResponse(new WSClientException(AppExceptionCodeEnum.FAULT_CLIENT_WS_EXCEPTION));
    }
    @Test
    public void testConstructor3()
    {
        obj = new CRUDErrorResponse(new AppException());
    }

    @Test
    public void testGetters() {

        try {
            ReflectionUtil.useGetterMethods(obj);
        } catch (IllegalAccessException | IllegalArgumentException
            | InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    @Test
    public void testSetters()
    {
        try {
            obj = (CRUDErrorResponse)ReflectionUtil.useSetters(obj, obj.getClass());
        } catch (NoSuchMethodException | SecurityException
            | InstantiationException | IllegalAccessException
            | IllegalArgumentException | InvocationTargetException
            | ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
