package com.citi.cards.acquisition.exception;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class WSClientExceptionTest {

    WSClientException obj;

    @Before
    public void setUp() throws Exception {

        obj = new WSClientException(
            AppExceptionCodeEnum.FAULT_CLIENT_WS_EXCEPTION);
    }

    @Test
    public void testWSClientExceptionIntStringString() {

        obj = new WSClientException(404, "description", "cause");
    }

    @Test
    public void testWSClientExceptionAppExceptionCodeEnum() {

        obj = new WSClientException(AppExceptionCodeEnum.FAULT_CLIENT_WS_EXCEPTION);
    }

    @Test
    public void testGetExCause() {

        assertNotNull(obj.getExCause());
    }

}
