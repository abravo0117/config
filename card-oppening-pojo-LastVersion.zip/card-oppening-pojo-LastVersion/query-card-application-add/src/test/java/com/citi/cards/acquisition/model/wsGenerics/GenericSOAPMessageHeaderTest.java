package com.citi.cards.acquisition.model.wsGenerics;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.citi.cards.acquisition.model.shared.system.header.RqHeader;


public class GenericSOAPMessageHeaderTest {

    GenericSOAPMessageHeader obj;
    
    @Before
    public void setUp() throws Exception {

        obj = new GenericSOAPMessageHeader();
        obj.setHeader(new RqHeader());
    }

    @Test
    public void testGetHeader() {

        assertNotNull(obj.getHeader());
    }

}
