package com.citi.cards.acquisition.model.preCreatedCardAccept;

import static org.junit.Assert.*;

import java.lang.reflect.InvocationTargetException;

import org.junit.Before;
import org.junit.Test;

import com.citi.cards.acquisition.ms.testProject.victor.ReflectionUtil;


public class WsPreCreatedCardAcceptReqTest {
    
    WsPreCreatedCardAcceptReq obj;

    @Before
    public void setUp() throws Exception {
        
        obj = new WsPreCreatedCardAcceptReq();

    }

    @Test
    public void testGetters() {

        try {
            ReflectionUtil.useGetterMethods(obj);
        } catch (IllegalAccessException | IllegalArgumentException
            | InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    @Test
    public void testSetters(){
        try {
            obj = (WsPreCreatedCardAcceptReq)ReflectionUtil.useSetters(obj, obj.getClass());
        } catch (NoSuchMethodException | SecurityException
            | InstantiationException | IllegalAccessException
            | IllegalArgumentException | InvocationTargetException
            | ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
